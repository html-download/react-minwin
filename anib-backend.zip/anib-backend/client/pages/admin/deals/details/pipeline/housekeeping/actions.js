'use strict';
const Store = require('./store');
const Constant =  require('./constants');
const ApiActions = require('../../../../../../actions/api');

class Actions {
    
    static toggleQuote() {
            
        Store.dispatch({
            type : Constant.TOGGLE_QUOTE
        });
    }

    static updateVerificationState(status,index) {

        Store.dispatch({
            type : Constant.UPDATE_VERIFICATION_STATUS,
            status: status,
            index: index
        });
    }

    static getDealQuote(id) {

        if (id) {
            this.getPolicyDetails(id);
            this.getQuoteVerification(id);        
            ApiActions.get(
                `/deal-quote/${id}`,
                undefined,
                Store,
                Constant.GET_DEAL_QUOTE_DETAILS,
                Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE
            );
        }
    }


    static getPolicyDetails(id) {
                
        ApiActions.get(
            `/policy/${id}`,
            undefined,
            Store,
            Constant.GET_POLICY_DETAILS,
            Constant.GET_POLICY_DETAILS_RESPONSE
        );
    }

    static getProduct() {

        ApiActions.get(
            '/underwriters',
            undefined,
            Store,
            Constant.GET_PRODUCT_DETAILS,
            Constant.GET_PRODUCT_DETAILS_RESPONSE
        );
    }


    static getQuoteVerification(id) {

        ApiActions.get(
            `/quote-verification?deal_quote_id=${id}`,
            undefined,
            Store,
            Constant.GET_QUOTE_VERIFICATION_DETAILS,
            Constant.GET_QUOTE_VERIFICATION_DETAILS_RESPONSE
        );
    }
    
    static saveQuoteDetails(data) {
        
        ApiActions.post(
            `/deal-quote`,
            data,
            Store,
            Constant.SAVE_QUOTE_DETAILS,
            Constant.SAVE_QUOTE_DETAILS_RESPONSE
        );
    }

    static updateQuoteDetails(id, data, toggle, updateOrderId) {
        
        updateOrderId(false);

        ApiActions.put(
            `/deal-quote/${id}`,
            data,
            Store,
            Constant.UPDATE_QUOTE_DETAILS,
            Constant.UPDATE_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(5);
                    }
                }
                toggle(5 , false, id);
            }
        );
    }

    static openPolicyModal() {

        Store.dispatch({
            type : Constant.OPEN_POLICY_MODAL
        });
    }
    static hideViewModal() {

        Store.dispatch({
            type : Constant.HIDE_POLICY_MODAL
        });
    }

    static completeDeal(data, toggle, updateOrderId) {

        ApiActions.post(
            '/deal/complete',
            data,
            Store,
            Constant.COMPLETE_DEAL_DETAILS,
            Constant.COMPLETE_DEAL_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(5);
                    }
                }
            }
        );
    }
}

module.exports = Actions;