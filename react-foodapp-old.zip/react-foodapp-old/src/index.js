import ReactDOM from 'react-dom';
import AppUniversal from  './appuniversal';

ReactDOM.render(AppUniversal, document.getElementById('app'));