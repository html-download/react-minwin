/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AddressType', {
    typeId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'type_id'
    },
    typeName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'type_name'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      field: 'trash'
    }
  }, {
    tableName: 'ss16_address_type'
  });
};
