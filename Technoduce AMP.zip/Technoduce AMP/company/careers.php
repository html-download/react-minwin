<?php include ('../inc/header.php'); ?>

<section class="page_banner">
  <div class="container">
    <h1 class="animated fadeInDown">Jobs @ Technoduce</h1>
    <p class="desc animated fadeInUp mb0">Provide your details, and we present you the right opportunity.<br>Submit your resume with us along with a cover letter to <b>jobs@technoduce.com</b></p>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="careers grey full_row">
  <div class="container md">
    <h2 class="head style1 text-center">current job openings</h2>
    
    <amp-accordion animate>
    <section>
      <header class="heading">
        <i class="icon react"></i>
        <h2>React JS Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>0 - 2 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>5 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Strong proficiency in JavaScript, including DOM manipulation and the JavaScript object model.</li>
            <li>Thorough understanding of React.js and its core principles.</li>
            <li>Experience with popular React.js workflows (such as Flux or Redux).</li>
            <li>Familiarity with newer specifications of EcmaScript.</li>
            <li>Experience with data structure libraries (e.g., Immutable.js).</li>
            <li>Knowledge of isomorphic React is a plus.</li>
            <li>Familiarity with RESTful APIs.</li>
            <li>Knowledge of modern authorization mechanisms, such as JSON Web Token.</li>
            <li>Familiarity with modern front-end build pipelines and tools.</li>
            <li>Experience with common front-end development tools such as Babel, Webpack, NPM, etc.</li>
            <li>Familiarity with code versioning tools such as Git, SVN, and Mercurial.</li>
            <li>Make sure to mention any other framework, libraries, or other technology relevant to your project.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon angular"></i>
        <h2>Angular JS Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>0 - 2 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>5 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Develop User interfaces for Modern Rich Internet Applications with the latest Front End Technologies.</li>
            <li>Perform product analysis and development tasks of increasingly complex nature which may require extensive research and analysis.</li>
            <li>Writing tested and documented JavaScript, HTML and CSS.</li>
            <li>Make design and technical decisions for AngularJS projects.</li>
            <li>Develop application code and unit test in the AngularJS, Rest Web Services and Java technologies for the Application Development Center.</li>
            <li>Strong expertise with HTML, CSS, and writing cross-browser compatible code.</li>
            <li>Good understanding of AJAX and JavaScript Dom manipulation Techniques.</li>
            <li>Experience with RESTful services.</li>
            <li>Experience in JavaScript build tools like grunt or gulp.</li>
            <li>Expert in any one of the modern JavaScript MV-VM/MVC frameworks (AngularJS, JQuery, NodeJS, GruntJS).</li>
            <li>Hand on and implements complex AngularJS applications, directives, controllers, services.</li>
            <li>Critical thinker and problem-solving skills.</li>
            <li>Good time-management skills.</li>
            <li>Great interpersonal and communication skills.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon node"></i>
        <h2>Node JS Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>0 - 2 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>5 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Strong proficiency with JavaScript or CoffeeScript depending on your technology stack.</li>
            <li>Knowledge of Node.js and frameworks available for it such as Express, StrongLoop, etc depending on your technology stack.</li>
            <li>Understanding the nature of asynchronous programming and its quirks and workarounds.</li>
            <li>Integration of multiple data sources and databases into one system.</li>
            <li>Good understanding of server-side CSS preprocessors such as Stylus, Less, etc depending on your technology stack.</li>
            <li>Basic understanding of front-end technologies, such as HTML5, and CSS3.</li>
            <li>Understanding accessibility and security compliance Depending on the specific project.</li>
            <li>User authentication and authorization between multiple systems, servers, and environments.</li>
            <li>Integration of multiple data sources and databases into one system.</li>
            <li>Understanding fundamental design principles behind a scalable application.</li>
            <li>Understanding differences between multiple delivery platforms, such as mobile vs. desktop, and optimizing output to match the specific platform.</li>
            <li>Creating database schemas that represent and support business processes.</li>
            <li>Good understanding of server-side templating languages such as Jade, EJS, etc depending on your technology stack.</li>
            <li>Implementing automated testing platforms and unit tests.</li>
            <li>Proficient understanding of code versioning tools, such as Git.</li>
            <li>Make sure to mention other frameworks, libraries, or any other technology related to your development stack.</li>            
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon digital"></i>
        <h2>Digital Marketing Manager</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>3 - 5 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>3 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Experience in Search Engine Optimization (SEO), Search Engine Marketing (SEM) and Social media marketing (SMM).</li>
            <li>Expertise in Event tracking, Schema creation, Analytics goal settings.</li>
            <li>Generating leads targeting globally and maintaining report monthly basis.</li>
            <li>Experience with A/B testing and other testing metrics.</li>
            <li>Develop a strategy for the improvement of organic search ranking and the maximization of ROI.</li>
            <li>Experience working with popular keyword tools (Google, WordTracker, Keyword Discovery, etc).</li>
            <li>Should have worked with CMS and building/administering content in multiple CMS environments.</li>
            <li>Knowledge of HTML/CSS and website administration.</li>
            <li>Experience with website analysis using a variety of analytics tools including Google Analytics and webmaster tools.</li>
            <li>Knowledge of PPC programs and optimizing data gathered from both organic and paid sources.</li>
            <li>Must be skilled in competitor analysis.</li>
            <li>High-level proficiency in MS Excel, PowerPoint, and Word.</li>
            <li>Manage relationships with web developers and marketing teams to properly implement SEO.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon writer"></i>
        <h2>Technical Content Writer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>1 - 3 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>1</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <p>Technical Content Writer with strong copywriting and skills to research, develop and maintain high-quality website content. Must have good communication skill.</p>
          <p class="mb10"><b>Content for</b></p>

          <ul class="reset">
            <li>Website content</li>
            <li>Blogs &amp; Articles</li>
            <li>Technical content (Products, Latest technology based)</li>
            <li>Press release / Newsletters</li>
            <li>PDF content</li>
            <li>Email marketing</li>
            <li>Presentation</li>
            <li>Whitepaper</li>
            <li>Case study</li>
            <li>Brochure</li>
            <li>Much more </li>            
          </ul>

          <p class="style1">Research product lines thoroughly and becomes a product expert.</p>
          <p class="style1">Write concise, easy-to-read copy (copywriter) for website product descriptions.</p>
          <p class="style1">Ensure that existing product lines are up-to-date and content is accurate.</p>
          <p class="style1">Work closely with other teams to ensure that all content is updated (descriptions, questions, articles) is consistent.</p>

          <a on="tap:careers" class="btn mt10">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon php"></i>
        <h2>PHP Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>1 - 5 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>5 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Candidate should have excellent communication skill.</li>
            <li>Object-oriented programming in PHP.</li>
            <li>Front-end technologies such as JavaScript, HTML, and CSS.</li>
            <li>Complex SQL queries and database schema design.</li>
            <li>MVC frameworks (Laravel, Yii2, Any Framework).</li>
            <li>Working in a collaborative team environment using tools like JIRA and Git.</li>
            <li>Consuming and creating web services.</li>
            <li>Stable work history and an ability to collaborate effectively.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon apple"></i>
        <h2>IOS Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>1 - 3 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>3 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Design and build advanced applications for the iOS platform.</li>
            <li>Collaborate with cross-functional teams to define, design, and ship new features.</li>
            <li>Work on bug fixing and improving application performance.</li>
            <li>Continuously discover, evaluate, and implement new technologies to maximize development efficiency.</li>
            <li>Build and publish applications in app stores.</li>
            <li>Proficient with Objective-C or Swift.</li>
            <li>Experience with iOS frameworks such as Core Data, Core Animation, etc.</li>
            <li>Experience with offline storage, threading, and performance tuning.</li>
            <li>Familiarity with RESTful APIs to connect iOS applications to back-end services.</li>
            <li>Understanding of Apple’s design principles and interface guidelines.</li>
            <li>Knowledge of low-level C-based libraries is preferred.</li>
            <li>Experience with performance and memory tuning with tools.</li>
            <li>Familiarity with continuous integration.</li>
            <li>Familiarity with cloud message APIs and push notifications.</li>            
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon android"></i>
        <h2>Android Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>2 - 4 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>3 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Understanding of the full mobile development life cycle.</li>
            <li>Strong knowledge of Android UI design principles, patterns, and best practices.</li>
            <li>Familiarity with RESTful APIs to connect Android applications to back-end services</li>
            <li>Experience with third-party libraries and APIs.</li>
            <li>Have published at least one original Android app.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon net"></i>
        <h2>Dot NET Developer</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>2 - 4 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>3 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Working experience in MVC,C#,ASP.Net</li>
            <li>Working experience AJAX Webservices,Jquery/Angular JS</li>
            <li>Working experience in MS SQL - Stored procedure,Trigger, Cursor, Query optimization</li>
            <li>Good in Unit testing</li>
            <li>Possess Analytical and logical thinking.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon business"></i>
        <h2>Business Development Executive Outbound</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>3 - 6 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>3 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Excellent Verbal and Communication skill.</li>
            <li>Research to find the target customers according to the product , service assigned.</li>
            <li>Source &amp; Work directly with customers via telephone, and email to describe products, services in order to persuade potential and current customers to purchase new products, services&nbsp;</li>
            <li>Educate customers on product and services to improve their "on-line presence" and explain pricing and answer questions from customers building value in the customer relationship.&nbsp;</li>
            <li>Follows up with a&nbsp;customer via Skype, phone, or email following initial sales contact.&nbsp;</li>
            <li>Identifies customer issues and provides appropriate solutions via up sell of additional products and or services and obtain customer commitment and facilitates</li>
            <li>Maintains an&nbsp;accurate daily record of sales pipeline</li>
            <li>Maintain report sheets and update activities on CRM in the&nbsp;daily&nbsp;basis.</li>
            <li>Close sales and achieve quarterly targets.</li>
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>

    <section>
      <header class="heading">
        <i class="icon business"></i>
        <h2>Business Development Executive INBOUND</h2>
        <div class="info">
          <span>Location:<b>Coimbatore</b></span>
          <span>Experience:<b>3 - 5 Years</b></span>
          <span>Salary:<b>Best In The Industry</b></span>
          <span>Openings:<b>2 nos</b></span>
        </div>
      </header> <!--heading-->

      <div>
        <div class="content">
          <h3>Key skills required</h3>
          <ul class="reset">
            <li>Excellent Verbal and Communication skill.</li>
            <li>Excellent Skill set in Technical.</li>
            <li>Experienced in IT-based products and service.</li>
            <li>Source new sales opportunities through inbound live chat, phone call, lead follow-up and outbound cold calls and emails.&nbsp;</li>
            <li>Understand customer needs and document requirements&nbsp;</li>
            <li>Route qualified opportunities to the appropriate sales executives for further development and closure&nbsp;</li>
            <li>Maintain report sheets and update activities on CRM in a&nbsp;daily basis.</li>
            <li>Close sales and achieve quarterly targets&nbsp;</li>
            <li>Research accounts, identify key players and generate interest&nbsp;</li>
            <li>Maintain and expand your database of prospects within your assigned territory Team to build pipeline and close deals&nbsp;</li>
            <li>Perform effective online demos to prospects.</li>            
          </ul>

          <a on="tap:careers" class="btn">Apply for this Job</a>
        </div> <!--content-->
      </div>
    </section>
  </amp-accordion>
  </div> <!--container-->    
</section> <!--careers-->

<section class="half blue">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right">        
        <h2 class="head style1 mb10">Employee Benefits</h2>
        <h3 class="head_desc mb20">How we take care of our employess?</h3>

        <ul class="lists">
          <li><b>Casual Leave</b> - 3 Days per quarter</li>
          <li><b>Leave encashment</b> - End of every quarter</li>
          <li><b>Medical Leave</b> - 8 Days per year</li>
          <li><b>Saturdays</b> - 1, 3, 4, 5 will be Off</li>
          <li><b>Permission</b> - 2 times per month</li>
          <li><b>Birthday</b> - Paid leave</li>
          <li><b>Marriage day</b> - Paid leave</li>
          <li><b>Marriage Leave </b> -  1 week paid leave</li>
          <li><b>Marriage</b> - Compensation amount will be given</li>
          <li><b>Paternity Leave</b> - 1 week paid leave</li>
          <li><b>Baby Birth</b> - Compensation amount will be given </li>
          <li><b>Events</b> will be conducted for festivals</li>
          <li><b>Tour</b> - Yearly once</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<amp-lightbox id="careers" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner sm">
			<div class="dialog_content">
				<a on="tap:careers.close" class="close"><i class="fi close"></i></a>
        <h4><i class="fa fa-file-text-o"></i> Submit your resume <br>with us along with a cover letter to</h4>
        <h5 class="mb0">jobs@technoduce.com</h5>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<?php include ('../inc/footer.php'); ?>