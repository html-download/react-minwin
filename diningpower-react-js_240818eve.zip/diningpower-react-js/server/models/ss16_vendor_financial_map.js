/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorFinancialMap', {
    financialMapid: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'financial_mapid'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    billingContactName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_contact_name'
    },
    billingContactEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_contact_email'
    },
    emailStatement: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'yes',
      field: 'email_statement'
    }
  }, {
    tableName: 'ss16_vendor_financial_map'
  });
};
