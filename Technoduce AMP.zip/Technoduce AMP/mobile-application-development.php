<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/angular-logo.png" alt="AngularJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Top Rated Mobile Application Development Company</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="pt0">
  <div class="container text-center">
    <h2 class="head style1">Mobile application development</h2>
    <p class="md mb0">Technoduce Info Solutions has proven to be an established developer of mobile applications for clients from across the world. The team at Technoduce is skilled with many years of experience in mobile app development, to develop scintillating apps for the end-user. The mobile applications we develop are customized with the most advanced technologies, to serve the individual needs of different classes of customers. Our customer-centric approach accompanied with the fresh-minds of our team deliver cost-effective results for your project.</p>
  </div> <!--container-->
</section>

<section class="products full_row">
  <div class="content_head full_row">
    <div class="container relative">
      <h2 class="head style1">Mobile App Development Services</h2>
      <p class="md mb40">The mobile app development company of Technoduce stresses on maintaining the highest standards of quality for all its projects. We can develop both native and hybrid apps for different mobile platforms to suit your business needs. Our mobile app and design services have served the needs of different clients and boosted their sales massively. In fact, we are the best mobile app development company in the region and a perfect partner for app development outsourcing.</p>
    </div> <!--container-->
  </div> <!--content_head-->

  <div class="container md relative text-left">
    <ul class="boxes reset col3">
      <li>
        <div class="box ios">
            <i class="icon apple"></i>
            <h3>iPhone Application Development</h3>
            <p>Extensive experience with iOS app development services enables us to craft bespoke solutions for large and small enterprises rapidly and efficiently.</p>
            <a href="<?php echo $baseurl;?>iphone-application-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box android">
          <i class="icon android"></i>
          <h3>Android Application Development</h3>
          <p>We offers top-notch, flawless and dynamic Android app development services all around the globe.</p>
          <a href="<?php echo $baseurl;?>android-application-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box react">
          <i class="icon react"></i>
          <h3>React Native Application Development</h3>
          <p>Reliable and scalable react native app development for both Android and iOS platforms in single code base.</p>
          <a href="<?php echo $baseurl;?>react-native-app-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
    </ul> <!--boxes-->

    <h3 class="head style1 text-center">Want dedicated developers for your project?</h3>
    <p class="mb text-center"><a href="<?php echo $baseurl;?>hire-developers" class="btn">Hire our developer</a></p>
  </div> <!--container-->
</section> <!--products-->

<section class="dark">
  <div class="container text-center white">
    <h2 class="head style1">Our mobile app development process flow</h2>
    <p class="md mb40">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit vulputate urna sit amet, consectetur adipiscing elit.</p>
    <amp-img src="https://www.technoduce.com/images/site/inner_flow.png" alt="AngularJS Development" width="917" height="313" style="max-width:917px; margin:0 auto" layout="responsive"></amp-img>
  </div> <!--container-->
</section>

<section class="mobile full_row">
  <div class="container">
    <div class="content">
      <h3 class="head_desc">Mobile Technologies</h3>
      <h2 class="head">Mobile application development tools & technologies</h2>
      <p>Take a look at some of the advanced technological tools that we use to develop productive mobile applications. Our staff 
is well-versed and hold a lot of experience in using these tools.</p>
    
      <a href="<?php echo $baseurl;?>mobile-application-development" class="btn green">Learn More</a>
    </div> <!--content-->
    
    <div class="boxes">
      <div class="box_col">
        <div class="box ios">
          <i class="icon apple"></i>
          <h3>iPhone Application Development</h3>
          <p><b>Tools:</b> Xcode</p>
          <p><b>Technologies:</b> iPhone SDK, Cocoa Touch.</p>
          <p><b>Languages:</b> Objective-C, Swift</p>
        </div> <!--box-->
      </div> <!--box_col-->

      <div class="box_col">
        <div class="box mb30 android">
          <i class="icon android"></i>
          <h3>Android Application Development</h3>
          <p><b>Tools:</b> Android Studio</p>
          <p><b>Technologies:</b> Android SDK</p>
          <p><b>Languages:</b> Java</p>
        </div> <!--box-->
        
        <div class="box react">
          <i class="icon react"></i>
          <h3>React Native Application Development</h3>
          <p><b>Tools:</b> Android Studio, Xcode</p>
          <p><b>Technologies:</b> Android SDK, iPhone SDK</p>
          <p><b>Languages:</b> JavaScript</p>
        </div> <!--box-->
      </div> <!--box_col-->
    </div> <!--boxes-->
  </div> <!--container-->
</section> <!--mobile-->

<section class="section grey text-center portfolio">
	<div class="container wow fadeInUp">
		<h2 class="head style1">Some of our clients</h2>
		<p class="md mb40">Our work speaks a lot about our commitment to performance and quality. Over here, you can take a peek at some of the many successful mobile applications we developed for clients.</p>
		<div class="row">
			<div class="col_3">
				<a href="https://192.168.1.149:444//portfolio/caterninja.html" target="_blank">
					<amp-img src="https://192.168.1.149:444/images/food-dashboard.png" alt="food dashboard" width="987" height="410" layout="responsive"></amp-img>
				</a>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<?php include ('inc/footer.php'); ?>