'use strict';
const Async = require('async');
const Boom = require('boom');
const EscapeRegExp = require('escape-string-regexp');
const Joi = require('joi');
const Config = require('../../config');
//const moment = require('moment');
const moment = require('moment-timezone');

const internals = {};

internals.applyRoutes = function(server, next) {
    const History = server.plugins['hapi-mongo-models'].History;
    const User = server.plugins['hapi-mongo-models'].User;

    server.route({
        method: 'GET',
        path: '/history-test',
        handler: function(request, reply) {

            reply({ message: 'Welcome to the plot device.' });
        }
    });

    server.route({
        method: 'POST',
        path: '/history/lot',
        config: {
            auth: false,
            validate: {
                payload: {
                    username: Joi.string().token().lowercase().required(),
                    email: Joi.string().email().lowercase().required(),
                    password: Joi.string().required()
                }
            },
        },
        handler: function(request, reply) {
            const username = 'username';
            const password = 'password';
            const email = 'email';

            User.create(username, password, email, (err, user) => {

                if (err) {
                    return reply(err);
                }

                reply(user);
            });
        }
    });

    server.route({
        method: 'GET',
        path: '/history/update',
        config: {
            auth: false
        },
        handler: function(request, reply) {
            let conditions = {
                'log.client_name': 'auburn',
                'log.lots': {
                    $elemMatch: {
                        lot_name: 'poultry-front'
                    }
                }
            };
            let elemMatchCondition = {
                'log.lots.$': 1,
                'timeCreated': 1,
                'time': 1,
            }

            /*History.update({
                '_id': "5c1278dde25b9f47f0f1a79f",
                'log.lots': {
                    $elemMatch: {
                        'lot_name': 'poultry-rear'
                    }
                }
            }, {
                $set: {
                    'log.lots.$.lot_name': 'au-poultry-rear'
                }
            }, (err, historys) => {
                console.log("historys", historys);
                console.log("err", err);

            });*/
            /*db.getCollection('history').find({ 'log.client_name': 'auburn', 'log.lots': { $elemMatch: { 'lot_name': 'poultry-rear' } } },{'log.lots.$' : 1})*/

            History.find(conditions, elemMatchCondition, (err, historys) => {
                if (historys.length > 0) {
                    Async.each(historys, function (history, callback1) {

                        let lots = history.log.lots ? history.log.lots : null;
                        Async.each(lots, function (lot, callback2) {
                            if (lot.lot_name === 'poultry-front') {
                                console.log("lot", lot);
                            }
                        }, function(err, result) {
                            if (err) console.log('ERROR:2', err);

                        });
                    }, function(err, result) {
                        if (err) console.log('ERROR:1', err);

                    });
                }

                if (err) {
                    return reply(err);
                }

                reply(historys.length);
            });
        }
    });

    server.route({
        method: 'GET',
        path: '/history',
        config: {
            validate: {
                query: {
                    key: Joi.string().required().label('Api Key'),
                    date: Joi.string().required().label('Date'),
                    days: Joi.any().optional().label('Days'),
                    is_lot: Joi.number().required().label('Is Lot'),
                    client_name: Joi.string().required().label('Client Name'),
                    lot_name: Joi.label('Lot Name').when('is_lot', {
                        is: 0,
                        then: Joi.optional(),
                        otherwise: Joi.string().required()
                    }),
                    zone: Joi.label('Zone Name').when('is_lot', {
                        is: 1,
                        then: Joi.optional(),
                        otherwise: Joi.string().required()
                    })
                }
            },
            pre: [{
                assign: 'user',
                method: function(request, reply) {
                    Async.auto({
                        auth: function(done) {
                            let auth_result = true;
                            if (request.query.key !== Config.get('/historicalApiToken')) {
                                return reply(Boom.badRequest('Invalid authentication key!'));
                            }
                            done(null, auth_result);
                        }
                    }, (err, results) => {
                        if (err) {
                            return reply(err);
                        }

                        return reply(results);
                    });
                }
            }]
        },
        handler: function(request, reply) {
            let result = request.pre;
            let params = request.query;
            let timeArray = ['00:00', '00:30', '01:00', '01:30', '02:00', '02:30', '03:00', '03:30', '04:00', '04:30', '05:00', '05:30', '06:00', '06:30', '07:00', '07:30', '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '12:30', '13:00', '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00', '17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00', '23:30'];

            let timeReturnArray = ['0:30 am', '1:00 am', '1:30 am', '2:00 am', '2:30 am', '3:00 am', '3:30 am', '4:00 am', '4:30 am', '5:00 am', '5:30 am', '6:00 am', '6:30 am', '7:00 am', '7:30 am', '8:00 am', '8:30 am', '9:00 am', '9:30 am', '10:00 am', '10:30 am', '11:00 am', '11:30 am', '12:00 pm', '12:30 pm', '1:00 pm', '1:30 pm', '2:00 pm', '2:30 pm', '3:00 pm', '3:30 pm', '4:00 pm', '4:30 pm', '5:00 pm', '5:30 pm', '6:00 pm', '6:30 pm', '7:00 pm', '7:30 pm', '8:00 pm', '8:30 pm', '9:00 pm', '9:30 pm', '10:00 pm', '10:30 pm', '11:00 pm', '11:30 pm', '12:00 am'];

            let perArray = [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00];

            let timeTempArray = [];
            if (params.date === moment().tz(Config.get('/timeZone')).format('DD-MM-YYYY').toString()) {
                timeArray.forEach(function(timeArrayValue, i) {
                    let check_today_value = timeArrayValue.replace(':', '.');
                    check_today_value = parseFloat(check_today_value).toFixed(2);

                    let today_time_value = moment().tz(Config.get('/timeZone')).format('HH:mm').toString().replace(':', '.');
                    today_time_value = parseFloat(today_time_value).toFixed(2);

                    if (Number(today_time_value) < Number(check_today_value)) {
                        perArray.splice(i)
                        timeReturnArray.splice(i)
                    } else {
                        timeTempArray[i] = timeArrayValue
                    }
                });
            } else {
                timeTempArray = timeArray
            }

            Async.auto({
                get: function(done) {
                    let get_result = null;

                    let conditions = {
                        "timeCreated": {
                            $gte: moment(`${params.date}`, 'DD-MM-YYYY').tz(Config.get('/timeZone')).add(1, "days").startOf('day')._d,
                            $lt: moment(`${params.date}`, 'DD-MM-YYYY').tz(Config.get('/timeZone')).add(1, "days").endOf('day')._d
                        },
                        'log.client_name': params.client_name
                    };
                    let elemMatchCondition = {}

                    if (params.is_lot === 1) {
                        conditions = Object.assign({
                            'log.lots': {
                                $elemMatch: {
                                    lot_name: params.lot_name
                                }
                            }
                        }, conditions);

                        elemMatchCondition = {
                            'log.lots.$': 1,
                            'timeCreated': 1,
                            'time': 1,
                        }
                    }



                    let checkArray = [];
                    let lots;
                    let logs;
                    var created_time
                    let history;
                    let output = {
                        'time': timeReturnArray,
                        'percentage': perArray,
                        'client_name': params.client_name,
                        'lot_name': params.lot_name,
                        'date': params.date,
                        'zone': params.zone
                    };

                    History.find(conditions, elemMatchCondition, (err, historys) => {

                        if (historys.length > 0 && params.is_lot === 1) {
                            Async.each(historys, function(history, callback1) {
                                created_time = history.time;

                                logs = history.log;
                                lots = history.log.lots;

                                Async.each(lots, function(lot, callback2) {
                                    let occupied = 0;
                                    let total = 0;
                                    let percentage = 0;
                                    let color = '';
                                    let isZoneSelected = false;

                                    if (lot.lot_name === params.lot_name) {
                                        Async.map(lot.occupancy, function(zone, next) {
                                            occupied += zone[1];
                                            total += zone[2] - zone[3];
                                            percentage = Math.ceil((occupied / total) * 100);
                                            next();
                                        }, function(err, result) {
                                            if (err) console.log('ERROR:4', err);
                                        });

                                        Async.forEachOf(timeArray, function(time, index, callback3) {
                                            let temp_percentage = 0;

                                            let time_created_time = created_time.replace(':', '.');
                                            time_created_time = parseFloat(time_created_time).toFixed(2);

                                            let time_inner = time.replace(':', '.');
                                            time_inner = parseFloat(time_inner).toFixed(2);

                                            if (index === 47) {
                                                if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(23.59).toFixed(2)) {
                                                    temp_percentage = perArray[index] === 0 ? percentage : ((perArray[index] + percentage) / 2);
                                                    perArray[index] = temp_percentage
                                                }
                                            } else {
                                                let prev_index = timeArray[index + 1].replace(':', '.');
                                                prev_index = parseFloat(prev_index).toFixed(2);

                                                if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(prev_index)) {

                                                    temp_percentage = perArray[index] === 0 ? percentage : ((perArray[index] + percentage) / 2);
                                                    perArray[index] = temp_percentage;
                                                }
                                            }

                                            callback3()
                                        }, function(err, result) {
                                            if (err) console.log('ERROR:3', err);
                                        });
                                    }

                                    callback2()
                                }, function(err, result) {
                                    if (err) console.log('ERROR:2', err);

                                });

                                callback1()
                            }, function(err, result) {
                                if (err) console.log('ERROR:1', err);

                                if (params.date === moment().tz(Config.get('/timeZone')).format('DD-MM-YYYY').toString()) {
                                    if (timeReturnArray.length > 0) {
                                        timeReturnArray.splice(timeReturnArray.length - 1)
                                    }

                                    if (perArray.length > 0) {
                                        perArray.splice(perArray.length - 1)
                                    }
                                }
                                output = {
                                    'time': timeReturnArray,
                                    'percentage': perArray,
                                    'client_name': params.client_name,
                                    'lot_name': params.lot_name,
                                    'date': params.date,
                                    'zone': ''
                                }
                            });

                        } else if (historys.length > 0 && params.is_lot === 0) {
                            Async.each(historys, function(history, callback1) {
                                created_time = history.time;
                                logs = history.log
                                lots = history.log.lots
                                let occupied = 0;
                                let total = 0;
                                let percentage = 0;
                                let over_all_total = 0;
                                let over_all_occupied = 0;
                                let over_all_percentage = 0;

                                //let zone_array = [ 'a', 'ada', 'b', 'c', 'pc-1', 'pc-2', 'pc-3', 'pc-4'];
                                let zone_array = [params.zone];
                                let zone_name = params.zone;
                                let temp_zone_per_array = [];
                                let temp_zone_array = [];

                                if (lots) {
                                    Async.map(lots, function(lot, next1) {

                                        var occupancy = lot.occupancy;
                                        Async.forEachOf(occupancy, function(zoneValue, zone, next2) {
                                            if (zone_name === zone) {
                                                if (temp_zone_per_array[zone]) {
                                                    temp_zone_per_array[zone] = {
                                                        'total': temp_zone_per_array[zone].total + (occupancy[zone][2] - occupancy[zone][3]),
                                                        'occupied': temp_zone_per_array[zone].occupied + occupancy[zone][1]
                                                    }
                                                } else {
                                                    temp_zone_per_array[zone] = {
                                                        'total': occupancy[zone][2] - occupancy[zone][3],
                                                        'occupied': occupancy[zone][1]
                                                    }

                                                }
                                                over_all_occupied += occupancy[zone][1];
                                            }
                                            if (zone === 'all') {
                                                over_all_total += occupancy[zone][2];
                                            }

                                            next2();
                                        }, function(err, result) {
                                            if (err) console.log('ERROR:3', err);
                                        });
                                        next1();

                                    }, function(err, result) {
                                        if (err) console.log('ERROR:2', err);

                                        if (temp_zone_per_array[zone_name]) {
                                            temp_zone_array[zone_name] = {
                                                'total': temp_zone_per_array[zone_name].total ? temp_zone_per_array[zone_name].total : 0,
                                                'occupied': temp_zone_per_array[zone_name].occupied ? temp_zone_per_array[zone_name].occupied : 0,
                                                'time': created_time
                                            };
                                        }
                                    });
                                }

                                let zone_per_array = [];

                                Async.forEach(Object.keys(temp_zone_array), function(element, next3) {
                                    let occupied = parseInt(temp_zone_array[element].occupied);
                                    let total = parseInt(temp_zone_array[element].total);
                                    percentage = Math.ceil((occupied / total) * 100);

                                    zone_per_array[element] = {
                                        'total': total,
                                        'occupied': occupied,
                                        'percentage': percentage
                                    }

                                    Async.forEachOf(timeArray, function(time, index, next4) {
                                        let temp_percentage = 0;
                                        let time_created_time = created_time.replace(':', '.');
                                        time_created_time = parseFloat(time_created_time).toFixed(2);

                                        let time_inner = time.replace(':', '.');
                                        time_inner = parseFloat(time_inner).toFixed(2);

                                        if (index === 47) {
                                            if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(23.59).toFixed(2)) {
                                                temp_percentage = perArray[index] === 0 ? percentage : ((perArray[index] + percentage) / 2);
                                                perArray[index] = temp_percentage
                                            }
                                        } else {
                                            let prev_index = timeArray[index + 1].replace(':', '.');
                                            prev_index = parseFloat(prev_index).toFixed(2);

                                            if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(prev_index)) {

                                                temp_percentage = perArray[index] === 0 ? percentage : ((perArray[index] + percentage) / 2);
                                                perArray[index] = temp_percentage;
                                            }
                                        }
                                        next4();
                                    }, function(err, result) {
                                        if (err) console.log('ERROR:4', err);
                                    });

                                    next3();
                                }, function(err, result) {
                                    if (err) console.log('ERROR:4', err);
                                });
                                callback1()
                            }, function(err, result) {
                                if (err) console.log('ERROR:1', err);

                                if (params.date === moment().tz(Config.get('/timeZone')).format('DD-MM-YYYY').toString()) {
                                    if (timeReturnArray.length > 0) {
                                        timeReturnArray.splice(timeReturnArray.length - 1)
                                    }

                                    if (perArray.length > 0) {
                                        perArray.splice(perArray.length - 1)
                                    }
                                }

                                output = {
                                    'time': timeReturnArray,
                                    'percentage': perArray,
                                    'client_name': params.client_name,
                                    'lot_name': '',
                                    'date': params.date,
                                    'zone': params.zone
                                }
                            });


                        }

                        done(null, output);
                    });

                }
            }, (err, results) => {
                if (err) {
                    return reply(err);
                }

                return reply(results.get);
            });
        }
    });

    server.route({
        method: 'GET',
        path: '/history/download',
        config: {
            validate: {
                query: {
                    key: Joi.string().required().label('Api Key'),
                    date: Joi.string().required().label('Date'),
                    days: Joi.any().required().label('Days'),
                    is_lot: Joi.number().required().label('Is Lot'),
                    client_name: Joi.string().required().label('Client Name'),
                    lot_name: Joi.label('Lot Name').when('is_lot', {
                        is: 0,
                        then: Joi.optional(),
                        otherwise: Joi.string().required()
                    }),
                    zone: Joi.label('Zone Name').when('is_lot', {
                        is: 1,
                        then: Joi.optional(),
                        otherwise: Joi.string().required()
                    })
                }
            },
            pre: [{
                assign: 'user',
                method: function(request, reply) {
                    Async.auto({
                        auth: function(done) {
                            let auth_result = true;
                            if (request.query.key !== Config.get('/historicalApiToken')) {
                                return reply(Boom.badRequest('Invalid authentication key!'));
                            }
                            done(null, auth_result);
                        }
                    }, (err, results) => {
                        if (err) {
                            return reply(err);
                        }

                        return reply(results);
                    });
                }
            }]
        },
        handler: function(request, reply) {
            let result = request.pre;
            let params = request.query;
            let final_out = []
            let dayArray = []
            let timeReturnArray = [
                '0:30 am',
                '1:00 am',
                '1:30 am',
                '2:00 am',
                '2:30 am',
                '3:00 am',
                '3:30 am',
                '4:00 am',
                '4:30 am',
                '5:00 am',
                '5:30 am',
                '6:00 am',
                '6:30 am',
                '7:00 am',
                '7:30 am',
                '8:00 am',
                '8:30 am',
                '9:00 am',
                '9:30 am',
                '10:00 am',
                '10:30 am',
                '11:00 am',
                '11:30 am',
                '12:00 pm',
                '12:30 pm',
                '1:00 pm',
                '1:30 pm',
                '2:00 pm',
                '2:30 pm',
                '3:00 pm',
                '3:30 pm',
                '4:00 pm',
                '4:30 pm',
                '5:00 pm',
                '5:30 pm',
                '6:00 pm',
                '6:30 pm',
                '7:00 pm',
                '7:30 pm',
                '8:00 pm',
                '8:30 pm',
                '9:00 pm',
                '9:30 pm',
                '10:00 pm',
                '10:30 pm',
                '11:00 pm',
                '11:30 pm',
                '12:00 am'
            ]
            Async.auto({
                get: function(done) {
                    let get_result = null;
                    let total_days = params.days;
                    let allHistory = [];

                    for (var i = 0; i < total_days; i++) {
                        dayArray.push({
                            start: moment(`${params.date}`, 'DD-MM-YYYY').tz(Config.get('/timeZone')).startOf('day').subtract(i - 1, "days")._d,
                            end: moment(`${params.date}`, 'DD-MM-YYYY').tz(Config.get('/timeZone')).endOf('day').subtract(i - 1, "days")._d,
                            date: moment(params.date, 'DD-MM-YYYY').tz(Config.get('/timeZone')).endOf('day').subtract(i - 1, "days").format('DD-MM-YYYY'),
                            index: i + 1
                        })
                    }
                    dayArray = dayArray.sort(function(a, b) {
                        // Turn your strings into dates, and then subtract them
                        // to get a value that is either negative, positive, or zero.
                        return b.index - a.index;
                    });

                    dayArray = dayArray.reverse();

                    Async.each(dayArray, function(day, callback) {
                        const conditions = {
                            "timeCreated": {
                                $gte: day.start,
                                $lt: day.end
                            },
                            'log.client_name': params.client_name
                        };
                        History.find(conditions, (err, historys) => {
                            allHistory.push({
                                data: historys,
                                day: moment(day.end).tz(Config.get('/timeZone')).format('DD-MM-YYYY').toString(),
                                index: day.index
                            });
                            callback();
                        })

                    }, function(err) {
                        // if any of the file processing produced an error, err would equal that error
                        if (err) {
                            // One of the iterations produced an error.
                            // All processing will now stop.
                            console.log('A file failed to process');
                        } else {
                            let checkArray = [];
                            let lots;
                            let logs;
                            let created_time
                            let history;
                            let output = {};
                            Async.each(allHistory, function(historys, callback) {
                                let timeArray = [
                                    '00:00',
                                    '00:30',
                                    '01:00',
                                    '01:30',
                                    '02:00',
                                    '02:30',
                                    '03:00',
                                    '03:30',
                                    '04:00',
                                    '04:30',
                                    '05:00',
                                    '05:30',
                                    '06:00',
                                    '06:30',
                                    '07:00',
                                    '07:30',
                                    '08:00',
                                    '08:30',
                                    '09:00',
                                    '09:30',
                                    '10:00',
                                    '10:30',
                                    '11:00',
                                    '11:30',
                                    '12:00',
                                    '12:30',
                                    '13:00',
                                    '13:30',
                                    '14:00',
                                    '14:30',
                                    '15:00',
                                    '15:30',
                                    '16:00',
                                    '16:30',
                                    '17:00',
                                    '17:30',
                                    '18:00',
                                    '18:30',
                                    '19:00',
                                    '19:30',
                                    '20:00',
                                    '20:30',
                                    '21:00',
                                    '21:30',
                                    '22:00',
                                    '22:30',
                                    '23:00',
                                    '23:30'
                                ];
                                let perArray = {
                                    '00:00': 0.00,
                                    '00:30': 0.00,
                                    '01:00': 0.00,
                                    '01:30': 0.00,
                                    '02:00': 0.00,
                                    '02:30': 0.00,
                                    '03:00': 0.00,
                                    '03:30': 0.00,
                                    '04:00': 0.00,
                                    '04:30': 0.00,
                                    '05:00': 0.00,
                                    '05:30': 0.00,
                                    '06:00': 0.00,
                                    '06:30': 0.00,
                                    '07:00': 0.00,
                                    '07:30': 0.00,
                                    '08:00': 0.00,
                                    '08:30': 0.00,
                                    '09:00': 0.00,
                                    '09:30': 0.00,
                                    '10:00': 0.00,
                                    '10:30': 0.00,
                                    '11:00': 0.00,
                                    '11:30': 0.00,
                                    '12:00': 0.00,
                                    '12:30': 0.00,
                                    '13:00': 0.00,
                                    '13:30': 0.00,
                                    '14:00': 0.00,
                                    '14:30': 0.00,
                                    '15:00': 0.00,
                                    '15:30': 0.00,
                                    '16:00': 0.00,
                                    '16:30': 0.00,
                                    '17:00': 0.00,
                                    '17:30': 0.00,
                                    '18:00': 0.00,
                                    '18:30': 0.00,
                                    '19:00': 0.00,
                                    '19:30': 0.00,
                                    '20:00': 0.00,
                                    '20:30': 0.00,
                                    '21:00': 0.00,
                                    '21:30': 0.00,
                                    '22:00': 0.00,
                                    '22:30': 0.00,
                                    '23:00': 0.00,
                                    '23:30': 0.00
                                };

                                let zoneArray = [];
                                let zonePerArray = {};
                                let zoneTempPerArray = perArray;
                                if (params.is_lot === 1) {
                                    historys.data.forEach((history, history_index) => {
                                        
                                        created_time = history.time; //moment(history.timeCreated).tz(Config.get('/timeZone')).format("HH:mm");
                                        logs = history.log
                                        lots = history.log.lots
                                        Object.keys(lots).map((lot) => {
                                            let occupied = 0;
                                            let total = 0; 
                                            let percentage = 0; 
                                            let zone_occupied = 0;
                                            let zone_total = 0;
                                            let zone_percentage = 0;
                                            let color = '';
                                            let isZoneSelected = false;
                                            var lotZoneArray = [];

                                            if (lots[lot].lot_name === params.lot_name) {
                                                
                                                Object.keys(lots[lot].occupancy).map((zone) => {
                                                    occupied += lots[lot].occupancy[zone][1];
                                                    total += lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3];
                                                    percentage = Math.ceil((occupied / total) * 100);
                                                    
                                                    zone_occupied = lots[lot].occupancy[zone][1];
                                                    zone_total = lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3];
                                                    zone_percentage = Math.ceil((zone_occupied / zone_total) * 100);
                                                    
                                                    let temp_zone_percentage = !lotZoneArray[zone] ? zone_percentage : ((lotZoneArray[zone] + zone_percentage) / 2);
                                                    
                                                    lotZoneArray[zone] = temp_zone_percentage;

                                                    zonePerArray[zone] = zonePerArray[zone] ? zonePerArray[zone] : {
                                                        '00:00': 0.00,
                                                        '00:30': 0.00,
                                                        '01:00': 0.00,
                                                        '01:30': 0.00,
                                                        '02:00': 0.00,
                                                        '02:30': 0.00,
                                                        '03:00': 0.00,
                                                        '03:30': 0.00,
                                                        '04:00': 0.00,
                                                        '04:30': 0.00,
                                                        '05:00': 0.00,
                                                        '05:30': 0.00,
                                                        '06:00': 0.00,
                                                        '06:30': 0.00,
                                                        '07:00': 0.00,
                                                        '07:30': 0.00,
                                                        '08:00': 0.00,
                                                        '08:30': 0.00,
                                                        '09:00': 0.00,
                                                        '09:30': 0.00,
                                                        '10:00': 0.00,
                                                        '10:30': 0.00,
                                                        '11:00': 0.00,
                                                        '11:30': 0.00,
                                                        '12:00': 0.00,
                                                        '12:30': 0.00,
                                                        '13:00': 0.00,
                                                        '13:30': 0.00,
                                                        '14:00': 0.00,
                                                        '14:30': 0.00,
                                                        '15:00': 0.00,
                                                        '15:30': 0.00,
                                                        '16:00': 0.00,
                                                        '16:30': 0.00,
                                                        '17:00': 0.00,
                                                        '17:30': 0.00,
                                                        '18:00': 0.00,
                                                        '18:30': 0.00,
                                                        '19:00': 0.00,
                                                        '19:30': 0.00,
                                                        '20:00': 0.00,
                                                        '20:30': 0.00,
                                                        '21:00': 0.00,
                                                        '21:30': 0.00,
                                                        '22:00': 0.00,
                                                        '22:30': 0.00,
                                                        '23:00': 0.00,
                                                        '23:30': 0.00
                                                    };
                                                    
                                                    if (zone !== 'all' && zoneArray.indexOf(zone) === -1){
                                                        zoneArray.push(zone);
                                                    }
                                                        

                                                });

                                                timeArray.forEach((time, index) => {
                                                    let temp_percentage = 0;
                                                    /*if (index === 11) {
                                                        if ( parseFloat(created_time).toFixed(2) >= parseFloat(time).toFixed(2) && parseFloat(created_time).toFixed(2) < parseFloat(23.59).toFixed(2)) {
                                                            temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                            perArray[time] = temp_percentage
                                                        } 
                                                    } else {
                                                        if ( parseFloat(created_time) >= parseFloat(time) && parseFloat(created_time) < parseFloat(timeArray[index+1]) ) {
                                                            temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                            perArray[time] = temp_percentage
                                                        } 
                                                    }*/
                                                    let time_created_time = created_time.replace(':', '.');
                                                    time_created_time = parseFloat(time_created_time).toFixed(2);

                                                    let time_inner = time.replace(':', '.');
                                                    time_inner = parseFloat(time_inner).toFixed(2);

                                                    if (index === 47) {
                                                        if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(23.59).toFixed(2)) {
                                                            temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                            perArray[time] = temp_percentage
                                                        }
                                                    } else {
                                                        let prev_index = timeArray[index + 1].replace(':', '.');
                                                        prev_index = parseFloat(prev_index).toFixed(2);

                                                        if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(prev_index)) {

                                                            temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                            perArray[time] = temp_percentage;
                                                        }
                                                    }
                                                    Object.keys(lotZoneArray).map((zones, zone_index) => {
                                                        
                                                        let zone_per = lotZoneArray[zones];
                                                        let zone_temp_percentage = 0;
                                                        let zone_per_array = zonePerArray;
                                                        
                                                        if (index === 47) {
                                                            
                                                            if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(23.59).toFixed(2)) {
                                                                
                                                                zone_temp_percentage = zonePerArray[zones][time] === 0 ? zone_per : ((zonePerArray[zones][time] + zone_per) / 2);
                                                                
                                                                var obj = {};
                                                                obj[time] = zone_temp_percentage;
                                                                
                                                                Object.assign(zone_per_array[zones], obj);

                                                            }
                                                        } else {
                                                            let prev_index = timeArray[index + 1].replace(':', '.');
                                                            prev_index = parseFloat(prev_index).toFixed(2);
    
                                                            if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(prev_index)) {
                                                                
                                                                zone_temp_percentage = zonePerArray[zones][time] === 0 ? zone_per : ((zonePerArray[zones][time] + zone_per) / 2);
                                                                
                                                                var obj = {};
                                                                obj[time] = zone_temp_percentage;
                                                                Object.assign(zone_per_array[zones], obj);
                                                            }
                                                        }
                                                        
                                                    });
                                                })
                                            }
                                        })
                                    });

                                    final_out.push({
                                        'time': timeReturnArray,
                                        'percentage': perArray,
                                        'client_name': params.client_name,
                                        'lot_name': params.lot_name,
                                        'date': historys.day,
                                        'zone': '',
                                        'days': params.days,
                                        'index': historys.index,
                                        'zones': zoneArray,
                                        'zone_percentage': zonePerArray
                                    });
                                    callback()
                                }
                                if (params.is_lot === 0) {
                                    historys.data.forEach((history) => {
                                        created_time = history.time; //moment(history.timeCreated).tz(Config.get('/timeZone')).format("HH:mm");
                                        logs = history.log
                                        lots = history.log.lots
                                        let occupied = 0;
                                        let total = 0;
                                        let percentage = 0;
                                        let over_all_total = 0;
                                        let over_all_occupied = 0;
                                        let over_all_percentage = 0;

                                        //let zone_array = [ 'a', 'ada', 'b', 'c', 'pc-1', 'pc-2', 'pc-3', 'pc-4'];
                                        let zone_array = [params.zone];
                                        let zone_name = params.zone;
                                        let temp_zone_per_array = [];
                                        let temp_zone_array = [];

                                        if (lots) {
                                            Object.keys(lots).map((lot) => {
                                                Object.keys(lots[lot].occupancy).map((zone) => {
                                                    if (zone_name === zone) {
                                                        if (temp_zone_per_array[zone]) {
                                                            temp_zone_per_array[zone] = {
                                                                'total': temp_zone_per_array[zone].total + (lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3]),
                                                                'occupied': temp_zone_per_array[zone].occupied + lots[lot].occupancy[zone][1]
                                                            }
                                                        } else {
                                                            temp_zone_per_array[zone] = {
                                                                'total': lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3],
                                                                'occupied': lots[lot].occupancy[zone][1]
                                                            }

                                                        }
                                                        over_all_occupied += lots[lot].occupancy[zone][1];
                                                    }
                                                    if (zone === 'all') {
                                                        over_all_total += lots[lot].occupancy[zone][2];
                                                    }

                                                });
                                            });
                                            temp_zone_array[zone_name] = {
                                                'total': temp_zone_per_array[zone_name].total ? temp_zone_per_array[zone_name].total : 0,
                                                'occupied': temp_zone_per_array[zone_name].occupied ? temp_zone_per_array[zone_name].occupied : 0,
                                                'time': created_time
                                            };
                                        }

                                        let zone_per_array = [];
                                        Object.keys(temp_zone_array).map((element) => {
                                            let occupied = parseInt(temp_zone_array[element].occupied);
                                            let total = parseInt(temp_zone_array[element].total);
                                            percentage = Math.ceil((occupied / total) * 100);

                                            zone_per_array[element] = {
                                                'total': total,
                                                'occupied': occupied,
                                                'percentage': percentage
                                            }
                                            timeArray.forEach((time, index) => {
                                                let temp_percentage = 0;
                                                /*if (index === 11) {
                                                    if ( parseFloat(created_time).toFixed(2) >= parseFloat(time).toFixed(2)  && parseFloat(created_time).toFixed(2) < parseFloat(23.59).toFixed(2)) {
                                                        temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                        perArray[time] = temp_percentage
                                                    } 
                                                } else {
                                                    if ( parseFloat(created_time) >= parseFloat(time) && parseFloat(created_time) < parseFloat(timeArray[index+1]) ) {
                                                        temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                        perArray[time] = temp_percentage
                                                    } 
                                                }*/
                                                let time_created_time = created_time.replace(':', '.');
                                                time_created_time = parseFloat(time_created_time).toFixed(2);

                                                let time_inner = time.replace(':', '.');
                                                time_inner = parseFloat(time_inner).toFixed(2);

                                                if (index === 47) {
                                                    if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(23.59).toFixed(2)) {
                                                        temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                        perArray[time] = temp_percentage
                                                    }
                                                } else {
                                                    let prev_index = timeArray[index + 1].replace(':', '.');
                                                    prev_index = parseFloat(prev_index).toFixed(2);

                                                    if (parseFloat(time_created_time) >= parseFloat(time_inner) && parseFloat(time_created_time) < parseFloat(prev_index)) {

                                                        temp_percentage = perArray[time] === 0 ? percentage : ((perArray[time] + percentage) / 2);
                                                        perArray[time] = temp_percentage;
                                                    }
                                                }
                                            })
                                        });
                                    });

                                    final_out.push({
                                        'time': timeReturnArray,
                                        'percentage': perArray,
                                        'client_name': params.client_name,
                                        'lot_name': '',
                                        'date': historys.day,
                                        'zone': params.zone,
                                        'days': params.days,
                                        'index': historys.index,
                                        'zones': zoneArray,
                                        'zone_percentage': zonePerArray
                                    })
                                    callback()
                                }
                            }, function(err) {
                                if (err) {
                                    // One of the iterations produced an error.
                                    // All processing will now stop.
                                    console.log('B file failed to process');
                                } else {
                                    //console.log('final_out', final_out);
                                    final_out = final_out.sort(function(a, b) {
                                        // Turn your strings into dates, and then subtract them
                                        // to get a value that is either negative, positive, or zero.
                                        return a.index - b.index;
                                    });
                                    done(null, { data: final_out });
                                }
                            });
                        }
                    });

                }
            }, (err, results) => {
                if (err) {
                    return reply(err);
                }
                
                return reply(results.get);
            });
        }
    });

    next();
};

exports.register = function(server, options, next) {

    server.dependency(['hapi-mongo-models'], internals.applyRoutes);

    next();
};

exports.register.attributes = {
    name: 'history'
};