
$(window).scroll(function () {
  if($(window).scrollTop() > 10) {
    $(".headerSection").addClass('sticky fadeInDown animated');
  } else {
    $(".headerSection").removeClass('sticky fadeInDown animated');
  }
});


jQuery(window).scroll(function() {
    var header = jQuery(".tabSection");
    var headerHeight = header.height();
    var scrollTop = jQuery(window).scrollTop();
    if (scrollTop > 450) {
      if (!header.hasClass('stickyTab')) {
        if(jQuery('body').width() < 450) header.height(headerHeight);
        header.addClass('stickyTab fadeInDown animated');
        header.animate({opacity: 1}, 450);
      }
    } else {
      if (header.hasClass('stickyTab')) {
        header.removeClass('stickyTab fadeInDown animated');      
        header.removeAttr('style');
        if(jQuery('body').width() < 450) header.height('auto');
      }
    }
  });




$(".scrollTop").click(function() {
  $("html, body").animate({ scrollTop: 0 }, "slow");
  return false;
});




if ($(window).width() < 960) {
  $('.requestDemo a').each(function() {
    var text = $(this).text();
    $(this).text(text.replace('Request Live Demo', 'Request Demo')); 
});
}
else {   
     $('.requestDemo a').each(function() {
    var text = $(this).text();
    $(this).text(text.replace('Request Live Demo', 'Request Live Demo')); 
});
}




$(".resMenu").click(function() {
  $(".resMenuclose").show();
  $(".navigator").toggleClass('activeNav');
  $(".resMenu").toggleClass('resclose');
  
});


 $(document).ready(function() {
$('.tabSection').onePageNav({
 currentClass: 'current',
 changeHash: false,
   scrollSpeed: 500,
   scrollThreshold: 0.2,

 });
});


$(document).ready(function(){
  $('.requestDemo a').click(function(){
     event.preventDefault();
        $('#requestDemo').modal('show');
   });
});


// contactus Footer 

 $(document).ready(function() {
     
       
         
         $.validator.addMethod("phone6", function(value, element) {
                return /^[0-9 +-]{5,20}$/.test(value);
        }); 
    
            
      $("form[name='contact_foot_form']").validate({
             rules:{
                contact_name:"required",
                contact_email:{
                    required:true,
                    email:true
                },
                contact_phone_con:{
                    required:true,
                    //number:true,
                   phone6:true,
                    minlength:7
                },
                   contact_message:"required",
                },
             messages: {
            contact_name: {
               required: "Enter your name",                         
           },
            contact_email: {
               required: "Enter your email id",
               email:"Enter a valid email id"                  
           },
            contact_phone_con : {
               required: "Enter your phone number",
               phone6: "Enter a valid phone number",
               minlength:"Enter a valid phone number"
            },
             contact_message : {
               required: "Enter your message"            
            },
            
        },
 submitHandler: function(form) { 
 form.submit();
 }

}); 
    var page_url = window.location.href;  
   $("#page_url").val(page_url);  
$("#contact_phone_con").intlTelInput({   
  initialCountry: "auto",
    geoIpLookup: function(callback) {
    $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
      var countryCode = (resp && resp.country) ? resp.country : "";
      callback(countryCode);
    });
  },
  separateDialCode: true,
  });

var con_page_url = window.location.href; 
$("#contact_pageurl").val(page_url);  

 var dataconcountry = $('#contact_foot_form .intl-tel-input .country-list li.active').find(".country-name").text();
 var datacondial = $('#contact_foot_form .intl-tel-input .country-list li.active').find(".dial-code").text();
 $("#contact_country").val(dataconcountry);  
 $("#contact_country_dial").val(datacondial); 


    $("#contact_phone_con").on("countrychange", function(e, countryData) {
      $("#contact_country_dial").val("+" + countryData.dialCode );    
         $("#contact_country").val(countryData.name);    
      
    }); 

});



// popup home page 

 $(document).ready(function() {
    
      $("form[name='getonelineContact']").validate({
             rules:{
                popname:"required",
                popemail:{
                    required:true,
                    email:true
                },
                popphone:{
                    required:true,
                    //number:true,
                   phone6:true,
                    minlength:7
                },
                   popprice:"required",
                },
             messages: {
            popname: {
               required: "Enter your name",                         
           },
            popemail: {
               required: "Enter your email id",
               email:"Enter a valid email id"                  
           },
            popphone : {
               required: "Enter your phone number",
               phone6: "Enter a valid phone number",
               minlength:"Enter a valid phone number"
            },
             popprice : {
               required: "Please select price Type"            
            },
            
        },
 submitHandler: function(form) {   
form.submit();
 }

}); 
   
$("#popphone").intlTelInput({   
  initialCountry: "auto",
    geoIpLookup: function(callback) {
    $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
      var countryCode = (resp && resp.country) ? resp.country : "";
      callback(countryCode);
    });
  },
  separateDialCode: true,  
  });

 var dataonlineecountry = $('#contact_foot_form .intl-tel-input .country-list li.active').find(".country-name").text();
 var dataonlinedial = $('#contact_foot_form .intl-tel-input .country-list li.active').find(".dial-code").text();
 $("#popcountry").val(dataonlineecountry);  
 $("#popcountrycode").val(dataonlinedial); 
    $("#popphone").on("countrychange", function(e, countryData) {
      $("#popcountrycode").val("+" + countryData.dialCode);    
         $("#popcountry").val(countryData.name);    
      
    }); 
});

// popup Request Demo 

 $(document).ready(function() {
     
            
      $("form[name='requestdemoForm']").validate({
             rules:{
                rename:"required",
                reemail:{
                    required:true,
                    email:true
                },
                rephone:{
                    required:true,
                    //number:true,
                   phone6:true,
                    minlength:7
                },
                   reprice:"required",
                },
             messages: {
            rename: {
               required: "Enter your name",                         
           },
            reemail: {
               required: "Enter your email id",
               email:"Enter a valid email id"                  
           },
            rephone : {
               required: "Enter your phone number",
               phone6: "Enter a valid phone number",
               minlength:"Enter a valid phone number"
            },
             reprice : {
               required: "Please select price Type"            
            },
            
        },
 submitHandler: function(form) { 
   form.submit();
    }

}); 
    var page_url = window.location.href;  
   $("#repageurl").val(page_url);  
$("#rephone").intlTelInput({   
  initialCountry: "auto",
    geoIpLookup: function(callback) {
    $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
      var countryCode = (resp && resp.country) ? resp.country : "";
      callback(countryCode);
    });
  },
  
  separateDialCode: true,
  });


 var datarecountry = $('#requestdemoForm .intl-tel-input .country-list li.active').find(".country-name").text();
 var dataredial = $('#requestdemoForm .intl-tel-input .country-list li.active').find(".dial-code").text();
 $("#recountry").val(datarecountry);  
 $("#recountrydial").val(dataredial); 

    $("#rephone").on("countrychange", function(e, countryData) {
      $("#recountrydial").val("+" + countryData.dialCode + "");    
         $("#recountry").val(countryData.name);    
      
    }); 
});
