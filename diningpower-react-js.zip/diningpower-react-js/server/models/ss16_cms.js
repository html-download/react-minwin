/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Cms', {
    pageId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'page_id'
    },
    pageKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'page_key'
    },
    pageName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'page_name'
    },
    slug: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'slug'
    },
    pageContent: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'page_content'
    },
    sortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort_order'
    },
    pageStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Deactive',
      field: 'page_status'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    cmsMetaTitle: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'cms_meta_title'
    },
    cmsMetaKeywords: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'cms_meta_keywords'
    },
    cmsMetaDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'cms_meta_description'
    }
  }, {
    tableName: 'ss16_cms'
  });
};
