/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const CommonFunctions = require('../../../../helpers/common-functions');
const Constants = require('./constants');
const Store = require('./store');
const Qs = require('qs');


class Actions {

    static getResults(data) {
        
        ApiActions.get(
            '/task',
            Object.assign(data, { is_pagination: 1 }),
            Store,
            Constants.GET_TASK_RESULTS,
            Constants.GET_TASK_RESULTS_RESPONSE
        );
    }

    static updatedStatus(data, query) {
        
        ApiActions.post(
            '/task/update-status',
            data,
            Store,
            Constants.GET_TASK_UPDATE_STATUS_RESULTS,
            Constants.GET_TASK_UPDATE_STATUS_RESULTS_RESPONSE,
            (err, response) => {
                if (!err) {
                    this.getResults(query);
                }
            }
        );
    }

    static showCreateNew(data = {}) {

        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW,
            task_data: data
        });
    }

    static hideCreateNew(data) {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }    

    static changeSearchQuery(data, history) {

        history.push({
            pathname: '/admin/tasks',
            search: `?${Qs.stringify(data)}`
        });

        window.scrollTo(0, 0);
    }    
}


module.exports = Actions;
