'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');

const initialState = {
    show: false,
    loading: false,
    hasError: {},
    help: {},
    error: null,
    lots: [],
    selected : '', 
    selectedAddress: {},
    selectedLatLng:'',
    title : '',
    percentage : '', 
    color : ''
};

const reducer = function (state = initialState, action) {

    if (action.type === Constants.SHOW_CREATE_NEW_MAP) {
        return ObjectAssign({}, state, {
            show: true,
            selected : action.lot_name,
            selectedAddress : action.address,
            selectedLatLng : action.LatLng,
            title : action.title,
            percentage : action.percentage, 
            color : action.color
        });
    }

    if (action.type === Constants.HIDE_CREATE_NEW_MAP) {
        return ObjectAssign({}, state, {
            show: false,
            selected : '',
            selectedAddress : {},
            selectedLatLng : '',
            title : '',
            percentage : '', 
            color : ''
        });
    }

    return state;
};


module.exports = reducer;
