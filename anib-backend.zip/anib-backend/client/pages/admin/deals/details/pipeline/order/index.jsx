'use strict';
const Actions = require('./actions');
const Button = require('../../../../../../components/form/button.jsx');
const Spinner = require('../../../../../../components/form/spinner.jsx');
const CommonActions = require('../../actions');
const Constants = require('./constants');
const Cookie = require('cookie');
const React = require('react');
const Store = require('./store');
const CStore = require('../../../../common-store/store');
const CommonHelper = require('../../../../../../helpers/common-functions');
const DateHelper = require('../../../../../../helpers/date-time');
const CreateQuote = require('./send-quote-modal');
const UploadFile = require('../../../../../../helpers/aixos-ajax');
const Toaster = require('../../../../../../helpers/toaster');
const cookies = Cookie.parse(document.cookie);
const moment = require('moment-timezone');

import DatePicker from "react-datepicker";

class Order extends React.Component {   

    constructor(props) {

        super(props);

        this.input = {};

        this.state = Store.getState();

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.paymentStatusChange = this.paymentStatusChange.bind(this);
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentDidUpdate(prevProps, prevState) {

        if (prevProps.order_id !== this.props.order_id && this.props.order_id !== '') {
            Actions.getDealQuote(this.props.order_id);
        }
    }

    componentWillReceiveProps(nextProps) {
        
        nextProps.deal_data.deal_quote_key ? Actions.getDealQuote(nextProps.deal_data.deal_quote_key) : undefined;
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());        
    }
        
    toggleQuote() {
        
        Actions.toggleQuote();
    }

    handleChange(date, type) {
        
        if(type === 'policy_start_date') {

            let policy_expire_date = moment(date,"DD-MM-YYYY").add('months', 13).format('DD-MMM-YYYY');            
            policy_expire_date = moment(policy_expire_date,"DD-MMM-YYYY").subtract(1, "days").format("DD-MMM-YYYY");            
            Actions.updateDate(policy_expire_date, 'policy_expire_date');
        }

        date = (date !== '') ? DateHelper._changeDefaultFormat2(date): '';
        Actions.updateDate(date, type);
    }

    handleSubmit(event) {

        const CUSTOMER_INFO = CStore.getState().customer_info;        

        let choosePolicy = {

            deal_quote_selected_plan_id : this.state.quote_data.plan_id,
            firstName: CUSTOMER_INFO.first_name,
            lastName : CUSTOMER_INFO.last_name,
            dateOfBirth : CUSTOMER_INFO.dob,
            nationality : CUSTOMER_INFO.nationality_id,
            emailAddress : CUSTOMER_INFO.email,
            mobileNo : CUSTOMER_INFO.mobile_number,
            gender : CUSTOMER_INFO.gender,
            poBox : CUSTOMER_INFO.po_box,
            emiratesID : CUSTOMER_INFO.emirate_id,
            adressLine1 : CUSTOMER_INFO.address,
            adressLine2 : ""
        };
        var value = this.state.quote_data;
        const id = this.props.id;        


        let policy_start_date = value.policy_start_date;        
        policy_start_date = policy_start_date !== '' ? DateHelper._getDbFormat(policy_start_date): undefined 

        let policy_expire_date = value.policy_expire_date;
        policy_expire_date = policy_expire_date !== '' ? DateHelper._getDbFormat(policy_expire_date): undefined 

        const data = {
            "insurence_product_id": value.insurence_product_id,
            "deal_id": value.deal_id,
            "quote_reference_number": value.quote_reference_number,
            "vehicle_insured_value": value.vehicle_insured_value,
            "premium_value": value.premium_value,
            "deduction": value.deduction,
            "extra_deduction": value.extra_deduction,
            "is_publish": value.is_publish,
            "is_agency_repair": value.is_agency_repair,
            "is_ncd_required": value.is_ncd_required,
            payment_type: value.payment_type,
            mortgage_id: value.mortgage_id,
            discount: value.discount,
            is_update_deal: 1,

            /* "policy_number" : this.input.policy_number.value, */
            "policy_start_date" : policy_start_date,
            "policy_expire_date" : policy_expire_date
        };

        !CommonHelper.isEmpty(this.state.quote_data) ? 
            Actions.updateQuoteDetails(choosePolicy, value.deal_quote_key, data, this.props.toggle, this.props.updateOrderId) : null;
    }

    openQuoteModal(deal_quote_key) {
                
        Actions.openQuoteModal(deal_quote_key,this.handleSubmit);
    }


    sendQuoteMail(e) {

        e.preventDefault();        
        /* this.props.info_data.submit_event(); */
        Actions.sendQuoteMail({
            deal_quote_id: this.state.quote_data.deal_quote_key,
            deal_id: this.props.id,
            /* to: this.to.value,
            cc: this.cc.value,
            bcc: this.bcc.value,
            subject: this.subject.value,
            message: this.message.value, */
        },this.props.toggle);
    }

    uploadDocument(type,refName) {
        if(this[refName] && this[refName].files[0]) {
            var formData = new FormData();
            formData.append("file", this[refName].files[0]);
            formData.append("deal_quote_id", this.state.quote_data.deal_quote_key);
            formData.append("document_type", type);
            UploadFile.upload('/deal-quote-document',formData,Store,Constants.GET_DEAL_QUOTE_DOCU_DETAILS,Constants.GET_DEAL_QUOTE_DOCU_DETAILS_RESPONSE);
        }
    }

    deleteQuoteDocument(deal_quote_document_key) {
        Actions.deleteQuoteDocument(deal_quote_document_key,this.state.quote_data.deal_quote_key);
    }

    paymentStatusChange(value) {

        const data = {
            'attribute_key': 'deal_payment_status',
            'attribute_value': value
        };

        value ? CommonActions.saveDealDetails(this.props.id, data) : null;

        Toaster.success('Enquiry payment status updated successfully!')
    }

    render() {        

        let value = this.state.quote_data;               

        return (
            <div>
                <div className="wi-content mt-30 full_row">
                    <div className="text-right mb-2"> 
                        <a className="link-text collapse-txt" data-toggle="collapse" href="#genrate"> Collapse </a> 
                    </div>
                    <div className="genrate-new-quote collapse show" id="genrate">
                        { CommonHelper.isEmpty(this.state.quote_data) ? (
                                <div className="under-construction">
                                    <h3>Sorry! Please select quote for order</h3>
                                    <p>Thank you for your patience.</p>
                                </div>
                            ): (
                            <div className="first-box">
                                <h4 className="f20">Order Summary{/*  <a href="" className="f16">Edit Order</a> */}</h4>
                                <p>Lt's Start by creating a new quote for the customer</p>
                                <div className="product-box">
                                    <ul className="product-listing reset">
                                        <li>
                                            <div className="box">
                                                <div className="img"><img src={value.insurence_product_image} /></div>
                                                <h5>{value['insurence_product_name']}</h5>
                                                <p>Sum Insured: AED {value['vehicle_insured_value']}</p>
                                                {/* <p>Quote Reference: {value['quote_reference_number']}</p> */}
                                                <p>Quotation Number: {value['quotation_number']}</p>
                                                <p className="tags" style={{'display': 'none'}}> <span>Pab Driver</span> <span>Pab Passenger</span> </p>
                                                <div className="right-cd text-cenetr">
                                                    <p className="bold text-center">Total Premium <br/> AED {value['premium_value']}</p>
                                                    <div className="text-center mt-2">
                                                        <select className="form-control" defaultValue={this.props.deal_payment_status} ref={(c) => (this.input.payment_status = c)} onChange={(e) => {this.paymentStatusChange(e.target.value)}}>
                                                            <option value={''}>Select Payment</option>
                                                            <option value={1}>Paid</option>
                                                            <option value={2}>Unpaid</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="box-fields">
                                                <div className="quicklink-share mt-3 mb-4">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" defaultValue={value.url} id="clone" />
                                                        <div className="fly">
                                                            <label className="link-copy" htmlFor="clone" onClick={() => {CommonHelper.copyToClipboard('quote_clone')}}><i className="fa fa-clone"></i></label>
                                                            <a href={value.url} className="link-targer" target="_blank"><i className="fa fa-external-link" aria-hidden="true"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <h4 className="f20 mb-3">Policy Details</h4>
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <div className="form-group">
                                                            <label>Policy Start Date</label>
                                                            <DatePicker
                                                                ref={(c) => (this.input.policy_start_date = c)}
                                                                key={ `${Math.floor((Math.random() * 1000))}`}
                                                                selected={ value.policy_start_date !== undefined ? DateHelper._getDefaultFormat2(value.policy_start_date): ''}
                                                                onChange={ (e) => {this.handleChange(e, 'policy_start_date')}}
                                                                className={{'form-control' : true}}
                                                                dateFormat="d-MMM-yyyy"
                                                                showYearDropdown
                                                                scrollableYearDropdown
                                                                yearDropdownItemNumber={40}
                                                            />
                                                        </div>
                                                    </div>                                                
                                                    <div className="col-md-4">
                                                        <div className="form-group">
                                                            <label>Policy Expiry Date</label>
                                                            <DatePicker
                                                                ref={(c) => (this.input.policy_expire_date = c)}
                                                                key={ `${Math.floor((Math.random() * 1000))}`}
                                                                selected={ value.policy_expire_date !== undefined ? DateHelper._getDefaultFormat2(value.policy_expire_date, 1): ''}
                                                                onChange={ (e) => {this.handleChange(e, 'policy_expire_date')}}
                                                                className={{'form-control' : true}}
                                                                dateFormat="d-MMM-yyyy"
                                                                showYearDropdown
                                                                scrollableYearDropdown
                                                                yearDropdownItemNumber={40}
                                                                maxDate={moment().add(1, 'years')}
                                                            />
                                                        </div>
                                                    </div>
                                                    {/* <div className="col-md-4">                                                
                                                        <div className="form-group">
                                                            <label>Policy Number</label>
                                                            <input type="text" ref={(c) => (this.input.policy_number = c)}
                                                            className="form-control" defaultValue={value['policy_number']} />
                                                        </div>
                                                    </div> */}
                                                </div>
                                                <div className="row mt-2 mb-4">
                                                    <div className="col-md-4">
                                                        <div className="form-group upload-file mb-0">
                                                            <label>Emirate ID</label>
                                                            <input type="file" ref={(c) => (this.type_one = c)} onChange={ (e) => this.uploadDocument(1,'type_one') }  className="hidden" id="f1" />
                                                            <label htmlFor="f1" className="form-control c-pointer">Choose file to Upload</label>
                                                        </div>
                                                        <ul className="list-file reset">
                                                            
                                                        {this.state.deal_quote_document.map((item, index) => ( (item.document_type === 1) ? 
                                                            <li key={item.deal_quote_document_key}>
                                                                <i className="icon fa fa-file-pdf-o"></i>
                                                                <a target="_blank" href={item.document_path} className="add-forms">Emirate ID</a>
                                                                <button className="btns remove" onClick={ (e) => this.deleteQuoteDocument(item.deal_quote_document_key)  }><i className="fa fa-trash"></i></button>
                                                            </li>  : ''
                                                        ))}
                                                            
                                                        </ul>
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="form-group upload-file mb-0">
                                                            <label>Driving License</label>
                                                            <input type="file" ref={(c) => (this.type_two = c)} onChange={ (e) => this.uploadDocument(2,'type_two') }  className="hidden" id="f2" />
                                                            <label htmlFor="f2" className="form-control c-pointer"> Choose file to Upload </label>
                                                        </div>
                                                        <ul className="list-file reset">
                                                            {this.state.deal_quote_document.map((item, index) => ( (item.document_type === 2) ? 
                                                                <li key={item.deal_quote_document_key}>
                                                                    <i className="icon fa fa-file-pdf-o"></i>
                                                                    <a target="_blank" href={item.document_path} className="add-forms">Driving License</a>
                                                                    <button className="btns remove" onClick={ (e) => this.deleteQuoteDocument(item.deal_quote_document_key)  }><i className="fa fa-trash"></i></button>
                                                                </li>  : ''
                                                            ))}
                                                        </ul>                                                                                        
                                                    </div>
                                                    <div className="col-md-4">
                                                        <div className="form-group upload-file mb-0">
                                                            <label>Other Documents</label>                                                   
                                                            <input type="file" ref={(c) => (this.type_three = c)} onChange={ (e) => this.uploadDocument(3,'type_three') }  className="hidden" id="f3" />
                                                            <label htmlFor="f3" className="form-control c-pointer">Choose file to Upload</label>
                                                        </div>    
                                                        <ul className="list-file reset">
                                                            {this.state.deal_quote_document.map((item, index) => ( (item.document_type === 3) ? 
                                                                <li key={item.deal_quote_document_key}>
                                                                    <i className="icon fa fa-file-pdf-o"></i>
                                                                    <a target="_blank" href={item.document_path} className="add-forms">Other Document</a>
                                                                    <button className="btns remove" onClick={ (e) => this.deleteQuoteDocument(item.deal_quote_document_key)  }><i className="fa fa-trash"></i></button>
                                                                </li>  : ''
                                                            ))}
                                                        </ul>                                             
                                                    </div>
                                                </div>
                                                <div className="text-right mt-3 mb-3">
                                                    <Button
                                                        type="button"
                                                        inputClasses={{ 'btn': true, 'btn-outline-primary': true, 'no-shadow': true, 'ml-2': true }}
                                                        disabled={this.state.order_save_loading}
                                                        onClick={ (e) => {this.handleSubmit(value['deal_quote_key'])}}>
                                                        <Spinner space="right" show={this.state.order_save_loading} />
                                                        Create Policy
                                                    </Button>                                                    
                                                    {/* <button onClick={ (e) => this.sendQuoteMail(e) }    className="btn btn-primary ml-1 loader no-shadow"> <Spinner space="right" show={this.state.order_save_loading} /> Save &amp; Send</button> */}
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                <CreateQuote
                    info_data={this.state}
                    id={this.props.id}
                    toggle={this.props.toggle}
                />
            </div>
        );
    }
}
module.exports = Order;
