
//Fixed Header  
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".site_header").addClass("fixed");
    } else {
        $(".site_header").removeClass("fixed");
	}	
	
	if (scroll >= 50) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }	
});

//Animation
new WOW().init();

// Modal popup
var modalUniqueClass = ".modal";
$('.modal').on('show.bs.modal', function(e) {
  var $element = $(this);
  var $uniques = $(modalUniqueClass + ':visible').not($(this));
  if ($uniques.length) {
    $uniques.modal('hide');
    $uniques.one('hidden.bs.modal', function(e) {
      $element.modal('show');
    });
    return false;
  }
});

//dropdown menu
$("ul.dropdown-menu label, .event").on('click', function(event) {
    event.stopPropagation();
});

//Mobile Menu
$("#mobile_nav").on('click', function() {
  $(".site_menu").fadeToggle();
  $(".site_menu").toggleClass("open");
  $(this).toggleClass("open");
  $("body").toggleClass("open");
});
$(".site_menu a, .site_menu").on('click', function() {
  $(".site_menu").fadeOut();
  $(".site_menu").removeClass("open");
  $("#mobile_nav").removeClass("open");
  $("body").removeClass("open");
});

//Custom scrollbar
jQuery(document).ready(function(){
	jQuery('.scrollbar-inner').scrollbar();
});

// Date Time Picker
$(".datepicker").datetimepicker({		
	minView: 2,
	format: "dd-M-yyyy",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

$(".datetime").datetimepicker({		
	format: "dd-M-yyyy - HH:ii P",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});


// Categories1 
$('#categories1').owlCarousel({
	loop:true,
	margin:0,
	nav:true,
	dots:false,
	responsiveClass:true,
	responsive:{
			0:{
					items:2,
			},
			640:{
					items:3,
			},
			1000:{
					items:4,
			}
	}
})

// Related Products 
$('#related').owlCarousel({
	loop:true,
	margin:0,
	nav:true,
	dots:false,
	responsiveClass:true,
	responsive:{
			0:{
					items:1,
			},
			640:{
					items:3,
			},
			1000:{
					items:4,
			}
	}
})

function convertJson(data){
    try{
      return JSON.parse(data);
    }catch(e){

    }
    return data;
}

function update_cart(result){
  result=convertJson(result);
  if(typeof(result.cart_data) != 'undefined' ){
    $('.mini_cart').html(result.cart_data);
  }
  if(typeof(result.count) != 'undefined' ){
    $('.cart_count').html(result.count);
  }
  if(typeof(result.price) != 'undefined' ){
    $('.cart_price').html(result.price);
  }
  if(typeof(result.checkout_order) != 'undefined' ){
    $('#checkout_cart').html(result.checkout_order);
  }

  if(typeof(result.msg) != "undefined" ) {
      Core.success(result.msg);
  }

  
}
//Mini Cart
$(".header-bottom .cart, .order_summary .edit").click(function(){
     Core.ajax({
         type: "POST",
         dataType: "json",
         url: "/cart/get-cart",
         data: $(this).serialize(),
         done: function (result) {
             update_cart(result);
             $("#mini_cart").fadeIn();
            $("#mini_cart").addClass("open");
            $("body").addClass("modal_open");
         }
     });
    
});
$('#mini_cart').click(function(){
    $("#mini_cart").fadeOut();
    $("#mini_cart").removeClass("open");
    $("body").removeClass("modal_open");
});
// $('html').on('click',".close_cart",function(){
//     $("#mini_cart").fadeOut();
//     $("#mini_cart").removeClass("open");
//     $("body").removeClass("modal_open");
// });
$(".mini_cart").on('click', function(event) {
    event.stopPropagation();
});

//Agent detail Close
$(".add-cart .btns.adding").on('click', function(event){   
  $(this).addClass('close'); 
  $(this).fadeOut();
  $(this).next('.qty').addClass('open'); 
  $(this).next('.qty').fadeIn(); 
});

//Sticky Sidebar
/*
 Sticky-kit v1.1.2 | MIT | Leaf Corcoran 2015 | http://leafo.net
*/
(function(){var c,f;c=this.jQuery||window.jQuery;f=c(window);c.fn.stick_in_parent=function(b){var A,w,B,n,p,J,k,E,t,K,q,L;null==b&&(b={});t=b.sticky_class;B=b.inner_scrolling;E=b.recalc_every;k=b.parent;p=b.offset_top;n=b.spacer;w=b.bottoming;null==p&&(p=0);null==k&&(k=void 0);null==B&&(B=!0);null==t&&(t="is_stuck");A=c(document);null==w&&(w=!0);J=function(a){var b;return window.getComputedStyle?(a=window.getComputedStyle(a[0]),b=parseFloat(a.getPropertyValue("width"))+parseFloat(a.getPropertyValue("margin-left"))+
parseFloat(a.getPropertyValue("margin-right")),"border-box"!==a.getPropertyValue("box-sizing")&&(b+=parseFloat(a.getPropertyValue("border-left-width"))+parseFloat(a.getPropertyValue("border-right-width"))+parseFloat(a.getPropertyValue("padding-left"))+parseFloat(a.getPropertyValue("padding-right"))),b):a.outerWidth(!0)};K=function(a,b,q,C,F,u,r,G){var v,H,m,D,I,d,g,x,y,z,h,l;if(!a.data("sticky_kit")){a.data("sticky_kit",!0);I=A.height();g=a.parent();null!=k&&(g=g.closest(k));if(!g.length)throw"failed to find stick parent";
v=m=!1;(h=null!=n?n&&a.closest(n):c("<div />"))&&h.css("position",a.css("position"));x=function(){var d,f,e;if(!G&&(I=A.height(),d=parseInt(g.css("border-top-width"),10),f=parseInt(g.css("padding-top"),10),b=parseInt(g.css("padding-bottom"),10),q=g.offset().top+d+f,C=g.height(),m&&(v=m=!1,null==n&&(a.insertAfter(h),h.detach()),a.css({position:"",top:"",width:"",bottom:""}).removeClass(t),e=!0),F=a.offset().top-(parseInt(a.css("margin-top"),10)||0)-p,u=a.outerHeight(!0),r=a.css("float"),h&&h.css({width:J(a),
height:u,display:a.css("display"),"vertical-align":a.css("vertical-align"),"float":r,"z-index":"-9"}),e))return l()};x();if(u!==C)return D=void 0,d=p,z=E,l=function(){var c,l,e,k;if(!G&&(e=!1,null!=z&&(--z,0>=z&&(z=E,x(),e=!0)),e||A.height()===I||x(),e=f.scrollTop(),null!=D&&(l=e-D),D=e,m?(w&&(k=e+u+d>C+q,v&&!k&&(v=!1,a.css({position:"fixed",bottom:"",top:d}).trigger("sticky_kit:unbottom"))),e<F&&(m=!1,d=p,null==n&&("left"!==r&&"right"!==r||a.insertAfter(h),h.detach()),c={position:"",width:"",top:""},a.css(c).removeClass(t).trigger("sticky_kit:unstick")),
B&&(c=f.height(),u+p>c&&!v&&(d-=l,d=Math.max(c-u,d),d=Math.min(p,d),m&&a.css({top:d+"px"})))):e>F&&(m=!0,c={position:"fixed",top:d},c.width="border-box"===a.css("box-sizing")?a.outerWidth()+"px":a.width()+"px",a.css(c).addClass(t),null==n&&(a.after(h),"left"!==r&&"right"!==r||h.append(a)),a.trigger("sticky_kit:stick")),m&&w&&(null==k&&(k=e+u+d>C+q),!v&&k)))return v=!0,"static"===g.css("position")&&g.css({position:"relative"}),a.css({position:"absolute",bottom:b,top:"auto"}).trigger("sticky_kit:bottom")},
y=function(){x();return l()},H=function(){G=!0;f.off("touchmove",l);f.off("scroll",l);f.off("resize",y);c(document.body).off("sticky_kit:recalc",y);a.off("sticky_kit:detach",H);a.removeData("sticky_kit");a.css({position:"",bottom:"",top:"",width:""});g.position("position","");if(m)return null==n&&("left"!==r&&"right"!==r||a.insertAfter(h),h.remove()),a.removeClass(t)},f.on("touchmove",l),f.on("scroll",l),f.on("resize",y),c(document.body).on("sticky_kit:recalc",y),a.on("sticky_kit:detach",H),setTimeout(l,
0)}};q=0;for(L=this.length;q<L;q++)b=this[q],K(c(b));return this}}).call(this);

$(function() {
	return $("[data-sticky_column]").stick_in_parent({
		parent: "[data-sticky_parent]"
	});
});

// Product Detail
$('.thumbs').owlCarousel({
    loop:false, scrollPerPage: true, margin:5, nav:true, dots:false, responsiveClass:true, mouseDrag: false, autoplay:false, responsiveClass: true,
    responsive: {
      0: {items: 4},480: {items: 4}, 1000: {items: 5}
    }
});



//Product Popup
$('#image_preview').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: true,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    image: {
      verticalFit: true,            
    },
    gallery: {
      enabled: true
    },
    zoom: {
      enabled: true,
      duration: 300,
      opener: function(element) {
        return element.find('img');
      }
    }    
});

//Product Image Replace
$('.thumbs .item').click(function(){
    var imgpath = $(this).attr('data-image');
    $('#image_preview').html('<a href='+imgpath+'><img src='+imgpath+'></a>');
});

//Product Image Active
$('.thumbs .item').click(function() {
    $('.thumbs .item.active').removeClass('active');
    $(this).addClass('active');
});

// Ratings
jQuery(function() {
    jQuery('.starbox').each(function() {
      var starbox = jQuery(this);
      starbox.starbox({
        average: starbox.attr('data-start-value'),
        changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
        ghosting: starbox.hasClass('ghosting'),
        autoUpdateAverage: starbox.hasClass('autoupdate'),
        buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
        stars: starbox.attr('data-star-count') || 5
      }).bind('starbox-value-changed', function(event, value) {
        if(starbox.hasClass('random')) {
          var val = Math.random();
          starbox.next().text('Random: '+val);
          return val;
        } else {
          $('input[name="'+$(this).attr('data-input-name')+'"]').val(value);
        }
      }).bind('starbox-value-moved', function(event, value) {
        if($(this).hasClass('dragupdate')) {
         $('input[name="'+$(this).attr('data-input-name')+'"]').val(value);
       }
      });
    });
  });


  
/*equal height*/
( function( $, window, document, undefined ){
	'use strict';
	var $list		= $( '.equal' ),
		$items		= $list.find( '.height' ),
		setHeights	= function()
	    {
			$items.css( 'height', 'auto' );
			var perRow = Math.floor( $list.width() / $items.width() );
			if( perRow == null || perRow < 2 ) return true;
			for( var i = 0, j = $items.length; i < j; i += perRow )
			{
				var maxHeight	= 0,
					$row		= $items.slice( i, i + perRow );

				$row.each( function()
				{
					var itemHeight = parseInt( $( this ).outerHeight() );
					if ( itemHeight > maxHeight ) maxHeight = itemHeight;
				});
				$row.css( 'height', maxHeight );
			}
		};	
	setHeights();
	$( window ).on( 'resize', setHeights );	
})( jQuery, window, document );


//Overflow Menu

if ($(window).width() > 768){

window.onresize = navigationResize;
navigationResize();

  function navigationResize() {  
    $('.site_menu ul li.more').before($('#overflow > li'));
    
    var $navItemMore = $('.site_menu ul > li.more'),
        $navItems = $('.site_menu ul > li:not(.more)'),
        navItemMoreWidth = navItemWidth = $navItemMore.width(),
        windowWidth = $(".site_menu").width(),
        navItemMoreLeft, offset, navOverflowWidth;
    
    $navItems.each(function() {
      navItemWidth += $(this).width();
    });
    
    navItemWidth > windowWidth ? $navItemMore.show() : $navItemMore.hide();
      
    while (navItemWidth > windowWidth) {
      navItemWidth -= $navItems.last().width();
      $navItems.last().prependTo('#overflow');
      $navItems.splice(-1,1);
    }

    if(typeof($('.site_menu ul .more').offset())!='undefined'){
      navItemMoreLeft = $('.site_menu ul .more').offset().left;
      navOverflowWidth = $('#overflow').width();  
      offset = navItemMoreLeft + navItemMoreWidth - navOverflowWidth;
    } 
  }
  
}

/* Go to top */
if ($('#back-to-top').length) {
  var scrollTrigger = 100, // px
      backToTop = function () {
          var scrollTop = $(window).scrollTop();
          if (scrollTop > scrollTrigger) {
              $('#back-to-top').addClass('show');
          } else {
              $('#back-to-top').removeClass('show');
          }
      };
  backToTop();
  $(window).on('scroll', function () {
      backToTop();
  });
  $('#back-to-top').on('click', function (e) {
      e.preventDefault();
      $('html,body').animate({
          scrollTop: 0
      }, 700);
  });
}
//Mobile filter
$("#mob-filter").on('click', function() {
  $(".filters").fadeIn().addClass("open");
  $("body").addClass("open");
  $("#close-filter").show();
});

$("#close-filter").on('click', function() {
  $(".filters").fadeOut().removeClass("open");
  $("body").removeClass("open");
  $("#close-filter").hide();
});

// Slider 
$('#slider').owlCarousel({
  loop:true,
  margin:10,
  nav:true,
  items: 1
})