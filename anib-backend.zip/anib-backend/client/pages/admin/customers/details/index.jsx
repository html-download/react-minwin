'use strict';
const Actions = require('./actions');
const DeleteForm = require('./delete-form.jsx');
const CustomerDetailsForm = require('./customer-info/index');
const DrivingDetailsForm = require('./driving-detail/index');
const CreateDeal = require('../../deals/new-deal/create-new-deal');
const PropTypes = require('prop-types');
const React = require('react');

const ReactRouter = require('react-router-dom');
const Store = require('./store');
const TaskForm = require('./task-form');


const Link = ReactRouter.Link;
const propTypes = {
    history: PropTypes.object,
    match: PropTypes.object
};



class DetailsPage extends React.Component {

    constructor(props) {

        super(props);
        Actions.getDetails(this.props.match.params.id);
        this.state = Store.getState();
        this.input = {};
        this.els = {};
        this.callBackFun = this.callBackFun.bind(this);
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentWillUnmount() {

        Actions.resetStore();
        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    callBackFun(data) {

        this.input.customer_name.value = data.name;
    }

    render() {

        let dealCount = 0;
        let policyCount = 0;

        return (

            <section className="page-container">
                <div className="container">
                    <div className="breadcums">
                        <ul className="reset">
                            <li><Link to="/admin">Dashboard</Link></li>
                            <li><Link to="/admin/customers">Customers</Link></li>
                            <li><span className="capitalize" id="customerName">Loading...</span></li>
                        </ul>
                        <button style={ {'display': 'none'} } onClick={ (e) => { Actions.showDeleteModal() }} className="btns outline-danger" data-toggle="modal" data-target="#delete"><i className="fa fa-trash"></i> Delete</button>
                    </div>
                    <div className="single-page-content">
                        <div className="row">
                            <div className="col-md-4">
                                <CustomerDetailsForm
                                    customer_id={this.props.match.params.id}
                                />
                                <DeleteForm
                                    history={this.props.history}
                                    id={this.props.match.params.id}
                                    {...this.state.delete} />
                                <DrivingDetailsForm
                                    customer_id={this.props.match.params.id}
                                />
                                <a href="javascript:" onClick={ (e) => {Actions.showDealModal() }} className="btn btn-primary btn-block mt-4">Create New Enquiry</a>
                            </div>
                            <div className="col-md-8">
                                <div className="white-box">
                                    <div className="customer-deals row">
                                        <div className="col-md-6">
                                            <h3 className="counter-head"><span className="count">{this.state.common.deals_data.length}</span> Open Enquiries</h3>
                                            <ul className="list-deals reset">
                                                {
                                                    this.state.common.deals_data.map((record) => {

                                                        dealCount++;
                                                        if (dealCount <= 2) {
                                                            return (
                                                                <li key={record.deal_key}>
                                                                    <a href="javascript:" onClick={ (e) => { this.props.history.push(`/admin/deals/${record.deal_key}`) } }>
                                                                        <div className="box">
                                                                            <div className="icon"><i className="fa fa-car"></i></div>
                                                                            <p>{record.customer_name} ({record.vehicle_brand})</p>
                                                                        </div>
                                                                    </a>
                                                                </li>
                                                            );
                                                        }
                                                    })
                                                }
                                                { (this.state.common.deals_data.length === 0) ? <li className="empty">Enquiries are empty..</li> : '' }
                                            </ul>
                                        </div>
                                        <div className="col-md-6">
                                            <h3 className="counter-head"><span className="count">{this.state.common.policy_data.length}</span> Active Policies</h3>
                                            <ul className="list-policy reset">
                                                {
                                                    this.state.common.policy_data.map((record) => {
                                                        
                                                        policyCount++;
                                                        if (policyCount <= 1) {
                                                            return (
                                                                <li key={record.deal_quote_key}>
                                                                    <div className="box">
                                                                        <div className="fly_image"><img src={record.insurence_product_image} /></div>
                                                                        <h5>{record.insurence_product_name}</h5>
                                                                        <p>Sum Insured: {record.vehicle_insured_value}</p>
                                                                        <p>{record.policy_start_date} - {record.policy_expire_date}</p>
                                                                    </div>
                                                                </li>
                                                            );
                                                        }
                                                    })
                                                }
                                                { (this.state.common.policy_data.length === 0) ? <li className="empty"> Policies are empty..</li> : '' }
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div className="white-box mt-30">
                                    <TaskForm
                                        history={this.props.history}
                                        common={this.state.common}
                                        id={this.props.match.params.id}
                                        {...this.state.taskDetails}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <CreateDeal
                    history={this.props.history}
                    location={this.props.location}
                    from_customer={true}
                    customer_id={this.state.details.customer_details.customer_key}
                    customer_type={this.state.details.customer_details.customer_type}
                    createDeal={this.state.details.createDeal}
                    parentAction={Actions}
                    searchData={this.els.filters ? this.els.filters.state : undefined}
                />
            </section>
        );
    }
}

DetailsPage.propTypes = propTypes;

module.exports = DetailsPage;