'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');


const initialState = {
    hydrated: false,
    loading: false,
    error: undefined,
    clients: [],
    data: [],
    pages: {},
    items: {}
};
const reducer = function (state = initialState, action) {

    if (action.type === Constants.GET_CLIENT_LOT_RESULTS) {
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true
        });
    }

    if (action.type === Constants.GET_CLIENT_LOT_RESULTS_RESPONSE) {
        return ObjectAssign({}, state, {
            hydrated: true,
            loading: false,
            clients: action.response,/*
            data:[],
            pages: action.response.pages,
            items: action.response.items*/
        });
    }

    if (action.type === Constants.GET_LOT_RESULTS) {
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true
        });
    }

    if (action.type === Constants.GET_LOT_RESULTS_RESPONSE) {
        console.log("action.response", action.response.lots);
        return ObjectAssign({}, state, {
            hydrated: true,
            loading: false,
            data: action.response.lots/*,
            pages: action.response.pages,
            items: action.response.items*/
        });
    }

    return state;
};


module.exports = reducer;
