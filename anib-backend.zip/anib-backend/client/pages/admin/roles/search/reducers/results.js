'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const Paginations = require('../../../../../helpers/paginations');

const initialState = {
    hydrated: false,
    loading: false,
    list_loading: true,
    error: undefined,
    data: [],
    pages: {},
    items: {}
};

const role_data = [{
    role_name: "Lead Generator",
    role_key: "9bf09eb5-f33c-4c73-8616-3346546546646",
    role_id: 1
}, {
    role_name: "Account Executive",
    role_key: "9bf09eb5-f33c-4c73-8616-4656436456666",
    role_id: 2
}, {
    role_name: "Bill Collector",
    role_key: "9bf09eb5-f33c-4c73-8616-5353535435555",
    role_id: 3
}, {
    role_name: "Technical Executives",
    role_key: "9bf09eb5-f33c-4c73-8616-5464665666545",
    role_id: 4
}, {
    role_name: "Technical Managers",
    role_key: "9bf09eb5-f33c-4c73-8616-7575633456665",
    role_id: 5
}]
const reducer = function (state = initialState, action) {

    if (action.type === Constants.GET_RESULTS) {
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true,
            list_loading: true
        });
    }

    if (action.type === Constants.GET_RESULTS_RESPONSE) {

        const headers = action.response ? action.response.headers : {};

        const data = {
            current_page: headers['x-pagination-current-page'] ? headers['x-pagination-current-page'] : 0,
            page_count: headers['x-pagination-page-count'] ? headers['x-pagination-page-count'] : 0,
            per_page: headers['x-pagination-per-page'] ? headers['x-pagination-per-page'] : 0,
            total_count: headers['x-pagination-total-count']  ? headers['x-pagination-total-count'] : 0 
        };        

        return ObjectAssign({}, state, {
            hydrated: true,
            loading: false,
            list_loading: false,
            data: action.response.data,
            pages: Paginations.pages(data)
        });
    }

    return state;
};


module.exports = reducer;
