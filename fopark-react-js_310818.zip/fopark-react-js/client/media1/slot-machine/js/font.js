var Font =
{
    Format : function(amt)
    {
        var s = amt.toFixed(0);
        var x = /(\d+)(\d{3})/;

        while (x.test(s))
        {
            s = s.replace(x, "$1,$2");
        }

        return s;
    },

    Write : function(id, font, text)
    {
        let Obj;
        if (text.length == 0)
        {
            Obj(id).innerHTML = "";
            return;
        }

        var h = "";
        var l = text.split("\n");

        for (var i = 0; i < l.length; i++)
        {
            for (var x = 0; x < l[i].length; x++)
            {
                var c = l[i].charCodeAt(x);

                h += '<img alt="" class="font_' + font + ' font_' + font + '_' + c + '" src="trans.gif">';
            }

            if (i < (l.length - 1))
            {
                h += "<br />";
            }
        }

        Obj(id).innerHTML = h;
    }
};
