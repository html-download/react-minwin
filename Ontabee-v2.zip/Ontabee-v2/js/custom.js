$(document).ready(function() {

  // masaary grid
 var options = {minMargin: 15, maxMargin: 15, itemSelector: ".effetct-gallery"};
  $(".container-masanry").rowGrid(options);

// zoom gallery

$('.effetct-gallery').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    image: {
      verticalFit: true,
      titleSrc: function(item) {

      }
    },
    gallery: {
      enabled: true
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
        return element.find('img');
      }
    }
    
  });


// rating pluign

 $(".rateYo").rateYo({
  precision: 2,
  spacing: "3px",
  starWidth: "25px",
   normalFill: "#888888"
 });


/*Equal Height*/
( function( $, window, document, undefined ){
   'use strict';
   var $list      = $('.equal'),
      $items      = $list.find( '.height'),
      setHeights  = function()
       {
         $items.css( 'height', 'auto' );
         var perRow = Math.floor( $list.width() / $items.width() );
         if( perRow == null || perRow < 2 ) return true;
         for( var i = 0, j = $items.length; i < j; i += perRow )
         {
            var maxHeight  = 0,
               $row     = $items.slice( i, i + perRow );

            $row.each( function()
            {
               var itemHeight = parseInt( $( this ).outerHeight() );
               if ( itemHeight > maxHeight ) maxHeight = itemHeight;
            });
            $row.css( 'height', maxHeight );
         }
      }; 
   setHeights();
   $( window ).on( 'resize', setHeights );   
})( jQuery, window, document );  


   // loader
   $('.loader').on('click', function() {
      var $this = $(this);
      var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
      if ($(this).html() !== loadingText) {
         $this.data('original-text', $(this).html());
         $this.html(loadingText);
      }
      setTimeout(function() {
         $this.html($this.data('original-text'));
      }, 2000);
   });
   // cuisines-slider
   $('.cuisines-slider').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      autoplay: true,
      autoPlaySpeed: 3000,
      autoWidth:true,
      autoPlayTimeout: 3000,
      navText: ["<i class='lni-chevron-left'></i>", "<i class='lni-chevron-right'></i>"]
   })
   // banner-slider
   $('.banner-slider').owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      autoplay: true,
      autoPlaySpeed: 3000,
      autoPlayTimeout: 3000,
      navText: ["<i class='lni-chevron-left'></i>", "<i class='lni-chevron-right'></i>"],
      responsive: {
         0: {
            items: 1
         },
         600: {
            items: 1
         },
         1000: {
            items: 1
         }
      }
   })

// cuisine slider
   $('.re-slider').owlCarousel({
      loop: true,
      margin: 0,
      nav: true,
       autoWidth:true,
      navText: ["<i class='lni-chevron-left'></i>", "<i class='lni-chevron-right'></i>"],
      responsive: {
         0: {
            items: 2
         },
         600: {
            items: 2
         },
         1000: {
            items: 2
         },
         1600: {
            items: 2
         }
      }
   })



   // map click show
   $('.delivery-address .form-control').click(function() {
      $('.map-box').addClass('d-inline-block');
      $('.delivery-address').addClass('d-none');
      $('.our-cuisines').addClass('d-none');
      $('.code').addClass('d-none');
     
   });
   $('.map-box .clear').click(function() {
      $('.map-box').removeClass('d-inline-block');
      $('.delivery-address').removeClass('d-none');
      $('.our-cuisines').removeClass('d-none');
      $('.code').removeClass('d-none');
   });


//Modal
   $('.modal').on('hidden.bs.modal', function () {
      if($('.modal').hasClass('show')) {
         $('body').addClass('modal-open');
      }    
   });

// modal show
  // window.setTimeout(function () {
  //       $("#login_modal").modal("show");
  //   }, 3000);


// smooth scroll


   jQuery('.nav-link-items .navs').onePageNav({
    currentClass: 'active',
    changeHash: false,
    scrollSpeed: 500,
    //scrollOffset: 140,
    scrollThreshold: 0.5,
    filter: ''
});


// sticky side

  $('.cart-side').stickySidebar({
      topSpacing: 140,
      bottomSpacing: 10,
      minWidth: 993,
      innerWrapperSelector: '.menu-item-left',
      });



  $('.stick-cart').stickySidebar({
      topSpacing: 100,
      bottomSpacing: 10,
      minWidth: 1200,
      innerWrapperSelector: '.stick-left-content',
      });

// menu toggle
$(".sideNavigation, .nav-mobil-hide, .nav-link-items ul a, .sidemenu_bg").click(function() {
  $(".nav-link-items").toggleClass('open'); 
  $("body").toggleClass('hide-overflow'); 
  $(".sidemenu_bg").toggleClass('open'); 
  
});

// cart toggle
$(".reviewOrder, .nav-mobil-minicart-hide, .mini_cart_bg").click(function() {
  $(".cart-side").toggleClass('open'); 
  $("body").toggleClass('hide-overflow'); 
  $(".mini_cart_bg").toggleClass('open'); 
});





});





// responsive js

$(document).ready(function() {
    var $window = $(window);

    function checkWidth() {
        var windowsize = $window.width();
        if (windowsize > 1000) {

     
         //Overflow Menu
window.onresize = navigationResize;
navigationResize();
function navigationResize() {
  $('.nav-link-items ul li.more').before($('#overflow > li'));
  var $navItemMore = $('.nav-link-items ul > li.more'),
    $navItems = $('.nav-link-items ul > li:not(.more)'),
    navItemMoreWidth = navItemWidth = $navItemMore.width(),
    windowWidth = $(".nav-link-items .navs").width(),
    navItemMoreLeft, offset, navOverflowWidth;
  $navItems.each(function() {
    navItemWidth += $(this).width();
  });
  navItemWidth > windowWidth ? $navItemMore.show() : $navItemMore.hide();
  while (navItemWidth > windowWidth) {
    navItemWidth -= $navItems.last().width();
    $navItems.last().prependTo('#overflow');
    $navItems.splice(-1, 1);
  }
  navItemMoreLeft = $('.nav-link-items ul .more').offset().left;
  navOverflowWidth = $('#overflow').width();
  offset = navItemMoreLeft + navItemMoreWidth - navOverflowWidth;
}





        }
    }
    // Execute on load
    checkWidth();
    // Bind event listener
    $(window).resize(checkWidth);
})