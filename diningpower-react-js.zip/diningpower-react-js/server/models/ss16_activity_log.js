/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16ActivityLog', {
    logId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'log_id'
    },
    logUserId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'log_user_id'
    },
    logUsername: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'log_username'
    },
    logUserType: {
      type: DataTypes.ENUM('admin','vendor','customer'),
      allowNull: false,
      defaultValue: 'admin',
      field: 'log_user_type'
    },
    logAction: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'log_action'
    },
    logIp: {
      type: DataTypes.STRING(30),
      allowNull: false,
      field: 'log_ip'
    },
    logDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'log_datetime'
    }
  }, {
    tableName: 'ss16_activity_log'
  });
};
