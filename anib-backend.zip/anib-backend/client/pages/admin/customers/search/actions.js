/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const CommonFunctions = require('../../../../helpers/common-functions');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../helpers/toaster');
const Qs = require('qs');


class Actions {

    static getResults(data) {
        data['is_pagination'] = 1;
        ApiActions.get(
            '/customer',
            data,
            Store,
            Constants.GET_RESULTS,
            Constants.GET_RESULTS_RESPONSE
        );
    }

    static getNationalityResults() {
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }

    static changeSearchQuery(data, history) {

        history.push({
            pathname: '/admin/customers',
            search: `?${Qs.stringify(data)}`
        });

        window.scrollTo(0, 0);
    }

    static showCreateCustomer() {
        
        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW
        });
    }

    static hideCreateCustomer() {
        
        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }    

    static createNew(data, history, searchData) {        

        ApiActions.post(
            '/customer',
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {                

                if (!err) {
                    Toaster.success('Customer saved successfully!');
                    
                    this.hideCreateNew();

                    this.changeSearchQuery(searchData, history);
                }
            }
        );
    }

    static updateDOB(date) {
        
        Store.dispatch({
            type: Constants.UPDATE_DOB,
            date: date
        });

    }

    static getUserTypes() {
        
        ApiActions.get(
            '/user/types',
            undefined,
            Store,
            Constants.GET_USER_TYPES,
            Constants.GET_USER_TYPES_RESPONSE
        );
    }
}


module.exports = Actions;
