'use strict';
const Form = require('./form.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');

const Link = ReactRouter.Link;

const Helmet = ReactHelmet.Helmet;


class ContactPage extends React.Component {
    componentDidMount() {    
    window.scrollTo(0, 0);
  }
    render() {

        return (
            <section >
                <Helmet>
                    <title>Contact us</title>
                </Helmet>
                <section className="empty-banner">
                </section>

                <section className="light_bg upload_details">
                    <div className="container">
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                 <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                               <li className="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                            </ol>
                        </nav>

                        <h2 className="blue-heading sub-heading">Contact Us</h2>
                        <div className="white-box-shadow text-center contact contents">
                            
                            <div className="box-container">
                                <div className="row">
                                    <Form />
                                    <div className="col-md-4 ">
                                        <div className="contact_info">
                                        <h5>Contact Info</h5>
                                       <ul className="reset">
                                        <li><i className="icon-location-pin"></i><b>Location</b>
                                            JV Building, 2/3 &amp; 2/4 Mullai Nagar, 
                                            <br/>Maruthamalai Main Road,
                                             <br/>Vadavalli, Coimbatore - 641041,
                                              <br/>Tamil Nadu, India.
                                          </li>
                                         <li><i className="icon-phone"></i>
                                            <b>Customer Care</b>
                                            <a href="tel:+91-9686869685">+91-9686869685</a>
                                          </li>
                                           <li><i className="icon-envelope"></i>
                                            <b>Self Support</b>
                                            <a href="mailto:support@support.com">support@support.com</a>
                                          </li>
                                           <li><i className="icon-clock"></i>
                                            <b>Opening Hours</b>
                                            <a href="mailto:support@support.com">support@support.com</a>
                                          </li>
                                       </ul>
                                   </div>
                                    </div>
                                  </div>

                            </div>
                        </div>

                    </div>
                </section>
            </section>
        );
    }
}


module.exports = ContactPage;
