'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const Paginations = require('../../../../../helpers/paginations');

const initialState = {
    hydrated: false,
    loading: false,
    list_loading: true,
    error: undefined,
    data: [],
    pages: {}
};

const reducer = function (state = initialState, action) {
    
    if (action.type === Constants.GET_TASK_RESULTS) {
        
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true,
            list_loading: true
        });
    }

    if (action.type === Constants.GET_TASK_RESULTS_RESPONSE) {

        const headers = action.response ? action.response.headers : {};

        const data = {
            current_page: headers['x-pagination-current-page'] ? headers['x-pagination-current-page'] : 0,
            page_count: headers['x-pagination-page-count'] ? headers['x-pagination-page-count'] : 0,
            per_page: headers['x-pagination-per-page'] ? headers['x-pagination-per-page'] : 0,
            total_count: headers['x-pagination-total-count']  ? headers['x-pagination-total-count'] : 0 
        };

        return ObjectAssign({}, state, {
            hydrated: true,
            loading: false,
            list_loading: false,
            data: action.response ? action.response.data : tempTasks,
            pages: Paginations.pages(data)
        });
    }    

    return state;
};


module.exports = reducer;
