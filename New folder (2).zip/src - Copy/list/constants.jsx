module.exports = require('flux-constants')([
  "REQUEST",
]);
