'use strict';
const Actions = require('./actions');
const Store = require('./store');
const Constants = require('./constants');
const CommonHelper = require('../../../../helpers/common-functions');
const CreateNoteForm = require('./notes/create-note-form.jsx');
const Notes = require('./notes/index.jsx');
const ViewPolicy = require('../../policies/search/view-form');
const Modal = require('../../../../components/modal.jsx');
const UploadFile = require('../../../../helpers/aixos-ajax');
const PropTypes = require('prop-types');
const React = require('react');
const ReactSelectControl = require('../../../../components/form/react-select-control.jsx');
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';



const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,    
};


class TaskForm extends React.Component {
    constructor(props) {

        super(props);

        this.toggle = this.toggle.bind(this);
        
        this.state = {
            activeTab: '1',
            deals_data : []
        };

        this.removeDocu = this.removeDocu.bind(this);
        this.removeNote = this.removeNote.bind(this);
    }

    toggle(tab) {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }

    componentWillReceiveProps(nextProps) {
        
        this.setState({
            deals_data : nextProps.common.deals_data
        });        
    }

    getStatusTextTableData(id, paid_status, paid_status_text) {
        
        let element;
        if (paid_status === 1) {
            element =  <label className="status green">{paid_status_text}</label>;
        } else {
            element =  <label className="status pink">{paid_status_text}</label>;            
        }

        return element;
    }

    renderNotes() {
                      
        return (this.props.common.customer_notes && this.props.common.customer_notes.length > 0) ? this.props.common.customer_notes.map((record) => {
            return ( <Notes 
                key={`notes-${record.deal_note_key}`}           
                deleteFun={ this.removeNote }
                {...record}
                ></Notes>);
        }) : [];
    }

    handleChoose() {
        
        const data = new FormData();
        data.append('file', this.document.files[0]);
        data.append('deal_id', this.deal_id.value());
        UploadFile.upload('/deal-document',data,Store,Constants.GET_DOCU_RESULT,Constants.GET_DOCU_RESULT_RESPONSE);
    }
    
    removeDocu(document_key) {  

        Actions.deleteDocument(document_key);
    }

    removeNote(note_key) {        

        Actions.deleteNote(note_key,this.props.id);
    }

    renderCustomerDocs() {

        return this.props.common.customer_docs.length > 0 ? this.props.common.customer_docs.map( (value, index) => {
            return (
                <div className="col-sm-12">
                    <div className="box">
                        <div className="icon"><i className="fa fa-file-pdf-o"></i></div>
                        <a href={value.deal_document_path} target="_blank" className="add-forms editable editable-click">{ value.deal_document_name }</a>
                        <p className="date">{value.created_at}</p>
                        <a href="javascript:" onClick={ (e) => this.removeDocu(value.deal_document_key)  } className="remove"><i className="fa fa-trash"></i> Remove</a>
                    </div>
                </div>
            )
        }) : '';
    }
    
    render() {                                

        const records = this.props.common.deals_data.map((row) => {
                return (
                    <tr key={row.deal_key} onClick={ (e) => { this.props.history.push(`/admin/deals/${row.deal_key}`) } }>
                        <td>{row.stage}</td>
                        <td> 
                            { this.getStatusTextTableData(row.deal_key, row.deal_payment_status, row.deal_payment_status_text) }
                        </td>
                        <td>{row.vehicle_brand}</td>
                        <td><a href="javascript:">{row.customer_name}</a></td>
                        <td>{row.created_at}</td>
                    </tr>
                );
            });                                   
        return (
          <div className={classnames({ 'cs-tab': true })}>
            <Nav tabs >
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '1' })}
                  onClick={() => { this.toggle('1'); }}
                >
                  All
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '2' })}
                  onClick={() => { this.toggle('2'); }}
                >
                  Notes
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '3' })}
                  onClick={() => { this.toggle('3'); }}
                >
                  Documents
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '4' })}
                  onClick={() => { this.toggle('4'); }}
                >
                  Enquiries
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '5' })}
                  onClick={() => { this.toggle('5'); }}
                >
                  Policies
                </NavLink>
              </NavItem>
            </Nav>
            <TabContent activeTab={this.state.activeTab} className={classnames({ 'tab-content': true} )}>
                <TabPane tabId="1">
                    <div className="btn-group-2">
                        <button className="btn btn-secondary"  onClick={ (e) => { Actions.addNoteModal() } }>Add Note</button>
                        <button className="btn btn-secondary" onClick={() => { this.toggle('3'); }}>Add Documents</button>
                    </div>

                    <div className="row">
                        <div className="col-md-6">                            
                            <div className={ `upload-listing mt-30 cus doc ${this.props.common.customer_notes_loading ? 'loader-tab-content' : ''}` }>
                                { this.props.common.customer_notes.length > 0 ? <h6>Customer Notes</h6> : <p className="empty"> Customer notes are empty..</p> }
                                { this.renderNotes() }
                            </div>
                        </div>
                        <div className="col-md-6">
                            <div className={ `upload-listing mx400 mt-30 cus doc ${this.props.common.customer_docs_loading ? 'loader-tab-content' : ''}` }>
                                { this.props.common.customer_docs.length > 0 ? <h6>Customer Deal Documents</h6> : <p className="empty"> Customer deal documents are empty..</p> }
                            <div className="row">{ this.renderCustomerDocs() } </div>                       
                            </div>
                        </div>  
                    </div>
                </TabPane>
                <TabPane tabId="2">
                    <div className="btn-group-2">
                        <button className="btn btn-secondary" onClick={ (e) => { Actions.addNoteModal() } }>Add Note</button>                        
                    </div>
                    <div className={ `upload-listing mt-30 cus doc ${this.props.common.customer_notes_loading ? 'loader-tab-content' : ''}` }>     
                        { this.props.common.customer_notes.length > 0 ? <h6>Customer Notes</h6> : ''}
                        { this.renderNotes() }
                    </div>
                </TabPane>
                <TabPane tabId="3">
                    <ReactSelectControl
                        ref={(input) => { this.deal_id = input; }}
                        name="deal_id"
                        label="Deal"
                        defaultValue={this.state.deal_id}
                        onChange={ (e) => { }}
                        disabled={ this.props.loading }
                        groupClasses={ { 'rq': true } }
                        inputClasses={ { 'select-modal': true } }
                        labelClasses={ { 'left-side': true, 'control-label': false, 'req': true } }
                        options={CommonHelper.getOptionData(this.props.common.deals_data, 'deal_key', 'deal_number')}
                    />
                    <input className="hidden" type="file" onChange={(e) => this.handleChoose(e)} id="file" ref={(input) => { this.document = input; }}/>
                    <label className="drag-files" htmlFor="file">
                        Drag Files here or click to upload
                    </label>
                    
                    <div className={ `upload-listing cus doc-list ${this.props.common.customer_docs_loading ? 'loader-tab-content' : ''}` }>
                        { this.props.common.customer_docs.length > 0 ? <h6>Customer Deal Documents</h6> : '' }
                        <div className="row">{ this.renderCustomerDocs() }  </div>                      
                    </div> 
                </TabPane>
                <TabPane tabId="4">
                     <div className="table-responsive">
                        <table className="table white_table">
                            <thead>
                                <tr>
                                    <th>Stage</th>
                                    <th>Status</th>
                                    <th>Vehicle</th>
                                    <th>User</th>
                                    <th>Created On</th>
                                </tr>
                            </thead>
                            {
                                this.props.deals_data_loading ? (
                                    <tbody>
                                        <tr key='0'>
                                            <td colSpan={5} className="text-center loader-tab-content">
                                                loading...
                                            </td>
                                        </tr>
                                        <tr key='1'>
                                            <td colSpan={5} className="text-center loader-tab-content">
                                                loading...
                                            </td>
                                        </tr>
                                        <tr key='2'>
                                            <td colSpan={5} className="text-center loader-tab-content">
                                                loading...
                                            </td>
                                        </tr>
                                        <tr key='3'>
                                            <td colSpan={5} className="text-center loader-tab-content">
                                                loading...
                                            </td>
                                        </tr>
                                        <tr key='4'>
                                            <td colSpan={5} className="text-center loader-tab-content">
                                                loading...
                                            </td>
                                        </tr>
                                    </tbody>
                                ) : (
                                    <tbody>
                                        {records}
                                    </tbody>
                                )
                            }
                            {
                                
                            }                            
                        </table>

                    </div>
                </TabPane>
                <TabPane tabId="5">
                    <div className="table-responsive">

                        <table className="table white_table">
                            <thead>
                                <tr>
                                    <th>Policy</th>
                                    <th>Status</th>
                                    <th>Enquiry</th>
                                    <th>Premium</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.props.common.policy_data.map((record) => {
                                        
                                        return (
                                            <tr key={record.deal_quote_key}>
                                                <td>
                                                    <div className="table-policy">
                                                        <div className="fly_image"><img src={record.insurence_product_image} /></div>
                                                        <a href="javascript:">{record.policy_number}</a>
                                                        <p>{record.policy_start_date} - {record.policy_expire_date}</p>
                                                        <label className="renewal">Renewal in {record.expiry_days} days</label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label className="status green">Paid</label>
                                                </td>
                                                <td>
                                                    <a href="javascript:" onClick={(e) => {Actions.getPolicy(record.deal_quote_key)}}>
                                                        {record.deal_number}
                                                    </a>
                                                </td>
                                                <td> {record.premium_value}</td>
                                            </tr>
                                        );
                                    })
                                }
                                <tr>
                                    <td colSpan="4">
                                        { (this.props.common.policy_data.length === 0) ? <span className="empty">Policies are empty..</span> : '' }
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </TabPane>
            </TabContent>
            <CreateNoteForm
                history={this.props.history}
                id={this.props.id}
                deals_data={this.props.common.deals_data}
                {...this.props} />
            <ViewPolicy
                is_view_policy = {this.props.common.is_view_policy}
                Actions = {Actions}
                {...this.props.common.policy_detail}
            />
          </div>
        );
      }
}

TaskForm.propTypes = propTypes;


module.exports = TaskForm;
