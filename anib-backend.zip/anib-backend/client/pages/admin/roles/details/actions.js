/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');


class Actions {
    static getDetails(id) {     

        ApiActions.get(
            `/role/${id}`,
            undefined,
            Store,
            Constants.GET_DETAILS,
            Constants.GET_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        document.getElementById('roleNameTag').innerHTML = response.data.role_name;
                    }
                }
            }
        );
    }

    static hideDetailsSaveSuccess() {

        Store.dispatch({
            type: Constants.HIDE_DETAILS_SAVE_SUCCESS
        });
    }

    static delete(id, history) {

        ApiActions.delete(
            `/user/${id}`,
            undefined,
            Store,
            Constants.DELETE,
            Constants.DELETE_RESPONSE,
            (err, response) => {

                if (!err) {
                    history.push('/admin/users');

                    window.scrollTo(0, 0);
                }
            }
        );
    }
}


module.exports = Actions;
