'use strict';

const Actions = require('./actions');
const CommonStore = require('../../../../common-store/store');
const ProductInfoForm = require('./product-info-form');
const ProductInfoBox = require('./product-info-box');
const QuoteModal = require('./send-quote-modal');
const React = require('react');
const Store = require('./store');



class NewDeal extends React.Component {

    constructor(props) {

        super(props);
        this.state = Store.getState();

        this.loadDeal = this.loadDeal.bind(this);
    }

    componentDidMount() {

        this.loadDeal();

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    loadDeal() {

        Actions.getDealQuote({
            deal_id:  this.props.id
        });
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    toggleDeal() {

        Actions.toggleDeal();        
    }

    toggleQuote() {
        
        Actions.toggleQuote();
    }

    openQuoteModal() {
        
        Actions.openQuoteModal();
    }

    render() {

        return (
            <div>
                <div className="wi-content mt-30 full_row">
                    
                    <div className="text-right mb-2"> <a className="link-text collapse-txt" data-toggle="collapse" href="javascript:" onClick={ this.toggleDeal.bind(this) }> { this.state.is_deal_collapsed ? 'Expand' : 'Collapse' } </a> </div>
                    
                    <div className={'genrate-new-quote collapse ' + (this.state.is_deal_collapsed ? 'hide' : 'show')}>
                        {
                            this.state.is_empty ? (
                                <div>
                                    {
                                        this.state.is_quote_create_collapsed ?  (
                                            <div className={'second-box ' + (this.state.is_quote_create_collapsed ? 'open' : 'hide') } >
                                                <h4 className="f20">Create a New Quote</h4>
                                                <p>{ 'Next, let\'s add some products to the quote based on the customer\'s driving and vehicle information' }</p>
                                                <ProductInfoForm
                                                    deal_data={this.props.deal_data}
                                                    info_data={this.state}
                                                    id={this.props.id}
                                                    loadDeal={this.loadDeal}
                                                    loading={this.state.loading}
                                                />
                                                <QuoteModal 
                                                    toggleModal={this.state.is_modal_active}
                                                    toggle={this.props.toggle}
                                                    id={this.props.id}
                                                />
                                            </div>
                                        ) : (
                                            <div className="first-box">
                                                <h4 className="f20">New Enquiry Created</h4>
                                                <p>{ 'Let\'s Start by creating a new quote for the customer' }</p>
                                                <div className="text-center padding-50">
                                                    <button className="btn btn-warning no-shadow big"  onClick={ this.toggleQuote.bind(this) }>Generate New Quote</button>
                                                </div>
                                            </div>
                                        )
                                    }
                                </div>  
                            ) : (
                                <div className={'second-box ' + (this.state.is_quote_create_collapsed ? 'hide' : 'open')+ (this.state.list_loading ? ' loader-tab' : '')} >
                                    <h4 className="f20">Create a New Quote</h4>
                                    <p>{ 'Next, let\'s add some products to the quote based on the customer\'s driving and vehicle information' }</p>
                                    <ProductInfoBox
                                        quote_data={ this.state.quote_data }
                                        deal_quote_request_key={ this.state.deal_quote_request_key }
                                        policy_plans={ this.state.policy_plans }
                                        sendQuoteEvent={ this.openQuoteModal.bind(this) }
                                        id={this.props.id}
                                        toggle={this.props.toggle}
                                        is_policy_modal_active={this.state.is_policy_modal_active}
                                        loadDeal={this.loadDeal}
                                        error={this.error}
                                        list_loading={this.state.list_loading}
                                        selected_plans={this.state.selected_plans}
                                        insurence_product_image={this.state.insurence_product_image}
                                    />
                                    { this.state.is_create ?  (
                                        <ProductInfoForm                                             
                                            info_data={this.state}
                                            id={this.props.id}
                                            loadDeal={this.loadDeal}
                                            loading={this.state.loading}
                                        />
                                    ) : null}
                                    <QuoteModal
                                        toggleModal={this.state.is_modal_active}
                                        toggle={this.props.toggle}
                                        id={this.props.id}
                                    />
                                </div>
                            )
                        }
                    </div>                        
                </div>
            </div>
        );
    }
}
module.exports = NewDeal;
