new WOW().init();

 $('[data-toggle="popover"]').popover();
 $('[data-toggle="tooltip"]').tooltip();

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();
    if (scroll >= 2) {
        $("header").addClass("white");
    } else {
    $("header").removeClass("white");
      }
});
$('.modal').on('hidden.bs.modal', function (e) {
    if($('.modal').hasClass('show')) {
    $('body').addClass('modal-open');
    }    
});
 // $("body").removeClass("modal-open");
// scroll nav

// word limit
$(document).ready(function(){
    var maxLength = 50;
    $(".show-read-more").each(function(){
        var myStr = $(this).text();
        if($.trim(myStr).length > maxLength){
            var newStr = myStr.substring(0, maxLength);
            var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
            $(this).empty().html(newStr);
            $(this).append(' <a href="javascript:void(0);" class="read-more">read more...</a>');
            $(this).append('<span class="more-text">' + removedStr + '</span>');
        }
    });
    $(".read-more").click(function(){
        $(this).siblings(".more-text").contents().unwrap();
        $(this).remove();
    });
});






// sticky side


// sticky responsive size


// remove


// date picker

$(".datepicker").datepicker({
  format: 'yyyy-mm-dd',
  startView: "2",
  getDate: true,
  autoHide:true
});



// change password


$("#changepassword").change(function() {
    if($(this).prop('checked')) {
        $(".show-hide").addClass("open");
    } else {
        $(".show-hide").removeClass("open");
    }
});


// slider

$('.banner_scroll').owlCarousel({
    loop:true,
    margin:0,
    nav:true,
    autoplay:true,
    autoplayTimeout:3000,
    autoplayHoverPause:false,
    navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})

$('#special').owlCarousel({
    loop: false,
    dots: false,
    mouseDrag: false,
    nav: true,
    margin: 20,
    responsiveClass: true,
    responsive: {0: {items: 1}, 640: {items: 1}, 768: {items: 3}, 900: {items: 4}}
});



 // tooltip
$(document).ready(function(){ 
   $(".chosen-select").chosen({
     "disable_search_threshold": 1
   }); 
});


// gallery
$('[data-fancybox="gallery"]').fancybox();


// responsive


// close responsive
$(".header-menu-toggle, .close-menu-toggle, .navigation a, .menu_over").click(function() {
  $(".navigation").toggleClass('open');
  $(".header-menu-toggle").toggleClass('open');
    $("body").toggleClass('overflow');  
    $(".menu_over").toggleClass('in');  
});



// sidebar click scroll

$(".menu-toggle, .sidemenu_over, .sidebar-navigation ul li a").click(function() {
  $(".menu_navigation").toggleClass('open');  
    $("body").toggleClass('overflow');  
    $(".sidemenu_over").toggleClass('in');  
});


// sidebar click scroll

$(".cart-toggle, .cart_over_over, .close-cartmini-mobile").click(function() {
  $(".cart-mini-mobile").toggleClass('open');  
    $("body").toggleClass('overflow');  
    $(".cart_over_over").toggleClass('in');  
});



// sticky responsive size


$(document).ready(function() {
    // Optimalisation: Store the references outside the event handler:
    var $window = $(window);

    function checkWidth() {
        var windowsize = $window.width();
        if (windowsize > 1000) {
         
          $("[data-sticky_column]").stick_in_parent({recalc_every: 1});

    $(function() {
      return $("[data-sticky_column]").stick_in_parent({
        parent: "[data-sticky_parent]"
      });
    });

    // menu click goestoo top

        $('#menu-tab').click(function(e){
        var $target = $('html,body');
        $target.animate({scrollTop: 0}, 100);
    });



        }
    }
    // Execute on load
    checkWidth();
    // Bind event listener
    $(window).resize(checkWidth);
})