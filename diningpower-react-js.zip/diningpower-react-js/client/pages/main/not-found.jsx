const React = require('react');
const ReactHelmet = require('react-helmet');
const RouteStatus = require('../../components/route-status.jsx');

const Helmet = ReactHelmet.Helmet;


class NotFoundPage extends React.Component {
    render() {

        return (
            <RouteStatus code={404}>
                <div className="home_banner full_row">
                    <Helmet>
                        <title>Page not found</title>
                    </Helmet>
                    <div className="container">
                        <h1 className="wow fadeInDown">PAGE NOT FOUND!</h1>
                    </div>
                    <div className="app_section">
                        <div className="container">
                            <div className="col-sm-6">
                                    <h3>Order power, hungry solver. Get the app.</h3>
                                    <a href="" className="google_play_img"><img src="/public/media/images/google_play_img.png" alt="googlePlayStoreImg" /></a>
                                    <a href="" className="app_store_img"><img src="/public/media/images/app_store_img.png" alt="googlePlayStoreImg" /></a>
                            </div>
                            <div className="col-sm-6">
                                <h1>Let’s Eat!</h1>
                            </div>
                        </div>  
                    </div>
                </div>
            </RouteStatus>
        );
    }
}


module.exports = NotFoundPage;
