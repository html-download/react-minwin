/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16IngredientsTypeList', {
    typeId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'type_id'
    },
    ingredientName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'ingredient_name'
    },
    ingredientDesc: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'ingredient_desc'
    },
    price: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'price'
    },
    pickupPrice: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'pickup_price'
    },
    delivryDpPrice: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'delivry_dp_price'
    },
    delivryResPrice: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'delivry_res_price'
    },
    premiumPrice: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'premium_price'
    },
    costPrice: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'cost_price'
    },
    weight: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'weight'
    },
    subModifier: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sub_modifier'
    },
    autoSelect: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'auto_select'
    },
    sortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort_order'
    },
    publicDisplay: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'public_display'
    },
    ingredientsTypeListStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'ingredients_type_list_status'
    },
    ingredientsTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'ingredients_type_id'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_ingredients_type_list'
  });
};
