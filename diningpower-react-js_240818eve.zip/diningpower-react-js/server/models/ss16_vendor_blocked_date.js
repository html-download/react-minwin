/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorBlockedDate', {
    blockId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'block_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'vendor_id'
    },
    fromBlockDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'from_block_date'
    },
    toBlockDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'to_block_date'
    },
    startTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'start_time'
    },
    endTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'end_time'
    },
    reason: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'reason'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_vendor_blocked_date'
  });
};
