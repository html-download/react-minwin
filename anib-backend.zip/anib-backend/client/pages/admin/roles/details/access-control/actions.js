'use strict';
const Store = require('./store');
const Constant =  require('./constants');
const ApiActions = require('../../../../../actions/api');
const CommonHelper = require('../../../../../helpers/common-functions');

class Actions {
    
    static update(id, value) {
           
        ApiActions.put(
            `/role/${id}`,
            value,
            Store,
            Constant.UPDATE_ROLE,
            Constant.UPDATE_ROLE_RESPONSE
        );        
    }

    static getRole(id) {

        ApiActions.get(
            `/role/${id}`,
            {},
            Store,
            Constant.GET_ROLE,
            Constant.GET_ROLE_RESPONSE
        );
    }
}

module.exports = Actions;