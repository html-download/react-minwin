'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {

    /** Loaders and Toast messages */
    hydrating: true,
    loading: false,

    error: undefined,    /** Error text */
    hasError: {}, /** Has error for field */
    help: {},
    
    customer_driving_profile_key: undefined, /** Customer Driving ID */

    editable_field: undefined, /** editable field */

    /** Form Data */
    name: undefined,
    first_name: undefined,
    last_name: undefined,
    arabic_first_name: undefined,
    arabic_last_name: undefined,
    email: undefined,
    mobile_number: undefined,
    nationality_id: undefined,
    nationality_name: undefined,
    gender: undefined,
    dob: undefined,
    po_box: undefined,
    address: undefined,
    emirate_id: undefined,
            
    city: undefined,
    company_name: undefined,
    country: undefined,
    customer_type: undefined,
    fax: undefined,
    ho_country: undefined,
    location: undefined,
    phone_number: undefined,
    short_name: undefined,
    vat_reg_no: undefined,
    website: undefined,
    source: undefined,
    lead_generator_id: undefined,
    account_executive_id: undefined,
    bill_collector_id: undefined,
    technical_executive_id: undefined,
    technical_manager_id: undefined,
    lead_generator_name: undefined,
    account_executive_name: undefined,
    bill_collector_name: undefined,
    technical_executive_name: undefined,
    technical_manager_name: undefined,

    /** Dropdown Data */
    nationality_data: [],
    user_roles: [],
    users: []
};
const reducer = function (state = initialState, action) {

    switch (action.type) {

        case Constants.GET_USERS:

            return ObjectAssign({}, state, {
                users: []
            });
            break;    
        case Constants.GET_USERS_RESPONSE:
            
            return ObjectAssign({}, state, {
                users: action.response.data
            });
            break;

        case Constants.CUSTOMER_DETAILS:
            return ObjectAssign({}, state, {
                loading: true,
                hydrating: true
            });
            break;
        case Constants.CUSTOMER_DETAILS_RESPONSE:

            const validation = ParseValidation(action.response);
            const stateUpdates = {
                loading: false,
                hydrating: false,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help
            };

            const data = (action.response && action.response.data) ? action.response.data : {};

            if (action.response && action.response.status === 200) {
                
                stateUpdates.name = data.name ? data.name : undefined;
                stateUpdates.first_name = data.first_name ? data.first_name : undefined;
                stateUpdates.last_name = data.last_name ? data.last_name : undefined;
                stateUpdates.arabic_first_name = data.arabic_first_name ? data.arabic_first_name : undefined;
                stateUpdates.arabic_last_name = data.arabic_last_name ? data.arabic_last_name : undefined;
                stateUpdates.email = data.email ? data.email : undefined;
                stateUpdates.mobile_number = data.mobile_number ? data.mobile_number : undefined;
                stateUpdates.nationality_id = data.nationality_id ? data.nationality_id : undefined;
                stateUpdates.nationality_name = data.nationality_name ? data.nationality_name : undefined;
                stateUpdates.gender = data.gender ? data.gender : undefined;
                stateUpdates.dob = data.dob ? data.dob : undefined;
                stateUpdates.po_box = data.po_box ? data.po_box : undefined;
                stateUpdates.address = data.address ? data.address : undefined;
                stateUpdates.emirate_id = data.emirate_id ? data.emirate_id : undefined;
                stateUpdates.city =  data.city ? data.city : undefined,
                stateUpdates.company_name =  data.company_name ? data.company_name : undefined,
                stateUpdates.country =  data.country ? data.country : undefined,
                stateUpdates.customer_type =  data.customer_type ? data.customer_type : undefined,
                stateUpdates.fax =  data.fax ? data.fax : undefined,
                stateUpdates.ho_country =  data.ho_country ? data.ho_country : undefined,
                stateUpdates.location =  data.location ? data.location : undefined,
                stateUpdates.phone_number =  data.phone_number ? data.phone_number : undefined,
                stateUpdates.short_name =  data.short_name ? data.short_name : undefined,
                stateUpdates.vat_reg_no =  data.vat_reg_no ? data.vat_reg_no : undefined,
                stateUpdates.website =  data.website ? data.website : undefined,
                stateUpdates.source =  data.source ? data.source : undefined,
                stateUpdates.lead_generator_id =  data.lead_generator_id ? data.lead_generator_id : undefined,
                stateUpdates.account_executive_id =  data.account_executive_id ? data.account_executive_id : undefined,
                stateUpdates.bill_collector_id =  data.bill_collector_id ? data.bill_collector_id : undefined,
                stateUpdates.technical_executive_id =  data.technical_executive_id ? data.technical_executive_id : undefined,
                stateUpdates.technical_manager_id =  data.technical_manager_id ? data.technical_manager_id : undefined,
                stateUpdates.lead_generator_name =  data.lead_generator_name ? data.lead_generator_name : undefined,
                stateUpdates.account_executive_name =  data.account_executive_name ? data.account_executive_name : undefined,
                stateUpdates.bill_collector_name =  data.bill_collector_name ? data.bill_collector_name : undefined,
                stateUpdates.technical_executive_name =  data.technical_executive_name ? data.technical_executive_name : undefined,
                stateUpdates.technical_manager_name =  data.technical_manager_name ? data.technical_manager_name : undefined
            }
            return ObjectAssign({}, state, stateUpdates);
            break;
        case Constants.DISABLE_LOADER:
            return ObjectAssign({}, state, {
                hydrating: false
            });
            break;
        case Constants.EDITABLE_SHOW:
            return ObjectAssign({}, state, {
                editable_field: action.field
            });
            break;
        case Constants.EDITABLE_HIDE:
            return ObjectAssign({}, state, {
                editable_field: undefined
            });
            break;
        case Constants.NATIONALITY_RESULTS:
            return ObjectAssign({}, state, {
                loading: true
            });
            break;
        case Constants.NATIONALITY_RESULTS_RESPONSE:
            
            if (action.response && action.response.status === 200) {
                return ObjectAssign({}, state, {
                    nationality_data: (action.response && action.response.data) ? action.response.data : []
                });
            }
            break;
        case Constants.UPDATE_DOB:
            return ObjectAssign({}, state, {
                dob: action.date
            });
            break;
        case Constants.GET_USER_TYPES:

            return ObjectAssign({}, state, {
                user_roles: []
            });
            break;
        case Constants.GET_USER_TYPES_RESPONSE:
                
            return ObjectAssign({}, state, {
                user_roles: action.response.data
            });
            break;
        default:
            return state;
            break;
    }
};


module.exports = Redux.createStore(reducer);
