'use strict';
const ClassNames = require('classnames');
const ControlGroup = require('./control-group.jsx');
const ObjectAssign = require('object-assign');
const PropTypes = require('prop-types');
const React = require('react');
const renderHTML = require('react-render-html');
import Select from 'react-select';

const propTypes = {
    children: PropTypes.node,
    defaultValue: PropTypes.string,
    disabled: PropTypes.bool,
    hasError: PropTypes.bool,
    help: PropTypes.string,
    inputClasses: PropTypes.object,
    hideLabel: PropTypes.bool,
    label: PropTypes.string,
    multiple: PropTypes.string,
    name: PropTypes.string,
    onChange: PropTypes.func,
    size: PropTypes.string,
    value: PropTypes.oneOfType([
        PropTypes.bool,
        PropTypes.string,
        PropTypes.integer
    ]),
    defaultValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    prependElement : PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    prependElementNotString : PropTypes.bool,
    appendElement: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    appendElementNotString : PropTypes.bool,
    isKeyEnable: PropTypes.bool,
};
const defaultProps = {
    type: 'text'
};


class ReactSelectControl extends React.Component {
    
    constructor(props){
        super(props);
        
        this.state = {
          value: this.props.defaultValue ? this.props.defaultValue : this.props.value
        }

        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(data) {
        
        this.setState({
          value: data.value
        });

        this.props.onChange ? this.props.onChange(data.value) : null;
    }

    value() {

        return this.state.value;
    }

    render() {

        const inputClasses = ClassNames(ObjectAssign({
            'form-control': true
        }, this.props.inputClasses));

        const options = [
          { value: 'chocolate', label: 'Chocolate' },
          { value: 'strawberry', label: 'Strawberry' },
          { value: 'vanilla', label: 'Vanilla' }
        ]
        return (
            <ControlGroup
                hasError={this.props.hasError}
                label={this.props.label}
                hideLabel={this.props.hideLabel}
                groupClasses={this.props.groupClasses}
                labelClasses={this.props.labelClasses}
                labelFor={this.props.id}
                help={this.props.help}>

                <div className="side-input right-side">
                    {(this.props.prependElement && this.props.prependElementNotString) ? (this.props.prependElement) : ''}
                    {(this.props.prependElement && !this.props.prependElementNotString) ? (renderHTML(this.props.prependElement)) : ''}

                    {/*<select
                        ref={(c) => (this.input = c)}
                        multiple={this.props.multiple}
                        className={inputClasses}
                        name={this.props.name}
                        size={this.props.size}
                        value={this.props.value}
                        defaultValue={this.props.defaultValue}
                        disabled={this.props.disabled}
                        onChange={this.props.onChange}>

                        {this.props.children}
                    </select>*/}
                    <Select 
                        ref={(c) => (this.input = c)}
                        options={this.props.options} 
                        //className={inputClasses}
                        setValue={this.props.defaultValue ? this.props.defaultValue : this.props.value}
                        name={this.props.name}
                        isLoading={this.props.disabled}
                        onChange={(e) => {this.handleChange(e)}}
                         isSearchable={this.props.isSearch}
                        />

                    {(this.props.appendElement && this.props.appendElementNotString) ? (this.props.appendElement) : ''}
                    {(this.props.appendElement && !this.props.appendElementNotString) ? (renderHTML(this.props.appendElement)) : ''}
                </div>
            </ControlGroup>
        );
    }
}

ReactSelectControl.propTypes = propTypes;
ReactSelectControl.defaultProps = defaultProps;


module.exports = ReactSelectControl;
