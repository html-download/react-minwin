
'use strict';
const Redux = require('redux');
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../helpers/parse-validation');
const CommonHelper = require('../../../../helpers/common-functions');

const initialState = {
    show: false,
    loading: false,
    customer_hydrated: true,
    make_hydrated: true,
    make_model_hydrated: true,
    trim_hydrated: true,
    enquiry_type_hydrated: true,
    error: undefined,
    hasError: {},
    help: {},
    customer: '',
    model_year: '',
    make: '',
    make_model: '',
    trim: '',
    enquiry_type: 0,
    no_of_passenger: 0,
    sub_insured: 0,
    nationality_data: [],
    customer_data: [],
    make_data: [],
    make_model_data: [],
    enquiry_type_data: [],
    trim_data: [],
    years: [],
    customer_detail: {}
};
const reducer = function (state = initialState, action) {
    if (action.type === Constants.CREATE_NEW) {
        return ObjectAssign({}, state, {
            loading: true,
        });
    }

    if (action.type === Constants.CREATE_NEW_RESPONSE) {
        const validation = ParseValidation(action.response);
        
        const stateUpdates = {
            loading: false,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            customer: '',
            model_year: '',
            make: '',
            make_model: '',
            trim: '',
            enquiry_type: 0,
            no_of_passenger: 0,
            sub_insured: 0,
        };

        return ObjectAssign({}, state, stateUpdates);
    }

    

    if (action.type === Constants.GET_NATIONALITY_RESULTS) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.GET_NATIONALITY_RESULTS_RESPONSE) {

        const validation = ParseValidation(action.response);
        
        const stateUpdates = {
            loading: false,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            nationality_data: action.response ? action.response.data : []   
        };

        return ObjectAssign({}, state, stateUpdates);
    }

    if (action.type === Constants.GET_CUTOMER_RESULTS) {

        return ObjectAssign({}, state, {
            customer_hydrated: false,
            customer_data:[]
        });
        
    }

    if (action.type === Constants.GET_CUTOMER_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            customer_hydrated: true,
            customer_data: action.response ? action.response.data : []
        });        
    }

    if (action.type === Constants.GET_SINGLE_CUSTOMER_DETAILS) {

        return ObjectAssign({}, state, {
            customer_detail: {}
        });        
    }

    if (action.type === Constants.GET_SINGLE_CUSTOMER_DETAILS_RESPONSE) {
        return ObjectAssign({}, state, {            
            customer_detail: action.response ? action.response.data : []
        });
    }

    if (action.type === Constants.GET_MAKE_RESULTS) {

        return ObjectAssign({}, state, {
            make_hydrated: false
        });        
    }

    if (action.type === Constants.GET_MAKE_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            make_hydrated: true,
            make_data: action.response ? action.response.data : []
        });
        
    }

    if (action.type === Constants.GET_YEAR_RESULTS) {

        return ObjectAssign({}, state, {
            make_hydrated: false
        });
        
    }

    if (action.type === Constants.GET_YEAR_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            make_hydrated: true,
            years: action.response ? action.response.data : []
        });
        
    }

    if (action.type === Constants.GET_MAKE_MODEL_RESULTS) {

        return ObjectAssign({}, state, {
            make_model_hydrated: false
        });
        
    }

    if (action.type === Constants.GET_MAKE_MODEL_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            make_model_hydrated: true,
            make_model_data: action.response ? action.response.data : []
        });
        
    }

    if (action.type === Constants.GET_ENQUIRY_TYPE_RESULTS) {

        return ObjectAssign({}, state, {
            enquiry_type_hydrated: false
        });        
    }

    if (action.type === Constants.GET_ENQUIRY_TYPE_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            enquiry_type_hydrated: true,
            enquiry_type_data: action.response ? action.response.data : []
        });
    }

    if (action.type === Constants.GET_TRIM_RESULTS) {

        return ObjectAssign({}, state, {
            trim_hydrated: false
        });
    }

    if (action.type === Constants.GET_TRIM_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            trim_hydrated: true,
            trim_data: action.response ? action.response.data : []
        });
    }

    return state;
};


module.exports = Redux.createStore(reducer);
