<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
      
      
        <!-- acc page content -->
        <div class="error-page">
          <div class="error-content text-center">
            <img src="assets/img/404.png">
            <h3>Something's missing.</h3>
            <p>The page you looking for is not found.
            </p>
            <button class="btn" onclick="location.href='/index';"> Back to home</button>
          </div>
              
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>