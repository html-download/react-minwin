'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'TOGGLE_NAVBAR',
     'TOGGLE_OPEN',
     'GET_USER_ADMIN',
     'GET_USER_ADMIN_RESPONSE'
]);
