<?php include ('inc/header.php'); ?>

<div class="page_banner bg4">
	<div class="container pad0">
		<h1 class="head wow fadeInDown">Vendor / Restaurant Dashboard</h1>
		<h2 class="head wow fadeInUp mb20">Restaurant Management Software</h2>
		<img src="images/restaurant-dashboard.png" class="wow fadeInUp" alt="Food Ordering System" data-wow-duration="1.5s">
	</div> <!--container-->
</div> <!--page_banner-->

<section class="text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Online Restaurant Delivery Software & System for <br>Branch manager</h2>
		<p class="mb0 wow fadeInUp">Ontabee, our online restaurant ordering software lets you manage a single restaurant with multi-branch (vendor). Each branch owner has a separate business page which allows branch owner to manage their customer's online order. Our branch panel manages numbers of orders, customers, branches & total turnover.</p>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="grey pt0 tabs">
	<ul class="nav nav-tabs responsive full_row">
		<li class="active"> <a class="tab" data-toggle="tab" href="#Order"><i class="fa fa-shopping-basket"></i>Order Section</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Delivery"><i class="fa fa-user-o"></i>Delivery Section</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Reports"><i class="fa fa-lock"></i>Report</a> </li>
	</ul>
	<div class="container">
		<div class="tab-content responsive full_row">
			<div id="Order" class="tab-pane fade active in row">
				<div class="col-sm-6">
					<h2 class="head">Order Section</h2>
					<p>Branch owner can manage order section which contains details of each order like order number, customer name, branch name, order date & time, total amount and also can change the notification of accepted/ rejected/ pending/ delivered status.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/restaurant-orders.png" alt="Order Section">
				</div>
			</div> <!--General-->
			
			<div id="Delivery" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Delivery Section</h2>
					<p>Branch owner can add delivery person in this section with the details of delivery staff name, branch name, email address and contact number.He can also track the status of the entire delivery status.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/restaurant-delivery-boy.png" alt="Delivery Boy">
				</div>
			</div> <!--Delivery-->
			
			<div id="Reports" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Report</h2>
					<p>In this section, the branch manager can generate report by using filter section. Filter section contains report type (order by an hour, order by day, order by month, most selling branches) and can select specific branch name, start date and end date. The report can be download as JPG, PNG, can also be exported to excel</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/restaurant-reports.png" alt="Reports">
				</div>
			</div> <!--Reports-->
		</div> <!--tab-content-->
	</div> <!--container-->
</section> <!--page_banner-->

<?php include('inc/footer.php');?>