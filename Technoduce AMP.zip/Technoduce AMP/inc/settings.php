<?php
	$email = 'sales@technoduce.com';
	$mobile = '+91 90039 60003';
	$phone = '+91-422-422-1160';
	$whatsapp = '919003960003';
	$skype = 'sales.technoduce';
	$address = 'JV Building, 2/3 & 2/4 Mullai Nagar, Maruthamalai Main Road, Vadavalli, Coimbatore - 641041, Tamil Nadu, India.';

	$facebook = 'https://www.facebook.com/technoduce';
	$twitter = 'https://twitter.com/technoduce';
	$gplus = '';
	$linkedin = 'https://www.linkedin.com/company/technoduce';
	$youtube = 'https://www.youtube.com/user/technoducevideos';
?>

<?php
	$url = explode('/',$_SERVER['REQUEST_URI']);
	if($url[1] == ''){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'home.css';
	}
?>

<?php
	$url = explode('/',$_SERVER['REQUEST_URI']);
	if($url[1] == 'restaurant-menu-ordering-application'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'foodpurby.css';
	}

	//Company
	if($url[1] == 'about-us'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'about-us.css';
	}
	if($url[1] == 'company' && isset($url[2]) && $url[2]=='our-team'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'our-team.css';
	}
	if($url[1] == 'company' && isset($url[2]) && $url[2]=='clients'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'clients.css';
	}
	if($url[1] == 'company' && isset($url[2]) && $url[2]=='testimonial'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'testimonial.css';
	}
	if($url[1] == 'company' && isset($url[2]) && $url[2]=='careers'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'careers.css';
	}
	
	//Web Development
	if($url[1] == 'angularjs-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'angular.css';
	}
	if($url[1] == 'react-js-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'reactjs.css';
	}
	if($url[1] == 'full-stack-web-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'fullstack.css';
	}
	if($url[1] == 'node-js-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'nodejs.css';
	}
	if($url[1] == 'ecommerce-application-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'ecommerce.css';
	}

	//Mobile Development
	if($url[1] == 'mobile-application-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'mobile.css';
	}
	if($url[1] == 'android-application-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'android.css';
	}
	if($url[1] == 'iphone-application-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'iphone.css';
	}
	if($url[1] == 'react-native-app-development'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'react.css';
	}

	//Hire Developer
	if($url[1] == 'hire-developers'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developers-landing.css';
	}
	if($url[1] == 'hire-android-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-iphone-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-angularjs-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-react-js-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-react-native-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-full-stack-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-php-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
	if($url[1] == 'hire-node-js-developer'){
		$title = '';
		$description = '';
		$keywords = '';
		$style = 'hire-developer.css';
	}
?>