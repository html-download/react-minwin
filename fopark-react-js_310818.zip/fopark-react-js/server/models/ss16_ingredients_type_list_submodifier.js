/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16IngredientsTypeListSubmodifier', {
    submodifierId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'submodifier_id'
    },
    ingredientType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'ingredient_type'
    },
    submodifierTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'submodifier_type_id'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_ingredients_type_list_submodifier'
  });
};
