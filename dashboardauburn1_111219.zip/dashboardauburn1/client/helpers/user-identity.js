'use strict';
const Config = require('../../config');

module.exports = {
    _userIdentity : function () {
        try {
            if (sessionStorage === undefined) {
                var sessionStorage = null;
            }

            if (localStorage === undefined) {
                var localStorage = null;
            }
            const tokens = sessionStorage.getItem('user');

            if (tokens === null) {
                const tokens = localStorage.getItem('user');
            }

            if (tokens !== null) {
                return JSON.parse(tokens);
            }

            return null;
        } catch (e) {
            //console.log(e.message);
            return null;
        }
    },
    _checkUserIdentity : function(){
        try {
            
            var storageVar = sessionStorage.getItem('user');

            if (storageVar === null) {
                storageVar = localStorage.getItem('user');
            }

            if (storageVar !== undefined && storageVar !== null) {
                return true;
            }
            return false;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },
    _checkUserToken : function(){
        try {
            var storageToken = localStorage.getItem('user');

            if (storageToken !== undefined && storageToken !== null) {
                var userStorage = JSON.parse(storageToken);
                return userStorage.api_key;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _checkSelectedZone : function(){
        try {
            var storageToken = localStorage.getItem('dashboard_zone_selected');

            if (storageToken !== undefined && storageToken !== null) {
                return storageToken;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _checkSelectedZoneDay : function(){
        try {
            var storageToken = localStorage.getItem('dashboard_zone_day_selected');

            if (storageToken !== undefined && storageToken !== null) {
                return storageToken;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    
    apiUrl : Config.get('/apiUrl'),
    googleApiKey : Config.get('/googleApiKey'),
    client : Config.get('/client'),
    defaultZones : Config.get('/defaultZones')
};
