'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');

const Redux = require('redux');

const initialState = {
    roles: []
};

const store = function (state = initialState, result) {

    switch (result.type) {
        case Constants.GET_ROLES_RESPONSE:
            return ObjectAssign({}, state, {
                roles: result.response.data
            });
            break;

        default:
            break;
    }
    
    return state;
};

module.exports = Redux.createStore(store);


