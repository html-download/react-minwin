<?php include ('inc/header.php'); ?>

<div class="page_banner bg4">
	<div class="container pad0">
		<h1 class="head wow fadeInDown">Online Ordering Software for Admin</h1>
		<h2 class="head wow fadeInUp mb20">Take your restaurant from simple to appetizing</h2>
		<img src="images/admin-dashboard.png" class="wow fadeInUp" alt="Food Ordering System" data-wow-duration="1.5s">
	</div> <!--container-->
</div> <!--page_banner-->

<section class="text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Online Ordering Systems for Restaurants - Admin</h2>
		<p class="wow fadeInUp">Ontabee's web-based admin panel gives full control to manage the software and can create CMS pages. It allows you to monitor and track entire online restaurant ordering & delivery system in real time. Manage your subsidiaries, menu items, customer details and delivery staff at a place.</p>
		<p class="mb"><b>Multiple location selections, Multiple time slots - Multiple access control</b></p>		

		<span class="play style1 wow fadeInUp" data-toggle="modal" data-target="#modal_video">
			<i class="fa fa-play"></i> Watch Video
		</span>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="grey pt0 tabs">
	<ul class="nav nav-tabs responsive full_row">
		<li class="active"> <a class="tab" data-toggle="tab" href="#General"><i class="fa fa-gear"></i>General Setting</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Access"><i class="fa fa-lock"></i>Access Control</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Master"><i class="fa fa-gears"></i>Master Section</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Items"><i class="fi fast-food"></i>Items</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Customer"><i class="fa fa-user-o"></i>Customer</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Orders"><i class="fa fa-shopping-basket"></i>Orders</a> </li>
		<li> <a class="tab" data-toggle="tab" href="#Delivery"><i class="fa fa-user-o"></i>Delivery Boy</a> </li>
	</ul>
	<div class="container">
		<div class="tab-content responsive full_row">
			<div id="General" class="tab-pane fade active in row">
				<div class="col-sm-6">
					<h2 class="head">General Setting</h2>
					<p>Super admin dashboard is provided with complete end to end setting for better business management. Admin has access control for below-mentioned features. They are</p>
					<ul class="reset list1">
						<li><b>Social media</b> - You can change social media pages like Facebook, Twitter, LinkedIn & etc.</li>
						<li><b>SMS setting</b> - Edit gateway account ID & authority token.</li>
						<li><b>Email setting</b> - Contain SMTP host username & password, type of encryption & port.</li>
						<li><b>Cart management</b> - Manages order item’s cart value & tax. </li>
						<li><b>Loyalty Points conversion</b> - Customer is eligible for loyalty points on his repeated orders which are later converted to wealth by admin.</li>
					</ul>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/setting.png" alt="Setting">
				</div>
			</div> <!--General-->
			
			<div id="Access" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Access Control</h2>
					<p>Access control has two section. They are </p>
					<ul class="reset list1">
						<li>Role</li>
						<li>Administrator</li>
					</ul>
					<p><b>Role</b> - Super admin (Restaurant owner) can allocate each role to the different branch user (like branch manager).</p>
					<p><b>Administrator</b> - It's giving different access control to each and every branch user (branch manager) role in this section.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/access-control.png" alt="Access Control">
				</div>
			</div> <!--Access-->
			
			<div id="Master" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Master Section</h2>
					<p>In master section, admin can add multi-branch, the different category which relates to their restaurant menu items, add extra ingredients to enrich the food item quality level, add a coupon with respective menu item offers, add coupon branch, add daily offers.</p>
					<ul class="reset list1">
						<li><b>Branch Section:</b> Admin (restaurant owner) can add multi-branch which includes branch name, address, area or locality, available status.</li>
						<li><b>Category Section:</b> Admin can add category of menu items like drinks, desserts, Kids meal, fries, sandwiches and etc.,</li>
						<li><b>Ingredients Section:</b> Admin can add extra ingredients list with the ingredients images and its name, they can show its available status.</li>
						<li><b>Coupon Section:</b> Admin, add a coupon list with the details of coupon name, type, start date and end date of coupon validity, they can show its available status too.</li>
						<li><b>Coupon Branch:</b> It denotes the coupon branch which is controlled by the branch manager of the restaurant. Admin can add coupon branch with the details of coupon name and branch name.</li>
						<li><b>Offer:</b> In this section, admin can add offers list with the details of offer name, offer type, offer price, start date time and end date time which are decided by the restaurant owner, they can show its status availability too.</li>
					</ul>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/master.png" alt="Master Section">
				</div>
			</div> <!--Master-->
			
			<div id="Items" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Items</h2>
					<p>Admin (Restaurant Owners) can add menu item list which is different for a different branch, they can enable/disable menu item which depends upon a branch.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/items.png" alt="Items">
				</div>
			</div> <!--Items-->
			
			<div id="Customer" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Customer</h2>
					<p>In customer section, admin can view every customer details (Name, Email Address) which is created by all the branch manager (branch admin), also can view the status of each customer.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/customer.png" alt="Customer">
				</div>
			</div> <!--Customer-->
			
			<div id="Orders" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Orders</h2>
					<p>Admin can manage customer order which contains the order number, customer name, branch name, order date & time of all the branch, admin can maintain status report too whether the order delivered or accepted or rejected or still in pending.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/orders.png" alt="Orders">
				</div>
			</div> <!--Orders-->
			
			<div id="Delivery" class="tab-pane fade row">
				<div class="col-sm-6">
					<h2 class="head">Delivery Boy</h2>
					<p>Admin can include each delivery boy in this section with the details of delivery staff name, email address, phone number. Admin can also track each and every delivery boy.</p>
				</div>
		
				<div class="col-sm-6 text-center">
					<img src="images/delivery-boy.png" alt="Delivery Boy">
				</div>
			</div> <!--Delivery-->
		</div> <!--tab-content-->
	</div> <!--container-->
</section> <!--page_banner-->

<div id="modal_video" class="modal fade" role="dialog">
	<div class="modal-dialog modal-md">
		<a class="close" data-dismiss="modal"><i class="fa fa-close"></i></a>
		<iframe id="video" width="100%" height="100%" src="https://www.youtube.com/embed/mAqgAeku_10?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div><!--modal-dialog-->
</div><!--modal_video-->

<?php include('inc/footer.php');?>