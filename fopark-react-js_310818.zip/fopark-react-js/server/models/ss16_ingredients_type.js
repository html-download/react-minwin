/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16IngredientsType', {
    ingredientsTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'ingredients_type_id'
    },
    ingredientsTypeName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'ingredients_type_name'
    },
    ingredientsTypeDesc: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'ingredients_type_desc'
    },
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'menu_id'
    },
    minimum: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'minimum'
    },
    maximum: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'maximum'
    },
    freeChoice: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'free_choice'
    },
    chargedChoice: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'charged_choice'
    },
    totalChoice: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'total_choice'
    },
    modifierType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modifier_type'
    },
    sameChoice: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'same_choice'
    },
    publicDisplay: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'public_display'
    },
    ingredientsTypeStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'ingredients_type_status'
    },
    saveAsType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'save_as_type'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    sort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort'
    }
  }, {
    tableName: 'ss16_ingredients_type'
  });
};
