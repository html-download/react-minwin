'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {

    /** Loaders and Toast messages */
    hydrating: true,
    loading: false,

    error: undefined,    /** Error text */
    hasError: {}, /** Has error for field */
    help: {},
    
    customer_driving_profile_key: undefined, /** Customer Driving ID */

    editable_field: undefined, /** editable field */

    /** Form Data */
    role_name: undefined,
    role_id: undefined,
    username: undefined,
    first_name: undefined,
    last_name: undefined,
    email: undefined,
    mobile_number: undefined,
    nationality_id: undefined,
    nationality_name: undefined,
    gender: undefined,
    dob: undefined,
    po_box: undefined,
    address: undefined,
    emirate_id: undefined,

    /** Dropdown Data */
    nationality_data: []
};
const reducer = function (state = initialState, action) {

    switch (action.type) {
        case Constants.CUSTOMER_DETAILS:
            return ObjectAssign({}, state, {
                loading: true,
                hydrating: true
            });
            break;
        case Constants.CUSTOMER_DETAILS_RESPONSE:

            const validation = ParseValidation(action.response);
            const stateUpdates = {
                loading: false,
                hydrating: false,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help
            };

            const data = (action.response && action.response.data) ? action.response.data : {};

            if (action.response && action.response.status === 200) {
                
                stateUpdates.username = data.username ? data.username : undefined;
                stateUpdates.first_name = data.first_name ? data.first_name : undefined;
                stateUpdates.last_name = data.last_name ? data.last_name : undefined;
                stateUpdates.email = data.email ? data.email : undefined;
                stateUpdates.mobile_number = data.mobile_number ? data.mobile_number : undefined;
                stateUpdates.role_id = data.role_id ? data.role_id : undefined;
                stateUpdates.role_name = data.role_name ? data.role_name : undefined;
                stateUpdates.user_type = data.user_type ? data.user_type : undefined;
                stateUpdates.user_type_label = data.user_type_label ? data.user_type_label : undefined;
            }
            return ObjectAssign({}, state, stateUpdates);
            break;
        case Constants.DISABLE_LOADER:
            return ObjectAssign({}, state, {
                hydrating: false
            });
            break;
        case Constants.EDITABLE_SHOW:
            return ObjectAssign({}, state, {
                editable_field: action.field
            });
            break;
        case Constants.EDITABLE_HIDE:
            return ObjectAssign({}, state, {
                editable_field: undefined
            });
            break;
        case Constants.NATIONALITY_RESULTS:
            return ObjectAssign({}, state, {
                loading: true
            });
            break;
        case Constants.NATIONALITY_RESULTS_RESPONSE:
            
            if (action.response && action.response.status === 200) {
                return ObjectAssign({}, state, {
                    nationality_data: (action.response && action.response.data) ? action.response.data : []
                });
            }
            break;
        case Constants.UPDATE_DOB:
            return ObjectAssign({}, state, {
                dob: action.date
            });
            break;
        default:
            return state;
            break;
    }
};


module.exports = Redux.createStore(reducer);
