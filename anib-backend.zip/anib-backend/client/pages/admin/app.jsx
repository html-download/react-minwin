'use strict';

const AccountSetting = require('./account-setting/index.jsx');
const CustomersDetails = require('./customers/details/index.jsx');
const CustomersSearch = require('./customers/search/index.jsx');
const DealsDetails = require('./deals/details/index.jsx');
const EmailSetting = require('./email-setting/index.jsx');
const DealsSearch = require('./deals/search/index.jsx');
const TaskSearch = require('./tasks/search/index.jsx');
const Policies = require('./policies/search/index.jsx');
const Permission = require('./permissions/index.jsx');
const Home = require('./home/index.jsx');
const Navbar = require('./navbar/index.jsx');
const NotFound = require('./not-found.jsx');
const React = require('react');
const ReactRouter = require('react-router-dom');
const RolesDetails = require('./roles/details/index.jsx');
const RolesSearch = require('./roles/search/index.jsx');
const ToasterContainer = require('../../components/toaster.jsx');
const UserDetails = require('./users/details/index.jsx');
const UserSearch = require('./users/search/index.jsx');



const Router = ReactRouter.BrowserRouter;
const Route = ReactRouter.Route;
const Switch = ReactRouter.Switch;


const App = (
    <Router>
        <div>
            <Route component={Navbar} />
            <Switch>
                <Route path="/admin" exact component={Home} />
                <Route path="/admin/account-setting" exact component={AccountSetting} />
                <Route path="/admin/email-setting" exact component={EmailSetting} />
                <Route path="/admin/customers" exact component={CustomersSearch} />
                <Route path="/admin/customers/:id" component={CustomersDetails} />
                <Route path="/admin/deals" exact component={DealsSearch} />
                <Route path="/admin/deals/:id" component={DealsDetails} />
                <Route path="/admin/users" exact component={UserSearch} />
                <Route path="/admin/users/:id" component={UserDetails} />
                <Route path="/admin/tasks" exact component={TaskSearch} />
                <Route path="/admin/policies" exact component={Policies} />
                <Route path="/admin/permissions" exact component={Permission} />
                <Route path="/admin/roles" exact component={RolesSearch} />
                <Route path="/admin/roles/:id" component={RolesDetails} />
                <Route component={NotFound} />
            </Switch>
            <ToasterContainer/>
        </div>
    </Router>
);


module.exports = App;
