//Data Tables
$(function () {
  $('.datatable').DataTable({
    'paging'      : true,
    'searching'   : true,
    'ordering'    : true
    //"scrollX": true
  })
});

$(function () {
  $('.datatable1').DataTable({
    'paging'      : false,
    'searching'   : false,
    'bLengthChange' : false,
    "bInfo": false,
    'ordering' : false
  })
});

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});

//Date picker
$('.datepicker').datepicker({
  autoclose: true
});

// timepicker

$(document).ready(function(){
    $('.timepicker').mdtimepicker(); //Initializes the time picker
  });

$(document).ready(function(){
$('.files-name').change(function() {
  var i = $(this).prev('label').clone();
  var file = $('.files-name')[0].files[0].name;
  $(this).prev('label').text(file);
});
});

   // loader
   $('.loader').on('click', function() {
      var $this = $(this);
      var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
      if ($(this).html() !== loadingText) {
         $this.data('original-text', $(this).html());
         $this.html(loadingText);
      }
      setTimeout(function() {
         $this.html($this.data('original-text'));
      }, 2000);
   });