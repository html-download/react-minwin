/* global window */
'use strict';
const ApiActions = require('../../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const CStore = require('../../../common-store/store');
const CConstants = require('../../../common-store/constants');
const Toaster = require('../../../../../helpers/toaster');


class Actions {

    static getCustomerDetails(id, renderDom = false) {

        this.getNationalityResults();
        ApiActions.get(
            `/customer/${id}`,
            undefined,
            Store,
            Constants.CUSTOMER_DETAILS,
            Constants.CUSTOMER_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        renderDom ? document.getElementById('customerName').innerHTML = response.data.first_name : null;

                        CStore.dispatch({
                            type: CConstants.CUSTOMER_DETAILS_RESPONSE,
                            response: response.data
                        });
                    }
                }
            }
        );
    }

    static getUserTypes() {
        
        ApiActions.get(
            '/user/types',
            undefined,
            Store,
            Constants.GET_USER_TYPES,
            Constants.GET_USER_TYPES_RESPONSE
        );
    }

    static getUsers() {
        
        ApiActions.get(
            '/user',
            undefined,
            Store,
            Constants.GET_USERS,
            Constants.GET_USERS_RESPONSE
        );
    }

    static changeLoader() {

        Store.dispatch({
            type: Constants.DISABLE_LOADER
        });
    }

    static saveCustomerDetails(id, data) {
        
        ApiActions.post(
            `/customer/attribute-save/${id}`,
            data,
            Store,
            Constants.CUSTOMER_DETAILS,
            Constants.CUSTOMER_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.removeEditable(data.attribute_key);
                        Toaster.success('Customer details has been updated.');
                    }
                }
            }
        );
    }

    static saveDealCustomerDetails(id, data) {

        ApiActions.post(
            `/deal/deal-customer-attribute-save/${id}`,
            data,
            Store,
            Constants.CUSTOMER_DETAILS,
            Constants.CUSTOMER_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.removeEditable(data.attribute_key);
                        Toaster.success('New cusotmer has been created.');
                    }
                }
            }
        );
    }

    static updateDOB(date) {

        Store.dispatch({
            type: Constants.UPDATE_DOB,
            date: date
        });

    }

    static getNationalityResults() {
        
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.NATIONALITY_RESULTS,
            Constants.NATIONALITY_RESULTS_RESPONSE
        );
    }    
   
    static addEditable(field) {
        
        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });

    } 

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });

    }         
    
    static datePicker(date,field) {

        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD,
            date: date,
            field:field
        });

    }
}


module.exports = Actions;
