const React = require('react');
const ReactRouter = require('react-router-dom');
const ToasterContainer = require('../../components/toaster.jsx');
const Toaster = new ToasterContainer();

const Link = ReactRouter.Link;

class Footer extends React.Component {
    constructor(props) {
        super(props);
        this.refreshSearch = this.refreshSearch.bind(this);
    }
    refreshSearch(event) {
        Toaster.success('Data Updated')
    }
    render() {
        const year = new Date().getFullYear();

        return (
            <footer className="site_footer full_row" onClick={this.refreshSearch}>
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12">
                            <ul className="reset copyright" >
                                <li>&#169; <a href="https://fopark.io/" target="_blank"><img style={{ height: '21px'}} src="/public/media/images/logo-w.png" /></a>    </li>
                            </ul>
                        </div>
                        
                    </div>
                </div> 
            </footer>
            
        );
    }
}


module.exports = Footer;
