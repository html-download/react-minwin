/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16DeliveryCostSettings', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    amount: {
      type: "DOUBLE",
      allowNull: false,
      field: 'amount'
    },
    kilometer: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'kilometer'
    },
    surcharge: {
      type: "DOUBLE",
      allowNull: false,
      field: 'surcharge'
    },
    additionalKmCharge: {
      type: "DOUBLE",
      allowNull: false,
      field: 'additional_km_charge'
    }
  }, {
    tableName: 'ss16_delivery_cost_settings'
  });
};
