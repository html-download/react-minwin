const Home = require('./home/index.jsx');
const About = require('./about/index.jsx');
const Contact = require('./contact/index.jsx');
const Footer = require('./footer.jsx');
const Login = require('./login/home/index.jsx');
const LoginForgot = require('./login/forgot/index.jsx');
const LoginLogout = require('./login/logout/index.jsx');
const LoginReset = require('./login/reset/index.jsx');
const LoginActivation = require('./login/activation/index.jsx');
const Navbar = require('./navbar.jsx');
const NotFound = require('./not-found.jsx');
const React = require('react');
const ReactRouter = require('react-router-dom');
const RouteRedirect = require('../../components/route-redirect.jsx');
const Signup = require('./signup/index.jsx');

/*after login pages*/
const Rewards = require('./rewards/index.jsx');
const MyRewards = require('./my-rewards/index.jsx');
const InviteFriends = require('./invite-friend/index.jsx');
//const SlotMachine = require('./slot-machine/index.jsx');

const Route = ReactRouter.Route;
const Switch = ReactRouter.Switch;
const Redirect = ReactRouter.Redirect;

const AppUniversal = function () {

    return (
        <div>
            <Route component={Navbar} />
            <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/about" exact component={About} />
                <Route path="/contact" exact component={Contact} />
                <Route path="/login" exact component={Login} />
                <Route path="/login/forgot" exact component={LoginForgot} />
                <Route path="/login/reset/:email/:key" component={LoginReset} />
                <Route path="/login/activation/:email/:key" component={LoginActivation} />
                <Route path="/login/logout" exact component={LoginLogout} />
                <Route path="/signup" exact component={Signup} />
                <Route path="/rewards" exact component={Rewards} />
                <Route path="/my-rewards" exact component={MyRewards} />
                <Route path="/invite-friend" exact component={InviteFriends} />
                {/*<Route path="/power-win" exact component={SlotMachine} />*/}

                <RouteRedirect from="/moved" to="/" code={301} />
                <Redirect to="/" />
                <Route component={NotFound} />
            </Switch>
            <Footer />
        </div>
    );
};


module.exports = AppUniversal;
