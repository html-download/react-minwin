'use strict';
//const AuthPlugin = require('../auth');
const Async = require('async');
const Boom = require('boom');
const EscapeRegExp = require('escape-string-regexp');
const Joi = require('joi');
const Config = require('../../config');
const models = require('../models');

const internals = {};


internals.applyRoutes = function(server, next) {
    const User = models.models.ss16Customer;
    server.route({
        method: 'GET',
        path: '/users/my',
        config: {
            auth: {
                strategy: 'session',
                scope: ['admin', 'account']
            }
        },
        handler: function (request, reply) {

console.log("request.auth.credentials.user", request.auth.credentials.user);
            /*const id = request.auth.credentials.user._id.toString();
            const fields = User.fieldsAdapter('username email roles');

            User.findById(id, fields, (err, user) => {

                if (err) {
                    return reply(err);
                }

                if (!user) {
                    return reply(Boom.notFound('Document not found. That is strange.'));
                }

                reply(user);
            });*/
        }
    });


next();
};


exports.register = function(server, options, next) {

    server.dependency(['mailer'], internals.applyRoutes);

    next();
};


exports.register.attributes = {
    name: 'users'
};