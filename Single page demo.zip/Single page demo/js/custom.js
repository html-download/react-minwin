//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});

//popover
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
});

$("[data-toggle=popover]").popover({
	html: true,
    content: function () {
        var targetId = $(this).attr('data-target');
        return $(targetId).html();
    }
});

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});

$(document).on("click", ".popover .btn" , function(){
	$(this).parents(".popover").popover('hide');
});

//floating_label
$(document).on('focus active', '.floating_label .form-control',function(){
	$('label[for='+$(this).attr('id')+']').addClass('focus');
});
$(document).on('blur', '.floating_label .form-control',function(){
	$('label[for='+$(this).attr('id')+']').removeClass('focus');
});

//Current Page
$(document).ready(function() {
    $("[href]").each(function() {
    if (this.href == window.location.href) {
        $(this).addClass("current_page");
        }
    });
});

// Date Time Picker
$(".datepicker").datetimepicker({		
	minView: 2,
	format: "dd-M-yyyy",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

$(".datetime").datetimepicker({		
	format: "dd-M-yyyy - HH:ii P",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

//Select
var config = {
  '.chosen-select'           : {},
  '.chosen-select-deselect'  : {allow_single_deselect:true},
  '.chosen-select-no-single' : {disable_search_threshold:10},
  '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
  '.chosen-select1'           : {disable_search: true}
}
for (var selector in config) {
  $(selector).chosen(config[selector]);
}

//Modal
$(".modal_change").click(function(){
	$("body").addClass("modal_open");
});
$(".modal .close").click(function(){
	$("body").removeClass("modal_open");
});

//Modal_Order
$(".view_detail").click(function(){
	$(".backdrop").fadeIn();
	$(".detail_overlay").addClass("open");
	window.setTimeout(function(){ $('.detail_overlay .loading').fadeOut(); }, 2000);
});

$(".backdrop, .close_overlay, .add_cart").click(function(){
	$(".backdrop").fadeOut();
	$(".detail_overlay").removeClass("open");
	$("ul.listing li").removeClass("focus");
	$(".detail_overlay").removeClass("right");
	$(".detail_overlay").removeClass("left");
	$(".detail_overlay .loading").fadeIn();
});

$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    var target = this.href.split('#');
    $('.nav a').filter('[href="#'+target[1]+'"]').tab('show');
})

$('.modal ul.listing').on('click', '.view_detail', function() {
      //$('li.focus').parent("li").removeClass('focus');
      $(this).parents("li").addClass('focus');
});

$('ul.listing > li:nth-child(odd)').addClass('left');
$('ul.listing > li:nth-child(even)').addClass('right');

$(".right .view_detail").click(function(){
	$(".backdrop").fadeIn();
	$(".detail_overlay").addClass("right");
	window.setTimeout(function(){ $('.detail_overlay .loading').fadeOut(); }, 2000);
});

//Placeholder
$(window).load(function(){
	if(!Modernizr.input.placeholder){
		$('[placeholder]').focus(function() {
		  var input = $(this);
		  if (input.val() == input.attr('placeholder')) {
			input.val('');
			input.removeClass('placeholder');
		  }
		}).blur(function() {
		  var input = $(this);
		  if (input.val() == '' || input.val() == input.attr('placeholder')) {
			input.addClass('placeholder');
			input.val(input.attr('placeholder'));
		  }
		}).blur();
		$('[placeholder]').parents('form').submit(function() {
		  $(this).find('[placeholder]').each(function() {
			var input = $(this);
			if (input.val() == input.attr('placeholder')) {
			  input.val('');
			}
		  })
		});
	}
});

jQuery(document).ready(function(){
	jQuery('.scrollbar-inner').scrollbar();
});

