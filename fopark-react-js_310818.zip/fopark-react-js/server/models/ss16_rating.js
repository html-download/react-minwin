/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Rating', {
    ratingId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'rating_id'
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'customer_key'
    },
    shopKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'shop_key'
    },
    rating: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'rating'
    },
    reviewTitle: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'review_title'
    },
    reviewText: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'review_text'
    },
    ratingStatus: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      defaultValue: '0',
      field: 'rating_status'
    },
    createdDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      field: 'created_date'
    }
  }, {
    tableName: 'ss16_rating'
  });
};
