<?php include ('inc/header.php'); ?>

<!-- schema --> 
<span itemprop="publisher" itemscope itemtype="http://schema.org/Organization">
	<a itemprop="url" class="hide" href="https://www.ontabee.com/"></a>
	<div itemprop="name" class="hide"><strong>Ontabee</strong></div>
	<div itemprop="description" class="hide">Get free online food ordering & delivery system with software for your restaurant business. We deliver both the web & mobile for customer and delivery boy. Try Ontabee for free.</div>
</span>

<div itemscope itemtype="http://schema.org/SoftwareApplication" class="outer">
	<div itemprop="aggregateRating" itemscope itemtype="http://schema.org/AggregateRating">
		<span class="no-display hide" itemprop="reviewCount">7</span>
		<span class="no-display hide" itemprop="worstRating">1</span>
		<span class="no-display hide" itemprop="bestRating">9</span>
		<span class="no-display hide" itemprop="ratingValue">8</span>
	</div>
	<meta itemprop="name" content="Ontabee">
	<meta itemprop="downloadUrl" content="https://www.ontabee.com/signup">
	<meta itemprop="operatingSystem" content="Windows & Linux">
	<meta itemprop="softwareVersion" content="7.2">
	<meta itemprop="applicationCategory" content="Restaurant Ordering Software">
	<meta itemprop="url" content="https://www.ontabee.com">
	<span itemprop="author" itemscope itemtype="http://schema.org/Person">
		<meta itemprop="name" content="Rajesh Prabhu">
	</span>
<!-- schema -->

<section class="home_banner">
	<div class="container">
		<div class="content wow fadeInUp">			
			<h1>Free Online <b>Food</b> Ordering System <span>For Restaurant Business</span></h1>
			<p class="signup_btn"><a href="<?php echo $baseurl;?>signup" class="btn">GET STARTED For Free</a></p>
			<p class="desc"><span>Get your software for free within 24 Hours</span></p>			
		</div>
		
		<form id="tryheader" method="post" name="tryheader" action="<?php echo $baseurl;?>signup" class="wow fadeInUp">
			<label>
				<i class="fa fa-envelope-o"></i>
				<input type="email" name="banner_email" placeholder="Your email ID" class="form-control" required="required">
			</label>
			<input type="hidden" value="" name="try_url">
			<input type="submit" class="btn" value="Try Ontabee For Free">
		</form>

		<p class="partner wow fadeInUp">Want to be a Partner or Reseller? <a href="mailto:<?php echo $partner_mail;?>"><?php echo $partner_mail;?></a></p>
	</div> <!--container-->
	
	<img src="images/food-ordering-system.png" class="img wow fadeInLeft" alt="Food Ordering System" data-wow-duration="2s">
	<i class="circle1 wow zoomIn" data-wow-duration="2s"></i>
	<i class="circle2 wow zoomIn" data-wow-duration="3s"></i>
	<i class="circle3 wow zoomIn" data-wow-duration="3s"></i>
</section><!--home_banner-->

<section class="about">
	<div class="container">
		<h2 class="head wow fadeInUp">Solution to <span>Automate</span> Restaurant Online Ordering System</h2>
		<p class="md wow fadeInUp">Manage your restaurant business with Ontabee. Rev up sales with our <a href="<?php echo $baseurl;?>features">feature-loaded online ordering system</a>. Ontabee provides back-end for admin to manage complete restaurant ordering system on the web platform. Admin can manage single/multiple outlets. Each outlet is provided with an order receiving app on both the web and Android platform. Your customers can order through the web as well as the mobile platform (Android & iPhone). Ontabee  trial lets you run your restaurant business in real time.</p>
		<?php /*
		<p class="trial">
			Hosted and managed by our secured server. <br><a href="" class="btn">Start my 14 days Trial</a>
		</p>
		*/ ?>		
		<h2 class="head mt30 wow fadeInUp"><span>Apps</span> Provided For</h2>
		<ul class="row reset">
			<li class="col-sm-3 wow fadeInUp">
				<div class="content">
					<h5>Admin</h5>
					<span>Back-end</span>
					<i class="fi monitor" data-toggle="tooltip" title="Web App"></i>
				</div>
			</li>
			<li class="col-sm-3 wow fadeInUp">
				<div class="content">
					<h5>Single / Multiple outlets</h5>
					<span>Order receiving app</span>
					<i class="fi monitor" data-toggle="tooltip" title="Web App"></i> 
					<i class="fi android-logo" data-toggle="tooltip" title="Android App"></i>
				</div>
			</li>
			<li class="col-sm-3 wow fadeInUp">
				<div class="content">
					<h5>Customers</h5>
					<span>Customer front end</span>					
					<i class="fi monitor" data-toggle="tooltip" title="Web App"></i> 
					<i class="fi kiosk" data-toggle="tooltip" title="Kiosk App"></i>
					<i class="fi android-logo" data-toggle="tooltip" title="Android App"></i> 
					<i class="fi apple-logo" data-toggle="tooltip" title="iPhone App"></i>
				</div>
			</li>
			<li class="col-sm-3 wow fadeInUp">
				<div class="content">
					<h5>Delivery staff</h5>
					<span>Delivery app</span>
					<i class="fi android-logo" data-toggle="tooltip" title="Android App"></i>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section> <!--section-->

<section class="features">
	<div class="container">
		<h2 class="head wow fadeInUp">Product Features</h2>
		<div class="row col_3">
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="0.5s">
				<i class="fi cart-browser"></i>
				<h3>Website Ordering</h3>
				<p>Be accessible to your customer with our website ordering system. You can seamlessly configure Ontabee to your website.</p>
			</div>
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1s">
				<i class="fi award"></i>
				<h3>Loyalty Points</h3>
				<p>Through our software, provide loyalty points to your customers on their orders anytime and make them your regular customers.</p>
			</div>
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1.5s">
				<i class="fi app"></i>
				<h3>Branded Mobile App</h3>
				<p>Ontabee lets your customer use the mobile app, both Android and iPhone to place an order. Get your application in your own brand and generate more customers to your business.</p>
			</div>
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="0.5s">
				<i class="fi monitor-chart"></i>
				<h3>Customer Insight</h3>
				<p>Get to know your customer better with analytics report.You can easily monitor and track the order report to perform better</p>
			</div>
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1s">
				<i class="fi globe"></i>
				<h3>Multi-Language</h3>
				<p>Nothing stops us to connect with you, even our language. Ontabee can function in multiple languages despite your geography.</p>
			</div>
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1.5s">
				<i class="fi monitor1"></i>
				<h3>White label</h3>
				<p>You can get your website and mobile app white labeled to promote your brand identity.</p>
			</div>			
		</div>
		<a href="<?php echo $baseurl;?>features" class="btn line mt20">See More Features</a>
	</div> <!--container-->
</section> <!--section-->

<section class="subscription">
	<div class="container">
		<h2 class="head wow fadeInUp">Purpose of choosing Monthly Subscription</h2>
		<ul class="reset col_3">
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi cloud-server"></i>
					<h3>No need to pay for server</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi cloud-secure"></i>
					<h3>Better data security</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi clock-update"></i>
					<h3>Regular software updates & maintenance</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi key"></i>
					<h3>Access anywhere, anytime</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi care"></i>
					<h3>Technical support from anywhere</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi setting"></i>
					<h3>Simple setup</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi money-bag"></i>
					<h3>No Lifetime costs & Investments</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi monitor1"></i>
					<h3>Less financial risk</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi money-hand"></i>
					<h3>Better ROI</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi cloud-down"></i>
					<h3>Less downtime</h3>
				 </div>
			</li>
			<li>
				 <div class="content wow fadeInUp">
					<i class="fi smile"></i>
					<h3>Better customer experience</h3>
				 </div>
			</li>
		</ul>
		<img src="images/food-ordering-system.png" class="img wow fadeInRight" alt="Food Ordering System" data-wow-duration="2s">
	</div> <!--container-->
</section> <!--section-->

<section class="platform">
	<div class="container">
		<h2 class="head wow fadeInUp">Ontabee Suitable For All Online Ordering System</h2>
		<p class="desc wow fadeInUp">Ontabee a Cloud-Based Ordering System for Small and Large Businesses With Multi-chain Shops.</p>
		<ul class="reset">
			<li class="wow zoomIn"><span><i class="pizza"></i></span>Pizza</li>
			<li class="wow zoomIn"><span><i class="restaurant"></i></span>Food Court</li>
			<li class="wow zoomIn"><span><i class="truck"></i></span>Food Truck</li>
			<li class="wow zoomIn"><span><i class="meat"></i></span>Meat</li>
			<li class="wow zoomIn"><span><i class="desserts"></i></span>Desserts</li>
			<li class="wow zoomIn"><span><i class="drinks"></i></span>Drinks</li>
			<li class="wow zoomIn"><span><i class="liquor"></i></span>Liquor</li>
			<li class="wow zoomIn"><span><i class="grocery"></i></span>Grocery</li>
			<li class="wow zoomIn"><span><i class="cafe"></i></span>Cafe</li>
			<li class="wow zoomIn"><span><i class="cake"></i></span>Cake</li>
			<li class="wow zoomIn"><span><i class="ice"></i></span>Ice Cream</li>
			<li class="wow zoomIn"><span><i class="restaurant"></i></span>Bakery</li>
		</ul>
	</div> <!--container-->
</section> <!--platform-->
<?php /*
<section class="save_cost">
	<div class="container pad0">
		<div class="col-xs-6 first">
			<h2 class="head wow fadeInUp">Save Commission Cost</h2>
			<div class="sliders style1">
				<h3 class="wow fadeInUp">Monthly turnover from food portals</h3>				
				<span class="price wow fadeInUp">$<b data-price="200" id="price">200</b></span>
				<div id="price_slider"></div>

				<h3 class="wow fadeInUp">Commission</h3>				
				<span class="price wow fadeInUp"><b data-commission="5" id="commission">5</b>%</span>
				<div id="commission_slider"></div>

				<div class="results full_row wow fadeInUp">
					<div class="result"><span>Monthly saving</span>$<b id="monthly">10</b></div>
					<div class="result"><span>Yearly saving</span>$<b id="yearly">100</b></div>
				</div>
				<span class="note text-right">Save Two Month Fee</span>
			</div> <!--sliders-->
		</div>

		<div class="col-xs-6 last">
			<h2 class="head wow fadeInUp">Save Server Cost</h2>
			<div class="sliders">
				<h3 class="wow fadeInUp">Concurrent User</h3>				
				<span class="price wow fadeInUp"><b data-user="100" id="user">100</b></span>
				<div id="user_slider"></div>

				<h3 class="wow fadeInUp">RAM (With 1 Elastic IP)</h3>
				<span class="price wow fadeInUp"><b data-ram="200" id="ram">2</b> GB</span>
				<div id="ram_slider"></div>
				
				<div class="results full_row wow fadeInUp">
					<div class="result"><span>Monthly saving</span>$<b id="amount">22</b></div>
					<div class="result"><span>Hard Disk</span>40 GB</div>
				</div>
				<span class="note">Price from Amazon AWS</span>
			</div> <!--sliders-->
		</div>				
	</div> <!--container-->
</section> <!--save_cost-->
*/ ?>
<section class="business">
	<div class="container">
		<h2 class="head wow fadeInUp">Online ordering system built for Restaurants of small and large size</h2>
		<div class="row">
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1s">
				<div class="content">
					<i class="fi cloud-server"></i>
					<h3>Get everything you need</h3>
					<p>Ontabee provides you the required features that revolutionizes your business.</p>
				</div>
			</div> <!--col-sm-4-->
			
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1.3s">
				<div class="content">
					<i class="fi launch"></i>
					<h3>Ontabee ready made</h3>
					<p>Get your site ready within couple of hours and go live. Compatible for take away business.</p>
				</div>
			</div> <!--col-sm-4-->
			
			<div class="col-sm-4 wow fadeInUp" data-wow-duration="1.6s">
				<div class="content">
					<i class="fi monitor-chart"></i>
					<h3>Drive growth</h3>
					<p>Enhance your sales growth with Ontabee, drive traffic and increase sales volume.</p>
				</div>
			</div> <!--col-sm-4-->
		</div> <!--row-->
	</div> <!--container-->
</section> <!--section-->

<section class="revenue">
	<h2 class="head wow fadeInUp">Revenue Model for <span>Restaurant Business</span></h2>
	<ul class="reset">
		<li class="step1 wow fadeInUp" data-wow-duration="1s">
			<span><i class="fi shop"></i>Physical Restaurant No Online Ordering</span>
		</li>
		<li class="step2 wow fadeInUp" data-wow-duration="1.5s">
			<span><i class="fi phone-call"></i>Order Only <br>Phone Calls</span>
		</li>
		<li class="step3 wow fadeInUp" data-wow-duration="2s">
			<span><i class="fi cart-browser"></i>Website Ordering</span>
		</li>
		<li class="step4 wow fadeInUp" data-wow-duration="2.5s">
			<span><i class="fi mobile-cart"></i>Mobile App Ordering</span>
		</li>
	</ul>
</section> <!--section-->

<?php /*
<div id="loader">
	<span class="grey_logo"></span>
	<span id="color_logo" class="color_logo"></span>
</div>
*/ ?>

<?php include('inc/footer.php');?>
