import Constants from './constants.jsx';
import { createStore } from 'redux';

const initialState ={
	isLoaded: false,
	loading: false,
	restaurants:[]
}

const reducer = (state = initialState, action) => {

	if (action.type === Constants.REQUEST) {
		console.log('action.restaurants', action.restaurants)
	 	return {...state, restaurants: action.restaurants, isLoaded: true};
	}

   return state;
};

const store = createStore(reducer, initialState);

export default store; 