/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const CommonFunctions = require('../../../../helpers/common-functions');
const Constants = require('./constants');
const Store = require('./store');
const Qs = require('qs');


class Actions {

    static getResults(data) {
        data['is_pagination'] = 1;
        ApiActions.get(
            '/policy',
            data,
            Store,
            Constants.GET_RESULTS,
            Constants.GET_RESULTS_RESPONSE
        );
    }

    static showCreateNew(data) {
        //this.getNationalityResults();
        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW
        });
    }

    static hideCreateNew(data) {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }

    static createNew(data, history) {
        
        ApiActions.post(
            '/task',
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {

                if (!err) {
                    this.hideCreateNew();

                    const path = `/admin/task/${response.task_key}`;

                    history.push(path);

                    window.scrollTo(0, 0);
                }
            }
        );
    } 

    static changeSearchQuery(data, history) {                

        history.push({
            pathname: '/admin/policies',
            search: `?${Qs.stringify(data)}`
        });

        window.scrollTo(0, 0);
    }
    
    /* static getNationalityResults() {
        
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }
    */

    static getPolicy(policy_key)
    {
        ApiActions.get(
            `/policy/${policy_key}`,
            undefined,
            Store,
            Constants.GET_POLICY,
            Constants.GET_POLICY_RESPONSE
        );
    }


    static showViewModal(data) {
        
        Store.dispatch({
            type: Constants.SHOW_VIEW_MODAL,
            response:data
        });
    }

    static hideViewModal() {

        Store.dispatch({
            type: Constants.HIDE_VIEW_MODAL
        });
    }
}


module.exports = Actions;
