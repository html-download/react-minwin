/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Cuisines', {
    cuisineId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'cuisine_id'
    },
    cuisineKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'cuisine_key'
    },
    cuisineName: {
      type: DataTypes.STRING(260),
      allowNull: false,
      field: 'cuisine_name'
    },
    cuisineStatus: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'cuisine_status'
    },
    proposedStatus: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'proposed_status'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    attachedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'attached_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    sort: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'sort'
    },
    pagination: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'pagination'
    },
    isDeleted: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '0',
      field: 'is_deleted'
    },
    restoredDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'restored_datetime'
    },
    deletedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'deleted_datetime'
    },
    deletedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'deleted_by'
    },
    restoredBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'restored_by'
    }
  }, {
    tableName: 'ss16_cuisines'
  });
};
