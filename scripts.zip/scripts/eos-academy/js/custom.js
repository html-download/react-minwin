//calendar function
$(document).ready(function () {
    $('.datepicker').datepicker({
        format: "yyyy-mm-dd",
        autoclose: true,
        startDate: new Date()
    });
});

//animation
new WOW().init();

//Mobile Menu
$(".mobile-menu").on('click', function() {
    $(".menu-area nav").toggleClass("menu_open");
    $(this).toggleClass("menu_open");
    $("body").toggleClass("hideOverflow");
});

$(".menu-area nav ul.full-menu").on('click', function(event) {
    event.stopPropagation();
});

$(".menu-area nav").on('click', function() {
    $(".menu-area nav").removeClass("menu_open");
    $('.mobile-menu').removeClass("menu_open");
    $("body").removeClass("hideOverflow");
});

$('.menu-area a.sublink').click(function() {
    $('.header-sub-list').removeClass('open');
    $(this).next('.header-sub-list').addClass('open');
});


//tab
    $(document).ready(function(){
        $('.topic-tabs a:first').tab('show');
    });    

//timer
 // $(document).ready(function(){
// $('#demo').countdowntimer({
//   hours: 5,
//   minutes:20 ,
//   seconds: 60,
//   });
// });  
 