<footer id="footer" class="site_footer full_row">
    <section class="footer_form full_row">
        <div class="container">
            <h2 class="head">Request for proposal</h2>
            <p class="head_desc">To keep your project ideas confidential, we can sign an NDA document.</p>

            <form method="post" action-xhr="<?php echo $baseurl;?>"  custom-validation-reporting="show-first-on-submit" class="row">
                <div class="form_group">
                    <i class="fa fa-user-o"></i>
                    <input id="name" name="name" pattern="[A-Za-z]+" type="text" class="form_control" placeholder="Enter your name" required>
                    <span visible-when-invalid="valueMissing" validation-for="name" class="error">Name is required</span>
                    <span visible-when-invalid="patternMismatch" validation-for="name" class="error">Alphabets only</span>
                </div>
                <div class="form_group">
                    <i class="fa fa-envelope-o"></i>
                    <input id="email" name="email" type="email" class="form_control" placeholder="Enter your email" required>
                    <span visible-when-invalid="valueMissing" validation-for="email" class="error">Email is required</span>
                    <span visible-when-invalid="typeMismatch" validation-for="email" class="error">Invalid email</span>
                </div>
                <div class="form_group">
                    <i class="fa fa-mobile"></i>
                    <input id="mobile" name="mobile" type="text" class="form_control" pattern="[0-9]+" placeholder="Enter your mobile" required>
                    <span visible-when-invalid="valueMissing" validation-for="mobile" class="error">Mobile is required</span>
                    <span visible-when-invalid="patternMismatch" validation-for="mobile" class="error">Numbers only</span>
                </div>
                <div class="form_group full">
                    <textarea class="form_control" placeholder="Enter your message"></textarea>
                    <span class="error"></span>
                </div>
                <div class="form_group action">
                    <select class="form_control">
                        <option disabled="disabled" selected>Please select category</option>
                        <option>Entrepreneur</option>
                        <option>Consultant</option>
                        <option>Partnership</option>
                        <option>Startup</option>
                        <option>Freelancer</option>
                        <option>Developers/Designers</option>
                        <option>Student</option>
                        <option>Others</option>
                    </select>
                    <input type="submit" class="btn" value="Send Enquiry">
                </div>
            </form>
        </div> <!--container-->
    </section> <!--footer_form-->

    <div class="container footer_menu">
        <div class="row">
            <div class="col_3">
                <h3>Our Company</h3>
                <ul class="reset">
                    <?php echo $company;?>
                </ul>
            </div> <!--col_3-->

            <div class="col_3">
                <h3>Web Services</h3>
                <ul class="reset">
                    <?php echo $webServices;?>
                </ul>
            </div> <!--col_3-->

            <div class="col_3">
                <h3>Mobile Services</h3>
                <ul class="reset">
                    <?php echo $mobileServices;?>
                </ul>
            </div> <!--col_3-->

            <div class="col_3">
                <h3>Our Products</h3>
                <ul class="reset">
                    <?php echo $products;?>
                </ul>
            </div> <!--col_3-->
        </div>
    </div> <!--container-->

    <div class="copyright full_row">
		<div class="container">
			<ul class="reset">
				<li><a href="<?php echo $baseurl; ?>terms-and-conditions" title="Terms & Conditions">Terms & Conditions</a></li>
				<li><a href="<?php echo $baseurl; ?>refund-policy" title="Refund policy">Refund Policy</a></li>
				<li><a href="<?php echo $baseurl; ?>privacy-policy" title="Privacy Policy">Privacy Policy</a></li>
				<li><a href="<?php echo $baseurl; ?>delivery-shipping" title="Delivery Shipping">Delivery & Shipping</a></li>
                <li><a href="<?php echo $baseurl; ?>disclaimer" title="Disclaimer">Disclaimer</a></li>
                <li class="social">
                    <a href="<?php echo $facebook; ?>" title="Facebook" target="_blank" ><i class="fa fa-facebook"></i></a>
                    <a href="<?php echo $twitter; ?>" title="Twitter" target="_blank" ><i class="fa fa-twitter"></i></a>
                    <a href="<?php echo $gplus; ?>" title="Google+" rel="publisher" target="_blank"><i class="fa fa-google-plus"></i></a>
                    <a href="<?php echo $linkedin; ?>" title="Linkedin" target="_blank"><i class="fa fa-linkedin"></i></a>
                    <a href="<?php echo $youtube; ?>" title="Youtube" target="_blank"><i class="fa fa-youtube-play"></i></a>
                </li>
            </ul>
            
			<p class="full_row">&copy; <?php date_default_timezone_set("Europe/London"); echo date('Y'); ?> Technoduce Info Solutions Pvt. Ltd. All rights reserved.</p>
		</div> <!--container-->
	</div> <!--copyright-->
</footer> <!--site_footer-->

</body>
</html>