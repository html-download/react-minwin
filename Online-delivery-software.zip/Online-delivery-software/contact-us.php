<?php $title = 'Looking similar to Seamless, Doordash, Munchery, Caviar, hellofood clone-contact us' ?>
<?php $description = 'Looking similar to Seamless, Doordash, Munchery, Caviar, hellofood clone? Our online delivery software lets you manage your on-demand food delivery business. Check out our live demo.' ?>
<?php $keywords = 'Seamless clone, Doordash clone, Munchery clone, Caviar clone, hellofood clone' ?>


<?php include ("header.php")?>



<section class="subbanner portfolioPage text-center">
<div class="container">
<h1>Do you want to be the next Seamless, Munchery, hellofood?</h1>
</div>
</section>





<section class="getintouch text-center">
<div class="container">
<h2>Looking for online delivery management software?</h2>
<p class="sub">Our mission is to make your delivery more productive with less effort. <br> To keep your project ideas confidential, we can sign an NDA document.  </p>
<?php include ("contact-form.php");?>
</div>
</section>



<!-- <section class="contactUsplus">
<div class="container">
<div class="row">
<div class="col-md-4">
<div class="innerCon inter">
<i class="fa fa-map"></i>
<h4>Location</h4>

<p><b>Technoduce Info Solutions Pvt Ltd,</b><br>
JV Building, 2/3 &amp; 2/4 Mullai Nagar, <br>
Maruthamalai Main Road,<br>
Vadavalli, Coimbatore - 641041,<br>
Tamil Nadu, India.
</p>
</div>
</div>


<div class="col-md-4">
<div class="innerCon">
<i class="fa fa-phone"></i>
<h4>Call Us</h4>
<a href="tel:+91-422-422-1160" title="Phone">+91-422-422-1160</a>



</div>

<div class="innerCon">
<i class="fa fa-envelope"></i>
<h4>Mail us</h4>
<a href="mailto:sales@technoduce.com" title="EMail">sales@technoduce.com</a>
</div>

</div>


<div class="col-md-4">

<div class="innerCon">
<i class="fa fa-whatsapp"></i>
<h4>Whatsapp</h4>
<a href="intent://send/919003960003#Intent;scheme=smsto;package=com.whatsapp;action=android.intent.action.SENDTO;end" title="whatsapp">+91 90039 60003</a>
</div>

<div class="innerCon">
<i class="fa fa-skype"></i>
<h4>Skype</h4>
<a href="skype:sales.technoduce?call" title="Call us using Skype">sales.technoduce</a>
</div>

</div>

</div>
</div>
</section> -->



<?php include ("footer.php")?>