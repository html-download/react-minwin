/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16ItemUndo', {
    itemUndoId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'item_undo_id'
    },
    itemUndoKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'item_undo_key'
    },
    itemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_id'
    },
    tableName: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'table_name'
    },
    primaryFieldName: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'primary_field_name'
    },
    primaryId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'primary_id'
    },
    fieldName: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'field_name'
    },
    oldValue: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'old_value'
    },
    newValue: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'new_value'
    },
    type: {
      type: DataTypes.ENUM('ONE','ALL','DELETE','INSERT'),
      allowNull: false,
      field: 'type'
    },
    revoked: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '0',
      field: 'revoked'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    }
  }, {
    tableName: 'ss16_item_undo'
  });
};
