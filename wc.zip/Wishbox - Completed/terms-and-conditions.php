<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <!-- cms banner -->
  <section class="cms-page-banner text-center">
    <div class="container">
      <h2>Terms and conditions</h2>
      <ul class="br_ul reset">
        <li><a href="/">Home</a></li>
        <li><span>Terms and conditions</span></li>
      </ul>
    </div>
  </section>
  <!-- cms banner -->
  <section class="cms-full-content">
    <div class="container mx-1150">
      <div class="box-up">
        <h3>Authorisation of the Agreement</h3>
        <p>To become a member of WishBox, you will be required to complete and submit the online registration form. In order to successfully submit your registration, you must comply with the requirements found in WishBox’s user agreement.</p>

        <p>The fulfilment of provisions necessary to access the website – i.e. internet connection, computer, payment modes - will be your responsibility. People who use 
WishBox through your internet connection must also comply with the website’s terms. You agree to the Terms of Use by simply viewing, browsing or submitting any form or content on the website. The Terms of Use will serve as a binding legal agreement between you and WishBox. In the following paragraphs, the term "you" or "You" shall refer to any person or entity, who views, browses or submits any form of content on the website. If you refuse to comply with these Terms of Use, you are advised not to use the website. WishBox reserves the right to modify these Terms of Use at any time without prior notice. Furthermore, users must agree that during each visit to the website, the user will be subject to the then-current Terms of Use. Continued use of the WishBox website now or in the future following modifications in Terms of Use is considered as confirmation that you have read, accepted, and agreed to the terms mentioned. The terms and conditions apply to the WishBox website and its associated applications on devices such as iPhone, iPad, Android devices, and mobile site platforms.</p>

<h3>Description of Services</h3>
<p>Users who authorise the agreement will be allowed to order from merchants online via WishBox. The website offers a unique way for you to send your orders to merchants displayed. The key purpose of WishBox is to offer an easy and hassle-free service to customers, connecting them to merchants in their located area that 
offer delivery, takeaway, table bookings and appointments . Customers can build orders by using our interactive order menus and submit them in just a click.</p>

<p>The participating merchant is solely responsible for preparation and delivery of product. Users should be aware that merchant will always ensure that delivery is made on time. However, certain external forces that are well beyond their control (traffic blockades, road blocks, weather) can affect delivery at times. WishBox will 
inform you if such an unexpected delay is made known to us by the merchant.</p>

<p>WishBox does not sell or participate in any production. It only provides users with the ability to find nearby merchants to order from. Since these merchants are legally obligated to comply with local laws, rules and regulations and industry standards pertaining to preparation, sale, marketing and safety of the products. 
WishBox does not verify their credentials, nor test the ingredients or quality of products being sold. WishBox in no way guarantees the quality of any product or that the merchant complies with applicable laws or that the item delivered to the user will match the item displayed or described on the online menu.</p>

<p>WishBox will not be held accountable in the event that any product or services offered by merchants is deemed unhealthy or is the cause of an injury or illness, or that the delivered item does not meet the customer’s expectations. You are solely responsible for ensuring the accuracy of the delivery address. WishBox will not be liable or responsible for any inaccurate addresses provided by the user.</p>



      </div>
    </div>
  </section>
  <!-- myaccount -->
</div>
<!-- site -->
<?php include ('inc/footer.php'); ?>