<?php include ('inc/header.php'); ?>

<section class="page_banner full_row">
  <div class="container">
    <h1 class="animated fadeInDown">Launch your own online food ordering & delivery app with web and mobile build for you from FoodPurby</h1>    
    <p class="btns animated fadeInUp mb30">
      <a class="btn line" on="tap:footer.scrollTo(duration=500)">Contact us</a>
      <a class="btn line" on="tap:live_demo">Try live demo</a>
    </p>
    <amp-img src="<?php echo $baseurl;?>images/food-dashboard.png" alt="food dashboard" width="987" height="410" layout="responsive" class="animated fadeInUp"></amp-img>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="section form_quote">
	<div class="container">		
      <div class="heading"><h3>Get Free Quote</h3></div>
      
      <form method="post" action-xhr="<?php echo $baseurl;?>" custom-validation-reporting="show-first-on-submit">
          <div class="form_group">
            <i class="fa fa-user-o"></i>
            <input id="quoteName" name="quoteName" pattern="[A-Za-z]+" type="text" class="form_control" placeholder="Enter your name" required>
            <span visible-when-invalid="valueMissing" validation-for="quoteName" class="error">Name is required</span>
            <span visible-when-invalid="patternMismatch" validation-for="quoteName" class="error">Alphabets only</span>
          </div>
          <div class="form_group">
            <i class="fa fa-envelope-o"></i>
            <input id="quoteEmail" name="quoteEmail" type="email" class="form_control" placeholder="Enter your email" required>
            <span visible-when-invalid="valueMissing" validation-for="quoteEmail" class="error">Email is required</span>
            <span visible-when-invalid="typeMismatch" validation-for="quoteEmail" class="error">Invalid email</span>
          </div>
          <div class="form_group">
            <i class="fa fa-mobile"></i>
            <input id="quoteMobile" name="quoteMobile" type="text" class="form_control" pattern="[0-9]+" placeholder="Enter your mobile" required>
            <span visible-when-invalid="valueMissing" validation-for="quoteMobile" class="error">Mobile is required</span>
            <span visible-when-invalid="patternMismatch" validation-for="quoteMobile" class="error">Numbers only</span>
          </div>
          <input type="submit" class="btn grey" value="Get Quote">
      </form>
		</div>
	</div> <!--container-->
</section> <!--section-->

<section class="section text-center">
	<div class="container">
		<h2 class="head style1">Online food ordering application like <span>FoodPanda, Just Eat</span></h2>
		<p class="md mb0">Looking for developing online food ordering software script for the restaurant business as like Food Panda, Just Eat Clone? Technoduce offers you the best ready-made online food delivery script which is similar to Food Panda, Just Eat clone which is well optimized for both the web and mobile platform. We provide you the customized app with your own brand name. Every customer can order their food, at the same time they can able to proceed with payment, admin (who hold the web back end) earns commission from every order, the restaurant receives payment from admin, then delivery staff delivers food to the respective customer.</p>
	</div> <!--container-->
</section> <!--section-->

<section class="section app_process">
	<div class="container">
    	<amp-img class="app" src="<?php echo $baseurl;?>images/food-app-splash.png" alt="food dashboard" width="800" height="206" layout="responsive"></amp-img>
		<ul class="reset col_3">
			<li>
				<i class="fa fa-mobile"></i>
				<h3 class="head style2">App Interface</h3>
				<p>App admin is benefited with tangible and simple interface. FoodPurby app provided with multiple options allowing to add restaurants in back end, as well as enabling customers to signup for food orders in front end.</p>
			</li>
			<li>
				<i class="fa fa-location-arrow"></i>
				<h3 class="head style2">Detect Location</h3>
				<p>The app owner can enter and then update the list of all branches of a particular restaurant, in a particular city. This is done according to the choice of the App owner. Customer can pick his or her preferred location.</p>
			</li>
			<li>
				<i class="fa fa-building-o"></i>
				<h3 class="head style2">Find Restaurant</h3>
				<p>The app owner lets the customer to choose the restaurant closest to their location, with the preferable menu and price range of its items. From the narrowed down list, the person can simply click to place an order from any of these restaurants.</p>
			</li>
			<li>
				<i class="fa fa-cutlery"></i>
				<h3 class="head style2">Choose Menu</h3>
				<p>The app's admin has the facility to update the items listed in the menu, in accordance with the items currently available in the selected restaurants. Customers can browse through those menu's.</p>
			</li>
			<li>
				<i class="fa fa-credit-card"></i>
				<h3 class="head style2">Payment Option</h3>
				<p>Admin can setup multiple payment options, to receive payments from customers. The payment can be made through online banking, through cards, or as direct cash when delivered.</p>
			</li>
			<li>
				<i class="fa fa-truck"></i>
				<h3 class="head style2">Food Delivery</h3>
				<p>App owner gets notified with the customers order and sends the details of the order to the specific restaurant.The concerned restaurant then starts preparing the dish. After this, the food gets delivered to customer's specified address.</p>
			</li>
		</ul>
	</div> <!--container-->
</section> <!--section-->

<section class="section timeline">
	<div class="container">
		<h2 class="head style1">How restaurant ordering system works?</h2>
		<ul class="reset">
			<li>
				<div class="content">
					<span class="step">1</span><i class="fi cloud-mobile"></i>
					<h3>Customer placing order from web/mobile</h3>
					<p>Customers can place orders for their favorite dishes, right from the comfort of their choice through their web or smartphone, developed using our food ordering script.</p>					
				</div>
			</li>
			<li class="right">
				<div class="content fadeInRight">
					<span class="step">2</span><i class="fi shop"></i>
					<h3>Restaurant receives order via web app developed by FoodPurby</h3>
					<p>The restaurant management directs the order for food that the customer has placed, to the concerned restaurant, in a matter of seconds.</p>
				</div>
			</li>
			<li>
				<div class="content">
					<span class="step">3</span><i class="fi doc"></i>
					<h3>Customer receives confirmation</h3>
					<p>An acknowledgment of the food order takeaway is given to the customer, and he or she is informed of the expected time of delivery of the product.</p>
				</div>
			</li>
			<li class="right">
				<div class="content fadeInRight">
					<span class="step">4</span><i class="fi fry"></i>
					<h3>Restaurant starts to prepare order</h3>
					<p>The necessary steps are taken to prepare the order and get it ready with perfection for the final consumption by the respective customer.</p>
				</div>
			</li>
			<li>
				<div class="content">
					<span class="step">5</span><i class="fi care"></i>
					<h3>Restaurant assign orders to delivery staff</h3>
					<p>Delivery staff gets new order notification from restaurant to deliver the food to the concerned customer's place. The delivery staff updates the status to the restaurant as well as customers.</p>
				</div>
			</li>
			<li class="right">
				<div class="content fadeInRight">
					<span class="step">6</span><i class="fi food-bag"></i>
					<h3>Delivery staff delivers the food to customers</h3>
					<p>The order is delivered to the address given by the restaurant. Once the delivery staff delivers the food, E-signature is received from customers and notification is sent to restaurant</p>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section> <!--section-->

<section class="section text-center">
	<div class="container">
		<h2 class="head style1 mb10">Own your restaurant menu ordering application with FoodPurby</h2>
		<p class="head style1">Get everything you need</p>
		<div class="row">
			<div class="col_5 text-center">
        	<amp-img src="<?php echo $baseurl;?>images/food-ordering-application.png" alt="food dashboard" width="350" height="500" style="margin:0 auto; max-width:350px" layout="responsive"></amp-img>
			</div>
			<div class="col_7">
				<ul class="reset col_3 box_feature">
					<li>
						<span><i class="fa fa-code"></i>100% Source Code</span>
					</li>
					<li>
						<span><i class="fa fa-credit-card"></i>One-Time Payment</span>
					</li>
					<li>
						<span><i class="fa fa-sliders"></i>Customizable</span>
					</li>
					<li>
						<span><i class="fa fa-mobile"></i>In your brand name</span>
					</li>
					<li>
						<span><i class="fa fa-file-text-o"></i>RTL Feature</span>
					</li>
					<li>
						<span><i class="fa fa-shield"></i>Secured</span>
					</li>
				</ul>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<section class="section grey text-center pb30">
	<div class="container">
		<h2 class="head style1"><span>Admin</span> features in web application</h2>
		<div class="row features">
			<div class="col_4">
				<div class="content">				
					<h2 class="head">Admin control panel <i class="fa fa-sliders"></i></h2>
					<p>An Admin can log into the app using the web. Allowing both the Super admin and sub-admin to easily manage.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage access control <i class="fa fa-lock"></i></h2>
					<p>The admin can have complete control over ordering system. Also, can enable and disable access certain access to the vendors.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Cuisines & Ingredients <i class="fa fa-list-ul"></i></h2>
					<p>You can easily manage cuisines and ingredients type from admin back end. Also, can keep track of each item.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage category <i class="fa fa-gear"></i></h2>
					<p>Admin can effectively manage the category and its sub-categories. You can filter out based on its availability.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content vertical">
					<i class="fi monitor1"></i>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage vendor <i class="fa fa-user"></i></h2>
					<p>New vendors can be added to from the admin back end, as well as the vendor's item, orders, payments all can be managed.</p>
				</div>
			</div>			
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage customers <i class="fa fa-user-o"></i></h2>
					<p>Admin can effectively manage the orders of particular customers and get updates on their deliveries.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">
					<h2 class="head">CMS & Activity log <i class="fa fa-file-text-o"></i></h2>
					<p>Manage your complete online food ordering page with back-end CMS and also can keep track of complete activity log.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">
					<h2 class="head">General setting <i class="fa fa-gears"></i></h2>
					<p>SMTP info, site info, contact inquiry, banner, FAQ, currency, vouchers, manage address, newsletters can be managed.</p>
				</div>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<section class="section text-center pb30">
	<div class="container">
		<h2 class="head style1"><span>Restaurant</span> features in web and mobile application</h2>
		<div class="row features">
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage item <i class="fa fa-sliders"></i></h2>
					<p>Vendors can update new items in vendor back end by adding and editing item description along with the picture uploaded.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage Ingredients type <i class="fa fa-sliders"></i></h2>
					<p>Vendors can easily manage ingredient type and list from the vendor back end. Ingredients can be filtered based on the availability.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage payments <i class="fa fa-credit-card"></i></h2>
					<p>Any options can be presented to the customer to pay cash-on-delivery, or through cards, or through payment gateways.</p>
				</div>
			</div>			
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage orders <i class="fa fa-shopping-basket"></i></h2>
					<p>Vendors can effectively manage the orders of particular customers and make updates on their deliveries.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Manage reviews <i class="fa fa-comments-o"></i></h2>
					<p>The reviews and feedback given by customers can be managed, as well necessary action taken upon by the restaurant's management.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Assign delivery staff <i class="fa fa-user"></i></h2>
					<p>Vendors can assign the task to delivery staff and can keep track of delivery status in real time from anywhere.</p>
				</div>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<section class="section grey text-center pb30">
	<div class="container">
		<h2 class="head style1"><span>Customer</span> features in both web and mobile application</h2>
		<div class="row features">
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Customer sign up <i class="fa fa-user"></i></h2>
					<p>Customers can signup using both the web and mobile app. He can maintain a user profile with the address</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Choose delivery type <i class="fa fa-truck"></i></h2>
					<p>The customer can choose their delivery type either pickup or delivery or both, along with the date, time and menu list.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Search restaurant <i class="fa fa-search"></i></h2>
					<p>The customer can choose the location and look for nearby restaurants within the locality, providing a user-friendly interface.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Filter option <i class="fa fa-filter"></i></h2>
					<p>Our ordering application allows your customer to filter the order list based on the cuisine type, distance and price value.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Sort by <i class="fa fa-sliders"></i></h2>
					<p>Your customers can easily sort out the order list based on the popularity of the menu, reviews & ratings, minimum value order.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Payment Methods <i class="fa fa-credit-card"></i></h2>
					<p>The customer can choose to pay for the ordered food either through Cash On Delivery or through the use of debit/credit cards.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Notification <i class="fa fa-bell-o"></i></h2>
					<p>Your customer gets notified with Email or SMS notification on confirmation of every order status.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">My orders <i class="fa fa-shopping-basket"></i></h2>
					<p>The past orders can be viewed, as well as can relook on the current selection, before making it final.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Reviews / Favourites <i class="fa fa-comments-o"></i></h2>
					<p>Your customer can write reviews and provide ratings for any restaurant. Also, they can mark favorites as a bookmark.</p>
				</div>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<section class="section text-center pb30">
	<div class="container">
		<h2 class="head style1"><span>Delivery app</span> features in mobile application</h2>
		<div class="row features">
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Delivery app login <i class="fa fa-lock"></i></h2>
					<p>The delivery staff can login with his respective username through his mobile device to check out that day's assigned orders.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Assigned Orders <i class="fa fa-shopping-basket"></i></h2>
					<p>The delivery staff can view the respective orders that have been assigned to him with location & time.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">My Profile <i class="fa fa-user"></i></h2>
					<p>The delivery staff can create a profile listing contact details as well as personal information including the name.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Order Info <i class="fa fa-file-text-o"></i></h2>
					<p>Delivery staff can view the order information, including the customer's name, ordered dish and the location.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Driver Location <i class="fa fa-map-marker"></i></h2>
					<p>The current location of all delivery staff can be established through this feature to see who is closest.</p>
				</div>
			</div>
			<div class="col_4">
				<div class="content">					
					<h2 class="head">Customer review <i class="fa fa-comments-o"></i></h2>
					<p>The reviews and feedback given by customers can be managed, as well necessary action taken upon for quality service.</p>
				</div>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<section class="section grey text-center portfolio">
	<div class="container wow fadeInUp">
		<h2 class="head style1">Some of our clients using <span>FoodPurby</span> product</h2>
		<p class="desc">View our clients live online food ordering application</p>
		<div class="row">
			<div class="col_3">
				<a href="<?php echo $baseurl;?>/portfolio/caterninja.html" target="_blank">
					<amp-img src="<?php echo $baseurl;?>images/food-dashboard.png" alt="food dashboard" width="987" height="410" layout="responsive"></amp-img>
				</a>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<amp-lightbox id="live_demo" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner sm">
			<div class="dialog_content">
				<a on="tap:live_demo.close" class="close"><i class="fi close"></i></a>
				<h2 class="head">Request Demo</h2>
				<form method="post" class="float_form" action-xhr="<?php echo $baseurl;?>" custom-validation-reporting="show-first-on-submit">
					<div class="form_group">
						<label>
							<i class="fa fa-user-o"></i>Your Name
							<input id="demoName" name="demoName" pattern="[A-Za-z]+" type="text" class="form_control" placeholder="Enter your name" required>
						</label>
						<span visible-when-invalid="valueMissing" validation-for="demoName" class="error">Name is required</span>
						<span visible-when-invalid="patternMismatch" validation-for="demoName" class="error">Alphabets only</span>
					</div>
					<div class="form_group">
						<label>
							<i class="fa fa-envelope-o"></i>Your Email
							<input id="demoEmail" name="demoEmail" type="email" class="form_control" placeholder="Enter your email" required>
						</label>
						<span visible-when-invalid="valueMissing" validation-for="demoEmail" class="error">Email is required</span>
						<span visible-when-invalid="typeMismatch" validation-for="demoEmail"> class="error"Invalid email</span>
					</div>
					<div class="form_group">
						<label>
							<i class="fa fa-mobile"></i>Phone Number
							<input id="demoMobile" name="demoMobile" type="text" class="form_control" pattern="[0-9]+" placeholder="Enter your mobile" required>
						</label>
						<span visible-when-invalid="valueMissing" validation-for="demoMobile" class="error">Mobile is required</span>
						<span visible-when-invalid="patternMismatch" validation-for="demoMobile" class="error">Numbers only</span>
					</div>
					<input type="submit" class="btn full" value="Get your Demo">
				</form>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<?php include ('inc/footer.php'); ?>