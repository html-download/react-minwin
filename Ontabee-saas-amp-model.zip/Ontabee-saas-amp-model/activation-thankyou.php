<?php $title = 'Thankyou - Ontabee' ?>
<?php $description = '' ?>
<?php $keywords = '' ?>
<?php
	$queries = array();
	parse_str($_SERVER['QUERY_STRING'], $queries);
?>

<?php include ('inc/header.php'); ?>
<section class="page_banner thankyou">
	<div class="container">
		<div class="content">			
			<i class="fi tick"></i>
			<h2>Thank you for activating your account!</h2>
			<p>Please check your demo site: <a href="https://<?php echo $queries['domain']; ?>.ontabee.com"><?php echo $queries['domain']; ?></a></p>
		</div>
	</div> <!--container-->
</section>

<?php include('inc/footer.php');?>