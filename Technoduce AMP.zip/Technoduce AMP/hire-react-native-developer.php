<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/react-js-logo.png" alt="Hire React Native developer" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Hire React Native developer</h1>
      <p class="desc animated fadeInUp">Scalable and interactive development services. <br>Bring additional growth to your business through mobile apps.</p>
      <p class="animated fadeInUp mb20">Custom React Native app development, M-commerce application, Enterprise React Native application, Complete support</p>
      <a href="<?php echo $baseurl;?>contactus" target="_blank" class="btn line animated fadeInUp">Get free quote</a>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="grey">
  <div class="container relative">
    <div class="col_6 pr30">
      <h2 class="head line style1">Hire React Native developer</h2>
      <p>Online shoppers across the globe are increasingly preferring to go shopping from their React Native phones. Hence, it is essential for your firm to hire React Native developers for the purpose of generating business from this trend. Worried on how to locate skilled developers at such short notice? No problem. You can hire React Native developers from Technoduce in a flexible manner. Experienced developers of the company to work at your or ours place!</p>
      <p>That's right! Hire our React Native developers for flexible periods of time, ranging from days to weeks and to months. The React Native developers of Technoduce can do work as outsource for React Native app development or work directly along your side, at your office location. Either way, you remain in total control of the project. A new way of hiring React Native developers!</p>
      <p><a href="<?php echo $baseurl;?>contactus" target="_blank" class="btn">Get free quote</a></p>
    </div>
    
    <div class="col_6 pl30 diagram">
      <amp-img src="https://192.168.1.149:444/images/angular-development.png" alt="Hire React Native developer" width="460" height="450" layout="responsive"></amp-img>
    </div>
  </div> <!--container-->
</section>

<section class="half blue white">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right">
        <h2 class="head style1">Key benifits of hiring</h2>
        <p>To develop an React Native application for your business, you will surely expect the best from the React Native developer. A mobile application is going to be the identity of your brand, in every React Native device, and you have to make sure that it represents your business attractively. Besides, you may have some constant changed to be made to the React Native application developed.</p>
        <p>All these factors make it essential to hire a talented and experienced React Native developer, who knows his or her trade. Moreover, you may need to hire an React Native developer only for a specific project. Andoid application development companies like Technoduce offer a solution, in which you can hire developers from them for a specific project and have all attention marked on it.</p>
        <p><a href="<?php echo $baseurl;?>contactus" target="_blank" class="btn line">Get free quote</a></p>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="half dark white">
  <div class="bg bg2 right"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_left">
        <h2 class="head style1">Skill set of developers</h2>
        <ul class="lists mb30">
          <li>Suspendisse at auctor nunc, aliquet vulputate urna sit amet</li>
          <li>Suspendisse at auctor nunc, aliquet vulputate urna sit amet</li>
          <li>Suspendisse at auctor nunc, aliquet vulputate urna sit amet</li>
          <li>Suspendisse at auctor nunc, aliquet vulputate urna sit amet</li>
          <li>Suspendisse at auctor nunc, aliquet vulputate urna sit amet</li>
        </ul>
        <p><a href="<?php echo $baseurl;?>contactus" target="_blank" class="btn green">Get free quote</a></p>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="section timeline">
	<div class="container md">
		<h2 class="head style1">Why choose Technoduce?</h2>
		<ul class="reset">
			<li>
				<div class="content">
					<span class="step">1</span><i class="fi setting"></i>
					<h3>Lorem ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consecte adipiscing. Fusce ac ultricies sapien suspendisse</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">2</span><i class="fi setting"></i>
					<h3>Lorem ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consecte adipiscing. Fusce ac ultricies sapien suspendisse</p>
				</div>
      </li>
      <li>
				<div class="content">
					<span class="step">3</span><i class="fi setting"></i>
					<h3>Lorem ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consecte adipiscing. Fusce ac ultricies sapien suspendisse</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">4</span><i class="fi setting"></i>
					<h3>Lorem ipsum dolor sit</h3>
					<p>Lorem ipsum dolor sit amet, consecte adipiscing. Fusce ac ultricies sapien suspendisse</p>
				</div>
      </li>
    </ul>
	</div> <!--container-->
</section> <!--section-->

<section>
	<div class="container text-center">  
    <h2 class="head">Technoduce hiring model</h2>
    <amp-img src="<?php echo $baseurl;?>images/hire-model.png" alt="Hire React Native developer" style="max-width:897px; margin:0 auto" width="897" height="393" layout="responsive"></amp-img>
  </div> <!--container-->
</section> <!--section-->

<?php include ('inc/footer.php'); ?>