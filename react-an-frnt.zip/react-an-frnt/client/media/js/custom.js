

$(".show_hide .btn").click(function() {
  $(this).toggleClass("open");
  var input = $(".passToggle");
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }

});



$(document).ready(function() {
    $(".btn-top").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});



$('.select-modal').select2({
    dropdownParent: $('#create'),
    width: '100%'
});



$('select').select2({
  width: '100%'
});



$('.collapse-txt').click(function() {
  $(this).toggleClass( "active" );
  if ($(this).hasClass("active")) {
    $(this).text("Expand");
  } else {
    $(this).text("Collapse");
  }
});




// loader
  $('.loader').on('click', function() {
    var $this = $(this);
    var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
    if ($(this).html() !== loadingText) {
      $this.data('original-text', $(this).html());
      $this.html(loadingText);
    }
    setTimeout(function() {
      $this.html($this.data('original-text'));
    }, 2000);
  });

  //tooltip
  $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})




$(document).ready(function() {
    $('.dataTable').DataTable({
      "aaSorting": []
    });

$('.dropdown-toggle').dropdown();

// toast alert

  $(".toast-alert").click(function(event) {
     Snackbar.show({text: 'Record Created Succesfully !'}); 
    });



$(document).ready(function() {
    $('.add-forms').editable({
      mode: 'inline',
      emptytext: '+Add', 
    });
});


$('.password-toggle').change(function() {
        $(".change-password").toggleClass("open");
    });


// close hide

  $(".first-box .btn-warning").click(function(event) {
       $(".first-box").addClass("hide");
       $(".second-box").addClass("open");
    });


// date picker

$('.datePicker').datepicker({
    language: 'en',
    minDate: new Date(),
    autoClose:true,
    dateFormat:"d/MM/yyyy"
});

$('.dateTimePicker').datepicker({
      language: 'en',
    minDate: new Date(),
    autoClose:true,
    dateFormat:"d/MM/yyyy",
    timepicker: true
});



} );

