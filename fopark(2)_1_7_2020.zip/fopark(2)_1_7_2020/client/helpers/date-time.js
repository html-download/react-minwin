'use strict';
const moment = require('moment');

module.exports = {
    _emailDateTemplate : function () {
        try {
            var day = moment().format("MMM DD, YYYY h:mmA");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getTimeInterval : function (startTime, endTime, lunchTime = 0){
        var start = moment(startTime, "HH:mm");
        var end = moment(endTime, "HH:mm");
        var minutes = end.diff(start, 'minutes');
        var interval = moment().hour(0).minute(minutes);
        interval.subtract(lunchTime, 'minutes');
        return interval.format("HH:mm");
    }
};
