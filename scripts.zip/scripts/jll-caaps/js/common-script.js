/**
 *
 */
function bindFileInputField() {
    $('.files-name').change(function () {

        var file = $(this).get(0).files[0];

        if (file !== undefined) {
            file = file.name;
        } else {
            file = '<i class="fa fa-upload" aria-hidden="true"></i> Choose File';
        }

        $(this).prev('label').html(file);
    });
}

/**
 *
 */
function bindSelectField() {
    $('.selectpicker').selectpicker();
}

runOnLoad(function () {
    $('.select2').select2();

    $('[data-input-format="decimal"]').inputmask("decimal", {
        radixPoint: ".",
        autoGroup: true,
        clearMaskOnLostFocus: false,
        rightAlign: false
    });

    $('[data-input-format="number"]').inputmask("numeric", {
        autoGroup: true,
        clearMaskOnLostFocus: false,
        rightAlign: false
    });

    $('[data-picker="date"]').datepicker({
        autoclose: true,
        format: 'd/m/yyyy'
    });

    $('[data-picker="year"]').datepicker({
        autoclose: true,
        format: 'yyyy',
        minViewMode: "years",
        maxViewMode: "years"
    });

    $('[data-picker="month"]').datepicker({
        autoclose: true,
        format: 'mm',
        minViewMode: "months",
        maxViewMode: "months"
    });

    $('[data-picker="month-year"]').datepicker({
        autoclose: true,
        format: 'mm yyyy',
        minViewMode: "years",
        maxViewMode: "months"
    });

    var date = new Date();
    date.setDate(date.getDate());

    $('[data-picker="future-date"]').datepicker({
        autoclose: true,
        format: 'd-m-yyyy',
        startDate : date
    });

    $('[data-picker="past-date"]').datepicker({
        autoclose: true,
        format: 'd-m-yyyy',
        endDate : date
    });

});


