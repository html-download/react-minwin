document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.bundle.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/Chart.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/tableHeadFixer.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.1.0/anime.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.sparkline.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap-datepicker.min.js" ></scr'+'ipt>');
