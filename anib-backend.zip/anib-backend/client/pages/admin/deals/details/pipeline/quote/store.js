'use strict';
const Constant =  require('./constants');
const ObjectAssign = require('object-assign');
const Redux = require('redux');
const ParseValidation = require('../../../../../../helpers/parse-validation');

const initialState = {    
    loading: false,
    product_hydrated: true,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    is_quote_collapsed: false,
    policy_start_date: undefined,
    quote_data: undefined,
    is_quote_modal_open: false,
    deal_quote_key: undefined,
    submit_quote:undefined,
    quote_save_loading: false,
    quote_save_send_loading: false,
    mortgage: []
};

let validation;
let result;
const reducer = function (state = initialState, request) {
        
    switch (request.type) {

        case Constant.GET_MORTGAGE_DETAILS:
            return ObjectAssign({}, state, {
                mortgage : []
            });
            break;
        case Constant.GET_MORTGAGE_DETAILS_RESPONSE:
            return ObjectAssign({}, state, {
                mortgage : request.response.data
            });
            break;

        case Constant.GET_DEAL_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                loading : true
            });
            break;

        case Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];

            return ObjectAssign({}, state, {
                loading: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                quote_data: result,
                is_empty: result.length > 0 ? false : true,
                product_hydrated: true,
                is_quote_modal_open: false,
            });

            break;

        case Constant.GET_PRODUCT_DETAILS:
            return ObjectAssign({}, state, {
                product_hydrated : true
            });
            break;

        case Constant.GET_PRODUCT_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                product_hydrated: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                product_data: result
            });

            break;

        case Constant.TOGGLE_QUOTE:
            return ObjectAssign({}, state, {
                is_quote_collapsed : (state.is_quote_collapsed) ? false : true,                
            });
            break;

        case Constant.UPDATE_DATE:

            return ObjectAssign({}, state, { policy_start_date: request.date });
            break;
        case Constant.OPEN_QUOTE_MODAL:
            return ObjectAssign({}, state, {
                is_quote_modal_open: true,
                deal_quote_key: request.deal_quote_key,
                submit_quote:request.submit_quote
            });
            break;
        case Constant.HIDE_QUOTE_MODAL:
            return ObjectAssign({}, state, { 
                is_quote_modal_open: false,
                deal_quote_key: undefined,
                submit_quote:undefined
            });
            break;

        case Constant.UPDATE_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                quote_save_loading : true,                
            });
            break;

        case Constant.UPDATE_QUOTE_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                quote_save_loading: false
            });

            break;

        default:
            return ObjectAssign({}, state);
            break;
    }           
};
module.exports = Redux.createStore(reducer);


