'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const Paginations = require('../../../../../helpers/paginations');
const ParseValidation = require('../../../../../helpers/parse-validation');

//import TempData from './sample-data.json';

const initialState = {
    hydrated: false,
    loading: false,
    list_loading: false,
    error: undefined,
    data: [],
    pages: {},
    items: {},
    is_pipeline: false,
    user_data: [],
    editable_field: undefined,
    createDeal:false,
};
const reducer = function (state = initialState, action) {


    if (action.type === Constants.SHOW_CREATE_NEW) {
        return ObjectAssign({}, state, {
            createDeal: true            
        });
    }

    if (action.type === Constants.HIDE_CREATE_NEW) {
        return ObjectAssign({}, state, {
            createDeal: false            
        });
    }

    if (action.type === Constants.GET_RESULTS) {
        return ObjectAssign({}, state, {
            hydrated: false,
            list_loading: true
        });
    }

    if (action.type === Constants.GET_RESULTS_RESPONSE) {

        let headers = action.response ? action.response.headers : {};

        let data = {
            current_page: headers['x-pagination-current-page'] ? headers['x-pagination-current-page'] : 0,
            page_count: headers['x-pagination-page-count'] ? headers['x-pagination-page-count'] : 0,
            per_page: headers['x-pagination-per-page'] ? headers['x-pagination-per-page'] : 0,
            total_count: headers['x-pagination-total-count']  ? headers['x-pagination-total-count'] : 0 
        }


        //console.log("action.response", action.response);
        return ObjectAssign({}, state, {
            hydrated: true,
            list_loading: false,
            data: action.response ? action.response.data : [],
            pages: Paginations.pages(data)
        });
    }

    if (action.type === Constants.GET_USER_DETAILS) {
        return ObjectAssign({}, initialState, {
            loading: true
        });
    }

    if (action.type === Constants.GET_USER_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);

        const result = (action.response && action.response.data) ? action.response.data : [];

        return ObjectAssign({}, state, {
            loading: false,
            user_data: result
        });
    }

    if (action.type === Constants.EDITABLE_SHOW) {
        return ObjectAssign({}, state, {
            editable_field: action.field
        });
    }

    if (action.type === Constants.EDITABLE_HIDE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }

    if (action.type === Constants.TOGGLE_PIPELINE) {
        return ObjectAssign({}, state, {
            is_pipeline: !state.is_pipeline
        });
    }

    return state;
};


module.exports = reducer;
