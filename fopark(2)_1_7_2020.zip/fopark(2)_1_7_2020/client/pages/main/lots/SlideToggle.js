import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import CircularProgressbar from 'react-circular-progressbar';
const UserIdentity = require('../../../helpers/user-identity');
const Actions = require('./actions.js');
const ModalForm = require('./modal-form.jsx');
const LocationSearchInput = require('./auto-complete-form.jsx');
const Store = require('./store');
const ObjectAssign = require('object-assign');

class SlideToggle extends Component {
    constructor(props) {
        super(props);
        /*this.state = {
            error: null,
            isLoaded: false,
            lots: []
        };*/
        this.state = Store.getState();
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.els = {};
        this.updateSlideToggle = this.updateSlideToggle.bind(this);

    };

    updateSlideToggle() {
        fetch(`${this.params.fopark_url}/client/lots?name=auburn`, {
            'headers': new Headers({
                'X-api-key':  this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    if('lots' in result){
                        //console.log(result.lots)
                        this.setState({
                            isLoaded: true,
                            lots: result.lots
                        });
                    } else {
                        this.setState({
                            isLoaded: true,
                            error: {
                                'message': 'No Lots Returned'
                            }
                        });
                    }
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            );
    };

    componentDidMount() {
        this.updateSlideToggle();
    };

    componentWillUnmount() {
        //this.unsubscribeStore();
    };
    render() {
        const {error, isLoaded, lots} = this.state;

        if (error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if (!isLoaded) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else {
            return (
                <div className="cur_loc">
                    <LocationSearchInput />
                </div>
            );
        }
    };
}

export default SlideToggle;