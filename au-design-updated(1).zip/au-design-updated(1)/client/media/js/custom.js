//Animation
new WOW().init();

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});

// Modal Popup Not to Close 
/*$(".custom-modal, .event").on('click', function(event) { event.stopPropagation(); });*/
//$(".custom-modal, .event").on('click', function(e) { e.stopPropagation(); });

/*$('.toggle-password').trigger( "click" );*/

// Password Show Hide
/*$(".toggle-password").click(function() {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
    input.attr("type", "text");
    } else {
    input.attr("type", "password");
    }
});*/

$("#load-signin-button").click(function(){
	$(".dropdown.custom-drop").removeClass("open");
	$(".dropdown.custom-drop.signup").addClass("open");
});

$("#load-signup-button").click(function(){
	$(".dropdown.custom-drop.signup").removeClass("open");
	$("li#login-popup .dropdown.custom-drop").addClass("open");
});

$("#forget").click(function(){
    $(".reset-part").addClass("show-in");
    $(".login-part").addClass("hide");
});

$("#signin").click(function(){
    $(".reset-part").removeClass("show-in");
    $(".login-part").removeClass("hide");
});


$(document).ready(function(){
	$(".site_footer h4").click(function(){
			$(this).next(".res_acc, .about_content").slideToggle();        
			$(this).toggleClass("res_arrow17");
	});
});

$(document).ready(function(){
	$(".sound a").click(function(){
        $(this).toggleClass("off");
    });
});


/*Equal Height*/
( function( $, window, document, undefined ){
	'use strict';
	var $list		= $( '.login-register' ),
		$items		= $list.find( '.equal' ),
		setHeights	= function()
	    {
			$items.css( 'height', 'auto' );
			var perRow = Math.floor( $list.width() / $items.width() );
			if( perRow == null || perRow < 2 ) return true;
			for( var i = 0, j = $items.length; i < j; i += perRow )
			{
				var maxHeight	= 0,
					$row		= $items.slice( i, i + perRow );

				$row.each( function()
				{
					var itemHeight = parseInt( $( this ).outerHeight() );
					if ( itemHeight > maxHeight ) maxHeight = itemHeight;
				});
				$row.css( 'height', maxHeight );
			}
		};	
	setHeights();
	$( window ).on( 'resize', setHeights );	
})( jQuery, window, document );	

// Main Menu
$(".main_menu").on('click', function() {
    $("nav.navbar").fadeToggle();
    $("nav.navbar").toggleClass("open");
    $(this).toggleClass("open");
    $("body").toggleClass("modal_open");
});

$("nav.navbar ul li a,nav.navbar").on('click', function() {
    $("nav.navbar").fadeOut();
    $("nav.navbar").removeClass("open");
    $(".main_menu").removeClass("open");
    $("body").removeClass("modal_open");
});
