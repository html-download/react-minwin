<?php $title = '404' ?>
<?php $description = "" ?>
<?php $keywords = '' ?>


<?php include("header.php");?>
<!-- flower banner -->
<section class="four-not-four text-center">
<div class="container">
<div class="row">
<div class="col-sm-12">
<img src="/img/404.png" alt="error" class="img-responsive">
<h3>Looks Like You're Lost</h3>
<p>The page you are looking for not availble!</p>
<a href="/">Go to Home! <i class="fa fa-arrow-right"></i></a>
</div>
</div>
</div>
</section>
<!-- flower banner -->
<?php include("footer.php");?>
