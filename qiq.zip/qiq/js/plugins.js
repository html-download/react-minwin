document.write('<scr'+'ipt type="text/javascript" src="js/popper.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.smoothState.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/wow.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.pagenav.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/particles.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/owl.carousel.min.js" ></scr'+'ipt>');


