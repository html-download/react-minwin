/* global window */
'use strict';
const ApiActions = require('../../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../../helpers/toaster');


class Actions {

    static getDetails(id, loadAnotherData = true) {

        if (loadAnotherData) {
            this.getNationalityResults();
            this.getUserResults();
            this.getEnquiryTypes();
            this.getCountryResults();
        }

        ApiActions.get(
            `/deal/${id}`,
            undefined,
            Store,
            Constants.GET_DEAL_DETAILS,
            Constants.GET_DEAL_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.data && response.data.customer_id && response.data.customer_id !== null) {
                        this.getCustomerDetails(response.data.customer_id);                        
                        this.getDrivingDetails(response.data.customer_id);
                    }
                }
            }
        );
    }

    static getCustomerDetails(id) {

        ApiActions.get(
            `/customer/${id}`,
            undefined,
            Store,
            Constants.GET_DETAILS,
            Constants.GET_DETAILS_RESPONSE
        );
    }

    static getNationalityResults() {
        
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }

    static getEnquiryTypes() {
        
        ApiActions.get(
            '/deal/enquiry-type',
            undefined,
            Store,
            Constants.GET_ENQUIRY_RESULTS,
            Constants.GET_ENQUIRY_RESULTS_RESPONSE
        );
    }

    static getUserResults() {
        
        ApiActions.get(
            '/user',
            undefined,
            Store,
            Constants.GET_USER_DETAILS,
            Constants.GET_USER_DETAILS_RESPONSE
        );
    }

    static saveDetails(id, data) {

        ApiActions.post(
            `/customer/attribute-save/${id}`,
            data,
            Store,
            Constants.SAVE_DETAILS,
            Constants.SAVE_DETAILS_RESPONSE
        );
    }

    static saveDealDetails(id, data) {

        ApiActions.post(
            `/deal/attribute-save/${id}`,
            data,
            Store,
            Constants.SAVE_DEAL_DETAILS,
            Constants.SAVE_DEAL_DETAILS_RESPONSE
        );
    }

    static saveDealCustomerDetails(id, data) {

        ApiActions.post(
            `/deal/deal-customer-attribute-save/${id}`,
            data,
            Store,
            Constants.SAVE_CUSTOMER_DETAILS,
            Constants.SAVE_CUSTOMER_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    this.getDetails(id, false);
                }
            }
        );
    }

    static getCountryResults() {
        
        ApiActions.get(
            '/country',
            undefined,
            Store,
            Constants.GET_COUNTRY_RESULTS,
            Constants.GET_COUNTRY_RESULTS_RESPONSE
        );
    }

    static getDrivingDetails(id) {
        
        ApiActions.get(
            `/customer-driving-profile/${id}`,
            undefined,
            Store,
            Constants.GET_DRIVING_DETAILS,
            Constants.GET_DRIVING_DETAILS_RESPONSE
        );
    }
    
    static saveDrivingDetails(data) {
        
        ApiActions.post(
            '/customer-driving-profile/attribute-save',
            data,
            Store,
            Constants.SAVE_DRIVING_DETAILS,
            Constants.GET_DRIVING_DETAILS_RESPONSE
        );
    }

    static hideDetailsSaveSuccess() {

        Store.dispatch({
            type: Constants.HIDE_DETAILS_SAVE_SUCCESS
        });
    }

    static savePassword(id, data) {

        if (data.password !== data.passwordConfirm) {
            return Store.dispatch({
                type: Constants.SAVE_PASSWORD_RESPONSE,
                err: new Error('password mismatch'),
                response: {
                    message: 'Passwords do not match.'
                }
            });
        }

        delete data.passwordConfirm;

        ApiActions.put(
            `/api/users/${id}/password`,
            data,
            Store,
            Constants.SAVE_PASSWORD,
            Constants.SAVE_PASSWORD_RESPONSE
        );
    }

    static hidePasswordSaveSuccess() {

        Store.dispatch({
            type: Constants.HIDE_PASSWORD_SAVE_SUCCESS
        });
    }

    static delete(id, history) {

        ApiActions.delete(
            `/customer/delete/${id}`,
            undefined,
            Store,
            Constants.DELETE,
            Constants.DELETE_RESPONSE,
            (err, response) => {

                if (!err) {
                    
                    history.push('/admin/customers');

                    window.scrollTo(0, 0);
                }
            }
        );
    }

    static addEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });

    } 

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });

    } 

    static showDeleteModal() {

        Store.dispatch({
            type: Constants.DELETE_MODAL_SHOW
        });

    } 

    static hideDeleteModal() {

        Store.dispatch({
            type: Constants.DELETE_MODAL_HIDE
        });

    }

    static addTaskModal() {

        Store.dispatch({
            type: Constants.ADD_TASK_MODAL_SHOW
        });
    }

    static hideTaskModal() {

        Store.dispatch({
            type: Constants.ADD_TASK_MODAL_HIDE
        });

    }

    static addNoteModal() {

        Store.dispatch({
            type: Constants.ADD_NOTE_MODAL_SHOW
        });
    }

    static hideNoteModal() {

        Store.dispatch({
            type: Constants.ADD_NOTE_MODAL_HIDE
        });
    }

    static getNotes() {

        ApiActions.get(
            '/deal-note',
            undefined,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE
        );
    }

    static createNoteNew(data) {

        ApiActions.post(
            '/deal-note',
            data,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.hideNoteModal();
                        this.getNotes();
                        Toaster.success('Note Has been created..');
                    }
                }
            }
        );
    }

    static updateDOB(date) {

        Store.dispatch({
            type: Constants.UPDATE_DOB,
            date: date
        });

    }

    static datePicker(date,field) {

        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD,
            date: date,
            field:field
        });

    }
    static resetStore() {

        Store.dispatch({
            type: Constants.RESET_STORE
        });

    } 

    static toggleTab(tab, url, id) {

        Store.dispatch({
            type: Constants.TOGGLE_TAB,
            tab: tab,
            url: url,
            id: id,
        });

    } 

    static updateOrderId(id) {

        Store.dispatch({
            type: Constants.UPDATE_ORDER_ID,
            id: !id ? '' : id,
        });

    } 
    

    static getPipelineDetails() {

        ApiActions.get(
            '/pipeline',
            undefined,
            Store,
            Constants.GET_PIPELINE_DETAILS,
            Constants.GET_PIPELINE_DETAILS_RESPONSE
        );
    }
    
}


module.exports = Actions;
