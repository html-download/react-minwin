<?php include ('../inc/header.php'); ?>

<section class="page_banner">
  <div class="container">
    <h1 class="animated fadeInDown">All best brain of us!</h1>
    <p class="desc animated fadeInUp mb0">Meet our Subject Matter Experts (SME) who are leading our organization with their talents and dedicated service to deliver exceptional products and services.</p>
  </div> <!--container-->
</section> <!--page_banner-->

<?php include ('../inc/footer.php'); ?>