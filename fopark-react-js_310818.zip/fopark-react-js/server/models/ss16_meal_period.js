/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16MealPeriod', {
    periodId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'period_id'
    },
    mealSizeId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'meal_size_id'
    },
    days: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: '',
      field: 'days'
    },
    fromTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'from_time'
    },
    toTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'to_time'
    },
    mealSize: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'meal_size'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_meal_period'
  });
};
