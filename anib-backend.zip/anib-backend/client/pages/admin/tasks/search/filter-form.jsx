'use strict';
const FilterFormHoc = require('../../../../pages/admin/components/filter-form-hoc.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const SelectControl = require('../../../../components/form/select-control.jsx');
const TextControl = require('../../../../components/form/text-control.jsx');
const Actions = require('./actions');

const propTypes = {
    linkInputState: PropTypes.func,
    linkSelectState: PropTypes.func,
    loading: PropTypes.bool,
    state: PropTypes.object,
    history:PropTypes.object
};
const defaultValues = {
    username: '',
    sort: '_id',
    limit: '5',
    page: '1'
};


class FilterForm extends React.Component {

    constructor(props) {

        super(props);
        this.els = {};
    }
    searchFilter() {

        let task_status = this.els.task_status_all.checked ? '' : this.els.task_status_active.checked ? 1 : 2;
        Actions.changeSearchQuery({limit : this.els.limit.value(), search_input : this.els.search.value(), task_status : task_status } ,this.props.history);
    }


    render() {

        return (
            <div className="row header_filter">
            
            <div className="col-sm-12">
            <div className="quick-filters">
                    <h5>Quick Filters</h5>

                    <div className="label-list">
                    <input type="radio" name="task_status" ref={(c) => (this.els.task_status_all = c)} onChange={this.searchFilter.bind(this)} className="hidden" id="all" defaultChecked/>
                    <label className="filter" htmlFor="all">All</label>

                    <input type="radio" name="task_status" ref={(c) => (this.els.task_status_active = c)} onChange={this.searchFilter.bind(this)} className="hidden" id="active" value="1"/>
                    <label className="filter" htmlFor="active">Pending</label>

                    <input type="radio" name="task_status" ref={(c) => (this.els.task_status_pending = c)} onChange={this.searchFilter.bind(this)} className="hidden" id="ex" value="2"/>
                    <label className="filter" htmlFor="ex">Completed</label>
                    </div>
                </div> 
            </div>

            

                <div className="col-sm-6">
                    <SelectControl
                        name="limit"
                        label="Limit"
                        ref={(c) => (this.els.limit = c)}
                        value={this.props.limit}
                        onChange={this.searchFilter.bind(this)}
                        disabled={this.props.loading}>

                        <option value="5">5 items</option>
                        <option value="10">10 items</option>
                        <option value="20">20 items</option>
                        <option value="50">50 items</option>
                        <option value="100">100 items</option>
                    </SelectControl>
                </div>
               
                <div className="col-sm-6 rightEnd">
                    <TextControl
                        name="search"
                        label="Search"
                        ref={(c) => (this.els.search = c)}
                        value={this.props.search}
                        onChange={this.props.linkInputState}
                        disabled={this.props.loading}
                    />
                </div>
            </div>
        );
    }
}

FilterForm.propTypes = propTypes;


module.exports = FilterFormHoc(FilterForm, defaultValues);
