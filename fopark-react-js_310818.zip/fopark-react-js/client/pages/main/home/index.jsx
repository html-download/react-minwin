const React = require('react');
const ReactHelmet = require('react-helmet');

const Helmet = ReactHelmet.Helmet;

class HomePage extends React.Component {
    render() {

        return (
            <div>
                <div className="home_banner full_row">
                    <Helmet>
                        <title>Welcome to Fo Park</title>
                    </Helmet>
                    <div className="container">
                        <h1 className="wow fadeInDown">Delivery, pickup and catering from your favorite restaurants.</h1>
                        
                        <form className="banner_form wow fadeInUp" method="post">
                            <div className="col-sm-4">
                                <div className="form-group location">
                                    <input type="text" className="form-control" placeholder="Enter a location"/>
                                </div>
                            </div>
                            <div className="col-sm-4">
                                <select id="delivery_option" name="cityloadingvalues">
                                <option value="3">Delivery &amp; Pickup</option>
                                <option value="2">Delivery</option>
                                <option value="1">Pickup</option>
                                </select>
                            </div>
                            <div className="col-sm-4">
                                <button className="btn">Find restaurants</button>
                            </div>
                            
                        </form> 
                    </div>
                    <div className="app_section">
                        <div className="container">
                            <div className="col-sm-6">
                                    <h3>Order power, hungry solver. Get the app.</h3>
                                    <a href="" className="google_play_img"><img src="/public/media/images/google_play_img.png" alt="googlePlayStoreImg" /></a>
                                    <a href="" className="app_store_img"><img src="/public/media/images/app_store_img.png" alt="googlePlayStoreImg" /></a>
                            </div>
                            <div className="col-sm-6">
                                <h1>Let’s Eat!</h1>
                            </div>
                        </div>  
                    </div>
                </div>
                <div className="steps">
                    <div className="container">
                            <h2 className="text-center">Dining Power Ordering</h2>
                            <p className="text-center">Eat deliciously...delivery, pickup and catering...so sweet.</p>
                        <div className="col-sm-4">
                            <div className="step">
                                <img src="/public/media/images/fantastic_img.png" className="wow zoomIn" alt="Fantastic"/>
                                <h4>Find Fantastic Food</h4>
                                <p>Browse menus now from your favorite local restaurant stars.</p>
                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="step">
                                <img src="/public/media/images/yummm_img.png" className="wow zoomIn" alt="Yummm"/>
                                <h4>Order Some YUMMMMTM <span className="tm">TM</span></h4>
                                <p>Select your food and submit your order. We’ll power up the eats!</p>
                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="step">
                                <img src="/public/media/images/dig_in_img.png" className="wow zoomIn" alt="dig-in"/>
                                <h4>Dig In!</h4>
                                <p>Enjoy fast delivery, easy pickup or hassle-free catering.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="subscribe">
                    <div className="quote">
                        <span>
                            "Life is uncertain, eat dessert first."
                            <a className="dessert_lnk" role="button"><img src="/public/media/images/click_order_img.png" alt="Subscribe" className="wow fadeInUp"/></a>
                        </span>
                    </div>
                    <div className="cookie">
                        <img src="/public/media/images/yellow_star.png" alt="Star" />
                        Dining Power Online Fortune Cookie
                    </div>
                </div>
            </div>
            
        );
    }
}


module.exports = HomePage;
