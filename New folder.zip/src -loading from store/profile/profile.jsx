import React, { Component } from "react";
/* Import Components */
import Inputtext from "../components/input-control.jsx";
import Selecttext from "../components/select-control.jsx";
import CheckboxControl from "../components/checkbox-control.jsx";
import Actions from './action.jsx';
import Store from './store.jsx';
/*DatePicker*/
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

/*Toastify*/

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

/*Select*/
import Select from "react-select";

const options = [
  { value: "chocolate", label: "Chocolate" },
  { value: "strawberry", label: "Strawberry" },
  { value: "vanilla", label: "Vanilla" }
];

class Profile extends Component {
  constructor(props) {
    super(props);
    this.input = {};

    this.handleFirstName = this.handleFirstName.bind(this);
    this.togglePassword = this.togglePassword.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);

    this.state = Store.getState();
  }

  //notify = () => toast("Wow so easy !");

 
  handleFirstName(e) {
    e.preventDefault();
    console.log('event', e.target.value)
  }

  togglePassword(e) {
  this.setState({
      showPassword: e.target.checked
    });
}
  handleSubmit(e) {
    e.preventDefault();
    let data = {
      first_name: this.input.first_name.value(),
      last_name: this.input.last_name.value(),
      email_id: this.input.email_id.value(),
      phone_number: this.input.phone_number.value()
    };
  }

  handleChange(date) {
    this.setState({
      startDate: date
    });
  }

  componentDidMount(){
      //console.log("this.input", this.input);

      Actions.getresponse();
      this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
  }


 componentWillUnmount() {
  this.unsubscribe();
}

 onStoreChange (){
    this.setState(Store.getState());       
 }

  handleChanged = selectedOption => {
    this.setState({ selectedOption });
    console.log(`Option selected:`, selectedOption);
  };

  render() {
console.log(this.state.first_name);
    /*const selectedDay = this.state.selectedDay; 
    const isDisabled = this.state.isDisabled; 
    const isEmpty = this.state.isEmpty; */

    const { 
      selectedDay, 
      isDisabled, 
      isEmpty 
    } = this.state;

    const { selectedOption } = this.state;

    return (
      <div>
        <section className="subpage-bg">
          <h2 className="wow fadeInUp">My Profile</h2>
        </section>

        <section className="boxed-container myaccount">
          <div className="container wow fadeInUp md">
            <h3 className="title-border wow fadeInUp">Personal Information</h3>
            <form onSubmit={this.handleSubmit}>
              <div className="row">
                <div className="col-sm-6">
                  <Inputtext
                    ref={c => (this.input.first_name = c)}
                    className="form-control"
                    name="first_name"
                    labelname="first name"
                    title="Full Name"
                    type="text"
                    value={this.state.first_name}
                    placeholder="Enter Your Name"
                    onChange={this.handleFirstName}
                  
                  />
                </div>
                <div className="col-sm-6">
                  <Inputtext
                    ref={c => (this.input.last_name = c)}
                    className="form-control"
                    name="last_name"
                    labelname="last name"
                    title="Last Name"
                    type="text"
                    placeholder="Enter Your LastName"
                    value={this.state.last_name}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-sm-6">
                  <Selecttext
                    ref={c => (this.input.gender = c)}
                    className="form-control"
                    title="Gender"
                    name="gender"

                    value={selectedOption}
                    onChange={this.handleChanged}
                    options={["male", "Female"]}
                    placeholder="Select Gender"
                  />
                </div>

                <div className="col-sm-6">
                
                  <DatePicker
                    ref={c => (this.input.date_of_birth = c)}
                    selected={this.state.startDate}
                    onChange={this.handleChange}
                    className="form-control"
                    showYearDropdown
                    dateFormatCalendar="MMMM"
                    scrollableYearDropdown
                    yearDropdownItemNumber={15}
                    name="date_of_birth"
                  />
                </div>
              </div>

              <h3 className="title-border wow fadeInUp">Contact Information</h3>
              <div className="row">
                <div className="col-sm-6">
                  <Inputtext
                    ref={c => (this.input.email_id = c)}
                    className="form-control"
                    name="email_id"
                    title="Last Name"
                    type="text"
                     labelname="Email id"
                    placeholder="Enter Your Email Id"
                    value={this.state.email_id}
                  />
                </div>
                <div className="col-sm-6">
                  <Inputtext
                    ref={c => (this.input.phone_number = c)}
                    className="form-control"
                    name="phone_number"
                    title="Last Name"
                    type="text"
                     labelname="Phone Number"
                    placeholder="Enter Your Phone Number"
                    value={this.state.phone_number}
                  />
                </div>
              </div>
              <div className="row">
                <div className="col-sm-12">
                  
                </div>
              </div>

              <div className="row">
                <div className="col-sm-12">
                  <CheckboxControl
                    ref={input => {
                      this.change_password = input;
                    }}
                    name="change_password"
                    id="change_password"
                    onChange={(e) => {
                     this.togglePassword(e);
                    }}
                    label="change password"
                    type="checkbox"
                    checked={this.state.showPassword}
                  />
                 </div>
              </div>


         <div className={this.state.showPassword ? "show-hide open"  : "show-hide"}>
                <h3 className="title-border">Change Password</h3>
                <div className="row">
                  <div className="col-sm-6">
                    <div className="form-group">
                      <label>Current password</label>
                      <input type="password" className="form-control" />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-sm-6">
                    <div className="form-group">
                      <label>New password</label>
                      <input type="password" className="form-control" />
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="form-group">
                      <label>Confirm password</label>
                      <input type="password" className="form-control" />
                    </div>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-sm-12">

                  <label class="upload" for="upload_file"></label>
                  <input type="file" class="form-control" id="upload_file"/>
                </div>
              </div>

              <div className="row">
                <div className="col-sm-12">
                  <label for="newsletter" className="switchup label">
                    <input id="newsletter" checked type="checkbox" /> I would
                    like to subscribe for Newsletters
                    <span className="slider round" />
                  </label>
                </div>
              </div>

              <div className="action full_row text-left">
                <button
                  onClick={this.notify}
                  className="btn btn-primary loader"
                >
                  Update
                </button>
                <ToastContainer
                  position={toast.POSITION.BOTTOM_RIGHT}
                  autoClose={6000}
                />
              </div>
            </form>
          </div>
        </section>
      </div>
    );
  }
}

export default Profile;
