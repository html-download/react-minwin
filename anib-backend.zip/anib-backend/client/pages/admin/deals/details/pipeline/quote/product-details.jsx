'use strict';
const Actions = require('./actions');
const React = require('react');
const CommonHelper = require('../../../../../../helpers/common-functions');
const DateHelper = require('../../../../../../helpers/date-time');
const Toaster = require('../../../../../../helpers/toaster');
const Button = require('../../../../../../components/form/button.jsx');
const Spinner = require('../../../../../../components/form/spinner.jsx');
const ReactSelectControl = require('../../../../../../components/form/react-select-control');
import DatePicker from "react-datepicker";

class ProductDetails extends React.Component {
    
    constructor(props) {

        super(props);

        this.state = {
            isEdit: false,
            policy_start_date: undefined,
            mortgage_id: this.props.mortgage_id,
        }
        
        this.input = {};

        this.toggle = this.toggle.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.morgate = this.morgate.bind(this);
    }     

    toggle() {
        
        this.setState({
            isEdit: !this.state.isEdit
        })

    }

    handleChange(date, type) {

        date = (date !== '') ? DateHelper._changeDefaultFormat2(date): '';
        this.setState({
            policy_start_date: date
        })
        
        
    }

    morgate(key) {
        this.setState({
            mortgage_id: key
        });
    }

    handleSubmit(event) {
                
        let value = this.props.data;
        const id = this.props.id;
                
        let policy_start_date = this.state.policy_start_date;
        policy_start_date = policy_start_date ? DateHelper._getDbFormat(this.state.policy_start_date) : DateHelper._getDbFormat(value.policy_start_date);        

        const data = {
            "insurence_product_id": this.props.data.insurence_product_id,
            "deal_id": this.props.data.deal_id,
            "quote_reference_number": this.props.data.quote_reference_number,
            "vehicle_insured_value": this.props.data.vehicle_insured_value,
            "premium_value": this.props.data.premium_value,
            "deduction": this.props.data.deduction,
            "extra_deduction": this.props.data.extra_deduction,
            "is_publish": this.props.data.is_publish,
            "is_agency_repair": this.props.data.is_agency_repair,
            "is_ncd_required": this.props.data.is_ncd_required,
            "policy_start_date": policy_start_date,
            "payment_type": this.input.payment_type.value,
            "mortgage_id": this.state.mortgage_id,
            /* discount: this.input.discount.value, */
            is_update_deal: 1
        };        
        
        Toaster.warning('It will take some time to update!');

        Actions.updateQuoteDetails(value.deal_quote_key, data, this.props.toggle);
    }

    openQuoteModal(deal_quote_key) {
        
        /* Actions.openQuoteModal(deal_quote_key,this.handleSubmit); */
        /* this.props.info_data.submit_quote(); */
        Actions.sendQuoteMail({
            deal_quote_id: deal_quote_key,
            deal_id: this.props.data.deal_id,
            /* to: this.to.value,
            cc: this.cc.value,
            bcc: this.bcc.value,
            subject: this.subject.value,
            message: this.message.value, */
        },this.props.toggle);
    }

    render() {        

        let value = this.props.data;
        
        return (
            <li title="Click to edit this quote and send to order">
                <div className="box" onClick={(e) => {this.toggle()}}>
                    <div className="img"><img src={value.insurence_product_image} /></div>
                    <h5>{value['insurence_product_name']}</h5>
                    <p>Sum Insured: AED {value['vehicle_insured_value']}</p>
                    {/* <p>Quote Reference: {value['quote_reference_number']}</p> */}
                    <p>Quotation Number: {value['quotation_number']}</p>
                    <p className="tags" style={{'display': 'none'}}> <span>Pab Driver</span> <span>Pab Passenger</span> </p>
                    <div className="right-cd">
                        <p>Deductible AED {value['deduction']}</p>
                        <p>Ded.Extra</p>
                        <p>Base Premium</p>
                        <p className="bold">AED {value['premium_value']}</p>
                    </div>
                </div>
                <div className="box-fields" style={{'display' : this.state.isEdit ? 'block' : 'none'}}>
                    <div className="row">
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Policy Start Date</label>
                                <DatePicker
                                    ref={(c) => (this.input.policy_start_date = c)}
                                    key={ `${Math.floor((Math.random() * 1000))}`}
                                    selected={ this.state.policy_start_date ? DateHelper._getDefaultFormat2(this.state.policy_start_date) : value.policy_start_date !== undefined ? DateHelper._getDefaultFormat2(value.policy_start_date): ''}
                                    onChange={ (e) => {this.handleChange(e, 'policy_start_date')}}
                                    className={{'form-control' : true}}
                                    dateFormat="d-MMM-yyyy"
                                    showYearDropdown
                                    scrollableYearDropdown
                                    yearDropdownItemNumber={40}
                                />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Payment Status</label>
                                <select className="form-control" defaultValue={value['payment_type']} ref={(c) => (this.input.payment_type = c)}>
                                    <option value={1}>Cash</option>
                                    <option value={2}>Check</option>
                                    <option value={3}>Online</option>
                                </select>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="form-group">
                                <ReactSelectControl
                                    ref={(c) => (this.input.mortgage = c)}
                                    name="mortgage"
                                    label="Mortgage"
                                    onChange={ (e) => {this.morgate(e) }}
                                    defaultValue={ value.mortgage_id }                                     
                                    groupClasses={{'rq': true}}
                                    inputClasses={{'select-modal': true}}
                                    labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                                    options={ (this.props.morgage !== []) ? CommonHelper.getOptionData(this.props.morgage,'mortgage_key','mortgage_name') : []}
                                />
                            </div>
                        </div>
                    </div>
                    {/* <div className="row">
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Discount</label>
                                <input type="text" className="form-control datePicker" defaultValue={value['discount']} ref={(c) => (this.input.discount = c)}/>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="form-group"></div>
                        </div>
                        <div className="col-md-4"></div>
                    </div> */}
                    <div className="text-right mt-3 mb-3">
                        <button className="btn btn-outline-primary loader no-shadow" onClick={(e) => {this.toggle()}}>Cancel</button>
                        <Button
                            type="button"
                            inputClasses={{ 'btn': true, 'btn-outline-primary': true, 'no-shadow': true, 'ml-2': true }}
                            disabled={this.props.quote_save_loading}
                            onClick={ (e) => {this.handleSubmit(value['deal_quote_key'])}}>

                            <Spinner space="right" show={this.props.quote_save_loading} />
                            Create
                        </Button>
                        
                        {/* <button data-toggle="modal" onClick={ (e) => {this.openQuoteModal(value.deal_quote_key)} } className="btn btn-primary ml-1 loader no-shadow">Create &amp; Send</button> */}
                    </div>
                </div>
            </li>
        );
    }
}
module.exports = ProductDetails;