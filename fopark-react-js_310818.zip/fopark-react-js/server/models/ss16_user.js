/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16User', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    roleName: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'role_name'
    },
    username: {
      type: DataTypes.STRING(25),
      allowNull: false,
      field: 'username'
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'email'
    },
    passwordHash: {
      type: DataTypes.STRING(60),
      allowNull: false,
      field: 'password_hash'
    },
    authKey: {
      type: DataTypes.STRING(32),
      allowNull: false,
      field: 'auth_key'
    },
    confirmedAt: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'confirmed_at'
    },
    unconfirmedEmail: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'unconfirmed_email'
    },
    blockedAt: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'blocked_at'
    },
    registrationIp: {
      type: DataTypes.STRING(45),
      allowNull: true,
      field: 'registration_ip'
    },
    createdAt: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_at'
    },
    updatedAt: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'updated_at'
    },
    flags: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'flags'
    },
    accountBalance: {
      type: "DOUBLE",
      allowNull: false,
      field: 'account_balance'
    }
  }, {
    tableName: 'ss16_user'
  });
};
