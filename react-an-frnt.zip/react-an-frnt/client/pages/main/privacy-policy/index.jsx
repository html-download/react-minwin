'use strict';
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');

const Link = ReactRouter.Link;
const Helmet = ReactHelmet.Helmet;


class PrivacyPolicyPage extends React.Component {
 componentDidMount() {    
    window.scrollTo(0, 0);
  }
    render() {

        return (
            <section >
                <Helmet>
                    <title>Privacy Policy</title>
                </Helmet>
                <section className="empty-banner">
                </section>

                <section className="light_bg upload_details">
                    <div className="container">
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                 <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                               <li className="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                            </ol>
                        </nav>

                        <h2 className="blue-heading sub-heading">Privacy Policy</h2>
                        <div className="white-box-shadow text-center contents">
                            
                            <div className="box-container">
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="content">
                                            <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                                            <p> When an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, </p>
                                            <p>Remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more </p>
                                            <p> Recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                                            <p>Simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
                                            <p> When an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, </p>
                                            <p>Remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more </p>
                                        </div>
                                    </div>
                                  </div>

                            </div>
                        </div>

                    </div>
                </section>
            </section>
        );
    }
}


module.exports = PrivacyPolicyPage;
