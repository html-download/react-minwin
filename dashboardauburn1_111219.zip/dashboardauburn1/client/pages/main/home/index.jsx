const React = require('react');
const Actions = require('./actions.js');
const Loader = require('./_loader.jsx');
const ExcelExport = require('./excel');
import {Link} from 'react-router-dom';
const ReactHelmet = require('react-helmet');
import { ExportToCsv } from 'export-to-csv';
import { Progress } from 'react-sweet-progress';

const UserIdentity = require('../../../helpers/user-identity');
const ObjectAssign = require('object-assign');
const ZoneHistoricalModal = require('./zone-historical-modal');
const Store = require('./store');
const Config = require('../../../../config.js');
const DateHelper = require('../../../helpers/date-time');
const moment = require('moment-timezone');

const Helmet = ReactHelmet.Helmet;

class HomePage extends React.Component {
    constructor(props) {
        super(props);
        this.state = Store.getState();
        
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.updateLotList = this.updateLotList.bind(this);
        this.getHistorical = this.getHistorical.bind(this);
        this.getHistoricalDownload = this.getHistoricalDownload.bind(this);
        this.getHistoricalExport = this.getHistoricalExport.bind(this);
        this.getLotAvgTime = this.getLotAvgTime.bind(this);
    };
    updateLotList() {
        let url = `${this.params.fopark_url}/client/lots?name=${UserIdentity.client}`;
        
        Actions.getLotList(url, this.getLotAvgTime);
    }

    getLotAvgTime() {
        let lots = this.state.lots;
        Object.keys(lots).map((lot) => {
            let lot_name = lots[lot].lot_name;
            //console.log("lot_name", lot_name);
            let url = `${this.params.fopark_url}/lot/occupancy?client_name=${UserIdentity.client}&name=${lot_name}&duration_flag=1`;//&duration_flag=1
            
            Actions.getLotAvgTime(url, lot_name);
        });
        
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        //this.interval = setInterval(this.updateLotList, 45000);
        this.updateLotList();
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }
    onStoreChange() {
        this.setState(Store.getState());
    }

    componentWillUnmount() {
        //clearInterval(this.interval);
        this.unsubscribeStore();
    }
    componentDidUpdate(prevProps, prevState) {
        
        const script = document.createElement("script");
        script.src = [
            "/public/media/js/dashboard.js"
        ];
        script.async = true;

        document.body.appendChild(script);
        
        $('.selectpicker').selectpicker('refresh');

        if ($("#modal_history").parents('div').css('display') === 'block') {
            let today = moment().tz(Config.get('/timeZone')).format('MM/DD/YYYY').toString();
            let endDate = "+0d";

            if (today !== moment().format('MM/DD/YYYY').toString()) {
                endDate = '-1d';
            }
            
            $("#date-inline" ).datepicker({
                inline: true,
                altField: '.date-inline',
                endDate: endDate,
                keyboardNavigation: false,
                forceParse: false,
                todayHighlight: false,
                setDate: today,
            })
            //.datepicker("setDate", today)
            .on('changeDate', function(e){
                e.stopPropagation();
                e.stopImmediatePropagation();
                var formatedValue = e.date;
                let date = DateHelper._historicalDateFormat(formatedValue);
                Actions.setHistoricalDate(date, {
                    key : Config.get('/historicalApiToken'),
                    date : date,
                    is_lot : 0,
                    days : UserIdentity._checkSelectedZoneDay() !== null ? UserIdentity._checkSelectedZoneDay() : 1,
                    client_name : Config.get('/client'),
                    lot_name : '',
                    zone : UserIdentity._checkSelectedZone() !== null ? UserIdentity._checkSelectedZone() : 'a',
                })
            });
        }
        var chart = Highcharts.chart('historical_zone', {
            chart: {
                type: 'area'
            },
            title: {
                text: 'Historical Graph'
            },
            xAxis: {
                title: {
                    text: 'Occupancy by Hour',
                    enabled: true
                },
                categories: [ 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00 ],
                tickmarkPlacement: 'on'
            },
            yAxis: {
                title: {
                    text: 'Percentage (%)'
                }
            },
            tooltip: {
                split: true,
                valueSuffix: ' %',
                formatter: function() {
                    return parseFloat(this.y).toFixed(2) + '%</b> occupied at <b>' + this.x + '</b>';
                }
            },
            plotOptions: {
                area: {
                    stacking: 'normal',
                    lineColor: '#666666',
                    lineWidth: 1,
                    marker: {
                        lineWidth: 1,
                        lineColor: '#666666'
                    }
                }
            },
            series: [{
                name: 'History',
                color: '#4dbb5b',
                data: [
                    '00:00',
                    '02:00',
                    '04:00',
                    '06:00',
                    '08:00',
                    '10:00',
                    '12:00',
                    '14:00',
                    '16:00',
                    '18:00',
                    '20:00',
                    '22:00'
                ]
            }]
        });
        
        chart.update({
            xAxis: {
                title: {
                    text: 'Occupancy by Hour',
                    enabled: true
                },
                categories: this.state.time_array,
                tickmarkPlacement: 'on'
            },
            series: [{
                name: 'History',
                data: this.state.percentage_array
            }]
        });
        
        if (prevState.over_all_percentage !== this.state.over_all_percentage) {
            
            var donut_chart = Highcharts.chart('sparkline', {
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false,
                    type: 'pie',
                    backgroundColor: 'transparent'
                },
                exporting: { enabled: false },
                title: false,
                plotOptions: {
                    pie: {
                        size:'100%',
                        allowPointSelect: false,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            format: '<b>{point.name}</b><br>{point.percentage:.1f} %',
                            distance: -50,
                            style: {
                                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                            },
                        },
                        showInLegend: true
                    }

                },
                colors: [
                    '#a4de04',
                    '#337118'
                ],
                series: [{
                    name: 'Lots',
                    colorByPoint: true,
                    data: [
                        { name: 'Occupied', y: this.state.over_all_percentage },
                        { name: 'Available', y: (100 - this.state.over_all_percentage) }
                    ],
                    showInLegend: true
                }]
            });
            
            $(window).resize(redrawchart);
            redrawchart(donut_chart);

            
            donut_chart.update({
                series: [{
                    name: 'Lots',
                    colorByPoint: true,
                    data: [
                        { name: 'Occupied', y: this.state.over_all_percentage },
                        { name: 'Available', y: (100 - this.state.over_all_percentage) }
                    ],
                    showInLegend: true
                }]
            });

            function redrawchart(donut_chart){
                var w = $('.content-wrapper').find(".col-sm-4").width()
                // setsize will trigger the graph redraw 
                donut_chart.setSize(       
                    w, w * (3/4), false
                );
            }
        }

    }

    componentWillUnmount() {
        clearInterval(this.interval);
    };
    getHistorical() {
        Actions.loadHistorical({
            key : Config.get('/historicalApiToken'),
            date : moment(this.state.historical_date, 'MM/DD/YYYY').format('DD-MM-YYYY').toString(),//this.state.historical_date,
            is_lot : 0,
            days : this.state.historical_day,
            client_name : Config.get('/client'),
            lot_name : '',
            zone : this.state.zone_selected,
        });
    }
    getHistoricalExport(tableID, filename = '') {
        var downloadLink;
        var dataType = 'application/vnd.ms-excel';
        var tableSelect = document.getElementById('export_data');
        var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
        
        // Specify file name
        filename = `${this.state.zone_selected} Zone report on ${moment().tz(Config.get('/timeZone')).format('MM/MM/YYYY hh:mm A').toString()} [${moment(this.state.historical_date, 'MM/DD/YYYY').subtract(this.state.historical_day - 1, "days").format('MM/DD/YYYY').toString()} - ${this.state.historical_date}]`
        filename = filename?filename+'.xls':'excel_data.xls';
        
        // Create download link element
        downloadLink = document.createElement("a");
        
        document.body.appendChild(downloadLink);
        
        if(navigator.msSaveOrOpenBlob){
            var blob = new Blob(['\ufeff', tableHTML], {
                type: dataType
            });
            navigator.msSaveOrOpenBlob( blob, filename);
        }else{
            // Create a link to the file
            downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
        
            // Setting the file name
            downloadLink.download = filename;
            
            //triggering the function
            downloadLink.click();
        }
    }
    getHistoricalDownload() {

        Actions.loadHistoricalDownload({
            key : Config.get('/historicalApiToken'),
            date : moment(this.state.historical_date, 'MM/DD/YYYY').format('DD-MM-YYYY').toString(),//this.state.historical_date,
            is_lot : 0,
            days : this.state.historical_day,
            client_name : Config.get('/client'),
            lot_name : '',
            zone : this.state.zone_selected,
        }, this.getHistoricalExport);
    }
    render() {
        const {error, isLoaded, loading, zone_percentage_array, first_time_loaded} = this.state;
        let lots = this.state.lots ? this.state.lots : [];
        const checkArray  = [];
        let zonePercentage  = zone_percentage_array;
        let count = 1;
        /*if (error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if (!isLoaded) {
            return <div className="loader"></div>
        } else {*/
            if (!first_time_loaded) {
                return <Loader/>
            }
            return (
                <div className="content-wrapper">
                    {loading ? (
                        <div className="loader"></div>
                    ) : ''}
                    <Helmet>
                        <title>Welcome to Dashboard</title>
                    </Helmet>
                    <section className="content">
                        <div className="box">
                            <div className="box-header with-border">
                                <h1 className="box-title">Analytics</h1>
                            </div>
                            <div className="box-body dashboard-analytics">
                                <div className="row">
                                    <div className="col-sm-4">
                                        <div className="space content-view">
                                            <h3>Parking Spaces Availability</h3>
                                            <div className="parking-content">
                                                Total number of spaces
                                                <span>{this.state.over_all_total}</span>
                                            </div>
                                            <div className="parking-content">
                                                Number of spaces occupied
                                                <span className="red-label">{this.state.over_all_occupied}</span>
                                            </div>
                                            <div className="parking-content">
                                                Number of spaces available
                                                <span className="green-label">{ parseInt(this.state.over_all_total) - parseInt(this.state.over_all_occupied)}</span>
                                            </div>
                                            <span className="updated-time">Updated less than a minute ago</span>
                                        </div>
                                        <div className="chart-view content-view">
                                            <h3>Space Distribution</h3>
                                            <span id="sparkline" className="spark-chart">
                                                
                                            </span>
                                            <span className="updated-time">Updated less than a minute ago</span>
                                        </div>
                                        
                                    </div>
                                    <div className="col-sm-4">
                                            <div className="box-wrap">
                                                <div className="progress-view content-view">
                                                    <h3>Current Zone Occupancy</h3>
                                                    <span className="sub-tit">Zone Name</span>
                                                    <span className="sub-tit right">Cur Avg. Time parked</span>
                                                    {
                                                        this.state.zone_array.sort().map((zone) => {
                                                        let percentage = (zonePercentage[zone]) ? zonePercentage[zone].percentage : 0;
                                                        let current_avg_time = !this.state.zone_time[zone] ? 0 : this.state.zone_time[zone].zone_total_duration_count > 0 ? Math.ceil(parseInt(this.state.zone_time[zone].zone_total_duration_mins / this.state.zone_time[zone].zone_total_duration_count)) : 0
                                                        count++;

                                                        let color;
                                                        if (percentage >= 95) {
                                                            color = 'per_gt_95';
                                                        } else if (percentage >= 85 && percentage < 95) {
                                                            color = 'per_gt_85';
                                                        } else {
                                                            color = 'per_lt_95';
                                                        }
                                                        return (
                                                            <div className="progress-group" key={`progress-group-zone-${count}`} title={`${zone === 'undefined' ? 'General' : zone} occupied ${percentage}%`} onClick={ () => {Actions.showZoneHistoricalModal(this.getHistorical, zone)}}>
                                                                <span className="progress-text capitalize" >{zone === 'undefined' ? 'General' : zone}</span>
                                                                <span className="progress-number">{current_avg_time !== 0 ? ` ${current_avg_time} mins` : ' -' }</span>
                                                                <div className="progress sm">
                                                                    <div className={`progress-bar progress-bar-aqua progress-bar-striped progress-bar-animated ${color}`} style={{'width': `${percentage}%`}}>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )
                                                        
                                                    })}
                                                <span className="updated-time">Updated less than a minute ago (click on zones for historical data)</span>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="col-sm-4">
                                        <div className="box-wrap">
                                            <div className="progress-view content-view">
                                                <h3>Current Lot Occupancy</h3>
                                                <span className="sub-tit">Lot Name</span>
                                                <span className="sub-tit right">Cur Avg. Time parked</span>
                                                {
                                                    Object.keys(lots).map((lot) => {
                                                        let occupied = 0;
                                                        let total = 0;
                                                        let percentage = 0;
                                                        let color = '';
                                                        let isZoneSelected = true;
                                                        
                                                        Object.keys(lots[lot].occupancy).map((zone) => {
                                                            occupied += lots[lot].occupancy[zone][1];
                                                            total += lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3];
                                                            percentage = Math.ceil((occupied / total) * 100);
                                                        })
                                                        
                                                        if (percentage >= 95) {
                                                            color = 'per_gt_95';
                                                        } else if (percentage >= 85 && percentage < 95) {
                                                            color = 'per_gt_85';
                                                        } else {
                                                            color = 'per_lt_95';
                                                        }

                                                        if (!lots[lot].status) {
                                                            color = 'per_gt_95';
                                                        }
                                                        let lot_name = lots[lot]['title'] !== null ? lots[lot]['title'] : lots[lot]['lot_name'];

                                                        if (isZoneSelected) {
                                                            checkArray.push(lots[lot]['lot_name']);
                                                            let distance_from_location = lots[lot]['distance_from_location'] !== undefined ? parseFloat(lots[lot]['distance_from_location']).toFixed(2) : 0;
                                                            return (
                                                                <a className="progress-group" key={`lot_api_${lots[lot]['lot_name']}`} title={`${lot_name} occupied ${percentage}%`}href={`/lots/${lots[lot]['lot_name']}`}>
                                                                    <span className="progress-text"  >
                                                                        {lot_name}
                                                                    </span>
                                                                    <span className="progress-number">
                                                                        {this.state.avg_time[lots[lot]['lot_name']] ? ` ${this.state.avg_time[lots[lot]['lot_name']]} mins` : ' -' }
                                                                    </span>
                                                                    <div className="progress sm">
                                                                        <div className={`progress-bar progress-bar-aqua progress-bar-striped progress-bar-animated ${color}`} style={{'width': `${percentage}%`}}>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            )
                                                        } 
                                                        return '';
                                                    })}
                                                    <span className="updated-time">Updated less than a minute ago (click on lots for historical data)</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <ZoneHistoricalModal 
                        getHistoricalDownload= {this.getHistoricalDownload}
                        {...this.state}
                    />
                    <span style={{ 'display' : 'none'}}>
                        <ExcelExport 
                            data={this.state.download_array}
                            {...this.state}
                        />
                    </span>
                  </div>
            );
        //}
    }
}


module.exports = HomePage;
