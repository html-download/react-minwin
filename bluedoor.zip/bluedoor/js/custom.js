  //Fixed Header  
  $(window).on('load scroll resize orientationchange', function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
      $(".site-header").addClass("sticky");
    }
    else {
      $(".site-header").removeClass("sticky");
    }
  });


  $(document).ready(function() {
  $(".rating").starRating({
    //initialRating: 4,
    emptyColor: '#CDCDCD',
    hoverColor: '#333333',
    activeColor: '#FC8B1E',
    ratedColor: '#FC8B1E',
    useGradient: false,
    disableAfterRate: false,
    strokeWidth: 0,
    readOnly: true,
    starSize: 22,
    callback: function(currentRating) {}
  });
  // owl slider
  // categories slide
  $('.testimonial-slider').owlCarousel({
    center: false,
    nav: true,
    dots: false,
    items: 1,
    autoplay: true,
    loop: true,
    navText: ["<i class='la la-angle-left'></i>", "<i class='la la-angle-right'></i>"],
    autoplay: true,
    margin: 0,
  });

// smooth scroll
   jQuery('.navigation').onePageNav({
    currentClass: 'active',
    changeHash: false,
    scrollSpeed: 1500,
    scrollThreshold: 0.5,
    filter: ''
});

   // wow

    new WOW().init();


//res-menu
$(".mobile-menu").click(function() {
  $(".navigation").toggleClass('show');
    $("body").toggleClass('overflow');
});

});