<?php include ('inc/header.php'); ?>

<div class="site_page full_row">
    <section class="offers listing_offers">
        <div class="offers_listing owl-carousel owl-theme">
            <div class="item">
                <a href="laundry-detail"><img src="assets/img/laundry/offer3.png"> 
                    <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="laundry-detail"><img src="assets/img/laundry/offer4.png"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="laundry-detail"><img src="assets/img/laundry/offer3.png"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="laundry-detail"><img src="assets/img/laundry/offer4.png"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="laundry-detail"><img src="assets/img/laundry/offer3.png"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="laundry-detail"><img src="assets/img/laundry/offer4.png"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
        </div> <!--offers_listing-->
    </section> <!--offers-->

    <section id="sorting" class="sorting full_row">
        <div class="pull-left">
            <ul class="category_menu">
                <li><a href="restaurant"><i class="fi shop"></i><span>Restaurants</span></a></li>
                <li><a href="grocery"><i class="fi grocery"></i><span>Grocery Stores</span></a></li>
                <li><a href="laundry" class="active"><i class="fi laundry"></i><span>Laundry</span></a></li>
                <li><a href="others"><i class="fi tools"></i><span>Others</span></a></li>
            </ul> <!--category_menu-->
        </div>

        <div class="pull-right">
            <span class="filter-toggle"><i class="fi slider"></i> Filter</span>
            <select class="selectpicker hide">
                <option>All Cleaners</option>
                <option>Popularity</option>
                <option>Rating</option>
                <option>Distance</option>
            </select>
        </div>
    </section> <!--sorting-->

    <section class="listing full_row">
        <div class="filter-overlay"></div>
        <div class="filters">
            <h3><span class="close-filter"><i>&times;</i> Filters</span> <span class="reset">Reset all</span></h3>
            
            <h4 class="mb0 full_row"><a data-toggle="collapse" href="#filter_1">Ratings</a></h4>
            <ul id="filter_1" class="filter collapse show ratings">
                <li>
                    <input id="r1" type="checkbox" class="hide" checked>
                    <label for="r1" class="checkbox"><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i> <span>125</span></label>
                </li>
                <li>
                    <input id="r2" type="checkbox" class="hide">
                    <label for="r2" class="checkbox"><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i> <span>90</span></label>
                </li>
                <li>
                    <input id="r3" type="checkbox" class="hide" checked>
                    <label for="r3" class="checkbox"><i class="lni-star-filled"><i class="lni-star-filled"></i><i class="lni-star-filled"></i></i> <span>43</span></label>
                </li>
                <li>
                    <input id="r4" type="checkbox" class="hide">
                    <label for="r4" class="checkbox"><i class="lni-star-filled"><i class="lni-star-filled"></i></i> <span>20</span></label>
                </li>
                <li>
                    <input id="r5" type="checkbox" class="hide">
                    <label for="r5" class="checkbox"><i class="lni-star-filled"></i> <span>10</span></label>
                </li>
            </ul>

            <h4 class="mb0 full_row"><a data-toggle="collapse" href="#filter_2">Category</a></h4>
            <ul id="filter_2" class="filter collapse show">
                <li>
                    <input id="l1" type="checkbox" class="hide">
                    <label for="l1" class="checkbox">Dry Cleaning</label>
                </li>
                <li>
                    <input id="l2" type="checkbox" class="hide" checked>
                    <label for="l2" class="checkbox">Wash & Dry</label>
                </li>
                <li>
                    <input id="l3" type="checkbox" class="hide">
                    <label for="l3" class="checkbox">Steam Ironing</label>
                </li>
                <li>
                    <input id="l4" type="checkbox" class="hide" checked>
                    <label for="l4" class="checkbox">Carpet Wash</label>
                </li>
                <li>
                    <input id="l5" type="checkbox" class="hide">
                    <label for="l5" class="checkbox">Toy Laundry</label>
                </li>
                <li>
                    <input id="l6" type="checkbox" class="hide" checked>
                    <label for="l6" class="checkbox">Shoe Laundry</label>
                </li>
                <li>
                    <input id="l7" type="checkbox" class="hide">
                    <label for="l7" class="checkbox">Starch Wash</label>
                </li>
                 <li>
                    <input id="l4" type="checkbox" class="hide" checked>
                    <label for="l4" class="checkbox">Roll Polishing / Roll Press</label>
                </li>
                <li>
                    <input id="l5" type="checkbox" class="hide">
                    <label for="l5" class="checkbox">Stain Removal</label>
                </li>
                <li>
                    <input id="l6" type="checkbox" class="hide" checked>
                    <label for="l6" class="checkbox">Rug Cleaning</label>
                </li>
             
            </ul>
            <button class="btn btn-filters">Show Restaurants</button>

       
        </div> <!--filters-->

        <div class="vendor_list">
            <div class="vendor_search full_row">
                <h2>Showing <b>100</b>Cleaner(s) in <b>Abu Hamour</b></h2>

                <div class="form-group icon">
                    <label for="vendor_search"><i class="la la-search"></i></label>
                    <input id="vendor_search" type="text" class="form-control" placeholder="Ex - Cleaner Name, Category...">
                </div> <!--form-group-->
            </div> <!--vendor_search-->

            <div class="filter_list full_row">
                <span>Wash & Dry<i class="fi close"></i></span>
                <span>Starch Wash<i class="fi close"></i></span>
                <span>3 Stars<i class="fi close"></i></span>
                <span class="clear">Clear All</span>
            </div> <!--filter_list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner1.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Southend Laundry</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner2.jpg)">
                            <p><span>Newly Added</span></p>
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.3</span></p>
                            <h3>Royal Cleaners</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                          <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner3.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Grocer’S Goodness</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                         <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Maytag Homestyle</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                           <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->


               <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner1.jpg)">
                            <p><span>Exclusive</span></p>
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Dirty Drawz Laundry Service</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                           <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner2.jpg)">
                            <p><span>wishbox delivery</span></p>
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Royal Cleaners</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner3.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Southend Laundry</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                           <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Maytag Homestyle</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

               <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner1.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Dirty Drawz Laundry Service</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner2.jpg)">
                            
                            <p><span class="green">Open</span></span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Royal Cleaners</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                          <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner3.jpg)">
                            <p><span>Southend Laundry</span></p>
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Grocer’S Goodness</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                           <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Maytag Homestyle</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

               <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner1.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Dirty Drawz Laundry Service</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                           <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner2.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Royal Cleaners</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                           <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner3.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Southend Laundry</h3>
                            <p class="desc grey">Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Maytag Homestyle</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->


               <div class="list closed">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner1.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Dirty Drawz Laundry Service</h3>
                            <p class="desc grey">
Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list closed">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="laundry-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/laundry/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Royal Cleaners</h3>
                            <p class="desc grey">
Dry Cleaning, Wash & Dry, Steam Ironing...</p>
                            <div class="laundry-price">
                                <span class="float-left">Min QR 30</span>
                                <span class="float-right delivery">Express Delivery <i class="fi delivery-truck"></i></span>
                            </div>
                        </div> <!--vendor_info-->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

        

            <div class="list loader">
                <img src="assets/img/loader.svg">
            </div> <!--list-->
        </div> <!--vendor_list-->
    </section> <!--listing-->
</div> <!--site_page-->

<?php include ('inc/footer.php'); ?>

<script type="text/javascript">
    $(document).ready(function(){

            $('.offers_listing').owlCarousel({
        loop: true,
        margin: 20,     
        mouseDrag: false,
        dots: false,
        responsiveClass: true,
        nav: true,
        responsive: {
          0: {
            items: 1,
            stagePadding: 50
          },
          640: {
            items: 1,
            stagePadding: 50
          },
          1000: {
            items: 4
          },
          1500: {
            items: 5
          }
        }
    });

        });
</script>