/* eslint-disable no-undef */

import React, {Component} from 'react';
import { withScriptjs, withGoogleMap, GoogleMap, Marker, GroundOverlay, InfoWindow, OverlayView } from "react-google-maps";
import { compose, withStateHandlers, withHandlers } from "recompose";
import GeoLocation from 'react-geolocation';
const UserIdentity = require('../../../helpers/user-identity');
const DateTimeHelper = require('../../../helpers/date-time');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();

const apiUrl = UserIdentity.apiUrl;
const fopark_key = UserIdentity._checkUserToken();
const Actions = require('./actions');

//const MapComponent = withScriptjs(withGoogleMap( props => (
const MapComponent = compose(
  withStateHandlers((index) => ({
    isOpen: false,
    showInfo: '0'
  }), {
    onToggleOpen: ({ isOpen }) => (index) => ({
      isOpen: !isOpen,
      index: 2
    }),
    showInfo: ({ showInfo, isOpen }) => (a, lat, lng) => ({
      isOpen: !isOpen,
      showInfoIndex: isOpen !== true ? a : a,
      showInfoLat: lat,
      showInfoLng: lng
    }),
    hideInfo: ({ hideInfo, isOpen }) => (a) => ({
      isOpen: false,
      showInfoIndex: '0'
    })
  }),
  withHandlers({
    onClick: props => (index, event) => {

        let stallBaseArray = props.markers[index];
        let stallOrgArray = [];
        
        /*fetch(`${apiUrl}/stall/image?lot_name=${stallBaseArray.lot_name}&stall_num=${stallBaseArray.stallNumber}`, {
            'headers': new Headers({
                'X-api-key':  fopark_key
            })
        })
        .then(response => response.blob())
        .then(
            (result) => {
                // Then create a local URL for that image and print it 
                let outside = URL.createObjectURL(result)
                $(".veh_pic img#img_"+stallBaseArray.stallNumber).attr('src', outside);
                $(".zone_img.veh_pic2 img#img_"+stallBaseArray.stallNumber).attr('src', outside);
            },
            (error) => {
                console.log(error)
            }
        );*/

        fetch(`${apiUrl}/stall/event?image_flag=1&id=${stallBaseArray.stallId}`, {
            'headers': new Headers({
                'X-api-key':  fopark_key
            })
        })
        .then(response => response.json())
        .then(
            (result) => {

                if (result.start_image) {
                    $(".zone_img.veh_pic2 img#img1_"+stallBaseArray.stallNumber).attr('src', "data:image/jpg;base64," + result.start_image);
                    
                    let entry_time = DateTimeHelper._getTimeStringFromDateString(result.start_time);
                    $(".zone_img.veh_pic2 #entry_time_"+stallBaseArray.stallNumber).html(entry_time)
                } else {
                    $(".zone_img.veh_pic2 img#img1_"+stallBaseArray.stallNumber).attr('src', "/public/media/images/312fe6d1-31b0-4c63-858b-ffd7717cefa7.png")
                    $(".zone_img.veh_pic2 #entry_time_"+stallBaseArray.stallNumber).html('-')
                }
                
                if (result.current_image) {
                    $(".zone_img.veh_pic3 img#img2_"+stallBaseArray.stallNumber).attr('src', "data:image/jpg;base64," + result.current_image);
                    
                    let current_time = DateTimeHelper._getTimeStringFromDateString(result.current_time);
                    $(".zone_img.veh_pic3 #current_time_"+stallBaseArray.stallNumber).html('')
                } else {
                    $(".zone_img.veh_pic3 img#img2_"+stallBaseArray.stallNumber).attr('src', "/public/media/images/312fe6d1-31b0-4c63-858b-ffd7717cefa7.png")
                    $(".zone_img.veh_pic3 #current_time_"+stallBaseArray.stallNumber).html('')
                }
            },
            (error) => {
                console.log(error)
            }
        );

        stallBaseArray['lat'] = event.latLng.lat() 
        stallBaseArray['lng'] = event.latLng.lng() 
        Actions.showInfoWindowModal(stallBaseArray)
        
    },
    onClose: props => (index) => {
        props.hideInfo(index); 
        Actions.recentInfoWindowCloseUpdate();
    }
  }),
  withScriptjs,
  withGoogleMap
)(props =>
        <GoogleMap
            ref={props.onMapMounted}
            defaultCenter={props.defaultCenter}
            defaultZoom={props.defaultZoom}
            defaultMapTypeId={ google.maps.MapTypeId.SATELLITE }
            defaultTilt={0}
            center={props.center}
            zoom={props.zoom}
            options={{draggable:true}}
            onBoundsChanged={props.onBoundsChanged}
            defaultOptions={{
                scrollwheel: false,
                disableDefaultUI: false,
                zoomControl: true,
                draggable: false
            }}
        >
            {
                (props.overlay_url !== "" && props.overlay_coords_ne !== "" && props.overlay_coords_sw !== "")  ? (
                        <OverlayView
                          key={Math.random()}
                          bounds={new google.maps.LatLngBounds(
                                new google.maps.LatLng(props.overlay_coords_sw_lat, props.overlay_coords_sw_lng),
                                new google.maps.LatLng(props.overlay_coords_ne_lat, props.overlay_coords_ne_lng)
                            )}
                          draggable={true}
                          mapPaneName={OverlayView.OVERLAY_LAYER}>
                          <div style={{ 'background' : "url('"+props.overlay_url+"') center center no-repeat", backgroundSize : 'contain'}}>
                          </div>
                        </OverlayView>
                    ) : null
            }
            {
                /*hide info*/
                (props.recentInfoWindowClose) ? props.onClose(undefined) : null
            }
            {props.markers.map( (marker, i) => {
                let lat = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.stallNumber &&  props.showInfoLat !== undefined) ? props.showInfoLat : marker.lat;
                let lng = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.stallNumber &&  props.showInfoLng !== undefined) ? props.showInfoLng : marker.lng;
                return (
                    <Marker
                        key={marker.stallNumber}
                        position={{'lat': lat, 'lng': lng}}
                        //defaultAnimation={(marker.is_blink) ? google.maps.Animation.BOUNCE : true}
                        icon={props.showInfoIndex === marker.stallNumber ? `/public/media/images/icons/open.png` : (!marker.is_blink) ? `/public/media/images/icons/${marker.icon}` : `/public/media/images/icons/flag.png`}
                        draggable={false} 
                        onClick={(event) => { props.showInfo(marker.stallNumber, marker.lat, marker.lng); props.onClick(i,event);  }}
                        //onDragEnd={(event) => { props.showInfo(marker.stallNumber, event.latLng.lat(), event.latLng.lng());}}
                    >
                        { !props.popupEnabled && props.isOpen && props.showInfoIndex === marker.stallNumber && 
                            <InfoWindow id="info{props.showInfoIndex}" onCloseClick={() => { props.hideInfo(props.showInfoIndex)}}>
                                <div>
                                    <ul className="reset zone-info">
                                        <li>
                                            <div className="form-group">
                                                <i className="fa fa-map-marker"></i>
                                                {marker.stallNumber}
                                            </div>
                                        </li>
                                        <li>
                                            <div className="form-group">
                                                <i className="fa fa-clock-o"></i>
                                                <span id={`occupancy_duration_${props.showInfoIndex}`}>- </span> mins
                                            </div>
                                        </li>
                                        <li className="veh_pic">
                                            <div className="form-group">
                                                <div className="form-group">
                                                    <input id={`reserved_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" defaultChecked={marker.reserve_flag === 1}/>
                                                    <label htmlFor={`reserved_${props.showInfoIndex}`} className="checkbox">Reserved</label>
                                                </div>  
                                                <span className="img"><img id={`img_${props.showInfoIndex}`} src="/public/media/images/312fe6d1-31b0-4c63-858b-ffd7717cefa7.png" alt="" width="150" height="130" style={{float: "left"}}/></span>
                                            </div>
                                        </li>
                                        <li style={{'display':'none'}}>
                                            <div className="form-group">
                                                <label>Stall Num:</label>
                                                <input type="text" className="form-control" value={marker.stallNumber} disabled={true}/>
                                                <span style={{'fontSize' : '10px'}}>(cannot edit)</span>
                                            </div>
                                        </li>
                                        <li style={{'display':'none'}}>
                                            <div className="form-group">
                                                <label>Zone:</label>
                                                <input type="text" name={`zone_${props.showInfoIndex}`} id={`zone_${props.showInfoIndex}`} className="form-control" defaultValue={marker.zone}/>
                                            </div>
                                        </li>
                                        <li style={{'display':'none'}}>
                                            <div className="form-group">
                                                <label>Alt ID:</label>
                                                <input type="text" name={`alt_id_${props.showInfoIndex}`} id={`alt_id_${props.showInfoIndex}`} className="form-control" defaultValue={marker.altId}/>
                                            </div>
                                        </li>
                                        <li className="" style={{'display':'none'}}>
                                            <div className="form-group">
                                                <div className="form-group w70">
                                                    <input id={`unavailable_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" />
                                                    <label htmlFor={`unavailable_${props.showInfoIndex}`} className="checkbox">Live flag</label>
                                                </div>
                                            </div>
                                        </li>
                                        <li style={{'display':'none'}}>
                                            <div className="form-group">
                                                <input id={`qa_flag_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" defaultChecked={marker.qa_flag === 1}/>
                                                <label htmlFor={`qa_flag_${props.showInfoIndex}`} className="checkbox">QA Flag</label>
                                            </div>
                                        </li>
                                        <li style={{'display':'none'}}>
                                            <div className="form-group">
                                                <input id={`context_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" defaultChecked={marker.context_flag === 1}/>
                                                <label htmlFor={`context_${props.showInfoIndex}`} className="checkbox">Context Flag</label>
                                            </div>
                                        </li>
                                        <li style={{'display':'none'}}>
                                            <div className="form-group">
                                                <label>Current Loc:</label>
                                                <label>{props.showInfoLat}, {props.showInfoLng}</label>
                                            </div>
                                        </li>
                                    </ul>
                                    <div className="form-group action mb0">
                                        <button style={{'display':'none'}} className="btn grey" onClick={()=>{ props.onToggleOpen(props.showInfoIndex); props.hideInfo(props.showInfoIndex)}}>HIDE in App</button>
                                        <button className="btn" onClick={(event)=>{ props.saveStallValue(event, marker.stallNumber, props.showInfoLat, props.showInfoLng, marker.lot_name, props.showInfoIndex)}} >Save</button>
                                    </div>
                                </div>
                            </InfoWindow>
                        }
                    </Marker>
                )
            })}
            <GeoLocation />
        </GoogleMap>
);

class Map extends Component {
    constructor(props) {
        super(props);
        this.params = {
            //fopark_url: 'http://localhost:5001',
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.saveStallValue = this.saveStallValue.bind(this);
    }
    componentDidMount(){
        //console.log("props.markers", this.props);
        //console.log('test')
    }
    saveStallValue(stallNumber, latitude, longitude, lotName, showInfoIndex, event) {
        this.props.occupancyUpdate();
        let zone = $("#zone_"+showInfoIndex).val();
        let alt_id = $("#alt_id_"+showInfoIndex).val();
        let unavailable = $("#unavailable_"+showInfoIndex).prop("checked") ? 1 : 0;
        let reserved = $("#reserved_"+showInfoIndex).prop("checked") ? 1 : 0;
        let qa_flag = $("#qa_flag_"+showInfoIndex).prop("checked") ? 1 : 0;
        let context = $("#context_"+showInfoIndex).prop("checked") ? 1 : 0;

        let data = {
                'stall_num' : stallNumber,
                'lot_name' : lotName,
                'reserve_flag' : reserved,
                'zone' : zone,
                'qa_flag' : qa_flag,
                'context_flag' : context,
                'coords' : latitude+','+longitude,
                live_flag : unavailable
            };

        fetch(`${this.params.fopark_url}/stall`, {
            method: "put",
            'headers': new Headers({
                'X-api-key': this.params.fopark_key,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(data)

        })
            //.then(response => response.json())
            .then(response => {
                setTimeout(() => null, 0);
                return response => response.json();
            })
            .then(
                (result) => {
                    Toaster.success('Stall data updated successfully! please wait...data updating..');
                    
                    //this.props.history.push(`/lots/${lotName}`);
                    console.log("Data saved!");
                    //console.log("result", result);
                },
                (error) => {
                    
                    console.log("error", error);
                }
            );
    }
    render(){
        //console.log("props.markers", this.props);
        let overlay_coords_ne_lat, overlay_coords_ne_lng, overlay_coords_sw_lat, overlay_coords_sw_lng;

        if (this.props.overlay_coords_ne !== "") {
            overlay_coords_ne_lat = parseFloat(this.props.overlay_coords_ne.split(',')[0]);
            overlay_coords_ne_lng = parseFloat(this.props.overlay_coords_ne.split(',')[1]);
            overlay_coords_sw_lat = parseFloat(this.props.overlay_coords_sw.split(',')[0]);
            overlay_coords_sw_lng = parseFloat(this.props.overlay_coords_sw.split(',')[1]);
        }
        if (!this.props.isOverlayLoaded) {
            return <div className="loader"></div>
        }
        return (
            <MapComponent
                googleMapURL='https://maps.googleapis.com/maps/api/js?key=AIzaSyDNlIS2XVNFDl-FS3HfSaEWAIzm4-t66Lw'
                loadingElement={<div style={{ height: `100%` }} />}
                containerElement={<div style={{ position: 'fixed', 'zIndex': 1, left: 0, top: 0, right: 0, bottom: 0 }} />}
                mapElement={<div style={{ height: `100%` }} />}
                defaultCenter={{
                    'lat': 32.6063355,
                    'lng': -85.4905577
                }}
                defaultZoom={17}
                center={this.props.center}
                zoom={this.props.zoom}
                markers={this.props.markers}
                draggable={false} 
                saveStallValue={this.props.saveStallValue}
                popupEnabled={this.props.popupEnabled} 
                recentInfoWindowClose={this.props.recentInfoWindowClose}
                recentInfoWindowClose={this.props.recentInfoWindowClose}
                overlay_coords_ne={this.props.overlay_coords_ne}
                overlay_coords_sw={this.props.overlay_coords_sw}
                overlay_url={this.props.overlay_url}
                overlay_coords_ne_lat={overlay_coords_ne_lat}
                overlay_coords_ne_lng={overlay_coords_ne_lng}
                overlay_coords_sw_lat={overlay_coords_sw_lat}
                overlay_coords_sw_lng={overlay_coords_sw_lng}
            >
            </MapComponent>
        )
    }
}

export default Map;