<footer>
    <div class="footerTop">
        <a href="javascript:void(0)" class="scrollTop"><i class="fa fa-angle-up"></i></a>
        <div class="container">
            <div class="row">

                <div class="col-md-12 contacts">
                    <!-- <h4>Email</h4> -->

                    <a href="mailto:onlinedeliverysoftware@technoduce.com" class="mailUs"><i class="fa fa-envelope"></i> onlinedeliverysoftware@technoduce.com</a>

                    <ul class="navigations">
                        <li><a href="http://www.croplataxi.com/" target="_blank">Taxi dispatch system</a></li>
                        <li><a href="https://www.purbis.com/" target="_blank">Restaurant ordering system</a></li>
                        <li><a href="https://www.purbis.com/online-pizza-ordering-system.html" target="_blank">Pizza delivery software</a></li>
                    </ul>

                    <p>©
                        <?php // echo the_time('Y');?> <a href="<?php // echo home_url();?>">Online Delivery Software.</a> All rights reserved.</p>
                </div>

            </div>

        </div>
    </div>
</footer>

</div>




</div>

<!-- request demo -->



<!-- popupForm -->

<!-- Modal -->

<div class="modal fade" id="requestDemo" tabindex="-1" role="dialog" aria-labelledby="requestDemo" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-body">

                <div class="formInnersNew">

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h3>Request Demo</h3>

                    <form id="requestdemoForm" method="post" name="requestdemoForm" action="mail/requestdemo.php">

                        <div class="row">
                            <div class="col-md-12">
                                <label class="smallText" for="rename">Name <span>*</span></label>
                                <input type="text" placeholder="Enter your Name" name="rename" id="rename">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <label class="smallText" for="reemail">Email Id <span>*</span></label>
                                <input type="email" placeholder="Enter your Email Id" name="reemail" onKeyUP="this.value = this.value.toLowerCase();" id="reemail">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <label class="smallText" for="rephone">Phone Number <span>*</span></label>
                                <input type="tel" placeholder="Enter Phone Number" name="rephone" id="rephone">
                                <input type="hidden" value="" name="recountry" id="recountry">
                                <input type="hidden" value="" name="recountrydial" id="recountrydial">
                                <input type="hidden" value="" name="repageurl" id="repageurl">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <input type="submit" value="Submit">
                            </div>
                        </div>

                    </form>

                </div>

            </div>

        </div>
    </div>
</div>

<script src="js/custom.js">
</script>

<script src="js/particles.js">
</script>

<script type="text/javascript">
    jQuery(document).ready(function() {

        particlesJS("particless",

            {
                "particles": {
                    "number": {
                        "value": 57,
                        "density": {
                            "enable": true,
                            "value_area": 946.9771699587272
                        }
                    },
                    "color": {
                        "value": "#ffffff"
                    },
                    "shape": {
                        "type": "circle",
                        "stroke": {
                            "width": 0,
                            "color": "#000000"
                        },
                        "polygon": {
                            "nb_sides": 10
                        },
                        "image": {
                            "src": "img/github.svg",
                            "width": 100,
                            "height": 100
                        }
                    },
                    "opacity": {
                        "value": 0.5,
                        "random": false,
                        "anim": {
                            "enable": false,
                            "speed": 1,
                            "opacity_min": 0.1,
                            "sync": false
                        }
                    },
                    "size": {
                        "value": 2,
                        "random": false,
                        "anim": {
                            "enable": true,
                            "speed": 63.34202255950492,
                            "size_min": 30.858934067451116,
                            "sync": false
                        }
                    },
                    "line_linked": {
                        "enable": true,
                        "distance": 150,
                        "color": "#ffffff",
                        "opacity": 0.4,
                        "width": 1
                    },
                    "move": {
                        "enable": true,
                        "speed": 6,
                        "direction": "none",
                        "random": false,
                        "straight": false,
                        "out_mode": "out",
                        "bounce": false,
                        "attract": {
                            "enable": false,
                            "rotateX": 600,
                            "rotateY": 1200
                        }
                    }
                },
                "interactivity": {
                    "detect_on": "canvas",
                    "events": {
                        "onhover": {
                            "enable": true,
                            "mode": "grab"
                        },
                        "onclick": {
                            "enable": true,
                            "mode": "repulse"
                        },
                        "resize": true
                    },
                    "modes": {
                        "grab": {
                            "distance": 304.52895461300443,
                            "line_linked": {
                                "opacity": 0.1892023066229032
                            }
                        },
                        "bubble": {
                            "distance": 400,
                            "size": 40,
                            "duration": 1.9489853095232281,
                            "opacity": 0.10557003759917487,
                            "speed": 3
                        },
                        "repulse": {
                            "distance": 200,
                            "duration": 0.4
                        },
                        "push": {
                            "particles_nb": 4
                        },
                        "remove": {
                            "particles_nb": 2
                        }
                    }
                },
                "retina_detect": true
            });

    });
</script>

</body>

</html>

<!-- Online delivery software is looking for a Techie like you. Share your profile to resume@technoduce.com and be a part of our Technoduce family. -->