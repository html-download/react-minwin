/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorDeliveryTimeslot', {
    timeslotId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'timeslot_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'vendor_id'
    },
    timeslotDay: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: '',
      field: 'timeslot_day'
    },
    timeslotStartTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'timeslot_start_time'
    },
    timeslotEndTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'timeslot_end_time'
    },
    takeawayStartTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'takeaway_start_time'
    },
    takeawayEndTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'takeaway_end_time'
    },
    timeslotMaximumOrders: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'timeslot_maximum_orders'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_vendor_delivery_timeslot'
  });
};
