 //function Obj    (i)         { return document.getElementById(i); }
 //function Hide   (i)         { document.getElementById(i).style.display = "none"; }
 //function Show   (i)         { document.getElementById(i).style.display = "block"; }
 //function ShowIf (i, c)      { document.getElementById(i).style.display = c ? "block" : "none"; }
 //function MoveTo (i, x, y)   { var o = document.getElementById(i); o.style.left = x + "px"; o.style.top = y + "px"; }

/*function FlipH  (i, width, initial, final, duration, delay)
{
    var obj     = Obj(i);
    var frames  = width >> 1;
    var speed   = duration / width;

    setTimeout(function() { obj.className = initial; obj.style.width = width + "px"; }, delay);

    for (var x = 0; x < frames; x++)
    {
        setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

        delay += speed;
    }

    setTimeout(function() { obj.style.width = "0"; obj.style.marginLeft = "0"; obj.className = final; }, delay);

    for (var x = frames - 1; x >= 0; x--)
    {
        setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

        delay += speed;
    }

    setTimeout(function() { obj.style.width = width + "px"; obj.style.marginLeft = "0"; }, delay);

    return delay;
}

function Slide(i, x1, y1, x2, y2, fps, duration, delay)
{

}*/

function Obj(id)
{
    var o = document.getElementById(id);

    if (o == null)
    {
        console.log("Object not found: " + id);
        return false;
    }

    if (!o.IsExtended)
    {
        //////////////////////////////////////////////////////////////////////
        //
        // HIDE
        //
        //////////////////////////////////////////////////////////////////////

        o.Hide = function()
        {
            this.style.display = "none";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SHOW
        //
        //////////////////////////////////////////////////////////////////////

        o.Show = function()
        {
            this.style.display = "block";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SHOW IF
        //
        //////////////////////////////////////////////////////////////////////

        o.ShowIf = function(c)
        {
            this.style.display = c ? "block" : "none";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // FLIP HORIZONTALLY
        //
        //////////////////////////////////////////////////////////////////////

        o.FlipH = function(width, initial, final, duration, delay)
        {
            var x;
            var obj     = this;
            var frames  = width >> 1;
            var speed   = duration / width;

            setTimeout(function() { obj.className = initial; obj.style.width = width + "px"; }, delay);

            for (x = 0; x < frames; x++)
            {
                setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

                delay += speed;
            }

            setTimeout(function() { obj.style.width = "0"; obj.style.marginLeft = "0"; obj.className = final; }, delay);

            for (x = frames - 1; x >= 0; x--)
            {
                setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

                delay += speed;
            }

            setTimeout(function() { obj.style.width = width + "px"; obj.style.marginLeft = "0"; }, delay);

            return delay;
        };

        //////////////////////////////////////////////////////////////////////
        //
        // MOVE TO
        //
        //////////////////////////////////////////////////////////////////////

        o.MoveTo = function(x, y)
        {
            this.style.left = x + "px";
            this.style.top  = y + "px";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // ROTATE
        //
        //////////////////////////////////////////////////////////////////////

        o.Rotate = function(a)
        {
            var s = "rotate(" + a + "deg)";

            this.style.transform        = s;
            this.style.mozTransform     = s;
            this.style.msTransform      = s;
            this.style.oTransform       = s;
            this.style.sandTransform    = s;
            this.style.webkitTransform  = s;
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SLIDE
        //
        //////////////////////////////////////////////////////////////////////

        o.Slide = function(x1, y1, x2, y2, fps, duration, delay)
        {
            var dx      = x2 - x1;
            var dy      = y2 - y1;
            var frames  = duration * fps / 1000;
            var speed   = duration / frames;
            var ox      = dx / frames;
            var oy      = dy / frames;
            var src     = this;

            setTimeout(function() { src.style.left = x1 + "px"; src.style.top = y1 + "px"; src.style.display = "block"; }, delay);

            for (var frame = 0; frame < frames; frame++) { delay += speed; setTimeout(function(x, y) { return function() { src.style.left = x + "px"; src.style.top  = y + "px"; }; }(x1 + (frame * ox), y1 + (frame * oy)), delay); }

            setTimeout(function() { src.style.left = x2 + "px"; src.style.top  = y2 + "px"; }, delay);

            return delay;
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SLIDE AND RESIZE
        //
        //////////////////////////////////////////////////////////////////////

        o.SlideResize = function(x1, y1, w1, h1, x2, y2, w2, h2, fps, duration, delay)
        {
            var dx      = x2 - x1;
            var dy      = y2 - y1;
            var frames  = duration * fps / 1000;
            var speed   = duration / frames;
            var ox      = dx / frames;
            var oy      = dy / frames;
            var ow      = (w2 - w1) / frames;
            var oh      = (h2 - h1) / frames;
            var src     = this;

            setTimeout(function()
            {
                src.style.left      = x1 + "px";
                src.style.top       = y1 + "px";
                src.style.width     = w1 + "px";
                src.style.height    = h1 + "px";
                src.style.display   = "block";
            }, delay);

            for (var frame = 0; frame < frames; frame++) { delay += speed; setTimeout(function(x, y, w, h) { return function() { src.style.left = x + "px"; src.style.top = y + "px"; src.style.width = w + "px"; src.style.height = h + "px"; }; }(x1 + (frame * ox), y1 + (frame * oy), w1 + (frame * ow), h1 + (frame * oh)), delay); }

            setTimeout(function()
            {
                src.style.left   = x2 + "px";
                src.style.top    = y2 + "px";
                src.style.width  = w2 + "px";
                src.style.height = h2 + "px";
            }, delay);

            return delay;
        };

        o.IsExtended = true;
    }

    return o;
}

var Font =
{
    Format : function(amt)
    {
        var s = amt.toFixed(0);
        var x = /(\d+)(\d{3})/;

        while (x.test(s))
        {
            s = s.replace(x, "$1,$2");
        }

        return s;
    },

    Write : function(id, font, text)
    {
        if (text.length === 0)
        {
            Obj(id).innerHTML = "";
            return;
        }

        var h = "";
        var l = text.split("\n");

        for (var i = 0; i < l.length; i++)
        {
            for (var x = 0; x < l[i].length; x++)
            {
                var c = l[i].charCodeAt(x);

                h += '<img alt="" class="font_' + font + ' font_' + font + '_' + c + '" src="trans.gif">';
            }

            if (i < (l.length - 1))
            {
                h += "<br />";
            }
        }

        Obj(id).innerHTML = h;
    }
};

var Shape =
{
    Rect        : 0,
    Rectangle   : 0,
    Square      : 0,

    Circ        : 1,
    Circle      : 1,
    Ellipse     : 1,
    Oval        : 1,

    Poly        : 2,
    Polygon     : 2
};

function HotSpot(shape, coords)
{
    this.Coord          = coords;
    this.Enabled        = false;
    this.IsCapturing    = false;
    this.IsHovering     = false;
    this.Shape          = shape;

    this.Click          = function(a, c, s) { };
    this.DoubleClick    = function(a, c, s) { };
    this.Down           = function(a, c, s) { };
    this.Hover          = function(a, c, s) { };
    this.Leave          = function(a, c, s) { };
    this.Up             = function(a, c, s) { };

    this.Disable        = function( ) { this.Enabled = false; };
    this.Enable         = function( ) { this.Enabled = true;  };
    this.EnableIf       = function(c) { this.Enabled = c;     };

    switch (this.Shape)
    {
        case Shape.Rectangle:
        {
            this.Contains = function(x, y)
            {
                return (x >= this.Coord[0]) && (x <= this.Coord[2]) && (y >= this.Coord[1]) && (y <= this.Coord[3]);
            };

            break;
        }

        case Shape.Ellipse:
        {
            this.cx = (this.Coord[0] + this.Coord[2]) >> 1;
            this.cy = (this.Coord[1] + this.Coord[3]) >> 1;
            this.rx = (this.Coord[2] - this.Coord[0]) >> 1;
            this.ry = (this.Coord[3] - this.Coord[1]) >> 1;

            this.Contains = function(x, y)
            {
                var dx = x - this.cx;
                var dy = y - this.cy;

                return ((((dx * dx) / (this.rx * this.rx)) + ((dy * dy) / (this.ry * this.ry))) <= 1);
            };

            break;
        }

        case Shape.Polygon:
        {
            this.Points = this.Coord.length >> 1;

            if (this.Points < 3)
            {
                this.Contains = function(x, y)
                {
                    return false;
                };
            }
            else
            {
                this.Contains = function(x, y)
                {
                    var inside = false;
                    var newX, oldX, x1, x2;
                    var newY, oldY, y1, y2;

                    oldX = this.Coord[this.Coord.length - 2];
                    oldY = this.Coord[this.Coord.length - 1];

                    for (var p = 0; p < this.Points; p++)
                    {
                        newX = this.Coord[(p << 1) + 0];
                        newY = this.Coord[(p << 1) + 1];

                        if (newX > oldX)
                        {
                            x1 = oldX; x2 = newX; y1 = oldY; y2 = newY;
                        }
                        else
                        {
                            x1 = newX; x2 = oldX; y1 = newY; y2 = oldY;
                        }

                        if (((newX < x) === (x <= oldX)) && (((y - y1) * (x2 - x1)) < ((y2 - y1) * (x - x1))))
                        {
                            inside = !inside;
                        }

                        oldX = newX;
                        oldY = newY;
                    }

                    return inside;
                };
            }

            break;
        }
        default:
            break; 
    }
}

var Game =
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GAME-SPECIFIC FIELDS
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Bet                 : 3,
    Credits             : 1000,
    LastOutcome         : 0,
    LastWin             : 0,
    Paytable            : [],
    Reel                : [],
    BonusActivated      : false,
    BeginBonus          : function() { },
    BonusWin            : 0,

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EVENT HANDLING
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Button              : false,
    CaptureStart        : [-1, -1],
    HotSpot             : [],
    IsCapturing         : false,
    IsHovering          : false,

    GetEventInfo        : function(e) { var o = Obj("capture"), x = 0, y = 0, a = e.altKey, c = e.ctrlKey, s = e.shiftKey; if (e.offsetX || e.offsetY) { x = e.offsetX; y = e.offsetY; } else { while (o) { x += o.offsetLeft; y += o.offsetTop; o = o.offsetParent; } x = e.pageX - x; y = e.pageY - y; } return { X : x, Y : y, Alt : a, Ctrl : c, Shift : s, Button : Game.Button }; },
    GlobalMouseDown     : function(e) { Game.Button = true; },
    GlobalMouseUp       : function(e) { Game.Button = false; Game.IsCapturing = false; for (var h in Game.HotSpot) { Game.HotSpot[h].IsCapturing = false; } },
    KeyReleased         : function(e) { /* if (Game.HotSpot["ButtonMsgBox"].Enabled === false) { return true; } if ((e.keyCode === 13) || (e.keyCode === 27) || (e.keyCode === 32)) { Game.HotSpot["ButtonMsgBox"].Click(); return false; } return true; */ },
    MouseClick          : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y) && Game.HotSpot[h].Contains(Game.CaptureStart[0], Game.CaptureStart[1])) { Game.IsCapturing = false; Game.IsHovering = true; Game.HotSpot[h].IsCapturing = false; Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].Click(evt.Alt, evt.Ctrl, evt.Shift); } } },
    MouseDoubleClick    : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y) && Game.HotSpot[h].Contains(Game.CaptureStart[0], Game.CaptureStart[1])) { Game.IsCapturing = false; Game.IsHovering = true; Game.HotSpot[h].IsCapturing = false; Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].DoubleClick(evt.Alt, evt.Ctrl, evt.Shift); } } },
    MouseDown           : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); Game.CaptureStart = [evt.X, evt.Y]; for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y)) { Game.IsCapturing = true; Game.HotSpot[h].IsCapturing = true; Game.HotSpot[h].Down(evt.Alt, evt.Ctrl, evt.Shift); } } },
    MouseMove           : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); var NewCap = false; var NewHov = false; for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled) { if (Game.IsCapturing && Game.Button) { if (Game.HotSpot[h].Contains(evt.X, evt.Y)) { if (Game.HotSpot[h].IsCapturing) { if (!Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].Down(evt.Alt, evt.Ctrl, evt.Shift); } } else { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(evt.Alt, evt.Ctrl, evt.Shift); } } } else { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(evt.Alt, evt.Ctrl, evt.Shift); } } } else { if (Game.HotSpot[h].Contains(evt.X, evt.Y)) { if (!Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].Hover(evt.Alt, evt.Ctrl, evt.Shift); } } else { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(evt.Alt, evt.Ctrl, evt.Shift); } } } } else { if (Game.HotSpot[h].IsCapturing || Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsCapturing = false; Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(); } } NewCap |= Game.HotSpot[h].IsCapturing; NewHov |= Game.HotSpot[h].IsHovering; } Game.IsCapturing = NewCap; Game.IsHovering = NewHov; },
    MouseOut            : function(e) { Game.IsHovering = false; for (var h in Game.HotSpot) { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(); } } },
    MouseUp             : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); for (var h in Game.HotSpot) { Game.IsCapturing = false; Game.HotSpot[h].IsCapturing = false; if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y)) { Game.HotSpot[h].IsHovering = true; if (Game.HotSpot[h].IsCapturing) { Game.HotSpot[h].Up(evt.Alt, evt.Ctrl, evt.Shift); } else { Game.HotSpot[h].Hover(evt.Alt, evt.Ctrl, evt.Shift); } } else { Game.HotSpot[h].IsHovering = false; } } },

    BeforeInitialize    : function() { },
    AfterInitialize     : function() { },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // INITIALIZE
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Initialize : function()
    {
        
        Game.BeforeInitialize();
console.log("Game", Game);

        Game.HotSpot.ButtonBetOne           = new HotSpot(Shape.Rectangle, [493,520, 560,575]);
        Game.HotSpot.ButtonBetMax           = new HotSpot(Shape.Rectangle, [571,520, 638,575]);
        Game.HotSpot.ButtonSpin             = new HotSpot(Shape.Circle,    [668,505, 753,589]);

console.log("HotSpot", Game.HotSpot);

console.log("Game.HotSpot.ButtonBetOne ", Game.HotSpot.ButtonBetOne );
console.log("Game.HotSpot.ButtonBetMax ", Game.HotSpot.ButtonBetMax );
console.log("Game.HotSpot.ButtonSpin ", Game.HotSpot.ButtonSpin );
        Game.HotSpot.ButtonBetOne.Leave     = function(a, c, s) { if (this.Enabled) { Obj("btn_betone").style.backgroundPosition = "0 0"; } };
        Game.HotSpot.ButtonBetOne.Down      = function(a, c, s) { Obj("btn_betone").style.backgroundPosition = "0 -55px"; };
        Game.HotSpot.ButtonBetOne.Up        = function(a, c, s) { Obj("btn_betone").style.backgroundPosition = "0 0"; };
        Game.HotSpot.ButtonBetOne.Click     = function(a, c, s) { Obj("btn_betone").style.backgroundPosition = "0 0"; Game.Clear(); Game.Bet = (Game.Bet % 3) + 1; Game.Update(true); };

        Game.HotSpot.ButtonBetMax.Leave     = function(a, c, s) { if (this.Enabled) { Obj("btn_betmax").style.backgroundPosition = "-67px 0"; } };
        Game.HotSpot.ButtonBetMax.Down      = function(a, c, s) { Obj("btn_betmax").style.backgroundPosition = "-67px -55px"; };
        Game.HotSpot.ButtonBetMax.Up        = function(a, c, s) { Obj("btn_betmax").style.backgroundPosition = "-67px 0"; };
        Game.HotSpot.ButtonBetMax.Click     = function(a, c, s) { Obj("btn_betmax").style.backgroundPosition = "-67px 0"; Game.Bet = 3; Game.Update(true); Game.Play(); };

        Game.HotSpot.ButtonSpin.Leave       = function(a, c, s) { if (this.Enabled) { Obj("btn_spin").style.backgroundPosition = "-134px 0"; } };
        Game.HotSpot.ButtonSpin.Down        = function(a, c, s) { Obj("btn_spin").style.backgroundPosition = "-134px -85px"; };
        Game.HotSpot.ButtonSpin.Up          = function(a, c, s) { Obj("btn_spin").style.backgroundPosition = "-134px 0"; };
        Game.HotSpot.ButtonSpin.Click       = function(a, c, s) { Obj("btn_spin").style.backgroundPosition = "-134px 0"; Game.Play(); };

        //var gam = Obj("game");
        var cap = Obj("capture");

        document.onselectstart              = function() { return false; };
        document.ondragstart                = function() { return false; };
        cap.onselectstart                   = function() { return false; };
        cap.ondragstart                     = function() { return false; };
        cap.onmousemove                     = Game.MouseMove;
        cap.onmousedown                     = Game.MouseDown;
        cap.onmouseup                       = Game.MouseUp;
        cap.onclick                         = Game.MouseClick;
        cap.ondblclick                      = Game.MouseDoubleClick;
        cap.onmouseout                      = Game.MouseOut;
        document.body.onmousedown           = Game.GlobalMouseDown;
        document.body.onmouseup             = Game.GlobalMouseUp;
        document.onkeydown                  = function(e) { return Game.KeyReleased(e || window.event); }

        Obj("loading").Hide();
        Obj("game").Show();

        Game.AfterInitialize();

        Game.HotSpot.ButtonBetOne.Enable();
        Game.HotSpot.ButtonBetMax.Enable();
        Game.HotSpot.ButtonSpin.Enable();

        Game.Update(true);

        Obj("game").scrollIntoView();
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CLEAR
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Clear : function()
    {
        Game.LastWin = 0;

        Obj("win").innerHTML = "";
        Obj("msg").innerHTML = "";
        Obj("payline").Hide();
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // UPDATE
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Update : function(btn)
    {
        Font.Write("credits", "lcd33", Game.Credits.toFixed(0));

        if (Game.LastWin > 0)
        {
            Font.Write("win", "lcd33", Game.LastWin.toFixed(0));
        }
        else
        {
            Obj("win").innerHTMl = "";
        }

        Font.Write("bet", "lcd33", Game.Bet.toFixed(0));

        if (btn)
        {
            Game.HotSpot.ButtonBetOne.Enable(); Obj("btn_betone").Show();
            Game.HotSpot.ButtonBetMax.Enable(); Obj("btn_betmax").Show();
            Game.HotSpot.ButtonSpin.Enable();   Obj("btn_spin").Show();
        }
        else
        {
            Game.HotSpot.ButtonBetOne.Disable(); Obj("btn_betone").Hide();
            Game.HotSpot.ButtonBetMax.Disable(); Obj("btn_betmax").Hide();
            Game.HotSpot.ButtonSpin.Disable();  Obj("btn_spin").Hide();
        }
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // PLAY
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Play : function()
    {
        Game.Clear();

        Font.Write("msg", "lcd17", "GOOD LUCK!");

        Game.HotSpot.ButtonBetOne.Disable(); Obj("btn_betone").Hide();
        Game.HotSpot.ButtonBetMax.Disable(); Obj("btn_betmax").Hide();
        Game.HotSpot.ButtonSpin.Disable();   Obj("btn_spin").Hide();

        Game.Credits -= Game.Bet;
        Font.Write("credits", "lcd33", Game.Credits.toFixed(0));

        Game.Reel[0].VirtualStop = Math.floor(Math.random() * Game.Reel[0].Weight);
        Game.Reel[1].VirtualStop = Math.floor(Math.random() * Game.Reel[1].Weight);
        Game.Reel[2].VirtualStop = Math.floor(Math.random() * Game.Reel[2].Weight);

        var w, s;

        w = Game.Reel[0].VirtualStop; s = 0; while (w >= Game.Reel[0].StopWeight[s]) { w -= Game.Reel[0].StopWeight[s++]; } Game.Reel[0].PhysicalStop = s;
        w = Game.Reel[1].VirtualStop; s = 0; while (w >= Game.Reel[1].StopWeight[s]) { w -= Game.Reel[1].StopWeight[s++]; } Game.Reel[1].PhysicalStop = s;
        w = Game.Reel[2].VirtualStop; s = 0; while (w >= Game.Reel[2].StopWeight[s]) { w -= Game.Reel[2].StopWeight[s++]; } Game.Reel[2].PhysicalStop = s;

        Game.Reel[0].Position = Math.floor(Math.random() * Game.Reel[0].Height);
        Game.Reel[1].Position = Math.floor(Math.random() * Game.Reel[1].Height);
        Game.Reel[2].Position = Math.floor(Math.random() * Game.Reel[2].Height);

        Game.Reel[0].Timer = setInterval(function() { Game.SpinReel(0); }, 5);
        Game.Reel[1].Timer = setInterval(function() { Game.SpinReel(1); }, 5);
        Game.Reel[2].Timer = setInterval(function() { Game.SpinReel(2); }, 5);

        setTimeout(function() { Game.StopReel(0); },  500);
        setTimeout(function() { Game.StopReel(1); }, 1100);
        setTimeout(function() { Game.StopReel(2); }, 1800);

        setTimeout(Game.PlayFinish, 1801);
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // SPIN REEL
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    SpinReel : function(n)
    {
        Game.Reel[n].Position = (Game.Reel[n].Position + 17) % Game.Reel[n].Height;

        Obj("reel" + n).style.backgroundPosition = "0 -" + (Game.Reel[n].Height - Game.Reel[n].Position) + "px";
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // STOP REEL
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    StopReel : function(n)
    {
        clearInterval(Game.Reel[n].Timer);

        Obj("reel" + n).style.backgroundPosition = Game.Reel[n].Offset[Game.Reel[n].PhysicalStop];
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // PLAY FINISH
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    PlayFinish : function()
    {
        var s1a = Game.Reel[0].Symbol1[Game.Reel[0].PhysicalStop];
        var s2a = Game.Reel[1].Symbol1[Game.Reel[1].PhysicalStop];
        var s3a = Game.Reel[2].Symbol1[Game.Reel[2].PhysicalStop];

        var s1b = Game.Reel[0].Symbol2[Game.Reel[0].PhysicalStop];
        var s2b = Game.Reel[1].Symbol2[Game.Reel[1].PhysicalStop];
        var s3b = Game.Reel[2].Symbol2[Game.Reel[2].PhysicalStop];

        var best = { Outcome : 0, Multiplier : 1 };

        var outcome1 = Game.GetOutcome(s1a, s2a, s3a); if (outcome1.Outcome > best.Outcome) { best = outcome1; }
        var outcome2 = Game.GetOutcome(s1a, s2a, s3b); if (outcome2.Outcome > best.Outcome) { best = outcome2; }
        var outcome3 = Game.GetOutcome(s1a, s2b, s3a); if (outcome3.Outcome > best.Outcome) { best = outcome3; }
        var outcome4 = Game.GetOutcome(s1a, s2b, s3b); if (outcome4.Outcome > best.Outcome) { best = outcome4; }
        var outcome5 = Game.GetOutcome(s1b, s2a, s3a); if (outcome5.Outcome > best.Outcome) { best = outcome5; }
        var outcome6 = Game.GetOutcome(s1b, s2a, s3b); if (outcome6.Outcome > best.Outcome) { best = outcome6; }
        var outcome7 = Game.GetOutcome(s1b, s2b, s3a); if (outcome7.Outcome > best.Outcome) { best = outcome7; }
        var outcome8 = Game.GetOutcome(s1b, s2b, s3b); if (outcome8.Outcome > best.Outcome) { best = outcome8; }

        Game.LastOutcome = best.Outcome;
        Game.LastWin     = Game.Paytable[Game.Bet - 1][Game.LastOutcome] * best.Multiplier;

        if (Game.LastWin > 0)
        {
            Obj("payline").Show();
            Font.Write("msg", "lcd17", "GAME PAYS " + Game.LastWin);
        }
        else
        {
            Obj("msg").innerHTML = "";
        }

        Game.Credits += Game.LastWin;
        Game.Update(true);
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GET OUTCOME
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    GetOutcome : function(s1, s2, s3)
    {
        return { Outcome : 0, Multiplier : 1 };
    }
};

var save = window.onload;

window.onload = function()
{
    if (save)
    {
        save();
    }
    if (typeof Game !== 'undefined') {
        Game.Initialize();
    }
};

Game.Paytable =
[
    [0, 2,  5, 10, 10, 14, 14, 18, 18, 100, 100, 100, 200],
    [0, 4, 10, 20, 20, 28, 28, 36, 36, 200, 200, 200, 400],
    [0, 6, 15, 30, 30, 42, 42, 54, 54, 300, 300, 300, 600]
];

Game.Reel =
[
    // REEL 1:
    {
        Height          : 1500,
        Weight          : 20,
        Symbol1         : [ 5,  2,  4,  6,  4,  5,  0,  3,  5,  6,  1,  4,  5,  4,  2,  4,  5,  4,  1,  4],
        Symbol2         : [-1, -1, -1, -1, -1, -1, -1,  1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
        StopWeight      : [ 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
        Offset          : ["0 -1425px", "0 0px", "0 -75px", "0 -150px", "0 -225px", "0 -300px", "0 -375px", "0 -450px", "0 -525px", "0 -600px", "0 -675px", "0 -750px", "0 -825px", "0 -900px", "0 -975px", "0 -1050px", "0 -1125px", "0 -1200px", "0 -1275px", "0 -1350px"],
        Position        : 0,
        VirtualStop     : 2,
        PhysicalStop    : 1,
        Timer           : 0
    },

    // REEL 2:
    {
        Height          : 1500,
        Weight          : 20,
        Symbol1         : [ 6,  4,  6,  0,  6,  3,  4,  3,  6,  5,  3,  2,  4,  3,  6,  1,  5,  6,  3,  2],
        Symbol2         : [-1, -1, -1,  5, -1, -1,  1, -1, -1, -1, -1,  5, -1, -1, -1, -1, -1, -1, -1,  5],
        StopWeight      : [ 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
        Offset          : ["-125px -1425px", "-125px 0px", "-125px -75px", "-125px -150px", "-125px -225px", "-125px -300px", "-125px -375px", "-125px -450px", "-125px -525px", "-125px -600px", "-125px -675px", "-125px -750px", "-125px -825px", "-125px -900px", "-125px -975px", "-125px -1050px", "-125px -1125px", "-125px -1200px", "-125px -1275px", "-125px -1350px"],
        Position        : 0,
        VirtualStop     : 2,
        PhysicalStop    : 1,
        Timer           : 0
    },

    // REEL 3:
    {
        Height          : 1500,
        Weight          : 20,
        Symbol1         : [ 3,  5,  4,  3,  5,  7,  3,  2,  3,  4,  7,  3,  4,  3,  0,  7,  3,  2,  3,  7],
        Symbol2         : [-1, -1, -1, -1, -1, -1, -1,  5, -1, -1, -1, -1, -1, -1,  1, -1, -1,  5, -1, -1],
        StopWeight      : [ 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
        Offset          : ["-250px -1425px", "-250px 0px", "-250px -75px", "-250px -150px", "-250px -225px", "-250px -300px", "-250px -375px", "-250px -450px", "-250px -525px", "-250px -600px", "-250px -675px", "-250px -750px", "-250px -825px", "-250px -900px", "-250px -975px", "-250px -1050px", "-250px -1125px", "-250px -1200px", "-250px -1275px", "-250px -1350px"],
        Position        : 0,
        VirtualStop     : 2,
        PhysicalStop    : 1,
        Timer           : 0
    }
];

Game.GetOutcome = function(s1, s2, s3)
{
    if ((s1 === 0) && (s2 === 0) && (s3 === 0)) { console.log("Outcome = 11"); return { Outcome : 12, Multiplier : 1 }; }   // 12 = SEVEN-SEVEN-SEVEN
    if ((s1 === 1) && (s2 === 1) && (s3 === 1)) { console.log("Outcome = 10"); return { Outcome : 11, Multiplier : 1 }; }   // 11 = BAR-BAR-BAR
    if ((s1 === 2) && (s2 === 2) && (s3 === 2)) { console.log("Outcome =  9"); return { Outcome : 10, Multiplier : 1 }; }   // 10 = MELON-MELON-MELON
    if ((s1 === 2) && (s2 === 2) && (s3 === 1)) { console.log("Outcome =  8"); return { Outcome :  9, Multiplier : 1 }; }   //  9 = MELON-MELON-BAR
    if ((s1 === 3) && (s2 === 3) && (s3 === 3)) { console.log("Outcome =  7"); return { Outcome :  8, Multiplier : 1 }; }   //  8 = BELL-BELL-BELL
    if ((s1 === 3) && (s2 === 3) && (s3 === 1)) { console.log("Outcome =  6"); return { Outcome :  7, Multiplier : 1 }; }   //  7 = BELL-BELL-BAR
    if ((s1 === 4) && (s2 === 4) && (s3 === 4)) { console.log("Outcome =  5"); return { Outcome :  6, Multiplier : 1 }; }   //  6 = PLUM-PLUM-PLUM
    if ((s1 === 4) && (s2 === 4) && (s3 === 1)) { console.log("Outcome =  4"); return { Outcome :  5, Multiplier : 1 }; }   //  5 = PLUM-PLUM-BAR
    if ((s1 === 5) && (s2 === 5) && (s3 === 5)) { console.log("Outcome =  3"); return { Outcome :  4, Multiplier : 1 }; }   //  4 = ORANGE-ORANGE-ORANGE
    if ((s1 === 5) && (s2 === 5) && (s3 === 1)) { console.log("Outcome =  2"); return { Outcome :  3, Multiplier : 1 }; }   //  3 = ORANGE-ORANGE-BAR
    if ((s1 === 6) && (s2 === 6))              { console.log("Outcome =  1"); return { Outcome :  2, Multiplier : 1 }; }   //  2 = CHERRY-CHERRY-ANY
    if  (s1 === 6)                            { console.log("Outcome =  0"); return { Outcome :  1, Multiplier : 1 }; }   //  1 = CHERRY-ANY-ANY

    return { Outcome : 0, Multiplier : 1 };                                                 //  0 = ALL OTHER
};

