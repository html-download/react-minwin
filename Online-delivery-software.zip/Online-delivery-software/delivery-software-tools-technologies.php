<?php $title = 'On-demand delivery software development with latest Tools &amp; technologies' ?>
<?php $description = 'Onlinedeliverysoftware.com uses latest tools and technology to develop an on-demand food delivery software for the restaurant. We provide the app on both the web and mobile platform.' ?>
<?php $keywords = 'On-demand delivery tracking software, on-demand delivery tracking system, transport tracking software, logistics delivery system' ?>


<?php include ("header.php")?>





<section class="subbanner techno portfolioPage text-center">
<div class="container">
<h1>Tools & Technologies used </h1>
</div>
</section>



<section class="rolesTech first">
<div class="container"><div class="row">
<div class="col-md-3 text-center">
<h2 class="circle"> Application and Data</h2>
</div>
<div class="col-md-9">

<div class="toolsTechro">
<ul>
<li>  <img src="img/tools-tech/html5.png" alt="HTML5"> <p>HTML5</p> <span>Languages</span></li>
<li>  <img src="img/tools-tech/boostrap.png" alt="Boostrap"> <p>Bootstrap</p> <span>Front-End Frameworks</span></li>
<li>  <img src="img/tools-tech/jquery.png" alt="jQuery"> <p>jQuery</p> <span>UI Libraries</span> </li>
<li>  <img src="img/tools-tech/javascript.png" alt="JavaScript"> <p>JavaScript</p> <span>Languages</span>  </li>
<li>  <img src="img/tools-tech/php.png" alt="PHP"> <p>PHP</p> <span>Languages</span>  </li>
<li>  <img src="img/tools-tech/yi2.png" alt="Yii2 Framework"> <p>Yii2 Framework</p> <span>Frameworks</span>  </li>
<li>  <img src="img/tools-tech/node.png" alt="Node.js"> <p>Node.js</p> <span>Frameworks (Full Stack)</span> </li>
<li>  <img src="img/tools-tech/mysql.png" alt="MySQL"> <p>MySQL</p> <span>Database</span> </li>
<li>  <img src="img/tools-tech/redis.png" alt="Redis"> <p>Redis</p> <span>In-memory Databases</span> </li>

<li>  <img src="img/tools-tech/amazonec2.png" alt="Amazon EC2"> <p>Amazon EC2</p> <span>Cloud Hosting</span> </li>
<li>  <img src="img/tools-tech/java.png" alt="Java"> <p>Java</p> <span>Languages</span> </li>
<li>  <img src="img/tools-tech/object-c.png" alt="Objective C"> <p>Objective-C</p> <span>Languages</span> </li>
</ul>
</div>
</div>
</div>
</div></section>


<section class="rolesTech">
<div class="container"><div class="row">
<div class="col-md-3 text-center">
<h2 class="circle appla">Utilities</h2>
</div>
<div class="col-md-9">

<div class="toolsTechro">
<ul>
<li>  <img src="img/tools-tech/googleana.png" alt="Google Analytics"> <p>Google Analytics</p><span>General Analytics</span>  </li>
<li>  <img src="img/tools-tech/gmaps.png" alt="Google Maps"> <p>Google Maps</p><span>Mapping APIs</span>  </li>

</ul>
</div>
</div>

</div>
</div></section>


<section class="rolesTech">
<div class="container"><div class="row">
<div class="col-md-3 text-center">
<h2 class="circle appla">DevOps</h2>
</div>
<div class="col-md-9">

<div class="toolsTechro threesize">
<ul>
<li> <img src="img/tools-tech/bitbuket.png" alt="BitBucket"> <p>BitBucket</p>   <span>Code collaboration & Version Control</span> </li>
<li>  <img src="img/tools-tech/android_studio.png" alt="Android Studio"> <p>Android Studio</p> <span>Integrated Development Environment</span>  </li>
<li> <img src="img/tools-tech/xcode.png" alt="Xcode"> <p>Xcode</p>  <span>Integrated Development Environment</span>  </li>
<li> <img src="img/tools-tech/jenkins.png" alt="Jenkins"> <p>Jenkins</p>   <span>Continuous  Integration</span> </li>
<li> <img src="img/tools-tech/capistrano.png" alt="Capistrano"> <p>Capistrano</p>   <span>Server Configuration & Automation</span> </li>
</ul>
</div>
</div>

</div>
</div></section>




<section class="rolesTech bor">
<div class="container"><div class="row">
<div class="col-md-3 text-center">
<h2 class="circle">Business Tools</h2>
</div>
<div class="col-md-9">

<div class="toolsTechro">
<ul>
<li>  <img src="img/tools-tech/googleapps.png" alt="Google Apps"> <p>Google Apps</p> <span>Productivity Suite</span>  </li>

</ul>
</div>
</div>
</div>
</div></section>



<section class="getintouch text-center">
<div class="container">
<h2>Looking for online delivery management software?</h2>
<p class="sub">Our mission is to make your delivery more productive with less effort. <br> To keep your project ideas confidential, we can sign an NDA document.  </p>
<?php include ("contact-form.php");?>
</div>
</section>


<?php include ("footer.php")?>