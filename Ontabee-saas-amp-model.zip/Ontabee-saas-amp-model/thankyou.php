<?php
session_start();
$title = 'Thankyou - Ontabee' ?>
<?php $description = '' ?>
<?php $keywords = '' ?>

<?php include ('inc/header.php');?>

<?php if(!isset($_SESSION['msg'])){ ?>
	<script type="text/javascript">
		window.location.href = '<?php echo $baseurl?>';
	</script>
<?php } ?>

<?php if ($_SESSION['msg'] == 0) { ?>
	<section class="page_banner thankyou">
		<div class="container">
			<div class="content">			
				<i class="fi tick"></i>
				<h2>Thank you !</h2>
				<p>We have received your information successfully. <br>We will get back to you shortly.</p>
				<hr>
				<a href="<?php echo $baseurl;?>" class="btn">Back To Home</a>
			</div>
		</div> <!--container-->
	</section>	
<?php } else if ( $_SESSION['msg'] == 1 ) { ?>
	<section class="page_banner thankyou">
		<div class="container">
			<div class="content">			
				<i class="fi tick"></i>
				<h2>Thank you !</h2>
				<h5>Please Check Your E-mail To Activate Your Free Trial Website.</h5>			
				<hr>			
				<p>We have received your information successfully. <br>We will get back to you shortly.</p>			
				<a href="<?php echo $baseurl;?>" class="btn">Back To Home</a>
			</div>
		</div> <!--container-->
	</section>
<?php } ?>
<?php 
unset($_SESSION['msg']);
session_destroy(); 
?>
<?php include('inc/footer.php');?>