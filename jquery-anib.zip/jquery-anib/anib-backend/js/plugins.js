document.write('<scr'+'ipt type="text/javascript" src="js/popper.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/wow.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.sticky-kit.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/datepicker.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/i18n/datepicker.en.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/select2.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/snackbar.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.steps.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/datatables.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap-editable.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery-sortable.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/main.min.js" ></scr'+'ipt>');

