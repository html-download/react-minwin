import React, {Component} from 'react';  
import {Container, Row, Col, Form, Label ,FormGroup , Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button } from 'reactstrap';
import PropTypes from 'prop-types'; 
import ClassName from 'classnames';

const Checkbox = (props) => {

  let groupClasses = ClassName(Object.assign({
    'form-group' : true
  }, props.groupClasses));

let lableClasses = ClassName(Object.assign({
    'checkbox' : true
  },props.labelClasses ));

  let inputClasses = ClassName(Object.assign({
    'checkbox' : true
  }), props.inputClasses)

    return( 
   
    <div className={groupClasses}>
     {props.title}
      {props.options.map(option => {
        return (
          <label key={option} htmlFor={props.name} className={lableClasses}>
            <input
              className={inputClasses}
              id = {props.name}
              name={props.name}
              onChange={props.onChange}
              value={option}
              checked={props.checked}
              type="checkbox" /> {option}

          </label>

        );
         
      })}
    </div>
  
);

}

Checkbox.propTypes={
  title: PropTypes.string,
  type: PropTypes.oneOf(['checkbox', 'radio']),
  options: PropTypes.array,
  onChange: PropTypes.func
};




export default Checkbox;