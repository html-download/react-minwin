import {fitBounds} from 'google-map-react/utils';
const Actions = require('./actions');
const LotMessageModal = require('./lot-message-modal');
const React = require('react');
const ExcelExport = require('./excel');
const ExcelZoneExport = require('./excel-zone');
import {Link} from 'react-router-dom';
const ReactHelmet = require('react-helmet');
import { ExportToCsv } from 'export-to-csv';
const Store = require('./store');
const UserIdentity = require('../../../helpers/user-identity');
const ExcelHelper = require('../../../helpers/excel');
const DateHelper = require('../../../helpers/date-time');
const Config = require('../../../../config.js');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const LotHistoricalModal = require('./lot-historical-modal');
const InfoWindowModal = require('./lot-info-window-modal');
const moment = require('moment-timezone');

import Map from './Map';

const Helmet = ReactHelmet.Helmet;

class LotsPage extends React.Component {
    constructor(props){
        super(props);
        this.state = Store.getState();
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.updateOccupancy = this.updateOccupancy.bind(this);
        this.toggleNav = this.toggleNav.bind(this);
        this.updateMapBounds = this.updateMapBounds.bind(this);
        this.editMapBounds = this.editMapBounds.bind(this);
        this.updateMapCenter = this.updateMapCenter.bind(this);
        this.setMarkers = this.setMarkers.bind(this);
        this.saveStallValue = this.saveStallValue.bind(this);
        this.setTimeLimit = this.setTimeLimit.bind(this);
        this.getHistorical = this.getHistorical.bind(this);
        this.getHistoricalDownload = this.getHistoricalDownload.bind(this);
        this.getHistoricalExport = this.getHistoricalExport.bind(this);
        this.getOverlayImage = this.getOverlayImage.bind(this);
        this.getLastMessage = this.getLastMessage.bind(this);
    }
    toggleNav() {
        this.setState({'showSideNav': !this.state.showSideNav})
    }

    updateMapCenter(center, zoom) {
        this.setState({center: null, zoom: null});
        this.setState({center: center, zoom: zoom});
    }

    updateMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    editMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    setMarkers(markers) {
        this.setState({'markers': markers});
    }

    getLastMessage(){
        Actions.getLotMessage({id: this.state.lot_id});
    }

    updateOccupancy(){
        let url = `${this.params.fopark_url}/lot/occupancy?client_name=${UserIdentity.client}&name=${this.props.match.params.lotID}&duration_flag=1`;//&duration_flag=1
        //let url = `${this.params.fopark_url}/lot/stalls?client_name=auburn&lot_name=${this.props.match.params.lotID}`;
        Actions.getOccupancy(url);
    }

    getOverlayImage() {
        let url = `${this.params.fopark_url}/lot/overlay?client_name=${UserIdentity.client}&lot_name=${this.props.match.params.lotID}`;
        Actions.getOverlay(url);
    }

    getSummary() {
        let url = `${this.params.fopark_url}/lot/summary?client_name=${UserIdentity.client}&name=${this.props.match.params.lotID}`;
        Actions.getSummary(url, this.updateMapBounds, this.updateOccupancy, this.getOverlayImage, this.getLastMessage);
    }
    saveStallValue(event, stallNumber, latitude, longitude, lotName, showInfoIndex, popup = false) {
        let popup_element = ''; 
        if (popup) {
            popup_element = 'info_window_popup_'
        }
        let zone = $("#"+popup_element+"zone_"+showInfoIndex).val();
        let alt_id = $("#"+popup_element+"alt_id_"+showInfoIndex).val();
        let unavailable = $("#"+popup_element+"unavailable_"+showInfoIndex).prop("checked") ? 1 : 0;
        let reserved = $("#"+popup_element+"reserved_"+showInfoIndex).prop("checked") ? 1 : 0;
        let qa_flag = $("#"+popup_element+"qa_flag_"+showInfoIndex).prop("checked") ? 1 : 0;
        let context = $("#"+popup_element+"context_"+showInfoIndex).prop("checked") ? 1 : 0;

        let data = {
                'stall_num' : stallNumber,
                'lot_name' : lotName,
                'reserve_flag' : reserved
            };

        Actions.saveStall(data, this.props.history, this.updateOccupancy);
        
    }
    componentDidMount(){
        window.scrollTo(0, 0);
        /*this.props.navigation.navigate(
          'nextComponent', 
          {
            onGoBack: () => console.log('Will go back from nextComponent'),
          }
        );*/
        Actions.initTimeLimit();
        this.getSummary()
        this.interval = setInterval(
            () => {
                this.getSummary();
            }, 60000
        );
        //this.updateOccupancy();

        this.setState({'mapHeight': window.innerHeight, 'mapWidth': window.innerWidth});
        if (this.state.center && this.state.zoom) {
            this.updateMapCenter(this.state.center, this.state.zoom);
        }
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentDidUpdate(prevProps) {
        /*$(".lot_detail").css({
            'height': window.innerHeight+'px',
            'min-height': window.innerHeight+'px'
        });*/
        if ($("#modal_lot_msg").parents('div').css('display') === 'block') {
            let today = moment().tz(Config.get('/timeZone')).format('MM/DD/YYYY').toString();
            let endDate = "+0d";

            $(".datepicker" ).datepicker({
                startDate: endDate,
                keyboardNavigation: false,
                forceParse: false,
                todayHighlight: false,
                setDate: today,
            }).on('changeDate', function(ev){
                $(this).datepicker('hide');
            });
            
            $('.timepicker').datetimepicker({
                format: 'LT'
            });
        }

        $('.selectpicker').selectpicker('refresh');

        if ($("#modal_history").parents('div').css('display') === 'block') {
            let today = moment().tz(Config.get('/timeZone')).format('MM/DD/YYYY').toString();
            let endDate = "+0d";

            if (today !== moment().format('MM/DD/YYYY').toString()) {
                endDate = '-1d';
            }
            
            $("#date-inline" ).datepicker({
                inline: true,
                altField: '.date-inline',
                endDate: endDate,
                keyboardNavigation: false,
                forceParse: false,
                todayHighlight: false,
                setDate: today,
            })
            //.datepicker("setDate", today)
            .on('changeDate', function(e){
                e.stopPropagation();
                e.stopImmediatePropagation();
                var formatedValue = e.date;
                let date = DateHelper._historicalDateFormat(formatedValue);
                Actions.setHistoricalDate(date, {
                    key : Config.get('/historicalApiToken'),
                    date : date,
                    is_lot : 1,
                    days : 0,
                    client_name : Config.get('/client'),
                    lot_name : prevProps.match.params.lotID,
                    zone : '',
                })
            });
            /*$('.date-inline').datetimepicker({
                inline:true,
                format: 'DD/MM/YYYY',
                maxDate: moment().tz(Config.get('/timeZone')),
            }).on('dp.change', function(e){ 
                e.stopPropagation();
                e.stopImmediatePropagation();
                var formatedValue = e.date.format(e.date._f);
                let date = DateHelper._historicalDateFormat(formatedValue);
                Actions.setHistoricalDate(date, {
                    key : Config.get('/historicalApiToken'),
                    date : date,
                    is_lot : 1,
                    days : 0,
                    client_name : Config.get('/client'),
                    lot_name : prevProps.match.params.lotID,
                    zone : '',
                })
            });*/
        }

        let chart = Highcharts.chart('historical', {
            chart: {
                type: 'area'
            },
            title: {
                text: 'Historical Data'
            },
            xAxis: {
                title: {
                    text: 'Occupancy by Hour',
                    enabled: true
                },
                categories: this.state.time_array,
                tickmarkPlacement: 'on'
            },
            yAxis: {
                title: {
                    text: 'Percentage (%)'
                }
            },
            tooltip: {
                split: true,
                valueSuffix: ' %',
                formatter: function() {
                    return parseFloat(this.y).toFixed(2) + '%</b> occupied at <b>' + this.x + '</b>';
                }
            },
            plotOptions: {
                area: {
                    stacking: 'normal',
                    lineColor: '#666666',
                    lineWidth: 1,
                    marker: {
                        lineWidth: 1,
                        lineColor: '#666666'
                    }
                }
            },
            series: [{
                name: 'History',
                color: '#4dbb5b',
                data: this.state.percentage_array
            }]
        });

        chart.update({
            xAxis: {
                title: {
                    text: 'Occupancy by Hour',
                    enabled: true
                },
                categories: this.state.time_array,
                tickmarkPlacement: 'on'
            },
            series: [{
                name: 'History',
                data: this.state.percentage_array
            }]
        });
        
    }


    componentWillUnmount() {
        Actions.hideInfoWindowModal()
        Actions.updateOverlayLoaded()
        clearInterval(this.interval);
        this.unsubscribeStore();
    }
    onStoreChange() {

        this.setState(Store.getState());
    }

    onChangeHybrid (checked) {
        
        let data = {
                'name' : this.state.lot_name,
                'client_name' : this.state.client_name,
                'hybrid_flag' : checked ? 1 : 0
            };

        Actions.saveStatusHybrid(data, this.props.history, this.updateOccupancy, false);
    }
    
    onChangeUnavailable (checked) {
        
        let data = {
                'name' : this.state.lot_name,
                'client_name' : this.state.client_name,
                'status' : checked ? 1 : 0
            };
        Actions.saveStatusHybrid(data, this.props.history, this.updateOccupancy, true);
    }
    setTimeLimit (event) {
        Actions.setTimeLimit(event.target.value);
    }
    getHistorical() {
        Actions.loadHistorical({
            key : Config.get('/historicalApiToken'),
            date : moment(this.state.historical_date, 'MM/DD/YYYY').format('DD-MM-YYYY').toString(),//this.state.historical_date,
            is_lot : 1,
            days : 0,
            client_name : Config.get('/client'),
            lot_name : this.props.match.params.lotID,
            zone : '',
        });
    }
    getHistoricalExport(tableID, filename = '') {
        
        // var downloadLink;
        // var dataType = 'application/vnd.ms-excel';
        // var tableSelect = document.getElementById('export_data');
        // var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
        
        // // Specify file name
        // filename = `${this.state.lot.title} report on ${moment().tz(Config.get('/timeZone')).format('MM/DD/YYYY hh:mm A').toString()} [${moment(this.state.historical_date, 'MM/DD/YYYY').subtract(this.state.historical_day - 1, "days").format('MM/DD/YYYY').toString()} - ${this.state.historical_date}]`
        // filename = filename?filename+'.xls':'excel_data.xls';
        
        // // Create download link element
        // downloadLink = document.createElement("a");
        
        // document.body.appendChild(downloadLink);
        
        // if(navigator.msSaveOrOpenBlob){
        //     var blob = new Blob(['\ufeff', tableHTML], {
        //         type: dataType
        //     });
        //     navigator.msSaveOrOpenBlob( blob, filename);
        // }else{
        //     // Create a link to the file
        //     downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
        
        //     // Setting the file name
        //     downloadLink.download = filename;
            
        //     //triggering the function
        //     downloadLink.click();
        // }

        // var tablesToExcel = (function() {
            
        //     return function(tables, wsnames, wbname, appname) {
        //       var ctx = "";
        //       var workbookXML = "";
        //       var worksheetsXML = "";
        //       var rowsXML = "";
        
        //       for (var i = 0; i < tables.length; i++) {
        //         if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
        //         for (var j = 0; j < tables[i].rows.length; j++) {
        //           rowsXML += '<Row>'
        //           for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
        //             var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
        //             var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
        //             var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
        //             dataValue = (dataValue)?dataValue:tables[i].rows[j].cells[k].innerHTML;
        //             var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
        //             dataFormula = (dataFormula)?dataFormula:(appname=='Calc' && dataType=='DateTime')?dataValue:null;
        //             ctx = {  attributeStyleID: (dataStyle=='Currency' || dataStyle=='Date')?' ss:StyleID="'+dataStyle+'"':''
        //                    , nameType: (dataType=='Number' || dataType=='DateTime' || dataType=='Boolean' || dataType=='Error')?dataType:'String'
        //                    , data: (dataFormula)?'':dataValue
        //                    , attributeFormula: (dataFormula)?' ss:Formula="'+dataFormula+'"':''
        //                   };
        //             rowsXML += format(tmplCellXML, ctx);
        //           }
        //           rowsXML += '</Row>'
        //         }
        //         ctx = {rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i};
        //         worksheetsXML += format(tmplWorksheetXML, ctx);
        //         rowsXML = "";
        //       }
        
        //       ctx = {created: (new Date()).getTime(), worksheets: worksheetsXML};
        //       workbookXML = format(tmplWorkbookXML, ctx);
        
        // console.log(workbookXML);
        
        //       var link = document.createElement("A");
        //       link.href = uri + base64(workbookXML);
        //       link.download = wbname || 'Workbook.xls';
        //       link.target = '_blank';
        //       document.body.appendChild(link);
        //       link.click();
        //       document.body.removeChild(link);
        //     }
        //   })();
        // let tables = ['export_data','export_data']; 
        // let wsnames = ['ProductDay1','ProductDay2']; 
        // let wbname = 'TestBook.xls'; 
        // let appname = 'Excel';
        //         var ctx = "";
        //       var workbookXML = "";
        //       var worksheetsXML = "";
        //       var rowsXML = "";
        
        //       for (var i = 0; i < tables.length; i++) {
        //         if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
        //         for (var j = 0; j < tables[i].rows.length; j++) {
        //           rowsXML += '<Row>'
        //           for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
        //             var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
        //             var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
        //             var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
        //             dataValue = (dataValue)?dataValue:tables[i].rows[j].cells[k].innerHTML;
        //             var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
        //             dataFormula = (dataFormula)?dataFormula:(appname=='Calc' && dataType=='DateTime')?dataValue:null;
        //             ctx = {  attributeStyleID: (dataStyle=='Currency' || dataStyle=='Date')?' ss:StyleID="'+dataStyle+'"':''
        //                    , nameType: (dataType=='Number' || dataType=='DateTime' || dataType=='Boolean' || dataType=='Error')?dataType:'String'
        //                    , data: (dataFormula)?'':dataValue
        //                    , attributeFormula: (dataFormula)?' ss:Formula="'+dataFormula+'"':''
        //                   };
        //             rowsXML += format(tmplCellXML, ctx);
        //           }
        //           rowsXML += '</Row>'
        //         }
        //         ctx = {rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i};
        //         worksheetsXML += format(tmplWorksheetXML, ctx);
        //         rowsXML = "";
        //       }
        
        //       ctx = {created: (new Date()).getTime(), worksheets: worksheetsXML};
        //       workbookXML = format(tmplWorkbookXML, ctx);
        
        // console.log(workbookXML);
        
        //       var link = document.createElement("A");
        //       link.href = uri + base64(workbookXML);
        //       link.download = wbname || 'Workbook.xls';
        //       link.target = '_blank';
        //       document.body.appendChild(link);
        //       link.click();
        //       document.body.removeChild(link);

        ExcelHelper.exportExcel(this.state);

    }
    getHistoricalDownload() {
        Actions.loadHistoricalDownload({
            key : Config.get('/historicalApiToken'),
            date : moment(this.state.historical_date, 'MM/DD/YYYY').format('DD-MM-YYYY').toString(),//this.state.historical_date,
            is_lot : 1,
            days : this.state.historical_day,
            client_name : Config.get('/client'),
            lot_name : this.props.match.params.lotID,
            zone : '',
        }, this.getHistoricalExport);
    }
    render() {
        
        console.log("this.state", this.state);
        const { error, isLoaded, lot, loading, zone_percentage_array} = this.state;
        let zonePercentage  = zone_percentage_array;
        let count = 1;
        /*if(error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if(!isLoaded) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else {*/
            return (
                <div>
                    {loading ? (
                        <div className="loader"></div>
                    ) : ''}
                <div className="content-wrapper lot_detail">
                <div className="" id="lots">
                    
                    <section className="">
                        <Helmet>
                            <title>{this.state.lot.title}</title>
                        </Helmet>
                        <div className="lot lot_history">
                            <h6 className="lowder">
                                {lot.title}
                            </h6>
                            { this.state.avg_duration_count > 0 ? (
                                <p className="parked">Cur. avg time parked : <span>{this.state.avg_duration_count} mins</span></p>
                            ) : null}
                            <ul className="reset">
                                {this.state.available > 0 ? (
                                    <li className="available">
                                      <i></i> 
                                      <span>Available: {this.state.available}</span>
                                      <div className="zone">
                                        {Object.keys(zonePercentage).sort().map((zone) => {
                                            count++;
                                            return (
                                                <p key={count}><span style={{'textTransform' : 'uppercase'}}>{zone === 'undefined' ? 'General' : zone}</span> Zone : {zonePercentage[zone].remaining}</p>
                                            )
                                            
                                        })}
                                      </div>
                                    </li> ) : null }
                                {this.state.occupied > 0 ? (
                                    <li className="occupied">
                                      <i></i> 
                                      <span>Occupied: {this.state.occupied}</span>
                                    </li> ) : null }
                                {this.state.reserved > 0 ? (
                                    <li className="reserved">
                                      <i></i> 
                                      <span>Reserved: {this.state.reserved}</span>
                                    </li> ) : null }
                                {this.state.noData > 0 ? (
                                    <li className="no_data">
                                      <i></i> 
                                      <span>No Data: {this.state.noData}</span>
                                    </li> ) : null }
                                <li><h5>Lot History</h5>
                                <a className="btn blue icon" onClick={ () => {Actions.showLotHistoricalModal(this.getHistorical)}}><i className="fa fa-info"></i></a></li>
                            </ul>
                        </div>
                        {/*<div className="my-3 p-3 bg-white rounded box-shadow" style={{
                            position: 'absolute',
                            top: '220px',
                            right: 0,
                            margin: '1rem 1rem',
                        }}>
                            <label className="switch1 custom">
                              <input type="checkbox" id='unavailable' name="unavailable" type="checkbox" className="hide" defaultChecked={this.state.unavailable} checked={this.state.unavailable} onChange={(event) => {this.onChangeUnavailable(event.target.checked) }} />
                              <span className="slider1 round" htmlFor='unavailable'></span>
                            </label>
                        </div>
                        <div className="my-3 p-3 bg-white rounded box-shadow" style={{
                            position: 'absolute',
                            top: '270px',
                            right: 0,
                            margin: '1rem 1rem',
                        }}>
                            <label className="switch1 custom">
                              <input type="checkbox" id='hybrid' name="hybrid" type="checkbox" className="hide" defaultChecked={this.state.hybrid_flag} checked={this.state.hybrid_flag} onChange={(event) => {this.onChangeHybrid(event.target.checked) }} />
                              <span className="slider1 round" htmlFor='hybrid'></span>
                            </label>
                        </div>*/}
                        <div className="lot lot_time">
                            <div>
                                <h2>Over Stay Violation Alert</h2>
                                <p>Enter time to find spots under violation</p>
                            </div>
                            <div className="form-group">
                                <label>Set time limit:</label>
                                    <input type="number" maxLength="4" className="form-control" onChange={this.setTimeLimit} />
                                <label>mins</label>
                            </div>
                        </div>
                        <div className="lot lot_msg">
                          <h5>Lot Message</h5><a className="btn blue icon" role="button" onClick={Actions.showLotMessageModal}><i className="fa fa-pencil"></i></a>
                        </div>
                        <Map
                            saveStallValue={this.saveStallValue}
                            markers={this.state.markers}
                            center={this.state.center}
                            zoom={this.state.zoom}
                            history={this.props.history}
                            {...this.state}
                        />
                    </section>
                    
                    
                    <span style={{ 'display' : 'none'}}>
                        <ExcelExport 
                            data={this.state.download_array}
                            {...this.state}
                        />
                        {
                            this.state.download_array.length > 0 && this.state.download_array[0].zones.length > 0 ? this.state.download_array[0].zones.map((zone, zoneIndex) => { 
                                return (<ExcelZoneExport 
                                    zone_name={zone}
                                    data={this.state.download_array}
                                    {...this.state}
                                />)
                            }) : null
                        }
                    </span>
                </div>
                </div>
                <LotHistoricalModal 
                    getHistoricalDownload= {this.getHistoricalDownload}
                    {...this.state}
                />
                <LotMessageModal 
                    {...this.state}
                />
                <InfoWindowModal 
                    saveStallValue={this.saveStallValue}
                    {...this.state}
                />
                </div>
            );  
        //}
    }
}


module.exports = LotsPage;
