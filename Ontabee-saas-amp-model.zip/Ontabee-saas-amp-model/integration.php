<?php include ('inc/header.php'); ?> 
 
<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Ontabee Integration</h1>
		<h2 class="head small wow fadeInUp">Integrated third-party service providers in Ontabee</h2>
	</div> <!--container-->
</div> <!--page_banner--> 

<section class="grey portfolio integration text-center">
	<div class="container">
		<ul class="reset">
         <li class="title"><h3>Social media integration</h3></li>
			<li class="wow zoomIn">
				<img src="images/integration/facebook.jpg" alt="facebook">
				<h5>Login with Facebook</h5>
         </li>
            <li class="wow zoomIn">
				<img src="images/integration/twitter.jpg" alt="twitter">
				<h5>Login with Twitter</h5>
         </li>
         <li class="title"><h3>Payment Gateway Integrations</h3></li>
			<li class="wow zoomIn">
				<img src="images/integration/cc-avenue.jpg" alt="cc-avenue">
				<h5>CCAvenue</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/pay-stack.jpg" alt="pay-stack">
				<h5>Pay Stack</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/paytm.jpg" alt="paytm">
				<h5>Paytm</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/stripe.jpg" alt="stripe">
				<h5>Stripe</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/paypal.jpg" alt="paypal">
				<h5>Paypal</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/smoovpay.jpg" alt="smoovpay">
				<h5>SmoovPay</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/axis-bank.jpg" alt="axis-bank">
				<h5>Axis Bank</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/pesapal.jpg" alt="pesapal">
				<h5>Pesapal</h5>
         </li>
         <li class="title"><h3>Marketing & Communication Integrations</h3></li>
			<li class="wow zoomIn">
				<img src="images/integration/live-chat.jpg" alt="live-chat">
				<h5>LiveChat</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/tawk.jpg" alt="tawk">
				<h5>Tawk</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/one-signal.jpg" alt="one-signal">
				<h5>One Signal</h5>
         </li>
            <li class="title"><h3>Productivity Integrations</h3></li>
			<li class="wow zoomIn">
				<img src="images/integration/google-analytics.jpg" alt="google-analytics">
				<h5>Google Analytics</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/facebook-pixel-code.jpg" alt="facebook-pixel-code">
				<h5>Facebook Pixel Code</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/mail-chimp.jpg" alt="mail-chimp">
				<h5>MailChimp</h5>
         </li>
         <li class="title"><h3>SMS settings</h3></li>
			<li class="wow zoomIn">
				<img src="images/integration/twilio.jpg" alt="twilio.">
				<h5>Twilio</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/text-local.jpg" alt="text-local">
				<h5>TextLocal</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/nexmo.jpg" alt="nexmo">
				<h5>Nexmo</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/bytekat.jpg" alt="bytekat">
				<h5>ByteKat</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/hspsms.jpg" alt="hspsms">
				<h5>HSPSMS</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/sms.jpg" alt="sms">
				<h5>Sms</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/sendpk.jpg" alt="sendpk">
				<h5>SendPk</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/smppsmshub.jpg" alt="smppsmshub">
				<h5>SMPPSMShub</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/clickatell.jpg" alt="clickatell">
				<h5>Clickatell</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/sms-hubs.jpg" alt="sms-hubs">
				<h5>SMShubs</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/smsmkt.jpg" alt="smsmkt">
				<h5>SMSMKT</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/crazy-sms.jpg" alt="crazy-sms">
				<h5>CrazySMS</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/bongolive.jpg" alt="bongolive">
				<h5>Bongolive</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/aikon-sms.jpg" alt="aikon-sms">
				<h5>AikonSMS</h5>
            </li>
			<li class="wow zoomIn">
				<img src="images/integration/multitexter.jpg" alt="multitexter">
				<h5>Multitexter</h5>
         </li>
			<li class="wow zoomIn">
				<img src="images/integration/1s2u.jpg" alt="1s2u">
				<h5>1s2u</h5>
         </li>
		</ul>
	</div> <!--container--> 
</section>

<?php include('inc/footer.php');?>