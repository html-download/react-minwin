'use strict';
const Gulp = require('gulp');


Gulp.task('build', ['less', 'webpack', 'media']);
