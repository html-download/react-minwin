<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- acc page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi heart"></i>
            <h2>Favorites</h2>
            <p>View the favorite restaurants</p>
          </div>
          <div class="white-30 fav_list">
            <div class="vendor_list">
              <div class="cs-row">
                <ul class="row-2 ">
                  <li>
                    <div class="list">
                      <div class="info full_row">
                        <span class="fav added" data-toggle="tooltip" title="" data-original-title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                        <a href="restaurant-detail" class="full_row">
                          <div class="img" style="background-image:url(assets/img/shop/2.jpg)">
                            <p><span>Promoted</span></p>
                            <p><span class="red">Will be closed in 30 Min</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            <span class="vendor_logo"><img src="assets/img/logo/2.jpg"></span>
                          </div>
                          <!--img-->
                          <div class="vendor_info full_row">
                            <p class="review grey">120 Reviews <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Zam Zam Mandi &amp; Grill</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                              <span>35-40 min</span>
                              <span>Min QR 30</span>
                              <span>QR 30 FOR 2</span>
                            </p>
                          </div>
                          <!--vendor_info-->
                          <div class="ventor_footer full_row">
                            <div class="float-left icons">
                              <i class="fi scooter1"></i>
                              <i class="fi table"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                          </div>
                          <!--ventor_footer-->
                        </a>
                      </div>
                      <!--info-->
                    </div>
                  </li>
                  <li>
                    <div class="list">
                      <div class="info full_row">
                        <span class="fav added" data-toggle="tooltip" title="" data-original-title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                        <a href="restaurant-detail" class="full_row">
                          <div class="img" style="background-image:url(assets/img/shop/3.jpg)">
                            <p><span>Promoted</span></p>
                            <p><span class="green">Open</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            <span class="vendor_logo"><img src="assets/img/logo/3.jpg"></span>
                          </div>
                          <!--img-->
                          <div class="vendor_info full_row">
                            <p class="review grey">120 Reviews <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Zam Zam Mandi &amp; Grill</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                              <span>35-40 min</span>
                              <span>Min QR 30</span>
                              <span>QR 30 FOR 2</span>
                            </p>
                          </div>
                          <!--vendor_info-->
                          <div class="ventor_footer full_row">
                            <div class="float-left icons">
                              <i class="fi scooter1"></i>
                              <i class="fi table"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                          </div>
                          <!--ventor_footer-->
                        </a>
                      </div>
                      <!--info-->
                    </div>
                  </li>
                  <li>
                    <div class="list">
                      <div class="info full_row">
                        <span class="fav added" data-toggle="tooltip" title="" data-original-title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                        <a href="restaurant-detail" class="full_row">
                          <div class="img" style="background-image:url(assets/img/shop/4.jpg)">
                            <p><span>Promoted</span></p>
                            <p><span class="green">Open</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            <span class="vendor_logo"><img src="assets/img/logo/4.jpg"></span>
                          </div>
                          <!--img-->
                          <div class="vendor_info full_row">
                            <p class="review grey">120 Reviews <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Zam Zam Mandi &amp; Grill</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                              <span>35-40 min</span>
                              <span>Min QR 30</span>
                              <span>QR 30 FOR 2</span>
                            </p>
                          </div>
                          <!--vendor_info-->
                          <div class="ventor_footer full_row">
                            <div class="float-left icons">
                              <i class="fi scooter1"></i>
                              <i class="fi table"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                          </div>
                          <!--ventor_footer-->
                        </a>
                      </div>
                      <!--info-->
                    </div>
                  </li>
                  <li>
                    <div class="list">
                      <div class="info full_row">
                        <span class="fav added" data-toggle="tooltip" title="" data-original-title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                        <a href="restaurant-detail" class="full_row">
                          <div class="img" style="background-image:url(assets/img/shop/5.jpg)">
                            <p><span>Promoted</span></p>
                            <p><span class="green">Open</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                            <span class="vendor_logo"><img src="assets/img/logo/5.jpg"></span>
                          </div>
                          <!--img-->
                          <div class="vendor_info full_row">
                            <p class="review grey">120 Reviews <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Zam Zam Mandi &amp; Grill</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                              <span>35-40 min</span>
                              <span>Min QR 30</span>
                              <span>QR 30 FOR 2</span>
                            </p>
                          </div>
                          <!--vendor_info-->
                          <div class="ventor_footer full_row">
                            <div class="float-left icons">
                              <i class="fi scooter1"></i>
                              <i class="fi table"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                          </div>
                          <!--ventor_footer-->
                        </a>
                      </div>
                      <!--info-->
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>