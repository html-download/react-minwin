'use strict';
const About = require('./about/index.jsx');
const Contact = require('./contact/index.jsx');
const ChoosePolicy = require('./choose-policy/index.jsx');
const Footer = require('./footer.jsx');
const Home = require('./home/index.jsx');
const Login = require('./login/home/index.jsx');
const LoginForgot = require('./login/forgot/index.jsx');
const LoginLogout = require('./login/logout/index.jsx');
const LoginReset = require('./login/reset/index.jsx');
const Navbar = require('./navbar.jsx');
const NotFound = require('./not-found.jsx');
const OrderSummary =  require('./order-summary/index.jsx');
const PrivacyPolicy = require('./privacy-policy/index.jsx');
const PolicyCompare = require('./policy-compare/index.jsx');
const React = require('react');
const ReactRouter = require('react-router-dom');
const ToasterContainer = require('../../components/toaster.jsx');
const RouteRedirect = require('../../components/route-redirect.jsx');
const TermsANDCondtions = require('./terms-and-conditions/index.jsx');
const UploadDocuments = require('./upload-documents/index.jsx')
const Route = ReactRouter.Route;
const Switch = ReactRouter.Switch;


const AppUniversal = function () {

    return (
        <div className="route">
            <Route component={Navbar} />
            <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/about" exact component={About} />
                <Route path="/contact" exact component={Contact} />
                <Route path="/privacy-policy" exact component={PrivacyPolicy} />
                <Route path="/terms-and-conditions" exact component={TermsANDCondtions} />
                 <Route path="/choose-policy" exact component={ChoosePolicy} />
                 <Route path="/policy-compare" exact component={PolicyCompare} />
                 <Route path="/order-summary" exact component={OrderSummary} />
                 <Route path="/upload-documents" exact component={UploadDocuments} />
                {/*<Route path="(/|/login)" exact component={Login} />
                <Route path="/login/forgot" exact component={LoginForgot} />
                <Route path="/login/reset/:email/:key" component={LoginReset} />
                <Route path="/login/logout" exact component={LoginLogout} />*/}
                <RouteRedirect from="/moved" to="/" code={301} />

                <Route component={NotFound} />

            </Switch>
            <ToasterContainer/>
            <Footer />
        </div>
    );
};


module.exports = AppUniversal;
