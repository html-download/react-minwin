/* global window, document */
'use strict';
const Cookie = require('cookie');
const Config = require('../../config.js');
const Qs = require('qs');
const Xhr = require('xhr');


const jsonFetch = function (options, callback) {

    const cookies = Cookie.parse(document.cookie);
    
    let nodeApiDirection = [
        '/api/login',
        '/api/logout'
    ];

    let url = nodeApiDirection.includes(options.url) ? options.url : `${Config.get('/apiUrl')}${options.url}`;
    let checkApiDirection = nodeApiDirection.includes(options.url);
    const config = {
        url: url,
        method: options.method,
        headers: {
            //'Cache-Control': 'no-cache',
            //'Accept': 'application/json',
            //'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            //"Access-Control-Allow-Origin": "*",
            //"Access-Control-Allow-Headers": "Origin, X-Requested-With, Content-Type, Accept, Authorization"
        }
    };

    if (cookies.crumb) {
        if (checkApiDirection) {
            config.headers['X-CSRF-Token'] = cookies.crumb;
        } else if (cookies.token) {
            config.headers['Authorization'] = `Bearer ${cookies.token}`;
        }
        config.headers['Accept-Language'] = 'en';
    }

    if (options.query) {
        config.url += '?' + Qs.stringify(options.query);
    }

    if (options.data && options.method === 'POST' && !checkApiDirection) {
        //config.headers['content-type'] = 'multipart/form-data';
        //config.headers['Content-type'] = 'application/x-www-form-urlencoded';
        //config.headers['Content-type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        //config.headers['Cache-Control'] = 'no-cache';
        config.headers['Accept'] = 'application/json';
        config.body = JSON.stringify(options.data);
        /*var form_data = new FormData();
        
        let obj = options.data;
        Object.keys(obj).map(key => {
          form_data.append(key, obj[key]);
        });
        
        config.body = form_data*/
    } else {
        config.body = JSON.stringify(options.data);
    }

    Xhr(config, (err, response, body) => {

        if (err) {
            return callback(err);
        }

        if (response.statusCode >= 200 && response.statusCode < 300) {
            
            if (response.headers.hasOwnProperty('x-auth-required')) {
                if (window.location.pathname === '/login') {
                    return callback(Error('Auth required.'));
                }

                let returnUrl = window.location.pathname;

                if (window.location.search.length > 0) {
                    returnUrl += window.location.search;
                }

                returnUrl = encodeURIComponent(returnUrl);

                window.location.href = `/login?returnUrl=${returnUrl}`;
            }
            else {
                body = JSON.parse(body);
                body.headers = response.headers;
                callback(null, body);

                //callback(null, JSON.parse(body));
            }
        }
        else {
            const httpErr = new Error(response.rawRequest.statusText);

            callback(httpErr, JSON.parse(body));
        }
    });
};


if (global.window) {
    window.jsonFetch = jsonFetch;
}


module.exports = jsonFetch;
