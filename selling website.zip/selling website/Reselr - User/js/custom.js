
$(document).ready(function() {

  
  new WOW().init();

   // loader
   $('.loader').on('click', function() {
      var $this = $(this);
      var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
      if ($(this).html() !== loadingText) {
         $this.data('original-text', $(this).html());
         $this.html(loadingText);
      }
      setTimeout(function() {
         $this.html($this.data('original-text'));
      }, 2000);
   });

// selectpicker
   $('.selectpicker').selectpicker();

   // categories slide
   $('.categories-slide').owlCarousel({
    center: false,
    nav:true,
    dots:false,  
    items: 4,  
    autoplay:true,
    loop: true,
     navText: ["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
    autoplay:true,
    margin: 25,
    responsive: {
      320: {
      items: 2,
      margin: 10,
      },
      600: {
      items: 2
      },
      768: {
      items: 3
      },
      1000: {
        items: 4
      }
    }
    });


  //Fixed Header  
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".main-header").addClass("fixed");
    } else {
        $(".main-header").removeClass("fixed");
    }   
});
  

// equal height
/*Equal Height*/
$('.products-list, .ch_address_list').each(function(){  
        var highestBox = 0;

        $(this).find('.product-content, .boxo').each(function(){
            if($(this).height() > highestBox){  
                highestBox = $(this).height();  
            }
        })

        $(this).find('.product-content, .boxo').height(highestBox);
    });    


// modal shown
$('.modal').on('shown.bs.modal', function (e) {
  $('body').addClass('modal-open');
})

$('.modal').on('hidden.bs.modal', function (e) {
   $('body').removeClass('modal-open');
})

// rating

$(".rating").starRating({
  //initialRating: 4,
   emptyColor: '#CDCDCD',
  hoverColor: '#333333',
  activeColor: '#FC8B1E',
   ratedColor: '#FC8B1E',
   useGradient: false,
  disableAfterRate: false,
  strokeWidth: 0,
  starSize: 22,
  callback: function(currentRating){

        $('.rating-count').html(currentRating);
    }
});


   
});



// image gallery carosel

$(document).ready(function() {
  var bigimage = $(".large-image");
  var thumbs = $(".thumbs-slide-carosel");
  //var totalslides = 10;
  var syncedSecondary = true;

  bigimage
    .owlCarousel({
    items: 1,
    slideSpeed: 2000,
    nav: false,
    autoplay: true,
    dots: false,
    loop: true,
    responsiveRefreshRate: 200,
    navText: [
      '<i class="fa fa-arrow-left" aria-hidden="true"></i>',
      '<i class="fa fa-arrow-right" aria-hidden="true"></i>'
    ]
  })
    .on("changed.owl.carousel", syncPosition);

  thumbs
    .on("initialized.owl.carousel", function() {
    thumbs
      .find(".owl-item")
      .eq(0)
      .addClass("current");
  })
    .owlCarousel({
    items: 5,
    dots: false,
    nav: true,
    navText: [
      '<i class="fa fa-angle-left" aria-hidden="true"></i>',
      '<i class="fa fa-angle-right" aria-hidden="true"></i>'
    ],
    smartSpeed: 200,
    slideSpeed: 500,
    slideBy: 1,
    responsiveRefreshRate: 100,
    responsive : {
      320: {
        items: 2
      },
      768: {
        items: 5
      },
      1024: {
        items: 5
      }

    }
  })
    .on("changed.owl.carousel", syncPosition2);

  function syncPosition(el) {
    //if loop is set to false, then you have to uncomment the next line
    //var current = el.item.index;

    //to disable loop, comment this block
    var count = el.item.count - 1;
    var current = Math.round(el.item.index - el.item.count / 2 - 0.5);

    if (current < 0) {
      current = count;
    }
    if (current > count) {
      current = 0;
    }
    //to this
    thumbs
      .find(".owl-item")
      .removeClass("current")
      .eq(current)
      .addClass("current");
    var onscreen = thumbs.find(".owl-item.active").length - 1;
    var start = thumbs
    .find(".owl-item.active")
    .first()
    .index();
    var end = thumbs
    .find(".owl-item.active")
    .last()
    .index();

    if (current > end) {
      thumbs.data("owl.carousel").to(current, 100, true);
    }
    if (current < start) {
      thumbs.data("owl.carousel").to(current - onscreen, 100, true);
    }
  }

  function syncPosition2(el) {
    if (syncedSecondary) {
      var number = el.item.index;
      bigimage.data("owl.carousel").to(number, 100, true);
    }
  }

  thumbs.on("click", ".owl-item", function(e) {
    e.preventDefault();
    var number = $(this).index();
    bigimage.data("owl.carousel").to(number, 300, true);
  });
});



// gallery popup

$(document).ready(function() {
  $('.large-image').magnificPopup({
    delegate: '.owl-item:not(.cloned) a',
    type: 'image',
    tLoading: 'Loading image #%curr%...',
    mainClass: 'mfp-img-mobile',
    gallery: {
      enabled: true,
      navigateByImgClick: true,
      preload: [0,1] // Will preload 0 - before current, and 1 after the current image
    }

  });
});


// change password


$("#changepassword").change(function() {
    if($(this).prop('checked')) {
        $(".show-hide").addClass("open");
    } else {
        $(".show-hide").removeClass("open");
    }
});


// mobile toggle

$(".responsive-menu").click(function() {
  $(".header_right_side").addClass('open');
    $("body").addClass('overflow');    
    $(".menu-toggle").addClass('open');
});

$(".menu-toggle, .header_right_side a").click(function() {
  $(".header_right_side").removeClass('open');
    $("body").removeClass('overflow');    
    $(".menu-toggle").removeClass('open');
});

