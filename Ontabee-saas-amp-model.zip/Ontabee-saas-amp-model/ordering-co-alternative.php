<?php include ('inc/header.php'); ?>  

<div class="page_banner style4 bg1">
	<div class="container floating_label pad0">
		<div class="col-sm-8">
			<h1 class="head wow fadeInDown">Ordering.Co Alternative</h1>
			<h2 class="head wow fadeInUp">Paying More for Ordering.Co? <br>Need Another Alternative Solution?</h2>
			<p class="wow fadeInUp">Ontabee a Perfect Cost Effective Software</p>
		</div>
		
		<div class="col-sm-4 text-center">
			<form id="alternative" method="post" name="alternative" action="<?php echo $baseurl;?>signup" class="wow fadeInUp">
				<h4>Start your <span>Free Trial</span></h4>			
				<label class="icon">Your name
					<input type="text" name="try_name" class="form-control" required="required">
					<i class="fa fa-user-o"></i>
				</label>
				<label class="icon">Email Id
					<input type="email" name="try_email" class="form-control" required="required">
					<i class="fa fa-envelope-o"></i>
				</label>
				<input type="hidden" value="" name="try_url">
				<input type="submit" class="btn" value="Try Ontabee for Free">
			</form>
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Looking For Ordering.Co Alternative?</h2>		
		<p class="mb0 wow fadeInUp">The main difference between Ontabee and Ordering.co is cost and features. Ontabee provides you everything just $<?php echo $price;?>, but Ordering.co cost is 149$. Ontabee provides the website ordering is completely free. They provide web app is 29$, mobile apps 99$ with one location. They charge separately for some features like drivers tracking, payment gateway, Coupons but ontabee provides with just $<?php echo $price;?> only.</p>
	</div>
	
	<div class="container">
		<div class="compare">
			<div class="col-sm-6 wow fadeInUp first">
				<h2>Ontabee $<?php echo $price;?> <span>/ Month (Per Outlet)</span></h2>
				<ul class="reset">
					<li><i class="fi tick"></i>Sales Optimized Website</li>
					<li><i class="fi tick"></i>Branded Mobile Apps</li>
					<li><i class="fi tick"></i>Get all Features for just $<?php echo $price;?>/month only</li>
				</ul>
			</div>			
			<span class="vs"><b>VS</b></span>
			<div class="col-sm-6 wow fadeInUp last">
				<h2>Ordering.Co <span>(Per Location)</span></h2>
				<ul class="reset">
					<li><i class="fi tick"></i><b>$29 Per Month</b> - Sales Optimized Website</li>
					<li><i class="fi tick"></i><b>$99 Per Month</b> - Branded Mobile Apps</li>
					<li><i class="fi tick"></i>Every feature you choose to pay extra (Check in Available on marketplace).</li>
				</ul>
			</div>
			
			<p class="mb0 text-center">* Pricing data from Ordering.co pricing page as of June 2018</p>
		</div>
	</div> <!--container-->
</section>

<section class="text-center">
	<div class="container">
		<h2 class="head wow fadeInUp">What do you get for $0 from Ontabee?</h2>
		<p class="mb30 wow fadeInUp">Our perfect online ordering system provides these for free with zero setup cost</p>
		
		<div class="row">
			<div class="col-md-6 text-center">
				<img src="images/dashboard.png" class="wow zoomIn mb30" alt="Online Ordering">
			</div>
			
			<div class="col-md-6 text-left wow fadeInUp">
				<ul class="reset list1 style1">
					<li>Single Outlet </li>
					<li>Unlimited Orders</li>
					<li>Integrate Live Chat</li>
					<li>Basic Reports</li>
					<li>Pictures in Menu</li>
					<li>Order for Later</li>
					<li>Website Ordering</li>
					<li>Mobile Responsive</li>
				</ul>
				<p class="mb0 wow fadeInUp">Our Ontabee free trial offers full access to all the above features, allowing you to run and monitor your business in real-time. We aim at providing competitive solutions for your business. Also, we make sure you get maximum ROI with our enterprise online restaurant ordering system.</p>
			</div>
		</div>
	</div>
</section>

<section class="text-center grey">
	<div class="container">
		<h2 class="head wow fadeInUp">You get complete sales optimized website with Ontabee</h2>
		<p class="mb30 wow fadeInUp">Interested in Ontabee? Here is our <a href="<?php echo $baseurl;?>pricing">Pricing Plan</a></p>
		
		<div class="row">
			<div class="col-sm-6 text-center pull-right">
				<img src="images/graph.png" class="wow zoomIn mb30" alt="graph">
			</div>
				
			<div class="col-sm-6">
				<ul class="reset list1 text-left">
					<li>No Hidden Cost</li>
					<li>Get custom plan for multiple outlets </li>
					<li>Order receiving app provided (Android) </li>
					<li>You get a delivery app (Android).</li>
				</ul>
			</div>
		</div>
	</div>
</section>

<?php include('inc/footer.php');?>