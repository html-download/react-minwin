/* eslint-disable no-undef */

import React, {Component} from 'react';
import { withScriptjs, withGoogleMap, GoogleMap, Marker, GroundOverlay, InfoWindow } from "react-google-maps";
import { compose, withStateHandlers } from "recompose";
import GeoLocation from 'react-geolocation';
import {ToastContainer, ToastStore} from 'react-toasts';

//const MapComponent = withScriptjs(withGoogleMap( props => (
const MapComponent = compose(
  withStateHandlers((index) => ({
    isOpen: false,
    showInfo: '0'
  }), {
    onToggleOpen: ({ isOpen }) => (index) => ({
      isOpen: !isOpen,
      index: 2
    }),
    showInfo: ({ showInfo, isOpen }) => (a, lat, lng) => ({
      isOpen: true,
      showInfoIndex: a,
      showInfoLat: lat,
      showInfoLng: lng
    })
  }),
  withScriptjs,
  withGoogleMap
)(props =>
        <GoogleMap
            ref={props.onMapMounted}
            defaultCenter={props.defaultCenter}
            defaultZoom={props.defaultZoom}
            defaultMapTypeId={ google.maps.MapTypeId.SATELLITE }
            defaultTilt={0}
            center={props.center}
            zoom={props.zoom}
            options={{draggable:true}}
            onBoundsChanged={props.onBoundsChanged}
            defaultOptions={{
                scrollwheel: false,
                disableDefaultUI: false,
                zoomControl: true,
                draggable: false
            }}
        >
            <GroundOverlay
                defaultUrl="/images/lots/au-village.png"
                defaultBounds={new google.maps.LatLngBounds(
                    new google.maps.LatLng( 32.604884, -85.495396), //SW
                    new google.maps.LatLng( 32.606324, -85.490551) //NE
                )}
                defaultOpacity={1}
            />
            <GroundOverlay
                defaultUrl="/images/lots/au-mcwhorter.png"
                defaultBounds={new google.maps.LatLngBounds(
                    new google.maps.LatLng(32.5970724772583,-85.4961054392877),
                    new google.maps.LatLng(32.5979779904473,-85.4949013133689)
                )}
                defaultOpacity={1}
            />
            <GroundOverlay
                defaultUrl="/images/lots/au-lowder.png"
                defaultBounds={new google.maps.LatLngBounds(
                    new google.maps.LatLng(32.6048994061637,-85.4899258888674),
                    new google.maps.LatLng(32.6059788982184,-85.4884638424902)
                )}
                defaultOpacity={1}
            />
            <GroundOverlay
                defaultUrl="/images/lots/au-coliseum.png"
                defaultBounds={new google.maps.LatLngBounds(
                    new google.maps.LatLng(32.5990945277293,-85.4919890214792),
                    new google.maps.LatLng(32.6009730896994,-85.4905220454364)
                )}
                defaultOpacity={1}
            />
            <GroundOverlay
                defaultUrl="/images/lots/poultry-front.png"
                defaultBounds={new google.maps.LatLngBounds(
                    new google.maps.LatLng(32.5944359179616,-85.4864150228335),
                    new google.maps.LatLng(32.5957090128053,-85.4842924920977)
                )}
                defaultOpacity={1}
                draggable={true}
                onClick={(event) => { console.log(event)}}
                onDragEnd={(event) => { console.log(event)}}
            >
            </GroundOverlay>
            <Marker
                key={'1111'}
                position={{'lat': 32.5944359179616, 'lng': -85.4842924920977}}
                icon={`/images/icons/green-blue.png`}
                draggable={true}
                onClick={() => { props.showInfo('1111', 32.5944359179616, -85.4842924920977) }}
                onDragEnd={(event) => { props.showInfo('1111', event.latLng.lat(), event.latLng.lng());}} 
            >
                { props.isOpen && props.showInfoIndex === '1111' && 
                <InfoWindow>
                    <div style={{width: '100%', 'float' : "left", 'margin' : '0px', 'backgroundColor' : '#f5f5dc', height: '100%' }}>
                        <h4 style={{padding: '1px', 'color' : "white", 'margin' : '0px', 'backgroundColor' : '#0c254d', 'textAlign' : 'center' }}>SW</h4>
                        <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Latitude : {props.showInfoLat}</p>
                        <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Longitude : {props.showInfoLng}</p> 
                    </div>
                </InfoWindow>
                }
            </Marker>
            <Marker
                key={'2222'}
                position={{'lat': 32.5957090128053, 'lng': -85.4864150228335}}
                icon={`/images/icons/green-blue.png`}
                draggable={true} 
                onClick={() => { props.showInfo('2222', 32.5957090128053, -85.4864150228335) }}
                onDragEnd={(event) => { props.showInfo('2222', event.latLng.lat(), event.latLng.lng());}}
            >
                { props.isOpen && props.showInfoIndex === '2222' && 
                    <InfoWindow>
                        <div style={{width: '100%', 'float' : "left", 'margin' : '0px', 'backgroundColor' : '#f5f5dc', height: '100%' }}>
                            <h4 style={{padding: '1px', 'color' : "white", 'margin' : '0px', 'backgroundColor' : '#0c254d', 'textAlign' : 'center' }}>NE</h4>
                            <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Latitude : {props.showInfoLat}</p>
                                    <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Longitude : {props.showInfoLng}</p> 
                        </div>
                    </InfoWindow>
                }
            </Marker>
            {props.markers.map( marker => {
                let lat = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.stallNumber &&  props.showInfoLat !== undefined) ? props.showInfoLat : marker.lat;
                let lng = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.stallNumber &&  props.showInfoLng !== undefined) ? props.showInfoLng : marker.lng;
                return (
                    /*<Marker
                        key={marker.stallNumber}
                        position={{'lat': marker.lat, 'lng': marker.lng}}
                        icon={`/images/icons/${marker.icon}`}
                    />*/
                    <Marker
                        key={marker.stallNumber}
                        position={{'lat': lat, 'lng': lng}}
                        icon={`/images/icons/${marker.icon}`}
                        draggable={true} 
                        onClick={() => { props.showInfo(marker.stallNumber, marker.lat, marker.lng) }}
                        onDragEnd={(event) => { props.showInfo(marker.stallNumber, event.latLng.lat(), event.latLng.lng());}}
                    >
                        { props.isOpen && props.showInfoIndex === marker.stallNumber && 
                            <InfoWindow id="info{props.showInfoIndex}">
                                <div style={{width: '100%', 'float' : "left", 'margin' : '0px', 'backgroundColor' : '#f5f5dc', height: '100%' }}>
                                    <h4 style={{padding: '1px', 'color' : "white", 'margin' : '0px', 'backgroundColor' : '#0c254d', 'textAlign' : 'center' }}>Lot</h4>
                                    <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>No : {marker.stallNumber}</p>
                                    <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Latitude : {props.showInfoLat}</p>
                                    <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Longitude : {props.showInfoLng}</p> 
                                    <p style={{padding: '1px', 'color' : "black", 'fontSize' : '12px', 'fontWeight' : '500' }}>Status : <img src={`/images/icons/${marker.icon}`} alt="test"/></p> 
                                    <button className="btn btn-success" type="button" style={{marginLeft: '35%', 'display' : 'none' }} data-key={marker.stallNumber}  onClick={new Map().saveStallValue(marker.stallNumber, props.showInfoLat, props.showInfoLng, marker.lot_name)}>Save</button>
                                </div>
                            </InfoWindow>
                        }
                    </Marker>
                )
            })}
            <GeoLocation />
        </GoogleMap>
);

class Map extends Component {
    constructor(props) {
        super(props);
        this.params = {
            //fopark_url: 'http://localhost:5001',
            fopark_url: 'https://api6.fopark-api.com',
            fopark_key: 'd5a3c692930824c95141fb18c07fe2102b3a0c96af4227f5'
        };
        this.saveStallValue = this.saveStallValue.bind(this);
    }
    componentDidMount(){
        //console.log('test')
    }
    saveStallValue(stallNumber, latitude, longitude, lotName) {
        let data = {
                'stall_num' : stallNumber,
                'lot_name' : lotName,
                'coords' : latitude+','+longitude
            };

        fetch(`${this.params.fopark_url}/stall`, {
            method: "put",
            'headers': new Headers({
                'X-api-key': this.params.fopark_key,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(data)

        })
            .then(response => response.json())
            .then(
                (result) => {
                    ToastStore.success("Data saved!")
                    console.log("Data saved!");
                    //console.log("result", result);
                },
                (error) => {
                    
                    console.log("error", error);
                }
            );
    }
    render(){
        return (
            <div>
            <MapComponent
                googleMapURL='https://maps.googleapis.com/maps/api/js?key=AIzaSyDNlIS2XVNFDl-FS3HfSaEWAIzm4-t66Lw'
                loadingElement={<div style={{ height: `100%` }} />}
                containerElement={<div style={{ position: 'fixed', zIndex: -1, left: 0, top: 0, right: 0, bottom: 0 }} />}
                mapElement={<div style={{ height: `100%` }} />}
                defaultCenter={{
                    'lat': 32.6063355,
                    'lng': -85.4905577
                }}
                defaultZoom={17}
                center={this.props.center}
                zoom={this.props.zoom}
                markers={this.props.markers}
                draggable={false} 
            >
            </MapComponent>
            <ToastContainer store={ToastStore}/>
            </div>
        )
    }
}

export default Map;