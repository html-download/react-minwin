const React = require('react');
const ReactHelmet = require('react-helmet');
const UserIdentity = require('../../../helpers/user-identity');

import LotList from './LotList.js';
import Map from './Map';

const Helmet = ReactHelmet.Helmet;

class LotsPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            'showSideNav': false,
            'apiKey': {'key': UserIdentity.googleApiKey},
            'center': {
                'lat': 32.593357,
                'lng': -85.495163
            },
            'zoom': 17,
            'mapHeight': 0,
            'mapWidth': 0,
            'markers': [],
            'isOpen' : false,
            overlay_coords_ne : "",
            isOverlayLoaded : true
        };
        this.toggleNav = this.toggleNav.bind(this);
        this.updateMapBounds = this.updateMapBounds.bind(this);
        this.editMapBounds = this.editMapBounds.bind(this);
        this.updateMapCenter = this.updateMapCenter.bind(this);
        this.setMarkers = this.setMarkers.bind(this);
    }
    toggleNav() {
        this.setState({'showSideNav': !this.state.showSideNav})
    }

    updateMapCenter(center, zoom) {
        this.setState({center: null, zoom: null});
        this.setState({center: center, zoom: zoom});

    }

    updateMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    editMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    setMarkers(markers) {
        this.setState({'markers': markers});
    }

    componentDidMount() {
        window.scrollTo(0, 0);
        this.setState({'mapHeight': window.innerHeight, 'mapWidth': window.innerWidth});
        if (this.state.center && this.state.zoom) {
            this.updateMapCenter(this.state.center, this.state.zoom);
        }
    }
    render() {

        return (
            <div className="content-wrapper" id="lots">
                <section className="content">
                <Helmet>
                    <title>Welcome to Dashboard</title>
                </Helmet>
                <LotList />
                <Map
                    markers={this.state.markers}
                    center={this.state.center}
                    zoom={this.state.zoom}
                    {...this.state}
                />
                </section>
            </div>
        );
    }
}


module.exports = LotsPage;
