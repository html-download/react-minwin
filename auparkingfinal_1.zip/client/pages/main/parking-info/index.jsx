const React = require('react');
const ReactHelmet = require('react-helmet');
const LocationSearchInput = require('../lots/auto-complete-form.jsx');

const Helmet = ReactHelmet.Helmet;


class ParkingInfoPage extends React.Component {
    render() {

        return (
            <div className="content-wrapper error_page cms">
                <Helmet>
                    <title>Parking Info</title>
                </Helmet>
                <section className="content">
                    <h3>Parking Info</h3>
                    <ul className="reset pinfo">
                        <li>1. Monday – Friday all zones excluding R* are enforced 7am – 5pm</li>
                        <li>2. RW, RX, RH, RD, RT are enforced 24/7</li>
                        <li>3. Fall/ Spring – PC1, PC2 , PC3, PC4 enforced from  7am – 2:30pm</li>
                        <li>4. Fall/ Spring – All PC Zones after 2.30pm – Open for all AU registered vehicles except RW, RX, RH, RO, RD, RT</li>
                        <li>5. “B” and “C” Zones open for A zone permits</li>
                        <li>6. C Zone open for B zone permits</li>
                        <li>7. “Graduate Zone” is open for “B” and “C” Zone permits</li>
                        <li>8. Summer – PC1 , PC2, PC3, PC4 : 7am – 5pm – Open for all AU registered vehicles</li>
                        <li>9. Summer ONLY: RH, RW, RX, RT, RD Zones open to all registered vehicles during the summer</li>
                        <li>10. Unless noted with in a lot, all zones other than accessible are open to the public after 5pm.</li>
                        <li>Check back soon for more information!</li>
                    </ul>   
                </section>

            </div>
        );
    }
}


module.exports = ParkingInfoPage;