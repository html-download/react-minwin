/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Distance', {
    distanceId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'distance_id'
    },
    vendorLatitude: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'vendor_latitude'
    },
    vendorLongitude: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'vendor_longitude'
    },
    latitude: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'latitude'
    },
    longitude: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'longitude'
    },
    distanceInKm: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'distance_in_km'
    },
    createdTime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      field: 'created_time'
    }
  }, {
    tableName: 'ss16_distance'
  });
};
