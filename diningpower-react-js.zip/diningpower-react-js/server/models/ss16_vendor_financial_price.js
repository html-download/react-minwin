/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorFinancialPrice', {
    financialPriceId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'financial_price_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    price1: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_1'
    },
    price2: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_2'
    },
    price3: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_3'
    },
    price4: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_4'
    },
    price5: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_5'
    },
    price6: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_6'
    },
    price7: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_7'
    },
    price8: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_8'
    },
    price9: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_9'
    },
    price10: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'price_10'
    },
    overallPrice: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'overall_price'
    },
    overallPrice1: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'overall_price_1'
    },
    overallPrice2: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'overall_price_2'
    },
    overallPrice3: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'overall_price_3'
    },
    type: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'type'
    },
    dynamicPricing: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'dynamic_pricing'
    },
    calculate: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'calculate'
    },
    default: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'default'
    },
    modifier: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modifier'
    },
    modifierValue: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'modifier_value'
    },
    roundPrice: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '3',
      field: 'round_price'
    }
  }, {
    tableName: 'ss16_vendor_financial_price'
  });
};
