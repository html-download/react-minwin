const React = require('react');
const ReactHelmet = require('react-helmet');

/*spin weels dist*/

/*css*/
require('../../media/slot-machine/css/lcd17.css');
require('../../media/slot-machine/css/lcd33.css');
require('../../media/slot-machine/css/game.css');
require('../../media/slot-machine/css/21-bell.css');

/*js*/

//import {FlipH, Slide, Obj} from '../../media/slot-machine/js/animation.js';
//import { toggleIcon } from '../../media/slot-machine/js/test.js';
require('../../media/slot-machine/js/all.js');

/*require('../../media/slot-machine/js/animation.js');
require('../../media/slot-machine/js/font.js');
require('../../media/slot-machine/js/hotspot.js');
require('../../media/slot-machine/js/3-reel.js');*/
/*require('../../media/slot-machine/js/game.js');*/

/*images*/
const transImg = require('../../media/slot-machine/images/trans.gif');
/*const lcd17Img = require('../../media/slot-machine/images/lcd17.png');
const lcd33Img = require('../../media/slot-machine/images/lcd33.png');
const buttonImg = require('../../media/slot-machine/images/button.png');
const gameImg = require('../../media/slot-machine/images/game.png');
const paylineImg = require('../../media/slot-machine/images/payline.png');
const reelBordersImg = require('../../media/slot-machine/images/reel-borders.png');
const reelOutlinesImg = require('../../media/slot-machine/images/reel-outlines.png');
const reelShadingImg = require('../../media/slot-machine/images/reel-shading.png');
const reelStripImg = require('../../media/slot-machine/images/reel-strip.png');*/

const Helmet = ReactHelmet.Helmet;

class SlotMachinePage extends React.Component {
    constructor() {
        super()

        /*this.state = {
          conditionSound: true,
        };*/

        this.state = {
          isHidden: true
        }
    }
    
    toggleHidden () {
        console.log("'c'", 'c');
        /*this.setState({
          isHidden: !this.state.isHidden
        })*/
      }
    /*componentDidMount() {
        window.scrollTo(0, 0);
    }*/
    render() {

        return (
            <div className="spin-reel">
                <Helmet>
                    <title>Power Win</title>
                </Helmet>
                <div id="loading" style={{display: 'none'}}>
                    Loading...
                </div>
                <div id="game" className="gameTransform" style={{display: 'block'}}>
                    <div id="reel0"></div>
                    <div id="reel1"></div>
                    <div id="reel2"></div>
                    <div id="reel_shading"></div>
                    <div id="reel_borders"></div>
                    <div id="reel_outlines"></div>
                    <div id="payline"></div>
                    <div id="msg"></div>
                    <div id="credits">
                      <img alt="" className="font_lcd33 font_lcd33_49" src={transImg} alt="font_lcd33_49" />
                      <img alt="" className="font_lcd33 font_lcd33_48" src={transImg} alt="font_lcd33_49" />
                      <img alt="" className="font_lcd33 font_lcd33_48" src={transImg} alt="font_lcd33_49" />
                      <img alt="" className="font_lcd33 font_lcd33_48" src={transImg} alt="font_lcd33_49" />
                    </div>
                    <div id="win"></div>
                    <div id="bet">
                      <img alt="" className="font_lcd33 font_lcd33_51" src={transImg} alt="font_lcd33_49" />
                    </div>
                    <div id="btn_sound_on" onClick={this.toggleHidden.bind(this)} className={this.state.isHidden ? "on" : "off"} style={{display: 'block'}}> </div>
                    <div id="btn_sound_off" style={{display: 'none'}}></div>
                    <div id="btn_betone" style={{display: 'block'}}></div>
                    <div id="btn_betmax" style={{display: 'block'}}></div>
                    <div id="btn_spin" style={{display: 'block'}}></div>

                    <div id="capture"></div>
                </div>

            </div>
            
        );
    }
}


module.exports = SlotMachinePage;
