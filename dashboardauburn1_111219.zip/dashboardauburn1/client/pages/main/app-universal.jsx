const React = require('react');
const ReactRouter = require('react-router-dom');
const RouteRedirect = require('../../components/route-redirect.jsx');
const UserIdentity = require('../../helpers/user-identity');

const Route = ReactRouter.Route;
const Switch = ReactRouter.Switch;
const Redirect = ReactRouter.Redirect;

/*App Management*/
const Navbar = require('./navbar.jsx');
const Sidebar = require('./sidebar.jsx');
const Footer = require('./footer.jsx');
const About = require('./about/index.jsx');
const Contact = require('./contact/index.jsx');
const NotFound = require('./not-found.jsx');

/*Dashboard*/
const Home = require('./home/index.jsx');
const HomePrevV = require('./home-prev-v/index');

/*Login Management*/
const Login = require('./login/home/index.jsx');
const LoginForgot = require('./login/forgot/index.jsx');
const LoginLogout = require('./login/logout/index.jsx');
const LoginReset = require('./login/reset/index.jsx');
const LoginActivation = require('./login/activation/index.jsx');
const Signup = require('./signup/index.jsx');

/*Client Management*/
const ClientsDetails = require('./clients/details/index.jsx');
const ClientSearch = require('./clients/search/index.jsx');

/*Lots Management*/
const Lots = require('./lots/index.jsx');
const Lot = require('./lots/Lot.js');
const LotsDetails = require('./lots/lots-details/details/index.jsx');
const LotSearch = require('./lots/lots-details/search/index.jsx');

//const AppUniversal = function () {
class AppUniversal extends React.Component {
    render() {
        if (UserIdentity._checkUserToken() === null) {
            return (
                
                    <Switch>
                        <Route path="/" exact component={Login} />
                        <Route path="/dashboard" exact component={Home} />
                        <Route path="/dashboard-prev-v" exact component={HomePrevV} />
                        <Route path="/clients" exact component={ClientSearch} />
                        <Route path="/clients/:id" exact component={ClientsDetails} />
                        <Route path="/lots" exact component={Lots} />
                        <Route path="/lots/:lotID" component={Lot}/>
                        <Route path="/lots-details" exact component={LotSearch} />
                        <Route path="/lots-details/:id" exact component={LotSearch} />
                        <Route path="/lots-details/:client_name/:id" exact component={LotsDetails} />
                        <Route path="/about" exact component={About} />
                        <Route path="/contact" exact component={Contact} />
                        <Route path="/login" exact component={Login} />
                        <Route path="/login/forgot" exact component={LoginForgot} />
                        <Route path="/login/reset/:email/:key" component={LoginReset} />
                        <Route path="/login/activation/:email/:key" component={LoginActivation} />
                        <Route path="/login/logout" exact component={LoginLogout} />
                        <Route path="/signup" exact component={Signup} />
                        
                        <RouteRedirect from="/moved" to="/" code={301} />
                        <Redirect to="/" />
                        <Route component={NotFound} />
                    </Switch>
                );
            } else {
                return (
                    <div className="login-outer">
                        <Route component={Navbar} />
                        <Route component={Sidebar} />
                        <Switch>
                            <Route path="/" exact component={Login} />
                            <Route path="/dashboard" exact component={Home} />
                            <Route path="/dashboard-prev-v" exact component={HomePrevV} />
                            <Route path="/clients" exact component={ClientSearch} />
                            <Route path="/clients/:id" exact component={ClientsDetails} />
                            <Route path="/lots" exact component={Lots} />
                            <Route path="/lots/:lotID" exact component={Lot}/>
                            <Route path="/lots-details" exact component={LotSearch} />
                            <Route path="/lots-details/:id" exact component={LotSearch} />
                            <Route path="/lots-details/:client_name/:id" exact component={LotsDetails} />
                            <Route path="/about" exact component={About} />
                            <Route path="/contact" exact component={Contact} />
                            <Route path="/login" exact component={Login} />
                            <Route path="/login/forgot" exact component={LoginForgot} />
                            <Route path="/login/reset/:email/:key" component={LoginReset} />
                            <Route path="/login/activation/:email/:key" component={LoginActivation} />
                            <Route path="/login/logout" exact component={LoginLogout} />
                            <Route path="/signup" exact component={Signup} />
                            
                            <RouteRedirect from="/moved" to="/" code={301} />
                            <Redirect to="/clients" />
                            <Redirect to="/dashboard" />
                            <Route component={NotFound} />
                        </Switch>
                    </div>);
            }
    }
}


module.exports = AppUniversal;
