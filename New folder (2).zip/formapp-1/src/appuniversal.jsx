import React, { Component } from 'react';
import { Route, BrowserRouter as Router, Switch } from 'react-router-dom';
import './assets/css/style.css';

/*dynamic components*/
import App from './components/Formcontainer.jsx';
import details from './pages/details.jsx';
const AppUniversal = (
		<div>
		
				<Router>
						<Switch>
								<Route path="/" exact component={App}/>
								<Route path="/details" exact component={details}/>
						</Switch> 
				</Router> 
			
		</div>
			
	)


export default AppUniversal;