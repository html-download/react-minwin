const Actions = require('../actions');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Store = require('./store');
const ToasterContainer = require('../../../../components/toaster.jsx');
const Toaster = new ToasterContainer();


const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class LogoutPage extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
        Toaster.success('Signed out successfully!');
        localStorage.removeItem("user");
        sessionStorage.removeItem("user");
        this.props.history.goBack();
        /*if (localStorage.getItem('login'))
            this.props.history.goBack();
        }*/
        //Actions.logout();
        this.state.success = true;
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    render() {

        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success" className="alert alert-success">
                Logout successful.
            </div>);
        }
        else if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-warning">
                {this.state.error}
            </div>);
        }

        return (
            <section className="container">
                <Helmet>
                    <title>Sign out</title>
                </Helmet>
                <div className="container">
                    <h1 className="page-header">Signing out</h1>
                    <div key="success" className="alert alert-success">
                        Logout successful.
                    </div>
                </div>
            </section>
        );
    }
}


module.exports = LogoutPage;
