/* global window */
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const ForgotStore = require('./forgot/store');
const SForgotStore = require('./forgot-popup/store');
const SLoginStore = require('./popup/store');
const LoginStore = require('./home/store');
const LogoutStore = require('./logout/store');
const Qs = require('qs');
const ResetStore = require('./reset/store');
const ActivationStore = require('./activation/store');

const React = require('react');
const ReactRouter = require('react-router-dom');
const Redirect = ReactRouter.Redirect;

class Actions {
    static forgot(data) {

        ApiActions.post(
            '/api/login/forgot',
            data,
            ForgotStore,
            Constants.FORGOT,
            Constants.FORGOT_RESPONSE
        );
    }

    static sforgot(data) {

        ApiActions.post(
            '/api/login/forgot',
            data,
            SForgotStore,
            Constants.FORGOT,
            Constants.FORGOT_RESPONSE
        );
    }

    static getUserCreds() {

        if (!global.window) {
            return;
        }

        ApiActions.get(
            '/api/users/my',
            undefined,
            LoginStore,
            Constants.GET_USER_CREDS,
            Constants.GET_USER_CREDS_RESPONSE,
            (err, response) => {

                if (!err) {
                    const query = Qs.parse(window.location.search.substring(1));

                    if (query.returnUrl) {
                        window.location.href = query.returnUrl;
                    }
                    else if (response && response.roles) {
                        if (response.roles.admin) {
                            window.location.href = '/admin';
                        }
                        else {
                            window.location.href = '/account';
                        }
                    }
                }
            }
        );
    }

    static slogin(data) {

        ApiActions.post(
            '/api/login',
            data,
            SLoginStore,
            Constants.LOGIN,
            Constants.LOGIN_RESPONSE,
            (err, response) => {
                if (!err) {
                    if (response && response.user) {
                        localStorage.removeItem("user");
                        sessionStorage.removeItem("user");
                        if (response.rememberMe !== '') {
                            localStorage.setItem('user', JSON.stringify(response.user));
                        } else {
                            sessionStorage.setItem('user', JSON.stringify(response.user));
                        }
                        window.location.reload();
                    }
                }
            }
        );
    }
    static login(data) {

        ApiActions.post(
            '/api/login',
            data,
            LoginStore,
            Constants.LOGIN,
            Constants.LOGIN_RESPONSE,
            (err, response) => {
                if (!err) {
                    if (response && response.user) {
                        localStorage.removeItem("user");
                        sessionStorage.removeItem("user");
                        if (response.rememberMe !== '') {
                            localStorage.setItem('user', JSON.stringify(response.user));
                        } else {
                            sessionStorage.setItem('user', JSON.stringify(response.user));
                        }
                        window.location.reload();
                    }
                }
            }
        );
    }

    static logout() {

        ApiActions.delete(
            '/api/logout',
            undefined,
            LogoutStore,
            Constants.LOGOUT,
            Constants.LOGOUT_RESPONSE
        );
    }

    static reset(data) {

        ApiActions.post(
            '/api/login/reset',
            data,
            ResetStore,
            Constants.RESET,
            Constants.RESET_RESPONSE
        );
    }
    static activation(data) {

        ApiActions.post(
            '/api/login/activation',
            data,
            ActivationStore,
            Constants.ACTIVATION,
            Constants.ACTIVATION_RESPONSE
        );
    }
}


module.exports = Actions;
