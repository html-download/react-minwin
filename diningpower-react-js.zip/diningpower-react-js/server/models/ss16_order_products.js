/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16OrderProducts', {
    orderProductId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'order_product_id'
    },
    orderKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'order_key'
    },
    itemName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'item_name'
    },
    categoryKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'category_key'
    },
    itemKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'item_key'
    },
    itemQuantity: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_quantity'
    },
    itemPerPrice: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'item_per_price'
    },
    itemTotalPrice: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'item_total_price'
    },
    isIngredient: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'is_ingredient'
    }
  }, {
    tableName: 'ss16_order_products'
  });
};
