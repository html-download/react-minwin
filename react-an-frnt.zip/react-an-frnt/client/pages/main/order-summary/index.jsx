"use strict";
const React = require("react");
const ReactHelmet = require("react-helmet");
const ReactRouter = require("react-router-dom");

const Link = ReactRouter.Link;
const Helmet = ReactHelmet.Helmet;

class OrderSummaryPage extends React.Component {
   componentDidMount() {    
    window.scrollTo(0, 0);
  }
  render() {
    return (
      <section>
        <Helmet>
          <title>Order Summary</title>
        </Helmet>
        <section className="empty-banner" />

        <section className="light_bg order_summary">
          <div className="container">
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/choose-policy">Choose Policy</Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Order summary
                </li>
              </ol>
            </nav>
            <h2 className="blue-heading text-center">
              Mohammed, here's your order summary
            </h2>
            <div className="box-container">
              <div className="form-box order-form white-box-shadow">
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Name</label>
                      <input
                        type="text"
                        className="form-control"
                        value="Mohammed"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Email</label>
                      <input
                        type="email"
                        className="form-control"
                        value="ilan@anib.com"
                      />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group mb-number">
                      <label>Mobile Number</label>
                      <label className="mb-fly">+971</label>
                      <input
                        type="tel"
                        className="form-control"
                        value="600 525502"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Age</label>

                      <input type="text" className="form-control" value="20" />
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Nationality</label>
                      <input
                        type="text"
                        className="form-control"
                        value="United Arab Emirates"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Age of UAE license</label>
                      <input
                        type="text"
                        className="form-control"
                        value="United Arab Emirates"
                      />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Vehicle</label>
                      <input
                        type="text"
                        className="form-control"
                        value="United Arab Emirates"
                      />
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>Vehicle insured value</label>
                      <input
                        type="text"
                        className="form-control"
                        value="United Arab Emirates"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="white-box-shadow text-center">
              <h5 className="borderded">Your selected insurance policy:</h5>
              <div className="box-container">
                <div className="form-box order-form">
                  <img src="/public/media/images/c1.png" />
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Quotation reference number</label>
                        <input
                          type="text"
                          className="form-control"
                          value="1550474750"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Insurer</label>
                        <input
                          type="text"
                          className="form-control"
                          value="Union Insurance Silver"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group mb-number">
                        <label>Mobile Number</label>
                        <label className="mb-fly">+971</label>
                        <input
                          type="tel"
                          className="form-control"
                          value="600 525502"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Product selected</label>

                        <input
                          type="text"
                          className="form-control"
                          value="Union-TPL--24-10-18"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Add-ons selected</label>
                        <input
                          type="text"
                          className="form-control"
                          value="pab passenger"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Insurance policy</label>
                        <input
                          type="text"
                          className="form-control"
                          value="United Arab Emirates"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Emirate of registration</label>
                        <input type="text" className="form-control" value="" />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Vehicle insured value</label>
                        <input type="text" className="form-control" value="" />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Policy deductible</label>
                        <input
                          type="text"
                          className="form-control"
                          value="AED 0.00"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Total premium</label>
                        <input
                          type="text"
                          className="form-control"
                          value="AED 1,170 (Include 5% VAT)"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6 info-form">
                      <div className="form-group">
                        <label>Policy start date</label>
                        <label for="toggle-date" className="to-date">
                          <i className="fa fa-calendar" />
                        </label>
                        <input
                          type="text"
                          className="form-control datePicker"
                          data-position="top left"
                          value=""
                          id="toggle-date"
                        />
                      </div>
                      <i
                        className="fa fa-info info"
                        aria-hidden="true"
                        data-toggle="tooltip"
                        title=""
                        data-original-title="info"
                      />
                    </div>
                    <div className="col-md-6 info-form">
                      <div className="form-group">
                        <label>Bank finance</label>
                        <input
                          type="text"
                          className="form-control"
                          value="Enter bank name if applicable"
                        />
                      </div>
                      <i
                        className="fa fa-info info"
                        aria-hidden="true"
                        data-toggle="tooltip"
                        title=""
                        data-original-title="info"
                      />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-12">
                      <div className="form-group">
                        <div className="check-group">
                          <input
                            id="compare_chk"
                            className="hidden"
                            type="checkbox"
                          />
                          <label className="checkbox" for="compare_chk">
                            The above information is accurate and correct
                            <span className="highlight">*</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="compare-btn text-center">
            <Link to="/upload-documents">
              <button
                className="btn btn-primary"
              >
                Place Order
              </button>
              </Link>
            </div>
          </div>
        </section>
      </section>
    );
  }
}

module.exports = OrderSummaryPage;
