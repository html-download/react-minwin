'use strict';

const React = require('react');

class ProductDetails extends React.Component {
    
    constructor(props) {

        super(props);
        
    }     

    render() {

        return (
            <li>
                <div className="box">
                    <div className="img"><img src="/public/media/images/cl1.png" /></div>
                    <h5>Aman Third Party Libaility</h5>
                    <p>Sum Insured: AED 500,00.00</p>
                    <p>Insurer Quote Reference: 12345</p>
                    <p className="tags"> <span>Pab Driver</span> <span>Pab Passenger</span> </p>
                    <div className="right-cd">
                        <p>Deductible AED 0.00</p>
                        <p>Ded.Extra</p>
                        <p>Base Premium</p>
                        <p className="bold">AED 40,000.00</p>
                    </div>
                </div>
                <div className="box-fields">
                    <div className="row">
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Policy Start Date</label>
                                <input type="text" className="form-control datePicker" />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Payment Status</label>
                                <select className="form-control" >
                                    <option>Cash</option>
                                    <option>Check</option>
                                    <option>Online</option>
                                </select>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Mortgage</label>
                                <input type="text" className="form-control" />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-4">
                            <div className="form-group">
                                <label>Discount</label>
                                <input type="text" className="form-control datePicker" />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="form-group"></div>
                        </div>
                        <div className="col-md-4"></div>
                    </div>
                    <div className="text-right mt-3 mb-3">
                        <button className="btn btn-outline-primary loader no-shadow">Cancel</button>
                        <button className="btn btn-outline-primary loader ml-2 no-shadow">Create</button>
                        <button data-toggle="modal" data-target="#send-quote" className="btn btn-primary ml-1 loader no-shadow">Create &amp; Send</button>
                    </div>
                </div>
            </li>
        );
    }
}
module.exports = ProductDetails;