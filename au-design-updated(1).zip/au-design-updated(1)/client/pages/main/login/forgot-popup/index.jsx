const Actions = require('../actions');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');


const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class ForgotPage extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.email) {
            this.input.email.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.sforgot({
            email: this.input.email.value()
        });
    }

    render() {

        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success">
                <div className="alert alert-success">
                    If an account matched that address, an email will be sent with instructions.
                </div>
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.email = c)}
                    name="email"
                    hideLabel={true}
                    placeholder="Email Address"
                    hasError={this.state.hasError.email}
                    help={this.state.help.email}
                    disabled={this.state.loading}
                />
                <ControlGroup hideLabel={true} hideHelp={true}>
                    <Button
                        type="submit"
                        inputClasses={{ 'full' : true, 'mtb16' : true }}
                        disabled={this.state.loading}>
                        Reset Password
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <div className="modal-content reset-part">
                <Helmet>
                    <title>Reset Password</title>
                </Helmet>
                <div className="modal-header">
                    <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                    <h4 className="modal-title">Reset Your Password</h4>
                    <h4 className="sub-title normal">We’ll send you a link to reset your password.</h4>
                </div>
                <div className="modal-body">
                    <form onSubmit={this.handleSubmit.bind(this)} className="w100" autoComplete="off">
                        {alerts}
                        {formElements}
                    </form>
                    <h4 className="sub-title text-center">Have a FOPARK account? <a role="button" id="signin"> Sign In</a></h4>
                </div>
            </div>
        );
    }
}


module.exports = ForgotPage;
