'use strict';
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../helpers/toaster');


class Actions {    

    static getConfig() {

        ApiActions.get(
            '/configuration/smtp',
            undefined,
            Store,
            Constants.GET_CONFIG_RESULT,
            Constants.GET_CONFIG_RESULT_RESPONSE
        );
    }

    static saveSMTP(data) {

        ApiActions.post(
            '/configuration/save',
            data,
            Store,
            Constants.SAVE_CONFIG_RESULT,
            Constants.SAVE_CONFIG_RESULT_RESPONSE,
            (err, response) => {

                if (!err) {
                    
                    if (response.status === 200) {
                        Toaster.success('Config has been updated..');
                        this.getConfig();
                    }
                }
            }
        );
    }

}


module.exports = Actions;
