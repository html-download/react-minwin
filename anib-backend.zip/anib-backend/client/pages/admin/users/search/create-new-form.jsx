'use strict';
const Actions = require('./actions');
const Alert = require('../../../../components/alert.jsx');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const LinkState = require('../../../../helpers/link-state.js');
const Modal = require('../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../components/form/spinner.jsx');
const TextControl = require('../../../../components/form/text-control.jsx');
const ReactSelectControl = require('../../../../components/form/react-select-control.jsx');
const CStore = require('../common/store');
const CommonHelper = require('../../../../helpers/common-functions');
const DateHelper = require('../../../../helpers/date-time');

const propTypes = {
    email: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    password: PropTypes.string,
    show: PropTypes.bool,
    username: PropTypes.string
};


class CreateNewForm extends React.Component {
    constructor(props) {

        super(props);

        this.updateDOB = this.updateDOB.bind(this);

        this.els = {};
        this.state = {
            showing: false,
            roles: []
        };        
        CStore.subscribe(this.onCommonStoreUpdate.bind(this));
        this.checkMobileNumber = this.checkMobileNumber.bind(this);
        this.user_types = CommonHelper.getUserTypes();
    }

    updateDOB(date) {

        this.setState({
            dob: date
        });
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            username: nextProps.username,
            email: nextProps.email,
            password: nextProps.password
        });
    }

    onCommonStoreUpdate() {
        
        this.setState({
            roles: CStore.getState().roles
        });
    }

    componentDidUpdate() {

        if (this.props.show && this.state.username.length === 0) {
            this.els.username.focus();
        }
    }

    onSubmit(event) {

        event.preventDefault();
        event.stopPropagation();                

        const data = {
            first_name: this.els.first_name.value(),
            last_name: this.els.last_name.value(),
            mobile_number: this.els.mobile_number.value(),
            username: this.els.username.value(),
            email: this.els.email.value(),
            password: this.els.password.value(),
            role_id: this.els.role_id.value(),
            /* user_type: this.els.user_type.value() */
        };
        Actions.createNew(data, this.props.history);
    }

    checkMobileNumber(e) {

        let inputValue = e.target.value;
        let mobileNumber  = inputValue.replace(/\D/g,'');
        e.target.value = mobileNumber.substring(0, 10);
    }

    render() {
        
        let alert;

        if (this.props.error) {
            alert = <Alert
                type="danger"
                message={this.props.error}
            />;
        }

        const formElements = <fieldset>
            {alert}
            <TextControl
                ref={(c) => (this.els.first_name = c)}
                name="first_name"
                label="First Name"
                hasError={this.props.hasError.first_name}
                help={this.props.help.first_name}
                disabled={this.props.loading}
            />
            <TextControl
                ref={(c) => (this.els.last_name = c)}
                name="last_name"
                label="Last Name"
                hasError={this.props.hasError.last_name}
                help={this.props.help.last_name}
                disabled={this.props.loading}
            />
            <TextControl
                ref={(c) => (this.els.username = c)}
                name="username"
                label="Username"                                
                hasError={this.props.hasError.username}
                help={this.props.help.username}
                disabled={this.props.loading}
            />
            <TextControl
                ref={(c) => (this.els.mobile_number = c)}
                name="mobile_number"
                label="Mobile Number"                                
                hasError={this.props.hasError.mobile_number}
                help={this.props.help.mobile_number}
                disabled={this.props.loading}
                onChange={ (e) => this.checkMobileNumber(e) }
            />
            
            <TextControl
                name="email"
                label="Email"
                ref={(c) => (this.els.email = c)}                
                hasError={this.props.hasError.email}
                help={this.props.help.email}
                disabled={this.props.loading}
            />

            {/* <ReactSelectControl
                ref={(c) => (this.els.user_type = c)}
                name="user_type"
                label="User Type"
                onChange={() => {}}
                hasError={this.props.hasError.user_type}
                help={this.props.help.user_type}
                disabled={this.props.loading}
                groupClasses={{'rq': true}}
                inputClasses={{'select-modal': true}}
                labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                options={ this.user_types }
            /> */}

            <ReactSelectControl
                ref={(c) => (this.els.role_id = c)}
                name="role_id"
                label="User Role"
                onChange={() => {}}
                hasError={this.props.hasError.role_id}
                help={this.props.help.role_id}
                disabled={this.props.loading}
                groupClasses={{'rq': true}}
                inputClasses={{'select-modal': true}}
                labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                options={ CommonHelper.getOptionData(this.state.roles, 'role_key', 'role_name') }
            />
            
            <TextControl
                ref={(c) => (this.els.password = c)}
                name="password"
                label="Password"
                type="password"
                hasError={this.props.hasError.password}
                help={this.props.help.password}
                disabled={this.props.loading}
            />

            <ControlGroup hideLabel={true} hideHelp={true}>
                <Button
                    type="submit"
                    inputClasses={{ 'btn-primary': true }}
                    disabled={this.props.loading}>

                    Create new
                    <Spinner space="left" show={this.props.loading} />
                </Button>
            </ControlGroup>
        </fieldset>;

        return (
            <Modal
                header="Create new"
                show={this.props.show}
                onClose={Actions.hideCreateNew}>

                <form onSubmit={this.onSubmit.bind(this)}>
                    {formElements}
                </form>
            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;

module.exports = CreateNewForm;
