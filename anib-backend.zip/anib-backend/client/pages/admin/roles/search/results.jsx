"use strict";
const PropTypes = require("prop-types");
const React = require("react");
const ReactRouter = require("react-router-dom");

const Link = ReactRouter.Link;
const propTypes = {
  data: PropTypes.array
};

class Results extends React.Component {
  getTableData(id, value) {
    return (
      <td
        onClick={e => {
          this.props.history.push(`/admin/roles/${id}`);
        }}
      >
        {value}
      </td>
    );
  }

  render() {
    const rows =
      this.props.data && this.props.data.length > 0 ? (
        this.props.data.map(record => {
          return (
            <tr className="c-pointer" key={record.role_key}>
              {this.getTableData(record.role_key, record.role_name)}
            </tr>
          );
        })
      ) : (
        <tr key="0">
          <td colSpan={1} className="text-center">
            No record(s) found!
          </td>
        </tr>
      );

    return (

        <div className="table-responsive">
            <table className="table table-hover white_table">
            <thead>
                <tr>
                    <th>Role Name</th>
                </tr>
            </thead>
            {
                this.props.list_loading ? (
                    <tbody>
                        <tr key='0'>
                            <td colSpan={1} className="text-center loader-tab-content">
                                loading...
                            </td>
                        </tr>
                        <tr key='1'>
                            <td colSpan={1} className="text-center loader-tab-content">
                                loading...
                            </td>
                        </tr>
                        <tr key='2'>
                            <td colSpan={1} className="text-center loader-tab-content">
                                loading...
                            </td>
                        </tr>
                        <tr key='3'>
                            <td colSpan={1} className="text-center loader-tab-content">
                                loading...
                            </td>
                        </tr>
                        <tr key='4'>
                            <td colSpan={1} className="text-center loader-tab-content">
                                loading...
                            </td>
                        </tr>
                    </tbody>
                ) : (
                    <tbody>
                        {rows}
                    </tbody>
                )
            }
            </table>
        </div>
    );
  }
}

Results.propTypes = propTypes;

module.exports = Results;
