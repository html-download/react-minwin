/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorCommunicationReport', {
    vendorCommunicationReportId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'vendor_communication_report_id'
    },
    communicationMapid: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'communication_mapid'
    },
    dailySummary: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'daily_summary'
    },
    dailyPerformance: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'daily_performance'
    },
    dailyDelivery: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'daily_delivery'
    },
    dailyCalback: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'daily_calback'
    },
    weeklySummary: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'weekly_summary'
    },
    weeklyPerformance: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'weekly_performance'
    },
    weeklyDelivery: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'weekly_delivery'
    },
    weeklyCalback: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'weekly_calback'
    },
    sendAlert: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'send_alert'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    createdOn: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_on'
    }
  }, {
    tableName: 'ss16_vendor_communication_report'
  });
};
