<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- acc page content -->
        <div class="acc_page_content">
          <div class="acc_title nt_title">
            <i class="fi notification"></i>
            <h2>Notifications</h2>
            <p>View all notifications of your account</p>
            <button class="btn white">Clear All</button>
          </div>
          <div class="white-30 my-profile">
           <div class="notify un-read">
            <h5 class="mb10">Unread</h5>
              <ul>
                <li>
                  <div class="notify-content">
                      <i class="fi notification"></i>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <span class="date">07/25/2019  04:53 PM</span>
                  </div>
                </li>
                 <li>
                  <div class="notify-content">
                      <i class="fi notification"></i>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <span class="date">07/25/2019  04:53 PM</span>
                  </div>
                </li>
                 <li>
                  <div class="notify-content">
                      <i class="fi notification"></i>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <span class="date">07/25/2019  04:53 PM</span>
                  </div>
                </li>
              </ul>
          </div>
                   <div class="notify read mt10">
            <h5 class="mb10">Read</h5>
              <ul>
                <li>
                  <div class="notify-content">
                      <i class="fi notification"></i>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <span class="date">07/25/2019  04:53 PM</span>
                  </div>
                </li>
                 <li>
                  <div class="notify-content">
                      <i class="fi notification"></i>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <span class="date">07/25/2019  04:53 PM</span>
                  </div>
                </li>
                 <li>
                  <div class="notify-content">
                      <i class="fi notification"></i>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                      <span class="date">07/25/2019  04:53 PM</span>
                  </div>
                </li>
              </ul>
          </div>
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>