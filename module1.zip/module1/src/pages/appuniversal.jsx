import React from 'react';
import {Route, Switch} from 'react-router-dom';

import Home from './home.jsx';
import Contact from './contact/contact.jsx';

const AppUniversal = function () {
  return (
   <div>
    <Switch>
     <Route path="/" exact component={Home}/>
     <Route path="/contact" component={Contact} />
     </Switch>
   </div>
  );
}

export default AppUniversal;
