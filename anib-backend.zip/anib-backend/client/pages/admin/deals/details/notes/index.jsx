'use strict';
const Actions = require('../actions');
const React = require('react');
const CommonHelper = require('../../../../../helpers/common-functions');

class Notes extends React.Component {

    constructor(props) {

        super(props);
        this.state = {
            notes : props.notes
        };
    }

    render() {
        
        return (            
            <div className="box" key={this.props.deal_note_key}>
                <div className="icon"><i className="fa fa-sticky-note-o"></i></div>
                <h6>{CommonHelper.wordTruncate(this.props.note, 250)}</h6><p>{this.props.created_at} by {this.props.first_name} {this.props.last_name}</p>
                <a href="javascript:" onClick={ (e) => this.props.deleteFun(this.props.deal_note_key) } className="remove"><i className="fa fa-trash"></i> Remove</a>
            </div>
        );
    }
}

module.exports = Notes;