'use strict';
//const Actions = require('./actions');
const Alert = require('../../../../components/alert.jsx');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const LinkState = require('../../../../helpers/link-state.js');
const Modal = require('../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../components/form/spinner.jsx');
const SelectControl = require('../../../../components/form/select-control.jsx');
const TextControl = require('../../../../components/form/text-control.jsx');
const TextArea = require('../../../../components/form/textarea-control.jsx');

import { Form, FormGroup, Label, Input, FormText } from 'reactstrap';


class ViewForm extends React.Component {

    constructor(props) {

        super(props);
    }    

    componentDidUpdate() {

        if (this.props.show && this.state.name && this.state.name.length === 0) {
            this.els.name.focus();
        }           
    }


    render() {        

        return (
            <Modal
                header="Motor Policy Schedule"
                show={this.props.is_view_policy}
                onClose={this.props.Actions.hideViewModal}
                groupClasses={{'model_design1': true, 'motor_policy':true}}
                modalDialogClasses={{'modal-dialog-centered': true}}
                >
                <div className="modal-view-policy">

                    <div className="motor-policy-head">
                        <div className="img"><img src={this.props.insurence_product_image} /></div>
                        <h5>{this.props.insurence_product_name}</h5>
                    </div>

                    <div className="policy-body motor-policy-body">

                        <div className="row">
                            <div className="col-md-6">
                                <div className="table-responsive">
                                    <h6>CUSTOMER DETAILS</h6>
                                    <table className="view_table">
                                        <tbody>
                                            <tr>
                                                <td>Customer Name</td>
                                                <td>{this.props.customer_first_name}</td>
                                            </tr>
                                            <tr>
                                                <td>Email Id</td>
                                                <td>{this.props.email}</td>
                                            </tr>
                                            <tr>
                                                <td>Mobile Number</td>
                                                <td>{this.props.mobile_number}</td>
                                            </tr>
                                            <tr>
                                                <td>DOB</td>
                                                <td>{this.props.dob}</td>
                                            </tr>
                                            <tr>
                                                <td>Address</td>
                                                <td>{this.props.address}</td>
                                            </tr>
                                            <tr>
                                                <td>PO Box</td>
                                                <td>{this.props.po_box}</td>
                                            </tr>
                                            <tr>
                                                <td>Emirate ID</td>
                                                <td>{this.props.emirate_id}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className="table-responsive">
                                    <h6>INSURED VEHICLE DETAILS</h6>
                                    <table className="view_table">
                                        <tbody>
                                            <tr>
                                                <td>Manufatured Year</td>
                                                <td>{this.props.model_year}</td>
                                            </tr>
                                            <tr>
                                                <td>Make</td>
                                                <td>{this.props.vehicle}</td>
                                            </tr>
                                            <tr>
                                                <td>Model</td>
                                                <td>{this.props.vehicle_brand_model_name}</td>
                                            </tr>
                                            <tr>
                                                <td>Trim</td>
                                                <td>{this.props.vehicle_brand_model_trim_name}</td>
                                            </tr>
                                            <tr>
                                                <td>Engine Number</td>
                                                <td>{this.props.engine_number}</td>
                                            </tr>
                                            <tr>
                                                <td>Chassis Number</td>
                                                <td>{this.props.chassis_number}</td>
                                            </tr>
                                            <tr>
                                                <td>Color</td>
                                                <td>{this.props.vehicle_color}</td>
                                            </tr>
                                            <tr>
                                                <td>Registration Number</td>
                                                <td>{this.props.registration_number}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-12 policy_details">
                            <div className="table-responsive">
                                <h6>INSURED VEHICLE DETAILS</h6>
                                <table className="view_table bottom_detail">
                                    <tbody>
                                        <tr>
                                            <th style={ { width: "25%" } }>Quotation Number</th>
                                            <th>Policy Number</th>
                                            <th>Premium</th>
                                            <th>Policy Start Date</th>
                                            <th>Policy End Date</th>

                                        </tr>
                                        <tr>
                                            <td style={ {color:'unset'} }>{this.props.quotation_number}</td>                                            
                                            <td>{this.props.policy_number}</td>
                                            <td>{this.props.premium_value}</td>
                                            <td>{this.props.policy_start_date}</td>
                                            <td>{this.props.policy_expire_date}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <button type="button" className="btn pull-right" onClick={ (e) => {this.props.Actions.hideViewModal()}}>Close</button>
                </div>
            </Modal>
        );
    }
}

module.exports = ViewForm;
