'use strict';
const Store = require('./store');
const Constant =  require('./constants');
const ApiActions = require('../../../../../../actions/api');
const CommonHelper = require('../../../../../../helpers/common-functions');
const Toaster = require('../../../../../../helpers/toaster');
const QuoteAction = require('../quote/actions');


class Actions {


    static getProduct(data) {

        ApiActions.get(
            /* '/underwriter', */
            '/underwriter/list-with-model',
            data,
            Store,
            Constant.GET_PRODUCT_DETAILS,
            Constant.GET_PRODUCT_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                    }                    
                }
            }
        );
    }

    static getModelTrim(data) {

        ApiActions.get(                        
            '/vehicle-brand-model-trim',
            data,
            Store,
            Constant.GET_UNDERWRITER_TRIM,
            Constant.GET_UNDERWRITER_TRIM_RESPONSE
        );
    }


    static toggleDeal() {
            
        Store.dispatch({
            type : Constant.TOGGLE_DEAL
        });
    }

    static toggleQuote() {

        Store.dispatch({
            type : Constant.TOGGLE_QUOTE
        });
    }

    static toggleCreate() {
            
        Store.dispatch({
            type : Constant.TOGGLE_CREATE
        });
    }

    static openQuoteModal() {
        
        Store.dispatch({
            type : Constant.OPEN_QUOTE_MODAL
        });
    }

    static hideQuoteModal() {
        
        Store.dispatch({
            type : Constant.HIDE_QUOTE_MODAL
        });
    }    

    static getDealQuote(data) {                
        
        ApiActions.get(
            '/deal-quote',
            data,
            Store,
            Constant.GET_DEAL_QUOTE_DETAILS,
            Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE
        );
    }    

    static saveQuote(data, toggle) {
        
        ApiActions.post(
            '/deal/send',
            data,
            Store,
            Constant.SAVE_DEAL_QUOTE_DETAILS,
            Constant.SAVE_DEAL_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {

                        QuoteAction.getDealQuote(data);
                        toggle(2, response.data);
                        CommonHelper.windowScroll();
                    }                    
                }
            }
        );
    }

    static sendQuoteMail(data, toggle) {
        
        ApiActions.post(
            '/deal/send',
            data,
            Store,
            Constant.SAVE_DEAL_QUOTE_DETAILS,
            Constant.SAVE_DEAL_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(2, response.data);
                        CommonHelper.windowScroll();
                    }                    
                }
            }
        );
    }

    static openPolicyModal(dealQuoteRequestKey) {
       
        ApiActions.get(
            `/policy/plan-list/${dealQuoteRequestKey}`,
            undefined,
            Store,
            Constant.OPEN_POLICY_LIST,
            Constant.OPEN_POLICY_LIST_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        
                    }
                }
            }
        );
    }


    static changePlan(data) {

        ApiActions.post(
            '/policy/choose-plan',
            data,
            Store,
            Constant.CHANGE_POLICY_RESULT,
            Constant.CHANGE_POLICY_RESULT_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        Toaster.success('Plans has been updatd...');
                    }
                }
            }
        );
    }

    static closePolicyModal() {

        Store.dispatch({
            type : Constant.CLOSE_POLICY_MODAL
        });
    }

    static saveQuoteDetails(data, loadDeal) {
        
        Toaster.warning('It will take some time to create. Please wait');
        
        ApiActions.post(
            '/deal-quote',
            data,
            Store,
            Constant.SAVE_QUOTE_DETAILS,
            Constant.SAVE_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (response.status === 200) {
                    loadDeal ? loadDeal() : null;
                }
            }
        );
    }


    static checkApiStatus(deal_id, insurence_product_id, unCheckFun, element) {

        let data = {
            deal_id: deal_id,
            insurence_product_id: insurence_product_id
        };
        ApiActions.post(
            '/deal/check-api-status',
            data,
            Store,
            Constant.CHECK_INSURENCE_STATUS,
            Constant.CHECK_INSURENCE_STATUS_RESPONSE,
            (err, response) => {

                if (err) {                    
                    unCheckFun(element);
                }
            }
        );
    }

    static sendQuoteMail(data, toggle) {            

        ApiActions.post(
            '/deal/send',
            data,
            Store,
            Constant.SEND_QUOTE_DETAILS,
            Constant.SEND_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(2, response.data);
                        this.hideQuoteModal();
                        CommonHelper.windowScroll();
                    }                    
                }
            }
        );
    }

    static updatePublish(data) {
        
        ApiActions.post(
            '/deal-quote/change-publish-status',
            data,
            Store,
            Constant.UPDATE_POLICY_DETAILS,
            Constant.UPDATE_POLICY_DETAILS_RESPONSE,
            (err, response) => {

                if (err) {
                    Toaster.error('Server error occured');
                }

                if (response && response.status === 200) {
                    data.is_publish ? Toaster.success('Quote is added for publish!') : Toaster.error('Quote is removed from publish!');
                }
                
            }
        );
    }
    
}

module.exports = Actions;