'use strict';

const models = require('../models');
const Session = models.models.session;

exports.register = function (server, options, next) {
	const Session = models.models.session;
    server.route({
        method: 'GET',
        path: '/',
        handler: function (request, reply) {

            reply({ message: 'Welcome to the plot device.' });
        }
    });


    next();
};


exports.register.attributes = {
    name: 'index'
};
