'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');

const initialState = {
    show: false,
    loading: false,
    hasError: {},
    help: {},
    error: null,
    isLoaded: false,
    lots: [],
    selected : '', 
    selectedAddress: {},
    selectedLatLng:'',
    title : '',
    percentage : '', 
    color : '',
    lot_status : 1,
    show_message_modal : false
};

const reducer = function (state = initialState, action) {

    if (action.type === Constants.SHOW_CREATE_NEW) {
        return ObjectAssign({}, state, {
            show: true,
            selected : action.lot_name,
            selectedAddress : action.address,
            selectedLatLng : action.LatLng,
            title : action.title,
            percentage : action.percentage, 
            color : action.color,
            lot_status:  action.lot_status
        });
    }

    if (action.type === Constants.HIDE_CREATE_NEW) {
        return ObjectAssign({}, state, {
            show: false,
            selected : '',
            selectedAddress : {},
            selectedLatLng : '',
            title : '',
            percentage : '', 
            color : '',
            lot_status : 0
        });
    }

    return state;
};


module.exports = reducer;
