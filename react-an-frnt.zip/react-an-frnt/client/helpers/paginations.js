module.exports = {
    pages: function (data) {
        try {
            const {
                current_page,
                page_count,
                per_page,
                total_count,
            } = data;
            
            let response = {
                limit: per_page, 
                begin: ((current_page * per_page) - per_page) + 1,
                end: current_page * per_page, 
                total: total_count
            };

            return response;
        } catch (e) {
            //console.log(e.message);
            return {};
        }
    },

    items: function (data) {
        try {
            const {
                current_page,
                page_count,
                per_page,
                total_count,
            } = data;
            
            let response = {
                current: current_page,
                hasNext: false,
                hasPrev: false,
                next: 2,
                prev: 0,
                total: 1,
            };
            
            return response;
        } catch (e) {
            //console.log(e.message);
            return {};
        }
    },
};
