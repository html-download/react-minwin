"use strict";
const Actions = require("./actions");
const DeleteForm = require("../../../../../client/pages/admin/components/delete-form.jsx");
const DetailsForm = require("./details-form.jsx");
const PasswordForm = require("./password-form.jsx");
const PropTypes = require("prop-types");
const React = require("react");
const ReactRouter = require("react-router-dom");
const RolesForm = require("./roles-form.jsx");
const Store = require("./store");
const UserDetailsForm = require('./user-info/index');
const CAction = require('../common/action'); 

import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Card,
  Button,
  CardTitle,
  CardText,
  Row,
  Col
} from "reactstrap";
import classnames from "classnames";

const Link = ReactRouter.Link;
const propTypes = {
    history: PropTypes.object,
    match: PropTypes.object
};

class DetailsPage extends React.Component {
    constructor(props) {
        super(props);

        //Actions.getDetails(this.props.match.params.id);

        this.state = Store.getState();
        CAction.getRoles();
        this.state = {
            activeTab: "1"
        };
    }

    toggle(tab) {
        if (this.state.activeTab !== tab) {
        this.setState({
            activeTab: tab
        });
        }
    }

  componentDidMount() {
    this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
  }

  componentWillUnmount() {
    this.unsubscribeStore();
  }

  onStoreChange() {
    this.setState(Store.getState());
  }

  render() {    

    return (
      <section className="page-container">
        <div className="container">
          <div className="breadcums">
            <ul className="reset">
              <li>
                <a href="/admin">Dashboard</a>
              </li>
              <li>
                <a href="/admin/customers">Users</a>
              </li>
              <li>
                <span className="capitalize" id="userNameBreadCrumb"> </span>
              </li>
            </ul>
            {/* <button
                className="btns outline-danger"
                data-toggle="modal"
                data-target="#delete"
                >
              <i className="fa fa-trash" /> Delete
            </button> */}
          </div>
          <div className="single-page-content">
            <div className="row">
                <div className="col-md-4">
                    <UserDetailsForm
                        user_id={this.props.match.params.id}
                    />
                </div>
                <div className="col-md-8">
                <div className="white-box">                    
                  <div className="cs-tab">
                    <Nav tabs>
                      <NavItem>
                        <NavLink
                          className={classnames({
                            active: this.state.activeTab === "1"
                          })}
                          onClick={() => {
                            this.toggle("1");
                          }}
                        >
                          All
                        </NavLink>
                      </NavItem>
                      <NavItem>
                        <NavLink
                          className={classnames({
                            active: this.state.activeTab === "2"
                          })}
                          onClick={() => {
                            this.toggle("2");
                          }}
                        >
                          Notes
                        </NavLink>
                      </NavItem>
                      <NavItem>
                        <NavLink
                          className={classnames({
                            active: this.state.activeTab === "3"
                          })}
                          onClick={() => {
                            this.toggle("3");
                          }}
                        >
                          Documents
                        </NavLink>
                      </NavItem>
                    </Nav>
                    <TabContent activeTab={this.state.activeTab}>
                      <TabPane tabId="1" className={classnames({
                            active: this.state.activeTab === "1"
                          })}>
                        <Row>
                          <Col sm="12">
                            <div className="btn-group-2">
                              <button
                                className="btn btn-secondary"
                                data-toggle="modal"
                                data-target="#add-notes"
                              >
                                Add Note
                              </button>
                              <button className="btn btn-secondary">
                                Add Documents
                              </button>
                            </div>
                            <div className="full_row mt-5">
                              <ul className="list-notes reset">
                                <li>
                                  <div className="box">
                                    <div className="icon">
                                      <i className="fa fa-sticky-note-o" />
                                    </div>
                                    <h6>Note Created</h6>
                                    <p>Feb, 13, 2019, 9.25 am by ilan K</p>
                                  </div>
                                </li>
                              </ul>
                            </div>
                          </Col>
                        </Row>
                      </TabPane>
                      <TabPane tabId="2" className={classnames({
                            active: this.state.activeTab === "2"
                          })}>
                        <Row>
                          <Col sm="12">
                            <div className="btn-group-2">
                              <button
                                className="btn btn-secondary"
                                data-toggle="modal"
                                data-target="#add-notes"
                              >
                                Add Note
                              </button>
                            </div>
                          </Col>
                        </Row>
                      </TabPane>
                      <TabPane tabId="3" className={classnames({
                            active: this.state.activeTab === "3"
                          })}>
                        <Row>
                          <Col sm="12">
                            <input className="hidden" type="file" id="file" />
                            <label className="drag-files" htmlFor="file">
                              Drag Files here or click to upload
                            </label>

                            <div className="upload-listing mx400 mt-5">
                              <div className="box">
                                <div className="icon">
                                  <i className="fa fa-file-pdf-o" />
                                </div>
                                <a
                                  href="#"
                                  className="add-forms editable editable-click"
                                >
                                  document.pdf
                                </a>
                                <p className="date">Feb-23-2020</p>
                                <a href="" className="remove">
                                  <i className="fa fa-trash" /> Remove
                                </a>
                              </div>
                            </div>
                          </Col>
                        </Row>
                      </TabPane>
                    </TabContent>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}

DetailsPage.propTypes = propTypes;

module.exports = DetailsPage;
