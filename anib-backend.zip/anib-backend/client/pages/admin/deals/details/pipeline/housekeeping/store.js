'use strict';
const Constant =  require('./constants');
const ObjectAssign = require('object-assign');
const Redux = require('redux');
const ParseValidation = require('../../../../../../helpers/parse-validation');

const initialState = {
    loading: false,
    product_hydrated: true,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    is_quote_collapsed: false,
    quote_data: {},
    quote_verification:[],
    quote_verification_count:0,
    is_view_policy:false,
    policy_details:{},
    loading_mark_as_won: false
};

let validation;
let result;
const reducer = function (state = initialState, request) {
        
    switch (request.type) {   

        case Constant.COMPLETE_DEAL_DETAILS:
            return ObjectAssign({}, state, {
                loading_mark_as_won : true
            });
            break;
        case Constant.COMPLETE_DEAL_DETAILS_RESPONSE:
            return ObjectAssign({}, state, {
                loading_mark_as_won : false
            });
            break;
        case Constant.GET_DEAL_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                loading : true
            });
            break;

        case Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : {};
            
            return ObjectAssign({}, state, {
                loading: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                quote_data: result
            });

            break;

        case Constant.GET_PRODUCT_DETAILS:
            return ObjectAssign({}, state, {
                product_hydrated : true
            });
            break;

        case Constant.GET_PRODUCT_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                product_hydrated: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                product_data: result
            });
            break; 
        case Constant.GET_QUOTE_VERIFICATION_DETAILS:
            return ObjectAssign({}, state, {
                quote_verification : []
            });
            break;
        case Constant.GET_QUOTE_VERIFICATION_DETAILS_RESPONSE:
                        
            return ObjectAssign({}, state, {
                quote_verification : request.response.data,
                quote_verification_count: request.response.data.length
            });
            break;
        case Constant.TOGGLE_QUOTE:
            return ObjectAssign({}, state, {
                is_quote_collapsed : (state.is_quote_collapsed) ? false : true                
            });
            break;
        case Constant.UPDATE_VERIFICATION_STATUS:

            let tempState = state;
            tempState.quote_verification[request.index].is_verified = request.status ? 1 : 0;
            return ObjectAssign({}, state, tempState);
            break;
        case Constant.GET_POLICY_DETAILS:
                    
            return ObjectAssign({}, state, {
                policy_details:{}
            });
            break;
        case Constant.GET_POLICY_DETAILS_RESPONSE:
                    
            if (request.response.status === 200) {
                return ObjectAssign({}, state, {
                    policy_details:request.response.data
                });
            }            
            break;
        case Constant.OPEN_POLICY_MODAL:
            return ObjectAssign({}, state, {
                is_view_policy:true
            });
            break;
        case Constant.HIDE_POLICY_MODAL:
            return ObjectAssign({}, state, {
                is_view_policy:false
            });
            break;
        default:
            return ObjectAssign({}, state);
            break;
    }           
};
module.exports = Redux.createStore(reducer);


