const React = require('react');
const ReactHelmet = require('react-helmet');
import ContentLoader from 'react-content-loader'

const Helmet = ReactHelmet.Helmet;

class LoaderPage extends React.Component {
    
    render() {

        return (
            <div className="content-wrapper">
                <Helmet>
                    <title>Welcome to Dashboard</title>
                </Helmet>
                <section className="content">
                    <div className="box">
                        <div className="box-header with-border">
                            <h1 className="box-title">Analytics</h1>
                        </div>
                        <div className="box-body">
                            <div className="row">
                                <div className="col-sm-4">
                                    <ContentLoader
                                        height={160}
                                        width={400}
                                        speed={1}
                                        primaryColor="#f3f3f3"
                                        secondaryColor="#ecebeb"
                                    >
                                        <rect x="0" y="13" rx="4" ry="4" width="400" height="9" />
                                        <rect x="0" y="29" rx="4" ry="4" width="100" height="8" />
                                        <rect x="0" y="50" rx="4" ry="4" width="400" height="10" />
                                        <rect x="0" y="65" rx="4" ry="4" width="400" height="10" />
                                        <rect x="0" y="79" rx="4" ry="4" width="100" height="10" />
                                        <rect x="0" y="99" rx="5" ry="5" width="400" height="200" />
                                    </ContentLoader>
                                </div>
                                <div className="col-sm-4">
                                    <ContentLoader
                                        height={160}
                                        width={400}
                                        speed={1}
                                        primaryColor="#f3f3f3"
                                        secondaryColor="#ecebeb"
                                    >
                                        <rect x="0" y="13" rx="4" ry="4" width="400" height="9" />
                                        <rect x="0" y="29" rx="4" ry="4" width="100" height="8" />
                                        <rect x="0" y="50" rx="4" ry="4" width="400" height="10" />
                                        <rect x="0" y="65" rx="4" ry="4" width="400" height="10" />
                                        <rect x="0" y="79" rx="4" ry="4" width="100" height="10" />
                                        <rect x="0" y="99" rx="5" ry="5" width="400" height="200" />
                                    </ContentLoader>
                                </div>
                                <div className="col-sm-4">
                                    <ContentLoader
                                        height={160}
                                        width={400}
                                        speed={1}
                                        primaryColor="#f3f3f3"
                                        secondaryColor="#ecebeb"
                                    >
                                        <rect x="0" y="13" rx="4" ry="4" width="400" height="9" />
                                        <rect x="0" y="29" rx="4" ry="4" width="100" height="8" />
                                        <rect x="0" y="50" rx="4" ry="4" width="400" height="10" />
                                        <rect x="0" y="65" rx="4" ry="4" width="400" height="10" />
                                        <rect x="0" y="79" rx="4" ry="4" width="100" height="10" />
                                        <rect x="0" y="99" rx="5" ry="5" width="400" height="200" />
                                    </ContentLoader>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        );
    }
}


module.exports = LoaderPage;
