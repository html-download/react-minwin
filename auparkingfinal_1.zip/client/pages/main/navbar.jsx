const React = require('react');
const PropTypes = require('prop-types');
const ReactRouter = require('react-router-dom');
const Favicon = require('react-favicon');

const SignupForm = require('./signup-popup/index.jsx');
const LoginForm = require('./login/popup/index.jsx');
const ForgotForm = require('./login/forgot-popup/index.jsx');
const UserIdentity = require('../../helpers/user-identity');

const Link = ReactRouter.Link;

const propTypes = {
    location: PropTypes.object
};
class Navbar extends React.Component {
    constructor(props) {
        super(props);
        this.handleModalClick = this.handleModalClick.bind(this);
        this.refreshSearch = this.refreshSearch.bind(this);
    }
    handleModalClick(event) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
    }
    refreshSearch(event) {
        localStorage.removeItem(`address_${UserIdentity._checkUserToken()}`);
    }
    componentDidMount() {
        //localStorage.setItem('setStorage', null);
    }
    render() {
        return (
              <header className="main-header">  
                <Favicon url="/public/media/images/favicon.png"/>  
                <a className="main_menu"><i className="fa fa-bars"></i></a>
                <Link to="/" className="logo" onClick={this.refreshSearch}><img src="/public/media/images/logo1.png" /></Link>    
                <nav className="navbar navbar-static-top">      
                  <div className="navbar-custom-menu">
                    <ul className="nav navbar-nav">
                      <li>
                          <Link className="" to="/lots" onClick={this.refreshSearch}>Lots</Link>
                      </li>
                      <li>
                          <Link className="" to="/zones">Zones</Link>
                      </li>
                      <li>
                          <Link className="" to="/about">About</Link>
                      </li>
                      <li>
                          <Link className="" to="/parking-info">Parking info</Link>
                      </li>
                      <li>
                          {/*<a href="https://au-parking.com/#contact-us" target="_blank">Contact Us</a>*/}
                          <a onClick={() => {window.open("https://au-parking.com/#contact-us", "", "width=600,height=400")}} role="button">Contact Us</a>
                      </li>
                      <li>
                          <Link className="" to="/terms">Terms & Policy</Link>
                      </li>
                    </ul>
                    <ul className="reset copyright">
                        <li>&#169; <a href="https://fopark.io/" target="_blank"><img style={{ height: '21px'}} src="/public/media/images/logo-w.png" /></a>    </li>
                    </ul>
                  </div>
                </nav>
              </header> 
          );
    }
}

Navbar.propTypes = propTypes;


module.exports = Navbar;