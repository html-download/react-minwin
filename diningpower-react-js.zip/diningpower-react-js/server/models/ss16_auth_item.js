/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AuthItem', {
    id: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'id'
    },
    name: {
      type: DataTypes.STRING(64),
      allowNull: false,
      primaryKey: true,
      field: 'name'
    },
    type: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'type'
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'description'
    },
    ruleName: {
      type: DataTypes.STRING(64),
      allowNull: true,
      field: 'rule_name'
    },
    data: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'data'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'modified_datetime'
    },
    createdAt: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_at'
    },
    updatedAt: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'updated_at'
    }
  }, {
    tableName: 'ss16_auth_item'
  });
};
