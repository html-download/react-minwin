'use strict';
const Constants = require('./constants');
const DateHelper = require('../../../../../helpers/date-time');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {
    /** Error and Loading */
    show: false,
    loading: false,
    error: undefined,
    hasError: {},
    help: {},

    /** Form Data */
    task_title: '',
    task_date: DateHelper.getCurrentDate(),
    task_time: DateHelper.getCurrentTime(),
    duration: '00:30',
    note: '',
    task_type_id: '',
    assigned_user_id: '',
    task_status: 0,

    /** Dropdown list  */
    deal_data: [],
    customer_data: [],

    events: []
};

const reducer = function (state = initialState, action) {
        

    if (action.type === Constants.CREATE_NEW) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.CREATE_NEW_RESPONSE) {

        if (action.response.status !== 200) {            
            const validation = ParseValidation(action.response);
            
            const stateUpdates = {
                show: true,
                loading: false,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help
            };
            return ObjectAssign({}, state, stateUpdates);
        }
    }

    if (action.type === Constants.HIDE_CREATE_NEW) {
        return ObjectAssign({}, state, {
            show: false
        });
    }
        
    if (action.type === Constants.GET_DEALS_RESULTS) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.UPDATE_DATE_FIELD) {
        if (action.field === 'task_date') {
            return ObjectAssign({}, state, {
                task_date : action.date
            });
        }
        if (action.field === 'task_time') {
            
            return ObjectAssign({}, state, {
                task_time : action.date
            });
        }
    }

    if (action.type === Constants.GET_CUTOMER_RESULTS_RESPONSE) {

        return ObjectAssign({}, state, {
            customer_data: action.response ? action.response.data : []
        });
        
    }

    if (action.type === Constants.GET_DEALS_RESULTS_RESPONSE) {

        const validation = ParseValidation(action.response);
        
        const stateUpdates = {
            loading: false,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            deal_data: action.response ? action.response.data : []
        };

        return ObjectAssign({}, state, stateUpdates);
    }

    if (action.type === Constants.SET_EVENTS) {

        return ObjectAssign({}, state, {
            events: action.eventArray ? action.eventArray : []
        });
        
    }

    return state;
};


module.exports = Redux.createStore(reducer);
