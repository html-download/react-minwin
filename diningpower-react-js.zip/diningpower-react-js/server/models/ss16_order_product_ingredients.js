/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16OrderProductIngredients', {
    ingredientsId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'ingredients_id'
    },
    orderProductId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'order_product_id'
    },
    ingredientName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'ingredient_name'
    },
    ingredientPrice: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'ingredient_price'
    }
  }, {
    tableName: 'ss16_order_product_ingredients'
  });
};
