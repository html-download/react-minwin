'use strict';
const ClassNames = require('classnames');
const ControlGroup = require('./control-group.jsx');
const ObjectAssign = require('object-assign');
const PropTypes = require('prop-types');
const React = require('react');
const renderHTML = require('react-render-html');

const propTypes = {
    children: PropTypes.node,
    defaultValue: PropTypes.string,
    disabled: PropTypes.bool,
    hasError: PropTypes.bool,
    help: PropTypes.string,
    inputClasses: PropTypes.object,
    hideLabel: PropTypes.bool,
    label: PropTypes.string,
    multiple: PropTypes.string,
    name: PropTypes.string,
    onChange: PropTypes.func,
    size: PropTypes.string,
    /*value: PropTypes.oneOfType([
        PropTypes.bool,
        PropTypes.string,
        PropTypes.integer
    ]),*/
    defaultValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    prependElement : PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    prependElementNotString : PropTypes.bool,
    appendElement: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    appendElementNotString : PropTypes.bool,
    isKeyEnable: PropTypes.bool,
};
const defaultProps = {
    type: 'text'
};


class SelectControl extends React.Component {
    value() {

        return this.input.value;
    }

    render() {

        const inputClasses = ClassNames(ObjectAssign({
            'form-control': true
        }, this.props.inputClasses));

        return (
            <ControlGroup
                hasError={this.props.hasError}
                label={this.props.label}
                hideLabel={this.props.hideLabel}
                groupClasses={this.props.groupClasses}
                labelClasses={this.props.labelClasses}
                labelFor={this.props.id}
                help={this.props.help}>

                <div className="side-input right-side">
                    {(this.props.prependElement && this.props.prependElementNotString) ? (this.props.prependElement) : ''}
                    {(this.props.prependElement && !this.props.prependElementNotString) ? (renderHTML(this.props.prependElement)) : ''}

                    <select
                        ref={(c) => (this.input = c)}
                        key={ this.props.isKeyEnable ? `${Math.floor((Math.random() * 1000))}-${this.props.name}` : "" }
                        multiple={this.props.multiple}
                        className={inputClasses}
                        name={this.props.name}
                        size={this.props.size}
                        value={this.props.value}
                        defaultValue={this.props.defaultValue}
                        disabled={this.props.disabled}
                        onChange={this.props.onChange}>

                        {this.props.children}
                    </select>

                    {(this.props.appendElement && this.props.appendElementNotString) ? (this.props.appendElement) : ''}
                    {(this.props.appendElement && !this.props.appendElementNotString) ? (renderHTML(this.props.appendElement)) : ''}
                </div>
            </ControlGroup>
        );
    }
}

SelectControl.propTypes = propTypes;
SelectControl.defaultProps = defaultProps;


module.exports = SelectControl;
