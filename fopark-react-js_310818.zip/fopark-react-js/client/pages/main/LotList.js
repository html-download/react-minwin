import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import CircularProgressbar from 'react-circular-progressbar';


class LotList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            lots: []
        };
        this.params = {
            //fopark_url: 'http://localhost:5001',
            fopark_url: 'https://api6.fopark-api.com',
            fopark_key: 'd5a3c692930824c95141fb18c07fe2102b3a0c96af4227f5'
        };
        this.updateLotList = this.updateLotList.bind(this);
    };

    updateLotList() {
        fetch(`${this.params.fopark_url}/client/lots?name=auburn`, {
            'headers': new Headers({
                'X-api-key':  this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    if('lots' in result){
                        //console.log(result.lots)
                        this.setState({
                            isLoaded: true,
                            lots: result.lots
                        });
                    } else {
                        this.setState({
                            isLoaded: true,
                            error: {
                                'message': 'No Lots Returned'
                            }
                        });
                    }
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            );
    };

    componentDidMount() {
        this.interval = setInterval(this.updateLotList, 15000);
        this.updateLotList();
    };

    componentWillUnmount() {
        clearInterval(this.interval);
    };

    render() {
        const {error, isLoaded, lots} = this.state;

        if (error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if (!isLoaded) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else {
            return (
                <div className="my-3 p-3 bg-white rounded box-shadow">
                    <h6 className="border-bottom border-gray pb-2 mb-0">
                        <div>Choose a Lot</div>
                    </h6>
                    {Object.keys(lots).map((lot) => {
                        let occupied = 0;
                        let total = 0;
                        let percentage = 0;
                        let color = '';
                        if(percentage <= 85){
                            color = 'rgb(36, 187, 70)';
                        } else if(percentage <= 95){
                            color = 'rgb(223, 146, 0)';
                        } else {
                            color = 'rgb(237, 35, 40)';
                        }
                        return (
                            <Link to={`/lots/${lots[lot]['lot_name']}`} key={lots[lot]['api_id']} className='lotLink'>
                                <div className="media text-muted pt-3">
                                    <img data-src="holder.js/32x32?theme=thumb&bg=007bff&fg=007bff&size=1" alt=""
                                         className="mr-2 rounded"/>
                                    <div className="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                                        <div className="d-flex justify-content-between align-items-center w-100">
                                            <div>
                                                <strong className="text-gray-dark">{lots[lot]['title']}</strong>
                                                <div className="d-flex">
                                                    <div className='p-2'>Spaces Available By Zone</div>
                                                    {Object.keys(lots[lot].occupancy).map((zone) => {
                                                        console.log(zone)
                                                        if (zone !== 'undefined' && zone !== 'all') {
                                                            let isZoneSelected = localStorage.getItem(`${zone}_selected`);

                                                            let zoneColor = 'rgb(211, 170, 23)';
                                                            switch(zone){
                                                                case 'a':
                                                                    zoneColor = 'rgb(232, 228, 2)';
                                                                    break;
                                                                case 'b':
                                                                    zoneColor = 'rgb(69, 255, 25)';
                                                                    break;
                                                                case 'c':
                                                                    zoneColor = 'rgb(1, 34, 112)';
                                                                    break;
                                                                case 'ada':
                                                                    zoneColor = 'rgb(18, 90, 214)';
                                                                    break;
                                                                default:
                                                                    zoneColor = 'rgb(211, 170, 23)';
                                                                    break;
                                                            }

                                                            if (typeof isZoneSelected === 'string') {
                                                                if (isZoneSelected === 'false') {
                                                                    isZoneSelected = false;
                                                                }
                                                                if (isZoneSelected) {
                                                                    isZoneSelected = true;
                                                                }
                                                            }
                                                            if (isZoneSelected == null) {
                                                                isZoneSelected = true;
                                                            }
                                                            if (isZoneSelected) {
                                                                occupied += lots[lot].occupancy[zone][1];
                                                                total += lots[lot].occupancy[zone][2];
                                                                percentage = Math.floor((occupied / total) * 100);
                                                                return (
                                                                    <div className='p-2'
                                                                         key={`${lots[lot]['api_id']}_${zone}`}>
                                                                        <strong style={{
                                                                            'color': zoneColor
                                                                        }}>{zone.toUpperCase()}</strong>: {lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][1]}
                                                                    </div>
                                                                );
                                                            }
                                                        }
                                                        return '';
                                                    })}
                                                </div>
                                            </div>
                                            <div style={{
                                                'width': '50px'
                                            }}>
                                                <CircularProgressbar
                                                    percentage={percentage}
                                                    text={
                                                        (total > 0)?`${percentage}%`:'-'
                                                    }
                                                    strokeWidth={16}
                                                    styles={{
                                                        fontSize: '1rem',
                                                        path: {
                                                            stroke: color
                                                        },
                                                        text: {
                                                            fill:'#6c757d',
                                                            alignmentBaseline: 'middle',
                                                            textAnchor: 'middle',
                                                            fontWeight: 'bold',
                                                            fontSize: '32px'
                                                        }
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Link>
                        )
                    })}
                </div>
            );
        }
    };
}

export default LotList;