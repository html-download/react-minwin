import React, {Component} from 'react';  
import {Container, Row, Col, Form, FormGroup, Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button } from 'reactstrap';

/* Import Components */
import Input from './inputcontrol.jsx'; 
import Select from './selectcontrol.jsx';
import Textarea from  './textareacontrol.jsx';
import Checkbox  from './checkboxcontrol.jsx';
import Radiobox  from './radioboxcontrol.jsx';

class FormContainer extends Component {  
  constructor(props) {
    super(props);
   
    this.state = {
    	name: '',
    	value: '',
    	gender: '',
    	comment:'',
    	skills:'',
    	checked:'',
    	language: '',
    	skillOptions: ['Design', 'Art'],
      genderOptions: ['Male','Female','Others'],
      languageOptions: ['Tamil', 'English', 'Hindi'],

    };
	
	this.input = {

	};
   

    this.handleFullName = this.handleFullName.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
     this.handleGender = this.handleGender.bind(this);
     this.handletextarea = this.handletextarea.bind(this);
     this.handlecheckbox = this.handlecheckbox.bind(this);
     this.handleradiobox = this.handleradiobox.bind(this);
   
  }




  handleSubmit(e) {
  	console.log("name", this.input.name.value());
  	e.preventDefault();
	const data = {
		'name' : this.state.name,
		'gender' : this.state.gender,
		'skills' : this.state.skills,
		'language' : this.state.language,
		'comment': this.state.comment
	}
	console.log("data", data);
   /*localStorage.setItem("datas", JSON.stringify(data));
 console.log("ref", this.textInput.value);

this.props.history.push("/details");*/

  }

handleFullName(e)
{

console.log("this.input", this.input);
	console.log('name1', this.input.name.props.value)
	console.log('com', this.input.name)
	console.log('name2', this.input.name.value())
	//console.log('type', this.input.name.type())
	 this.setState({name: e.target.value});

}

handleGender(e)
{
	this.setState({gender: e.target.value})

}

handletextarea(e)
{
	this.setState({comment: e.target.value})

}

handlecheckbox(e)
{
	
  const value = e.target.value;

  let valueArray;

  if( this.state.skills.indexOf(value) > -1 ){
      valueArray = this.state.skills.filter( s => s !== value)
  }else {
    valueArray = [... this.state.skills,  value]
  }

  /*
  console.log("this.state.skillOptions", this.state.skillOptions);

console.log("value", value);
  if( this.state.skillOptions.indexOf(value) > -1 ){
      valueArray = this.state.skillOptions.filter( s => s !== value)
      console.log("valueArray:1", valueArray);
  }else {
    valueArray = [... this.state.skillOptions,  value]
    console.log("valueArray:2", valueArray);
  }

*/
  this.setState({
    skills : valueArray
  });

  console.log(value);
}

handleradiobox(e)
{
const value = e.target.value;
 this.setState({
   language : value
  });

}


  render() {
    return (
    <Container>
      <Row>
        <Col xs="6">
          <Card>
          <form onSubmit={this.handleSubmit}>
           <Input 
            ref={ (c)=> (this.input = c) } 
          	title= "Full Name"
          	type={'text'}  
          	name= {'name'}  
          	value={this.input.name.value()}  
          	placeholder = {'Enter your name'}
          	onChange = {this.handleFullName}
           //(because parent form-group is created)groupClasses={ {'new-class' : true} }
          	labelClasses={ {'checkbox' : true, 'checkbox-from' : true} }
            inputClasses={ {'form-control' : true, 'new-class' : true} }
          	
           />

      <Select 
      	ref={ (c)=> (this.input.gender = c) } 
      	title="Gender"
        name="gender"
        options = {this.state.genderOptions}
        value = {this.state.gender}
        placeholder ="Select Gender"
        onChange = {this.handleGender}
        //groupClasses={ {'form-group' : true, 'new-class' : true} }
        inputClasses={ {'form-control' : true, 'new-class' : true} }
        />

      <Checkbox className="checkbox"
      title="Skills"
      name="check1"
      type="checkbox"
      value={this.state.skills}
      options={this.state.skillOptions}
      onChange={this.handlecheckbox}
      groupClasses={ {'form-group' : true, 'new-class' : true} }
      labelClasses={ {'checkbox-from' : true} }
      inputClasses={ {'new-class' : true} }
      />

      <Radiobox 
      title="Language"
      name="radiobox"
      value={this.state.language}
      options={this.state.languageOptions}
      onChange={this.handleradiobox}
      groupClasses={ {'form-group' : true, 'new-class' : true} }
      labelClasses={ {'new-class' : true} }
      inputClasses={ {'new-class' : true} }
      />

      <Textarea  
      title="Textarea"
      name="comment"
      content={this.state.comment}
      rows="4"
      onChange={this.handletextarea}
      placeholder="Enter your comments"
      groupClasses={ {'form-group' : true, 'new-class' : true} }
      inputClasses={ {'new-class' : true} }
      />

        <input type="text" ref={(input)=> this.textInput = input} />
        <input type="submit" value="Submit" className="btn btn-primary" Link to= "/details"/>

        </form>
      </Card>
      </Col> 
      <Col xs="6">
           <div className="display">
            <h4>Details</h4>
            <p>{this.state.name}</p>
            <p>{this.state.gender}</p>
            <p>{this.state.skills}</p>
            <p>{this.state.language}</p>
            <p>{this.state.comment}</p>
          </div>
        </Col>
       </Row>
      </Container>

    );


  }
}




export default FormContainer;
 