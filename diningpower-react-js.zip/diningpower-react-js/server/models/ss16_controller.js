/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Controller', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    controller: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'controller'
    }
  }, {
    tableName: 'ss16_controller'
  });
};
