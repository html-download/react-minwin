<?php include ('inc/header.php'); ?>

<div class="page_banner bg3 style1 grey"> 
	<div class="container pad0">
		<div class="col-sm-7 text-left mt30">
			<h1 class="head wow fadeInDown">FOOD ORDER RECEIVING APP</h1>
			<h2 class="head wow fadeInUp">Engage existing customers with varieties and attract new customers by service</h2>
			<p class="apps">
				<a href="https://play.google.com/store/apps/details?id=com.tech.ontabee.vendor" target="_blank"><img src="images/playstore.png" class="wow fadeInUp" alt="Playstore"></a>
				<a class="hide"><img src="images/appstore.png" class="wow fadeInUp" alt="Appstore"></a>
			</p>

			<span class="play wow fadeInUp" data-toggle="modal" data-target="#modal_video">
				<i class="fa fa-play"></i> Watch Video
			</span>
		</div>
		<div class="col-sm-5">
			<img src="images/order-receiving-app.png" class="wow fadeInUp" alt="Order Receiving App" data-wow-duration="1.5s">
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey">
	<div class="container text-center">
	<h1 class="head wow fadeInDown">Working Process of Order Receiving App</h1>
		<img src="images/order-receiving-progress.png">
	</div> <!--container-->	
</section>

<section>
	<div class="container pad0">		
		<div class="col-sm-6 text-center">
			<img src="images/food-order-receiving-app.png" class="wow zoomIn" alt="Order Receiving App" data-wow-duration="1.2s">
		</div>
		
		<div class="col-sm-6">
			<h2 class="head wow fadeInUp">Order Receiving App for restaurant branch manager</h2>
			<ul class="reset list1 wow fadeInUp">
				<li>Ontabee order receiving app lets you receive your orders instantly right on your mobile phone.</li>
				<li>Instant order notifications help to reduce delivery time significantly.</li>
				<li>Wherever the vendor is vendor will know what now leaving the kitchen.</li>
				<li>The vendor can easily manage menus without any prior knowledge.</li>
				<li>When it comes to an order receiving app, branch owner can change user status notification (Pending, Accepted / Rejected, Delivered) while receiving an order from the user.</li>
				<li>The report can be generated to know more about the status of all the orders.</li>
			</ul>
		</div>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="grey">
	<div class="container text-center">
		<h2 class="head wow fadeInUp">Mobile App Screens</h2>
		<div class="screens owl-carousel">
			<div><img src="images/screen1.jpg" alt="Splash"><span>1. Splash</span></div>
			<div><img src="images/da-screen2.jpg" alt="Login"><span>2. Login</span></div>
			<div><img src="images/va_screen1.jpg" alt="New Orders"><span>3. New Orders</span></div>
			<div><img src="images/va_screen2.jpg" alt="Assigned Orders"><span>4. Assigned Orders</span></div>
			<div><img src="images/va_screen3.jpg" alt="Filter Orders"><span>5. Filter Orders</span></div>
			<div><img src="images/va_screen4.jpg" alt="Order Details"><span>6. Order Details</span></div>
			<div><img src="images/va_screen5.jpg" alt="Order History"><span>7. Order History</span></div>
			<div><img src="images/va_screen6.jpg" alt="Profile"><span>8. Profile</span></div>
        </div>
	</div> <!--container-->
</section> <!--page_banner-->

<div id="modal_video" class="modal fade" role="dialog">
	<div class="modal-dialog modal-sm">
		<a class="close" data-dismiss="modal"><i class="fa fa-close"></i></a>
		<iframe id="video" width="100%" height="100%" src="https://www.youtube.com/embed/j1qWh_N5IxI?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div><!--modal-dialog-->
</div><!--modal_video-->

<?php include('inc/footer.php');?>