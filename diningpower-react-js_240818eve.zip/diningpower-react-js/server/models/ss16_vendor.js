/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Vendor', {
    vendorId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'vendor_id'
    },
    vendorKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'vendor_key'
    },
    categoryId: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'category_id'
    },
    cuisineId: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'cuisine_id'
    },
    imageId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'image_id'
    },
    vendorName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_name'
    },
    vendorSlug: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'vendor_slug'
    },
    vendorBrief: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'vendor_brief'
    },
    vendorReturnPolicy: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'vendor_return_policy'
    },
    vendorPublicEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'vendor_public_email'
    },
    vendorPublicPhone: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'vendor_public_phone'
    },
    vendorWorkingHours: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'vendor_working_hours'
    },
    vendorContactName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_contact_name'
    },
    vendorContactEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_contact_email'
    },
    vendorContactNumber: {
      type: DataTypes.STRING(256),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_contact_number'
    },
    vendorContactAddress: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'vendor_contact_address'
    },
    vendorEmergencyContactName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_emergency_contact_name'
    },
    vendorEmergencyContactEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_emergency_contact_email'
    },
    vendorEmergencyContactNumber: {
      type: DataTypes.STRING(256),
      allowNull: false,
      defaultValue: '',
      field: 'vendor_emergency_contact_number'
    },
    vendorMainOutletId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'vendor_main_outlet_id'
    },
    shortDescription: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'short_description'
    },
    vendorLogoPath: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'vendor_logo_path'
    },
    vendorBannerPath: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'vendor_banner_path'
    },
    vendorGifPath: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'vendor_gif_path'
    },
    commision: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'commision'
    },
    vendorDeliveryCharge: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'vendor_delivery_charge'
    },
    vendorPassword: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'vendor_password'
    },
    vendorStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'vendor_status'
    },
    approveStatus: {
      type: DataTypes.ENUM('Yes','No'),
      allowNull: false,
      defaultValue: 'Yes',
      field: 'approve_status'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    vendorBankName: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'vendor_bank_name'
    },
    pickupTime: {
      type: DataTypes.STRING(10),
      allowNull: true,
      field: 'pickup_time'
    },
    deliveryTime: {
      type: DataTypes.STRING(10),
      allowNull: true,
      field: 'delivery_time'
    },
    state: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'state'
    },
    city: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'city'
    },
    area: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'area'
    },
    locations: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'locations'
    },
    street: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'street'
    },
    suite: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'suite'
    },
    zip: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'zip'
    },
    coordinates: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'coordinates'
    },
    minOrderValue: {
      type: "DOUBLE",
      allowNull: false,
      field: 'min_order_value'
    },
    maxItemPrice: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'max_item_price'
    },
    vendorLatitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'vendor_latitude'
    },
    vendorLongitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'vendor_longitude'
    },
    preorderAvailable: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'preorder_available'
    },
    onlinePaymentAvailable: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '1',
      field: 'online_payment_available'
    },
    pureVegetarian: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'pure_vegetarian'
    },
    vatPercentage: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'vat_percentage'
    },
    accountBalance: {
      type: "DOUBLE",
      allowNull: false,
      field: 'account_balance'
    },
    vendorServiceTax: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'vendor_service_tax'
    },
    amount: {
      type: "DOUBLE",
      allowNull: false,
      field: 'amount'
    },
    kilometer: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'kilometer'
    },
    additionalKmCharge: {
      type: "DOUBLE",
      allowNull: false,
      field: 'additional_km_charge'
    },
    pickupCharge: {
      type: "DOUBLE",
      allowNull: false,
      field: 'pickup_charge'
    },
    contactName: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'contact_name'
    },
    smsNumber: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'sms_number'
    },
    callNumber: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'call_number'
    },
    contactEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'contact_email'
    },
    sort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort'
    },
    vendorDelieveryoption: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'vendor_delieveryoption'
    },
    delieveryoption: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'delieveryoption'
    },
    amenity: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'amenity'
    },
    internalArea: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'internal_area'
    },
    externalArea: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'external_area'
    },
    availability: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '3',
      field: 'availability'
    },
    priceLevel: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'price_level'
    },
    appendarea: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'appendarea'
    },
    substituteVendorid: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'substitute_vendorid'
    },
    substituteVendorIdMenus: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'substitute_vendor_id_menus'
    },
    alternateNumber: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'alternate_number'
    },
    extensionNumber: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'extension_number'
    },
    closeStarttime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'close_starttime'
    },
    csrDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'csr_description'
    },
    orderMessageDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'order_message_description'
    },
    flashMessage: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'flash_message'
    },
    overlap: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'overlap'
    },
    delDpNotes: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'del_dp_notes'
    },
    delRNotes: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'del_r_notes'
    },
    pickupNotes: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'pickup_notes'
    },
    generalNotes: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'general_notes'
    },
    vendorKeyword: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'vendor_keyword'
    },
    assignedMenus: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'assigned_menus'
    },
    timeZone: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'time_zone'
    }
  }, {
    tableName: 'ss16_vendor'
  });
};
