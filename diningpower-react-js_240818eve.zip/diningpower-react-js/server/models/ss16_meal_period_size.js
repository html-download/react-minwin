/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16MealPeriodSize', {
    sizeId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'size_id'
    },
    mealId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'meal_id'
    },
    sizeName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: '',
      field: 'size_name'
    },
    fromTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'from_time'
    },
    toTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'to_time'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_meal_period_size'
  });
};
