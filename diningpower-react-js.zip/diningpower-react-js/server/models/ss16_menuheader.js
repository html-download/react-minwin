/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Menuheader', {
    menuheaderId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'menuheader_id'
    },
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'menu_id'
    },
    menuheaderKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'menuheader_key'
    },
    subCategoryType: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '0',
      field: 'sub_category_type'
    },
    menuheaderName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'menuheader_name'
    },
    nameOnline: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '1',
      field: 'name_online'
    },
    menuheaderDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'menuheader_description'
    },
    descriptionOnline: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '1',
      field: 'description_online'
    },
    menuheaderImage: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'menuheader_image'
    },
    menuheaderStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'menuheader_status'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    sort: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'sort'
    }
  }, {
    tableName: 'ss16_menuheader'
  });
};
