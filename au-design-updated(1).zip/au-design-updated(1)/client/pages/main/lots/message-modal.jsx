'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool
};


class ModalForm extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <Modal
                id="terms_condition"
                header={false}
                footer={false}
                show={this.props.createNew.show_message_modal}
                onClose={Actions.hideMessageModal}>
                <img src="/public/media/images/logo1.png" alt="" />
                <div className="terms">
                    <h3>AUPARKING</h3>
                    <p>Just one thing before you continue.Using a smartphone and driving is not safe - please check AU Parking before you go. or right after you arrive</p>
                    <div className="form-group">
                    <input id="agree" name="checkbox" type="checkbox" className="hide" />
                    <label htmlFor="agree" className="checkbox" >I agree not to use AU Parking while driving</label>
                    </div>
                    <a className="btn orange">CONTINUE</a>
                </div>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
