### Forgot your password?

We received a request to reset the password for your account. You'll
need this key to do it.

__Key:__  
{{baseHref}}/{{email}}/{{key}}

Love,

The Plot Device
