<?php include ('../inc/header.php'); ?>

<section class="page_banner">
  <div class="container">
    <h1 class="animated fadeInDown">Our Branded Happy Clients</h1>
    <p class="desc animated fadeInUp mb0">Some of our esteemed clients in this showcase</p>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients page full_row">
  <div class="container">
    <ul class="reset">
      <li><amp-img src="<?php echo $baseurl;?>images/clients/jll.png" alt="Jll" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/mezzan.png" alt="Mezzan" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/foodfex.png" alt="FoodFex" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/foodazon.png" alt="Foodazon" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/advanta.png" alt="Advanta Africa Ltd" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/caterninja.png" alt="Caterninja" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/flatworld.png" alt="Flatworld" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/foodpine.png" alt="FoodPine" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/freshhomefood.png" alt="Freshhomefood" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/shuneez.png" alt="Shuneez" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/pickapp.png" alt="Pickapp" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/ju3an.png" alt="Ju3an" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/juaan.png" alt="Juaan" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/miugodo.png" alt="Miugodo" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/dukani.png" alt="Dukani" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/homey.png" alt="Homey" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/tiffinboss.png" alt="Tiffonboss" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/ghiza.png" alt="Ghiza" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/florist.png" alt="florist" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/fuelFill.png" alt="FuelFill" width="180" height="80" layout="responsive"></amp-img></li>
      <li><amp-img src="<?php echo $baseurl;?>images/clients/alo-order.png" alt="Alo Order" width="180" height="80" layout="responsive"></amp-img></li>
    </ul>  
  </div> <!--container-->
</section> <!--clients-->

<?php include ('../inc/footer.php'); ?>