/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Country', {
    countryId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'country_id'
    },
    countryKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'country_key'
    },
    countryName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'country_name'
    },
    isoCountryCode: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'iso_country_code'
    },
    currencyCode: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'currency_code'
    },
    currencySymbol: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'currency_symbol'
    },
    countryStatus: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'country_status'
    },
    default: {
      type: DataTypes.INTEGER(5),
      allowNull: false,
      defaultValue: '0',
      field: 'default'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    slug: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'slug'
    }
  }, {
    tableName: 'ss16_country'
  });
};
