import React, {Component } from 'react';
import Navi from './nav';
import { Button } from 'react-bootstrap';
import Dropdown from 'react-bootstrap/Dropdown'
import Modal from 'react-bootstrap/Modal';
import ModalDialog from 'react-bootstrap/ModalDialog';
import ModalHeader from 'react-bootstrap/ModalHeader';
import ModalTitle from 'react-bootstrap/ModalTitle';
import ModalBody from 'react-bootstrap/ModalBody';
import ModalFooter from 'react-bootstrap/ModalFooter';
class Header extends Component{
	constructor(props){
		super(props);
		 this.state = {show: false};
		  this.showModal = this.showModal.bind(this);
    this.hideModal = this.hideModal.bind(this);
	}	

 showModal() {
        this.setState({show: true});
    }

    hideModal() {
        this.setState({show: false});
    }


	render(){
		return(

			<header>
				<Navi/>
				<div className="head">
				 	<h1>WE design ,<br/> we create</h1>
					
				 	<p>Interger posurere leo non</p>
				 	<div><a className="contact" href="#">Contact Us</a></div>
				 	<Dropdown>
  <Dropdown.Toggle variant="success" id="dropdown-basic">
    Dropdown Button
  </Dropdown.Toggle>

  <Dropdown.Menu>
    <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
    <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
    <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>
				 </div>	

      <Button bsStyle="primary" onClick={this.showModal}>
            Launch demo modal
          </Button>

          <Modal
           
            show={this.state.show}
            onHide={this.hideModal}
            dialogClassName="custom-modal"
          >

            <Modal.Header closeButton>
              <Modal.Title id="contained-modal-title-lg">Modal heading</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <h4>Wrapped Text</h4>
              <p>Blah</p>
            </Modal.Body>
            <Modal.Footer>
              <Button onClick={this.hideModal}>Close</Button>
            </Modal.Footer>  
          </Modal>
			</header>

			);
	}

}

export default Header;