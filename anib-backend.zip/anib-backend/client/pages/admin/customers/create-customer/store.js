'use strict';
const Constants = require('../create-customer/constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../helpers/parse-validation');
const Redux = require('redux');

const initialState = {
    show: false,
    loading: false,
    error: undefined,
    nationality_hydrated: true,
    hasError: {},
    help: {},
    name: '',
    email: '',
    mobile_no: '',
    nationality: '',
    gender: '',
    dob: '',
    nationality_data: [],
    roles: [],
    users: [],
};
const reducer = function (state = initialState, action) {

    if(action.type === Constants.GET_USER_TYPES) {

        return ObjectAssign({}, state, {
            roles: []
        });
    }

    if(action.type === Constants.GET_USER_TYPES_RESPONSE) {
        
        return ObjectAssign({}, state, {
            roles: action.response.data
        });
    }

    if(action.type === Constants.GET_USERS) {

        return ObjectAssign({}, state, {
            users: []
        });
    }

    if(action.type === Constants.GET_USERS_RESPONSE) {
        
        return ObjectAssign({}, state, {
            users: action.response.data
        });
    }

    if (action.type === Constants.CREATE_NEW) {
        return ObjectAssign({}, state, {
            loading: true,
            name: action.request.data.name,
            email: action.request.data.email,
            mobile_no: action.request.data.mobile_no,
            nationality: action.request.data.nationality
        });
    }

    if (action.type === Constants.CREATE_NEW_RESPONSE) {
        const validation = ParseValidation(action.response);
        const stateUpdates = {
            loading: false,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        };

        return ObjectAssign({}, state, stateUpdates);
    }
    

    if (action.type === Constants.GET_NATIONALITY_RESULTS) {
        return ObjectAssign({}, state, {
            nationality_hydrated: false,
        });
    }

    if (action.type === Constants.UPDATE_DOB) {
        return ObjectAssign({}, state, {
            dob: action.date,
        });
    }

    if (action.type === Constants.GET_NATIONALITY_RESULTS_RESPONSE) {

        const validation = ParseValidation(action.response);
        
        const stateUpdates = {
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            nationality_data: action.response ? action.response.data : [],
            nationality_hydrated: true,
        };

        return ObjectAssign({}, state, stateUpdates);
    }

    return state;
};

module.exports = Redux.createStore(reducer);
