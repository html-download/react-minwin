'use strict';
const Actions = require('./actions');
const CommonFunctions = require('../../../../../client/helpers/common-functions');
const PropTypes = require('prop-types');
const React = require('react');
const TextControl = require('../../../../components/form/text-control.jsx');

const propTypes = {
    id: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    loading: PropTypes.bool,
    deal_id:PropTypes.string
};


class DetailsForm extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};

        this.state = {
            id: props.id,
            customer_name: props.customer_name,
            vehicle: props.vehicle,
            cc_emails: props.cc_emails,
            bcc_emails: props.bcc_emails,
            editable_field: props.editable_field,
            vehicle_brand:props.vehicle_brand
        };

        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);
        this.getNationalityOptions = this.getNationalityOptions.bind(this);
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            id: nextProps.id,
            customer_name: nextProps.customer_name,
            vehicle: nextProps.vehicle,
            cc_emails: nextProps.cc_emails,
            bcc_emails: nextProps.bcc_emails,
            editable_field: nextProps.editable_field
        });

        //(this.input[nextProps.editable_field]) ? this.input[nextProps.editable_field].focus() : null;
    }

    submitCustomer(event, field_name) {

        event.preventDefault();
        event.stopPropagation();
        const value = (this.input[field_name]) ? this.input[field_name].value() : undefined;
        const id = this.props.deal_id;
        const data = {
            'attribute_key': field_name,
            'attribute_value': value
        };
        value ? Actions.saveDealDetails(id, data) : null;
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();
    }

    addEditable(field) {

        Actions.addEditable(field)
    }

    getUpdateButton(field){

        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field) }} className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) }} className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        );
    }

    getLabelContent(name, field, value, type) {

        return (
            <div className="form-gp">
                <label className="side">{name}</label>
                <div className="side-input">
                    {
                        (value && value !== '') ? (
                            <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{value}</a>
                        ) : (
                            <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable(field) }} >+Add</a>
                        )
                    }
                </div>
            </div>
        );
    }

    getNationalityOptions() {

        const nationalitys = this.props.nationality_data;
        
        if (nationalitys.length === 0) {
            return null;
        }
        const data = nationalitys.map((nationality, index) => {
            
            return <option
                key={`nationality-option-${index}`}
                value={nationality.nationality_key}
                data-tokens={`${nationality.nationality_name}`}>
                {`${nationality.nationality_name}`}
            </option>;
        });

        return data;
    }

    render() {

        const formElements = <fieldset>            
            {
                this.state.editable_field === 'cc_emails' ? (
                    <TextControl
                        ref={(c) => (this.input.cc_emails = c)}
                        name="cc_emails"
                        label="CC Emails"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('cc_emails')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.cc_emails}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('CC Emails', 'cc_emails', this.state.cc_emails, 'text')
            }
            
            {
                this.state.editable_field === 'bcc_emails' ? (
                    <TextControl
                        ref={(c) => (this.input.bcc_emails = c)}
                        name="bcc_emails"
                        label="BCC Emails"
                        hasError={this.props.hasError.bcc_emails}
                        help={this.props.help.bcc_emails}
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{ 'form-group': true, 'form-gp': true }}
                        labelClasses={{ 'control-label': false, 'side': true }}
                        inputClasses={{ 'form-control': true, 'add-forms': true }}
                        appendElement={this.getUpdateButton('bcc_emails')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.bcc_emails}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('BCC Emails', 'bcc_emails', this.state.bcc_emails, 'text')
            }

        </fieldset>;

        const {
            customer_name,
            vehicle_brand
        } = this.props;
        
        const name = (customer_name && customer_name !== '') ? CommonFunctions.toTitleCase(customer_name, 2) + ' (' + vehicle_brand + ')' :  vehicle_brand;

        return (

            <div className={ `white-box ${!this.props.hydrated ? 'loader-tab-content' : ''}` }>
                <div className="header-box">
                    <div className="icon"><i className="fa fa-car"></i></div>
                    <h4> { name } </h4>
                </div>

                <form onSubmit={this.handleSubmit.bind(this)}>
                    {formElements}
                </form>

            </div>
        );
    }
}

DetailsForm.propTypes = propTypes;


module.exports = DetailsForm;
