/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Wishlist', {
    wishlistId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'wishlist_id'
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'customer_key'
    },
    shopKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'shop_key'
    },
    createdDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      field: 'created_date'
    }
  }, {
    tableName: 'ss16_wishlist'
  });
};
