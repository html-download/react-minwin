<?php include ('inc/header.php'); ?>

<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Knowledge Base</h1>
		<h2 class="head small wow fadeInUp">How can we help you today?</h2>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey">
	<div class="container pad0 md">
		<div class="col-sm-6">
			<div class="grid_box">
				<h3><i class="fa fa-gears"></i> App Setting</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011070-general-app-setting" target="_blank">General App Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011078-change-logo-and-favicon" target="_blank">Change Logo and Favicon</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011221-changing-the-banner-image" target="_blank">Changing the banner image</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011228-how-to-change-the-how-it-works-section-image-" target="_blank">How to change the “How it works” section image</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016450-how-to-manage-my-cart-" target="_blank">Cart Management</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011213-how-to-link-social-media-pages-" target="_blank">How to link Social Media pages</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016419-sms-setting" target="_blank">SMS Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016510-email-setting" target="_blank">Email Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016822-payment-gateway-setting" target="_blank">Payment Gateway Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016878-how-to-set-live-chat-" target="_blank">Live Chat Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000012340-how-to-add-google-analytics-license-in-website-" target="_blank">Analytics Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000012347-how-to-send-push-notifications-" target="_blank">Push Notification Setting</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011711-loyalty-point-setting" target="_blank">Loyalty Point Setting</a></li>				
				</ul>

				<h3><i class="fa fa-file-image-o"></i> Gallery</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011243-uploading-images-to-your-gallery-page" target="_blank">Uploading images to your Gallery page</a></li>
				</ul>

				<h3><i class="fa fa-gears"></i> Master</h3>
				<ul class="reset knowledge">									
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011253-how-to-add-branches-" target="_blank">How to add branch?</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011552-setup-pickup-delivery-options" target="_blank">Setup Pickup/Delivery options</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011553-how-to-set-delivery-area-" target="_blank">How to set delivery area</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011556-setting-up-restaurants-operational-hours" target="_blank">Setting up restaurants operational hours</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011558-adding-category-list" target="_blank">Adding Category list</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011602-how-to-create-ingredients-" target="_blank">How to create ingredients</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016464-adding-coupon-details" target="_blank">Adding Coupon details</a></li>					
				</ul>
			</div>
		</div>
		
		<div class="col-sm-6">
			<div class="grid_box">
				<h3><i class="fa fa-list-ul"></i> Items</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011597-add-new-items-to-the-menu" target="_blank">Add new items to the menu</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011657-how-to-group-ingredients-" target="_blank">How to group ingredients</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011700-how-to-add-your-grouped-ingredients-to-the-items-" target="_blank">How to add your grouped ingredients to the items</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011221-changing-the-banner-image" target="_blank">Changing the banner image</a></li>										
				</ul>
				
				<h3><i class="fa fa-users"></i> Users</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016445-how-to-create-new-user-in-the-admin-back-end-" target="_blank">How to create new user in the admin back end</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000016486-newsletter-management" target="_blank">Newsletter management</a></li>
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000012354-managing-customer-feedbacks" target="_blank">Managing Customer Feedbacks</a></li>										
				</ul>

				<h3><i class="fa fa-list-ul"></i> Orders</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000011718-how-to-accept-or-decline-orders-" target="_blank">How to accept or decline orders</a></li>
				</ul>
				
				<h3><i class="fa fa-truck"></i> Delivery Boy</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000012371-how-to-add-delivery-staff-to-the-application-" target="_blank">How to add delivery staff to the application</a></li>
				</ul>
				
				<h3><i class="fa fa-file-text-o"></i> CMS Pages</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000012352--how-to-manage-cms-page-" target="_blank">How to manage CMS Page</a></li>
				</ul>
				
				<h3><i class="fa fa-area-chart"></i> Report</h3>
				<ul class="reset knowledge">
					<li><a href="https://ontabee.freshdesk.com/support/solutions/articles/42000012349-how-to-generate-reports-" target="_blank">How to generate reports</a></li>
				</ul>
			</div> <!--grid_box-->
		</div>
	</div> <!--container-->
</section>

<?php include('inc/footer.php');?>