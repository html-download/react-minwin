'use strict';
const FilterFormHoc = require('../../../../pages/admin/components/filter-form-hoc.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const SelectControl = require('../../../../components/form/select-control.jsx');
const TextControl = require('../../../../components/form/text-control.jsx');


const propTypes = {
    linkInputState: PropTypes.func,
    linkSelectState: PropTypes.func,
    loading: PropTypes.bool,
    state: PropTypes.object
};
const defaultValues = {
    'search': '',
    'sort': 'id',
    'per-page': '5',
    'page': '1'
};


class FilterForm extends React.Component {
    render() {

        return (
            <div className="row header_filter">
                <div className="col-sm-6">
                    <SelectControl
                        name="per-page"
                        label="Limit"
                        value={this.props.state['per-page']}
                        onChange={this.props.linkSelectState}
                        disabled={this.props.loading}>

                        <option value="5">5 items</option>
                        <option value="10">10 items</option>
                        <option value="20">20 items</option>
                        <option value="50">50 items</option>
                        <option value="100">100 items</option>
                    </SelectControl>
                </div>                
                <div className="col-sm-6 rightEnd">
                    <TextControl
                        name="search"
                        label="Search"
                        value={this.props.state.search}
                        onChange={this.props.linkInputState}
                        disabled={this.props.loading}
                    />
                </div>
            </div>
        );
    }
}

FilterForm.propTypes = propTypes;


module.exports = FilterFormHoc(FilterForm, defaultValues);
