'use strict';
const CreateNew = require('./reducers/create-new');
const Map = require('./reducers/map');
const Redux = require('redux');


module.exports = Redux.createStore(
    Redux.combineReducers({
        createNew: CreateNew,
        map : Map
    })
);
