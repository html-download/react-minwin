'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const Paginations = require('../../../../../helpers/paginations');

const initialState = {
    loading: false,
    view_modal_data: {},
    is_view_policy: false
};

const reducer = function (state = initialState, action) {

    if (action.type === Constants.GET_POLICY) {
        
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true
        });
    }

    if (action.type === Constants.GET_POLICY_RESPONSE) {        
        return ObjectAssign({}, state, {            
            loading: false,
            view_modal_data: action.response.data ? action.response.data : {},
            is_view_policy: true
        });
    }

    if (action.type === Constants.SHOW_VIEW_MODAL) {
        return ObjectAssign({}, state, {
            is_view_policy: true
        });
    }

    if (action.type === Constants.HIDE_VIEW_MODAL) {
        return ObjectAssign({}, state, {
            view_modal_data: {},
            is_view_policy: false
        });
    }

    return state;
};

module.exports = reducer;