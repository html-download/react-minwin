'use strict';

const React = require('react');
/* import React from 'react'; */
/* const CheckboxTree = require('react-checkbox-tree'); */

const nodes = [{
    value: 'mars',
    label: 'Mars',
    children: [
        { value: 'phobos', label: 'Phobos' },
        { value: 'deimos', label: 'Deimos' },
    ]
}];

class Widget extends React.Component {

    /* constructor(props) {

        this.state = {
            checked: [],
            expanded: []
        };
        super(props);        
    } */

    render() {

        return (
            {/* <CheckboxTree
                nodes={nodes}
                checked={[]}
                expanded={[]}
                onCheck={checked => this.setState({ checked })}
                onExpand={expanded => this.setState({ expanded })}
            /> */}
        );

    }
}

module.exports = Widget;