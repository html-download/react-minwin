'use strict';
const Actions = require('../actions');
const Alert = require('../../../../../components/alert.jsx');
const Button = require('../../../../../components/form/button.jsx');
const ControlGroup = require('../../../../../components/form/control-group.jsx');
const LinkState = require('../../../../../helpers/link-state.js');
const Modal = require('../../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../../components/form/spinner.jsx');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const TextAreaControl = require('../../../../../components/form/textarea-control.jsx');

const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    note: PropTypes.string,
    add_modal_show: PropTypes.bool,
    note: PropTypes.string
};


class CreateNewForm extends React.Component {
    constructor(props) {

        super(props);

        this.els = {};
        this.state = {
            note: ''
        };
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            note: nextProps.note
        });
    }

    componentDidUpdate() {

        if (this.props.add_modal_show && this.state.note && this.state.note.length === 0) {
            this.els.note.focus();
        }
    }

    onSubmit(event) {

        event.preventDefault();
        event.stopPropagation();
        Actions.createNote({
            note: this.els.note.value(),
            deal_id: this.props.deal_id
        }, this.props.history);
    }

    render() {

        let alert;
        if (this.props.error) {
            alert = <Alert
                type="danger"
                message={this.props.error}
            />;
        }

        const formElements = <fieldset>
            {alert}
            <div className="form-box-horizandal">
                <TextAreaControl
                    ref={(c) => (this.els.note = c)}
                    name="note"
                    label="Note"
                    value={this.state.note}
                    onChange={LinkState.bind(this)}
                    disabled={this.props.loading}
                    groupClasses={{'rq': true}}
                    inputClasses={{'height-5': true}}
                />
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'actions': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn': true, 'btn-white': true }}
                        disabled={this.props.loading}
                        onClick={(e) => {Actions.hideNoteModal()}}>
                        Close
                    </Button>
                    <Button
                        type="submit"
                        inputClasses={{ 'btn': true, 'btn-primary': true }}
                        disabled={this.props.loading}>

                        <Spinner space="right" show={this.props.loading} />
                        Create
                    </Button>
                </ControlGroup>
            </div>
        </fieldset>;

        return (
            <Modal
                header="New Note"
                show={ this.props.note_modal_show }
                onClose={Actions.hideNoteModal}
                groupClasses={ { 'model_design1': true } }
                modalDialogClasses={ { 'modal-dialog-centered': true } }>

                <form onSubmit={this.onSubmit.bind(this)}>
                    {formElements}
                </form>
            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;


module.exports = CreateNewForm;
