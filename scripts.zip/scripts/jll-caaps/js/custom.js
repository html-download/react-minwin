//Data Tables
$(function () {
  $('.datatable').DataTable({
    'paging'      : true,
    'searching'   : true,
    'ordering'    : true
    //"scrollX": true
  })
});


    $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
    

$(function () {
  $('.datatable1').DataTable({
    'paging'      : false,
    'searching'   : false,
    'bLengthChange' : false,
    "bInfo": false,
    'ordering' : false
  })
});

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});

//Date picker
$('.datepicker').datepicker({
  autoclose: true,
});

// timepicker

$(document).ready(function(){
    $('.timepicker').mdtimepicker(); //Initializes the time picker
  });

$(document).ready(function(){
$('.files-name').change(function() {
  var i = $(this).prev('label').clone();
  var file = $('.files-name')[0].files[0].name;
  $(this).prev('label').text(file);
});
});

$('[data-toggle="popover"]').popover(); 