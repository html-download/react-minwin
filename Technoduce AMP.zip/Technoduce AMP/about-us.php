<?php include ('inc/header.php'); ?>

<section class="page_banner">
  <div class="container">
    <h1 class="animated fadeInDown">About Technoduce</h1>
    <p class="desc animated fadeInUp mb0">You’re Determined to Meet your Mission. We can Help.</p>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients find_us">
  <div class="container">
    <div class="years full_row mb30">
      <span>Years of experience</span>
      <span class="year">7+</span>
      <span>We are a team of 70+ who are dedicated to serving the customers and have been functioning in the IT industry since 2011.</span>
    </div> <!--years-->

    <div class="row facts">
      <div class="col_3">
        <span>50+</span><b>Countries</b>
      </div> <!--col_3-->
      <div class="col_3">
        <span>70+</span><b>Professionals</b>
      </div> <!--col_3-->
      <div class="col_3">
        <span>90+</span><b>Projects</b>
      </div> <!--col_3-->
      <div class="col_3">
        <span>99%</span><b>Satisfaction</b>
      </div> <!--col_3-->
    </div> <!--facts-->
  </div> <!--container-->
</section> <!--clients-->

<section class="half grey">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right">
        <h2 class="head style1">Reading the our story of </br>behind our success</h2>
        <p>Technoduce Info Solutions Pvt Ltd. is a leading Mobile Application Development Company. We are a team of 70+ who are dedicated to serving the customers and have been functioning in the IT industry since 2011. We engage in a massive endeavor of inventing and developing multiple webs and mobile applications that are suitable for all verticals of the industry supporting all the major platforms like Android, iPhone, Windows, and Blackberry.</p>
        <p class="mb30">Technoduce has a wonderful collection of products like, <b>FoodPurby, Purbis, CroplaTaxi, NectarChat</b> and more. All the products have good receipt in the market because of its uniqueness.</p>
        <p class="mb0"><a href="company/technoduce-info-solutions-private-limited-iso.pdf" target="_blank" class="btn green">Corporate profile</a></p>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="half blue white">
	<div class="container">
    <div class="row">
      <div class="col_6 pull_left">
        <h2 class="head style1">We create brand <br>new corporate identities</h2>
        <p>Here our developers choose the best technology that will suit your project such that the outcome is always a quality product. The clients of Technoduce include companies from the United States, the Arabian Gulf, Europe and more.</p>
        <div class="progress_bar mt10">
          <h5>Trustworthy <b>99%</b></h5>
          <span style="width:99%; background:#25C364"></span>
          <h5>Our Quality <b>95%</b></h5>
          <span style="width:95%; background:#ECC03F"></span>
          <h5>Our Skills <b>90%</b></h5>
          <span style="width:90%; background:#2CD6DE"></span>
          <h5>Customer Satisfaction <b>99%</b></h5>
          <span style="width:99%; background:#F048BC"></span>
        </div>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg2 video right">
    <a on="tap:video"><i class="fa fa-play"></i></a>
  </div>
</section>

<amp-lightbox id="video" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner md">
			<div class="dialog_content">
				<a on="tap:video.close" class="close"><i class="fi close"></i></a>
				<amp-youtube width="480" height="270" layout="responsive" data-param-rel="0" data-videoid="JJzpKYLXrpE"> </amp-youtube>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<section class="history text-center">
	<div class="container md">
    <h2 class="head style1 mb15">History of Technoduce</h2>
    <p class="head_desc mb30">To keep your project ideas confidential, we can sign an NDA document.</p>

    <amp-img src="<?php echo $baseurl;?>images/technoduce-logo.png" alt="technoduce" width="84" height="80" layout="responsive" style="max-width:84px; margin:0 auto"></amp-img>

    <ul class="reset history full_row">
      <li class="year"><span>2011</span></li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/bulb.png" alt="Started" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Founded</h3>
            <p>Contus was born with 2 people onboard</p>
          </div>
        </div>
      </li>
      <li class="year"><span>2012</span></li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Web & Mobile Services</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/globe.png" alt="Started" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
      </li>
      <li class="year"><span>2013</span></li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/users.png" alt="strength" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Increase in strength</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
      </li>
      <li class="year"><span>2014</span></li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Restaurant Ordering System</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/foodpurby-logo.png" alt="foodpurby" width="200" height="55" layout="responsive"></amp-img>
          </span>
        </div>
      </li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/duce-logo.png" alt="duce" width="200" height="55" layout="responsive"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Shopping cart software</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
      </li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Partnership with</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/partnership.png" alt="partnership" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
      </li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/nectarchat-logo.png" alt="nectarchat" width="200" height="55" layout="responsive"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Instant chat app</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
      </li>
      <li class="year"><span>2015</span></li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Expensive in space & strength</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/building.png" alt="space & strength" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
      </li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/iso-icon.png" alt="ISO" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Got ISO Certification</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
      </li>
      <li class="year"><span>2016</span></li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Online food ordering system</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/purbis-logo.png" alt="service expanded" width="220" height="55" layout="responsive"></amp-img>
          </span>
        </div>
      </li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/users.png" alt="strength" width="80" height="80" layout="responsive" class="icon"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Increase in strength</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
      </li>
      <li class="year"><span>2017</span></li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Taxi Dispatch Software</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/croplataxi-logo.png" alt="service expanded" width="220" height="55" layout="responsive"></amp-img>
          </span>
        </div>
      </li>
      <li class="left">
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/ontabee-logo.png" alt="service expanded" width="180" height="55" class="style1" layout="responsive"></amp-img>
          </span>
        </div>
        <div class="content">
          <div>
            <h3>Online Food Ordering System</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
      </li>
      <li class="year"><span>2018</span></li>
      <li class="right">
        <div class="content">
          <div>
            <h3>Online Grocery Shopping</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </div>
        </div>
        <div class="img">
          <span>
            <amp-img src="<?php echo $baseurl;?>images/grobino-logo.png" alt="service expanded" width="170" height="70" class="style2" layout="responsive"></amp-img>
          </span>
        </div>
      </li>
		</ul>
  </div> <!--container-->
</section>

<?php include ('inc/footer.php'); ?>