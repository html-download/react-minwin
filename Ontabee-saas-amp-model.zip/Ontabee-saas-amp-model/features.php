<?php include ('inc/header.php'); ?>

<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Start Your Online Restaurant Ordering Software Business with Ontabee</h1>
		<h2 class="head small wow fadeInUp">Build & manage your online food ordering software for free</h2>
		<img src="images/website-ordering.png" class="style1 wow fadeInUp" alt="Food Ordering System" data-wow-duration="1.2s">
	</div> <!--container-->
</div> <!--page_banner-->

<section class="style1 grey text-center">
	<div class="container">
		<h2 class="head wow fadeInUp">Our Rich Featured Online Ordering System Includes</h2>
		
		<ul class="box_type equal reset col_3">
			<li class="wow fadeInUp" data-wow-duration="1s">
				<div class="content height">
					<i class="fi cart-browser"></i>
					<h3>Website ordering system</h3>
					<p>Easily integrate our online restaurant ordering system to your website and start taking business orders.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.4s">
				<div class="content height">
					<i class="fi app"></i>
					<h3>Branded mobile app</h3>
					<p>Let your customer use their mobile app to place orders anytime anywhere. Get modernized with Ontabee.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi shop"></i>
					<h3>Unlimited outlets</h3>
					<p>You can easily manage multiple branches and take orders at one place using vendor backend.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Unlimited orders & category</h3>
					<p>You can add new orders and categories without any limit. Get access to your customer's order instantly with our online ordering system.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.4s">
				<div class="content height">
					<i class="fi responsive"></i>
					<h3>Mobile responsive</h3>
					<p>Ontabee is compatible with all major devices, providing a mobile responsive solution for your customers.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi optimize"></i>
					<h3>Sales optimized website</h3>
					<p>Get instantly build an optimized website to generate more business with our restaurant ordering system.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1s">
				<div class="content height">
					<i class="fi credit-card"></i>
					<h3>User-friendly checkout</h3>
					<p>Our restaurant ordering system has a user-friendly checkout page allowing you to maximize your conversation.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi diamond"></i>
					<h3>Advanced promo option</h3>
					<p>Our premium user gets benefitted with advanced promo option. This feature can take your business to the next level.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fa fa-mobile"></i>
					<h3>Phone call order</h3>
					<p>Admin can place an order on behalf of the customers from the backend by getting order details via phone call. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi award"></i>
					<h3>Loyalty points conversion</h3>
					<p>While customer placing an order each customer can earn loyalty points, admin can convert those loyalty points into normal money.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi money-bag"></i>
					<h3>Wallet</h3>
					<p>Digital wallet offers a feature-rich, secure, intuitive and convenient payment experience to the customer.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi clock-update"></i>
					<h3>Item time slot management</h3>
					<p>For the particular slot time the item get displayed on the front end for the customers. After that slot time, the item gets disappeared.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Update  banner from backend</h3>
					<p>The admin can add various images from backend which are showcased on the front end as a sliding banner.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Date based category setup</h3>
					<p>The particular set of a category will be displayed based on that particular date. Admin can enable or disable it from the backend. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi shop"></i>
					<h3>Branch based item setup</h3>
					<p>Admin can manage different types of items based on multiple branches. Each branch has its own item setup type.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi dinner"></i>
					<h3>Table reservation</h3>
					<p>Admin provides an option for the customer to book a table in advance to have a table available at the restaurant. So that customer doesn't have to wait. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Manage package charge</h3>
					<p>Admin offers personalized package service to customers. Those package charges are managed separately from the backend.  </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi user"></i>
					<h3>Order feedback</h3>
					<p>Admin can gather personalized feedback on orders status from customers. This feature lets you know what the customer thinks about your business. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi fry"></i>
					<h3>Comments field for allergic food</h3>
					<p>The customer is provided with the option to let know the admin about the customer’s allergenic foods. such foods can be avoided during preparation.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi app"></i>
					<h3>SMS gateway setting</h3>
					<p>The SMS gateway integration can be done from the backend by providing the SMS gateway API key details. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi credit-card"></i>
					<h3>Payment gateway setting</h3>
					<p>The Payment gateway integration can be done from the backend by providing the Payment gateway API key details. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi cart"></i>
					<h3>Cart management </h3>
					<p>Our online food ordering system’s cart management provides you to view all the carts. Its functionality to filter, view details and manage the order.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi doc"></i>
					<h3>Set Tax value</h3>
					<p>The admin can set the Tax value amount from the backend. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi cart"></i>
					<h3>Minimum cart value </h3>
					<p>The order is defined by the smallest amount or number that may be ordered in one delivery. The customer to maintain minimum value for products before checkout. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi key"></i>
					<h3>Social media login </h3>
					<p>Social media login feature helps in increasing user registration on your online food ordering system. The customer can directly sign up using social media.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Live chat setting </h3>
					<p>The live chat code can be integrated from admin back end. The complete live chat settings can be managed and monitored. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi monitor-chart"></i>
					<h3>Analytics setting</h3>
					<p>The analytics code is integrated from admin back end. The admin can keep track of statistical data of the customers entering an online food ordering website.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Send push notification </h3>
					<p>Admin can send a push notification to the customers notifying the food order status, food delivery status and any offer messages.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi globe"></i>
					<h3>Currency code management </h3>
					<p>The currency code management provides the functionality to support multiple currencies so that admin can do business internationally. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi app"></i>
					<h3>App settings </h3>
					<p>Admin can easily manage time zone, hour format, currency code, currency format, distance unit, email id, contact number, contact address, image.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi email"></i>
					<h3>E-mail setting</h3>
					<p>Smtp host, SMTP encryption, SMTP port, SMTP user name, SMTP password are maintained and managed under E-mail settings.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi list"></i>
					<h3>Ingredient group</h3>
					<p>Multiple sets of ingredients can be added under a single group named ingredient group. This ingredient group can be made enabled on the front end.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi dinner"></i>
					<h3>Add ingredient group to an item</h3>
					<p>The set of ingredient group can be added to an item. Item image, item name, category name, date & time are maintained under it. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Gallery</h3>
					<p>The food menu image, banner image, ingredient image, can be uploaded from backend, which gets displayed on the gallery page. It helps to attract the customer.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Manage image slider</h3>
					<p>The multiple banner image slider of online food ordering system can be managed from the backend. The admin can upload images anytime. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi promotion"></i>
					<h3>Newsletter subscription</h3>
					<p>Newsletter subscription feature lets to track subscribers and send the customers a message based on the pricing, offers and other details. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi user"></i>
					<h3>Rating</h3>
					<p>The customer reviews and ratings help admin to understand how customers feel about their food ordering system and their menu. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi user"></i>
					<h3>Manage delivery boy</h3>
					<p>The admin can manage the delivery boy. The delivery boy profile details, branch, phone number, email id are managed here. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Manage CMS page</h3>
					<p>The content management system is an application that is used to manage content, which can be easily created, edited and published. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi monitor1"></i>
					<h3>Reports</h3>
					<p>The admin can track report based on the hour wise, total order, total sales. The reports can be easily exported to excel, jpg or png format. </p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Stock availability</h3>
					<p>The admin can easily get to know the availability of the stock status details. Whether the stock is available or not.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>QR Code</h3>
					<p>It is the simplest and smart way to navigate the item and plan order from customer mobile app for saving customer's time.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.8s">
				<div class="content height">
					<i class="fi setting"></i>
					<h3>Preorder</h3>
					<p>To overcome your competition and save customers time by providing your customer to order prior. Pre-order feature attracts and satisfy customers.</p>
				</div>
			</li>
			<?php /*
			<li class="wow fadeInUp" data-wow-duration="1s">
				<div class="content height">
					<i class="fi fb-line"></i>
					<h3>Facebook ordering system</h3>
					<p>Start getting orders from your Facebook with just one click. Ontabee can easily integrate Facebook ordering system into your website.</p>
				</div>
			</li>
			*/ ?>
		</ul>

		<div class="clear_all"></div>
		<h2 class="head mt30 full_row wow fadeInUp">Extensive features for added benefits</h2>
		<p>Get detailed feedback from your customer directly with your online ordering software.</p>

		<ul class="reset timeline">
			<li>
				<i class="fi money-bag wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">No Commission</h2>
					<p>With your own online ordering system, you don't have to pay commission to the third party for each & every order.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi cloud-server wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Get Online</h2>
					<p>Your online ordering website for your restaurant. Your app. You can get in your own brand name.</p>
				</div>
			</li>
			<li>
				<i class="fi monitor2 wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Backend Solution</h2>
					<p>The restaurant can manage all your orders & bill smoothly, everything integrated into one place.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi map-location wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Multiple location selections</h2>
					<p>Each restaurant(outlet) can fix multiple locations for delivery services as per their available.</p>
				</div>
			</li>
			<li>
				<i class="fi clock-update wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Multiple time slots</h2>
					<p>Each restaurant (Outlet) can fix multiple time slot for a particular location for the delivery purpose.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi slider wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Multiple access control</h2>
					<p>Admin (Restaurant Owner) can allocate each to the multiple branches which like Branch Manager, Branch Supervisor.</p>
				</div>
			</li>
			<li>
				<i class="fi globe wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Multi-Language</h2>
					<p>Ontabee provides you the system with 15+ language.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi alarm wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Order Notification</h2>
					<p>You will receive an instant notification to your dashboard, once customer place an order.</p>
				</div>
			</li>
		</ul>
	</div>
</section> 
<section class="text-center">
	<h2 class="head wow fadeInUp">I am interested, Want to know the price?</h2>
	
	<a href="<?php echo $baseurl;?>pricing" class="btn">Pricing & Plans</a>
</section><!--page_banner-->

<?php include('inc/footer.php');?>