<?php include ('inc/header.php'); ?> 
 
<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">For big and small companies</h1>
		<h2 class="head small wow fadeInUp">Start A Free Trial, Before You Buy, No Credit Card Required, No hidden fees, Immediate access</h2>
	</div> <!--container-->
</div> <!--page_banner--> 

<section class="grey text-center">
	<div class="container md">
		<div class="plans full_row">
			<a class="monthly active">Monthly</a>
			<a class="annual">Annual <span>Save Two Months Fee</span></a>
			
		</div>
		
		<div class="price_table one">
			<h2>Free</h2>
			<p class="desc">No Credit Card Required, No Contracts</p>
			<ul class="reset">
				<li class="price">
					<span class="symbol">US$</span> 0
					<h4>Web Only with Single Outlet (Life Time)</h4>
				</li>
				<li>
					<p>&nbsp;</p>
					<span class="value">US$ 0</span>
					<h3>App Setup Cost</h3>					
					<p>&nbsp;</p>
				</li>
				<li>
					<h3>Single Outlet</h3>
					<p>Manage single branch and take orders.</p>
				</li>
				<li>
					<span class="value">Unlimited</span>
					<h3>Unlimited Orders</h3>
					<p>Create any number of orders with no extra charge.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Integrate Live Chat</h3>
					<p>Integrate third-party live chat to communicate with your customers.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Basic Reports</h3>
					<p>Take better decision with the reports generated from Ontabee.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Loyalty Point Conversion</h3>
					<p>Offer your customers some loyalty points of your choice.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Order for Later</h3>
					<p>Allow your customer to schedule order later.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Website Ordering</h3>
					<p>Get sales optimized website ordering.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Mobile Responsive</h3>
					<p>Our restaurant ordering system easily fits on any device.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Coupon</h3>
					<p>Attract your customers with exciting coupon code on their orders.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Ratings</h3>
					<p>Allow your customer to rate and review your restaurant.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Custom Domain</h3>
					<p>You can use your own domain.</p>
				</li>
				
				<li>
					<i class="fi ban"></i>
					<h3>Creditcard Service</h3>
					<p>Connecting restaurant ordering system with your payment gateway.</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Order receiving app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Delivery app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Powered By</h3>
					<p>&nbsp;</p>
					<p>Removing "Ontabee" brand name from the footer of the site.</p>
					<p>&nbsp;</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Customer App in Your Brand name <span class="text-reset">(Android & iPhone)</span></h3>
					<p>Your customer can order from both <span class="text-reset">(Android & iPhone)</span></p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Google Map API</h3>
					<p>API Should be provided by the client.</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Customer support</h3>
					<p>Mail support only.</p>
				</li>
			</ul>
			<a href="<?php echo $baseurl;?>signup" class="btn grey">Start My Free Website Now</a>
		</div><!--price_table-->
		
		<?php /*
		<div class="price_table two">
			<h2>Starter</h2>
			<p class="desc">Web + Customer App</p>
			<ul class="reset">
				<li class="price">
					<span class="symbol">$</span> 59 <span class="usd">USD</span>
					<h4>Per outlet / Month</h4>
				</li>
				<li>
					<span class="value">$500</span>
					<h3>Setup Cost</h3>
					<p>Once we received second month payment, we will refund setup cost in the same month.</p>
				</li>
				<li>
					<span class="value">Unlimited</span>
					<h3>Outlet</h3>
					<p>Manage multiple branches and take orders.</p>
				</li>
				<li>
					<span class="value">Unlimited</span>
					<h3>Unlimited Orders</h3>
					<p>Create any number of orders with no extra charge.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Integrate Live Chat</h3>
					<p>Integrate third-party live chat to communicate with your customers.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Basic Reports</h3>
					<p>Take better decision with the reports generated from Ontabee.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Photos in Menu</h3>
					<p>Upload photos of the food to make menu looks better.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Order for Later</h3>
					<p>Allow your customer to schedule order later.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Website Ordering</h3>
					<p>Get sales optimized website ordering.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Mobile Responsive</h3>
					<p>Our restaurant ordering system easily fits on any device.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Custom Domain</h3>
					<p>You can use your own domain.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Creditcard Service</h3>
					<p>Connecting restaurant ordering system with your payment gateway.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>FAQ</h3>
					<p>Get proactive search support from our FAQ.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Ratings</h3>
					<p>Allow your customer to rate and review your restaurant.</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Order receiving app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li class="mh">
					<i class="fi ban"></i>
					<h3>Delivery app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Powered By</h3>
					<p>Removing "Ontabee" brand name from the footer of the site.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Customer App in Your Brand name (Android & iPhone)</h3>
					<p>Your customer can order from both Android & iPhone.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Free Printer <span class="tag">New</span></h3>
					<p>The free printer is provided for only annual plan user.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Customer support</h3>
					<p>Mail and instant WhatsApp support for the premium user. *</p>
				</li>
			</ul>
			<a href="<?php echo $baseurl;?>signup" class="btn">Get Started</a>
		</div><!--price_table-->
		*/ ?>
		
		<div class="price_table three">
			<h2>Premium</h2>
			<p class="desc">Web + Customer App + Delivery App</p>
			<ul class="reset">
				<li class="price">
					<div id="monthly">
						<span class="symbol">US$</span> <?php echo $price;?> <span class="usd">/ Month</span>
					</div>
					<h4>Per Outlet</h4>
				</li>
				<li>
					<span class="value">US$ <?php echo $setupprice;?></span>
					<h3>App Setup Cost (One Time Cost)</h3>
					<p>We do change the logo, color code, and contact details then deploy it on our server. We won't add the items.</p>
				</li>
				<li>
					<h3>Multiple Outlet (Branch)</h3>
					<p>Manage multiple branches and take orders.</p>
				</li>
				<li>
					<span class="value">Unlimited</span>
					<h3>Unlimited Orders</h3>
					<p>Create any number of orders with no extra charge.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Integrate Live Chat</h3>
					<p>Integrate third-party live chat to communicate with your customers.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Basic Reports</h3>
					<p>Take better decision with the reports generated from Ontabee.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Loyalty Point Conversion</h3>
					<p>Offer your customers some loyalty points of your choice.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Order for Later</h3>
					<p>Allow your customer to schedule order later.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Website Ordering</h3>
					<p>Get sales optimized website ordering.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Mobile Responsive</h3>
					<p>Our restaurant ordering system easily fits on any device.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Coupon</h3>
					<p>Attract your customers with exciting coupon code on their orders.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Ratings</h3>
					<p>Allow your customer to rate and review your restaurant.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Custom Domain</h3>
					<p>You can use your own domain.</p>
				</li>
				
				<li>
					<i class="fi tick"></i>
					<h3>Creditcard Service</h3>
					<p>Connecting restaurant ordering system with your payment gateway.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Order receiving app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Delivery app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Powered By</h3>
					<p>Removing "Ontabee" brand name from the footer of the site. Ontabee brand name will be displayed in the footer of splash screen in mobile apps.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Customer App in Your Brand name <span class="text-reset">(Android & iPhone)</span></h3>
					<p>Your customer can order from both <span class="text-reset">(Android & iPhone)</span></p>
				</li>				
				<li class="mh">
					<i class="fi tick"></i>
					<h3>Google Map API</h3>
					<p>API Should be provided by the client.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Customer support</h3>
					<p>Mail and Instant WhatsApp support.</p>
				</li>
			</ul>
			<a href="<?php echo $baseurl;?>signup" class="btn">Start My Free Trial</a>
		</div><!--price_table-->				
		
		<?php /*
		<div class="price_table three">
			<h2>Enterprise</h2>
			<p class="desc">Web + Customer App + Delivery App</p>
			<ul class="reset">
				<li class="price">
					<div id="annual">
						<span class="symbol">$</span> 69 <span class="usd">/ Month</span>
					</div>
						<h4>Upto 10 Outlet</h4>					
				</li>
				<li>
					<span class="value">$200</span>
					<h3>Setup Cost</h3>
					<p>Once we received second month payment, we will refund setup cost in the same month.</p>
				</li>
				<li>
					<h3>Multiple Outlet (Branch)</h3>
					<p>Manage multiple branches and take orders.</p>
				</li>
				<li>
					<span class="value">Unlimited</span>
					<h3>Unlimited Orders</h3>
					<p>Create any number of orders with no extra charge.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Integrate Live Chat</h3>
					<p>Integrate third-party live chat to communicate with your customers.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Basic Reports</h3>
					<p>Take better decision with the reports generated from Ontabee.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Photos in Menu</h3>
					<p>Upload photos of the food to make menu looks better.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Order for Later</h3>
					<p>Allow your customer to schedule order later.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Website Ordering</h3>
					<p>Get sales optimized website ordering.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Mobile Responsive</h3>
					<p>Our restaurant ordering system easily fits on any device.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Custom Domain</h3>
					<p>You can use your own domain.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Creditcard Service</h3>
					<p>Connecting restaurant ordering system with your payment gateway.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>FAQ</h3>
					<p>Get proactive search support from our FAQ.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Ratings</h3>
					<p>Allow your customer to rate and review your restaurant.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Order receiving app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Delivery app for Android</h3>
					<p>Your delivery staff gets an app on Android platform.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Powered By</h3>
					<p>Removing "Ontabee" brand name from the footer of the site.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Customer App in Your Brand name (Android & iPhone)</h3>
					<p>Your customer can order from both Android & iPhone.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Free Printer <span class="tag">New</span></h3>
					<p>The free printer is provided for only annual plan user.</p>
				</li>
				<li>
					<i class="fi tick"></i>
					<h3>Customer support</h3>
					<p>Mail and Instant WhatsApp support.</p>
				</li>
			</ul>
			<a href="<?php echo $baseurl;?>signup" class="btn grey">Get Started</a>
		</div><!--price_table-->
		*/ ?>
</section>

<section class="text-center pt0 grey">
	<div class="container">
		<h2 class="head wow fadeInUp">Above 5 Outlet?</h2>
		<p class="wow fadeInUp">The price per outlet decreases when the outlet count increases.</p>
		<a data-toggle="modal" data-target="#modal_form" class="btn wow fadeInUp">Get Custom Price</a>
	</div> <!--container-->
</section>

<?php include('inc/footer.php');?>