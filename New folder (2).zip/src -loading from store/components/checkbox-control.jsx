import React, { Component } from "react";
import ControlGroup from "../components/control-group.jsx";

class CheckboxControl extends Component {
  constructor(props) {
    super(props);
  }

  value() {
    return this.name.checked;
  }

  checked() {
    return this.name.checked;
  }

  render() {
    return (
      <ControlGroup groupClasses={this.props.groupClasses}>
       <label htmlFor={this.props.id} class="switchup label">
                      
  <input
          ref={c => (this.name = c)}
          type={this.props.type}
          name={this.props.name}
          className={this.props.className}
          id={this.props.id}
          onChange={this.props.onChange}
          defaultChecked = {this.props.checked}

        />
                        {this.props.label}
                        <span class="slider round"></span>
                    </label>
      
      </ControlGroup>
    );
  }
}

export default CheckboxControl;
