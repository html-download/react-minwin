'use strict';
const Store = require('./store');
const Constant =  require('./constants');
const ApiActions = require('../../../../../../actions/api');
const CommonHelper = require('../../../../../../helpers/common-functions');

class Actions {
    
    static toggleQuote() {
            
        Store.dispatch({
            type : Constant.TOGGLE_QUOTE
        });
    }

    static getDealQuote(id) {

        if (id) {
            this.getDealQuoteDocument(id);
            ApiActions.get(
                `/deal-quote/${id}`,
                undefined,
                Store,
                Constant.GET_DEAL_QUOTE_DETAILS,
                Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE
            );
        }        
    }

    static getProduct() {

        ApiActions.get(
            '/underwriter',
            undefined,
            Store,
            Constant.GET_PRODUCT_DETAILS,
            Constant.GET_PRODUCT_DETAILS_RESPONSE
        );
    }

    static getDealQuoteDocument(id) {
        
        ApiActions.get(
            `/deal-quote-document?deal_quote_id=${id}`,
            undefined,
            Store,
            Constant.GET_DEAL_QUOTE_DOCU_DETAILS,
            Constant.GET_DEAL_QUOTE_DOCU_DETAILS_RESPONSE
        );
    }

    static saveQuoteDetails(data) {
        
        ApiActions.post(
            '/deal-quote',
            data,
            Store,
            Constant.SAVE_QUOTE_DETAILS,
            Constant.SAVE_QUOTE_DETAILS_RESPONSE
        );
    }

    static deleteQuoteDocument(deal_quote_document_key,quote_key) {

        ApiActions.delete(
            `/deal-quote-document/${deal_quote_document_key}`,
            undefined,  
            Store,
            Constant.DELETE_QUOTE_DOCUEMENT_DETAILS,
            Constant.DELETE_QUOTE_DOCUEMENT_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.getDealQuoteDocument(quote_key);
                    }
                }
            }
        );
    }

    static updateQuoteDetails(choosePolicy, id, data, toggle, updateOrderId) {

        ApiActions.post(
            '/policy/choose-policy',
            choosePolicy,
            Store,
            Constant.CHOOSE_POLICY_DETAILS,
            Constant.CHOOSE_POLICY_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        
                        updateOrderId(false);
                        if (id) {
                            ApiActions.put(
                                `/deal-quote/${id}`,
                                data,
                                Store,
                                Constant.UPDATE_QUOTE_DETAILS,
                                Constant.UPDATE_QUOTE_DETAILS_RESPONSE,
                                (err, response) => {

                                    if (!err) {
                                        if (response.status === 200) {
                                            toggle(4 , false, id);
                                            CommonHelper.windowScroll();
                                        }
                                    }
                                }
                            );
                        }
                    }
                }
            }
        );
    }

    static updateDate(date, field) {
            
        Store.dispatch({
            type : Constant.UPDATE_DATE,
            date: date,
            field: field
        });
    }        

    static sendQuoteMail(data, toggle) {

        ApiActions.post(
            '/deal-quote/send',
            data,
            Store,
            Constant.SAVE_DEAL_QUOTE_DETAILS,
            Constant.SAVE_DEAL_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(4 , false, data.deal_quote_id);
                        CommonHelper.windowScroll();
                    }
                }
            }
        );
    }


    static openQuoteModal(deal_quote_key,handleSumbit) {
        
        Store.dispatch({
            type : Constant.OPEN_QUOTE_MODAL,
            deal_quote_key: deal_quote_key,
            submit_event: handleSumbit
        });
    }

    static hideQuoteModal() {

        Store.dispatch({
            type : Constant.HIDE_QUOTE_MODAL,
            deal_quote_key: undefined,
            submit_event: undefined
        });
    }
    
}

module.exports = Actions;