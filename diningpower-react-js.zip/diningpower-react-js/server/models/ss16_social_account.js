/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16SocialAccount', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'user_id'
    },
    provider: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'provider'
    },
    clientId: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'client_id'
    },
    data: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'data'
    }
  }, {
    tableName: 'ss16_social_account'
  });
};
