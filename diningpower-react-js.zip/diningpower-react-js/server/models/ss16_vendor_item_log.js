/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorItemLog', {
    logId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'log_id'
    },
    itemId: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'item_id'
    },
    prevItemName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'prev_item_name'
    },
    newItemName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'new_item_name'
    },
    menuId: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'menu_id'
    },
    headerId: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'header_id'
    },
    actionScenario: {
      type: DataTypes.ENUM('Created','Edited','Attached','Approved','Restored','Deleted','Cloned'),
      allowNull: false,
      field: 'action_scenario'
    },
    scenarioDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'scenario_datetime'
    },
    doneBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'done_by'
    }
  }, {
    tableName: 'ss16_vendor_item_log'
  });
};
