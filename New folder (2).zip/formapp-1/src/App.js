import React, { Component } from 'react';
import {Container, Row, Col} from 'reactstrap';



import FormContainer from './components/Formcontainer.jsx';

class App extends Component {
  render() {
    return (
      <Container>
        <Row>
        <Col xs="12">
        <div className="App">
          <h3>Student Form</h3>
           <FormContainer />
        </div>
        </Col>
       
       </Row>
      </Container>
    );
  }
}

export default App;
