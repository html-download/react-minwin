'use strict';
const Actions = require('./actions');
const CActions = require('../actions');
const Alert = require('../../../../../components/alert.jsx');
const Button = require('../../../../../components/form/button.jsx');
const ControlGroup = require('../../../../../components/form/control-group.jsx');
const DateHelper = require('../../../../../helpers/date-time');
const LinkState = require('../../../../../helpers/link-state.js');
const Modal = require('../../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../../components/form/spinner.jsx');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const Store = require('./store');
const TextControl = require('../../../../../components/form/text-control.jsx');
const TextArea = require('../../../../../components/form/textarea-control.jsx');
import { Form, FormGroup, Label, Input, FormText } from 'reactstrap';

import BigCalendar from 'react-big-calendar';
import moment from 'moment-timezone';
const localizer = BigCalendar.momentLocalizer(moment);

const dummyEvents = [
    {
      allDay: false,
      end: new Date('April 26, 2019 22:00:00'),
      start: new Date('April 26, 2019 19:10:00'),
      title: 'Parambariyam Dinner',
    },

     {
      allDay: true,      
      title: 'Task',
      start: new Date(),
      end: new Date('April 26, 2028 19:50:00'),
    }
    
  ];


const propTypes = {    
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,    
    show: PropTypes.bool,

    title: PropTypes.string,
    datetime: PropTypes.string,
    notes: PropTypes.string,
    deal_id: PropTypes.number,
    customer_id: PropTypes.number,
    is_done: PropTypes.number,
};



class CreateNewForm extends React.Component {
    constructor(props) {
        
        
        super(props);
        this.els = {};

        Actions.getDealResults();
        Actions.getCustomerResults();        

        this.state = Store.getState();

        this.datePicker = this.datePicker.bind(this);
        this.updateEvents = this.updateEvents.bind(this);
    }

    componentDidMount() {
        
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    componentDidUpdate(prevProps, prevState) {
        
        if (prevState.task_date !== this.state.task_date || prevState.task_time !== this.state.task_time) {

            this.updateEvents();
        }
    }

    componentWillReceiveProps() {                

        this.setState({
            show : this.props.show
        });

    }

    onStoreChange() {

        this.setState(Store.getState());
    }        

    onSubmit(event) {
                                
        event.preventDefault();
        event.stopPropagation();                
        Actions.createNew({
            task_title: this.els.task_title.value(),
            task_date: DateHelper._getDbFormat(this.state.task_date),
            task_time: DateHelper._getDbTimeFormat(this.state.task_time),
            duration: this.els.duration.value(),
            note: this.els.note.value(),
            task_type_id: (!this.props.deal_id) ? this.els.task_type_id.value() : this.props.deal_id,
            assigned_user_id: this.els.assigned_user_id.value(),
            task_status: 1,
        }, this.props.history, this.props.onCreate,event);
    }

    getDealsOptions() {
        
        
        let deals = this.state.deal_data;        
        if (deals.length === 0 || deals.length == undefined) { 
            return null;
        }                
        let data = deals.map((deals, index) => {
            return <option 
                        key={`deal-option-${index}`} 
                        value={deals.deal_key}
                        data-tokens={`${deals.deal_number}`}>
                        {`${deals.deal_number}`}
                    </option>;
        });

        return data;
    }


    getCustomerOptions() {
        let customers = this.state.customer_data ? this.state.customer_data : [];                
        
        if (customers.length === 0) { 
            return null;
        }        
        let data = customers.map((customer, index) => {
            return <option 
                        key={`customer-option-${index}`}
                        value={customer.user_key}
                        data-tokens={`${customer.first_name} ${customer.last_name}`}>
                        {`${customer.first_name} ${customer.last_name}`}
                    </option>;
        });
        return data;
    }    


    datePicker(date,field) {
        
        Actions.datePicker(date,field);
    }

    updateEvents() {
        const task_title = this.els.task_title.value();
        const task_date = this.state.task_date;
        const task_time = this.state.task_time;
        const duration = DateHelper.getMinutesFromHour(this.els.duration.value());


        let eventArray = [{
          allDay: false,
          end: DateHelper.getEventFormat(`${this.state.task_date} ${this.state.task_time}`, 'DD MMM, YYYY hh:mm a', duration),
          start: DateHelper.getEventFormat(`${this.state.task_date} ${this.state.task_time}`, 'DD MMM, YYYY hh:mm a'),
          title: task_title,
        }]


        Actions.setEvent(eventArray);

    }

    render() {

        const editTaks = this.props.edit_task ? this.props.edit_task : {};
        let alert;
        
        if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }                

        const formElements = <fieldset>
            {alert}
            <div className="fields-2">
                <TextControl
                    ref={(c) => (this.els.task_title = c)}
                    name="task_title"
                    label="Title"
                    onChange={() => {LinkState.bind(this); this.updateEvents()}}
                    defaultValue={editTaks.task_title}
                    hasError={this.props.hasError.task_title}
                    help={this.props.help.task_title}
                    disabled={this.props.loading}
                    groupClasses={{'rq': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                />                
                <div className="row">
                    <div className="col-sm-4">
                     <TextControl
                        ref={(c) => (this.els.task_date = c)}
                        name="task_date"
                        label="Date"                       
                        hasError={this.props.hasError.task_date}
                        help={this.props.help.task_date}
                        disabled={this.props.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                        defaultValue={ this.state.task_date !== undefined ? DateHelper._getDefaultFormat(this.state.task_date) : new Date() }
                        onChange={(e) => { this.datePicker(e,'task_date'); }}
                        isDatePicker={true}
                        minDate={ new Date() }
                    />
                    </div>
                    <div className="col-sm-4">
                        <div className="side-input right-side">
                            <TextControl
                                ref={(c) => (this.els.task_time = c)}
                                name="task_time"
                                label="Time"
                                onChange={LinkState.bind(this)}
                                hasError={this.props.hasError.task_time}
                                help={this.props.help.task_time}
                                disabled={this.props.loading}
                                groupClasses={{'rq': true}}
                                labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                                defaultValue={ this.state.task_time !== undefined ? DateHelper._getDefaultTimeFormat(this.state.task_time) : DateHelper.getCurrentTime() }
                                onChange={(e) => { this.datePicker(e,'task_time'); }}
                                isTimePicker={true}
                                minutesInterval={15}
                                inputClasses={ { 'form-control': true } }
                            />
                        </div>
                    </div>
                    <div className="col-sm-4">
                        <div className="side-input right-side">
                            <TextControl
                                ref={(c) => (this.els.duration = c)}
                                name="duration"
                                label="Duration"
                                onChange={LinkState.bind(this)}
                                hasError={this.props.hasError.duration}
                                help={this.props.help.duration}
                                disabled={this.props.loading}
                                groupClasses={{'rq': true}}
                                labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                                onChange={(e) => { this.updateEvents()}}                      
                                defaultValue={ this.state.duration }
                            />
                        </div>
                    </div>
                </div>
               
                <TextArea
                    ref={(c) => (this.els.note = c)}
                    name="note"
                    label="Note"                    
                    onChange={LinkState.bind(this)}
                    hasError={this.props.hasError.note}
                    help={this.props.help.note}
                    disabled={this.props.loading}
                    groupClasses={{'rq': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                />
                {   
                    (!this.props.deal_id) ? 
                    <SelectControl
                        ref={(c) => (this.els.task_type_id = c)}
                        name="task_type_id"
                        label="Enquiry"
                        /* value={this.state.task_type_id} */
                        onChange={LinkState.bind(this)}
                        hasError={this.props.hasError.task_type_id}
                        help={this.props.help.task_type_id}
                        disabled={this.props.loading}
                        groupClasses={{'rq': true}}
                        inputClasses={{'select-modal': true}}
                        labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                    >
                        <option value="">Select Option</option>
                        { this.getDealsOptions() }
                    </SelectControl> : ''    
                }
                <SelectControl
                    ref={(c) => (this.els.assigned_user_id = c)}
                    name="assigned_user_id"
                    label="Assigned To"
                    /* value={this.state.assigned_user_id} */
                    onChange={LinkState.bind(this)}
                    hasError={this.props.hasError.assigned_user_id}
                    help={this.props.help.assigned_user_id}
                    disabled={this.props.loading}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req' : true}}
                >
                    <option value="">Select Option</option>
                    { this.getCustomerOptions() }
                </SelectControl>                

                {/* <div className="form-group right_left mb-0">
                    <label className="left-side">Mark as done</label>
                    <div className="right-side">
                        <label className="switch">
                        <input type="checkbox" id="checkbox" ref={(input) => { this.task_status = input; }}  value={this.state.task_status}/><span className="slider round"></span></label>
                    </div>
                </div> */}
                
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'actions': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn': true, 'btn-white': true }}
                        disabled={this.props.loading}
                        onClick={ (this.props.onModelClose) ? this.props.onModelClose : (e) => { CActions.hideCreateNew()}}
                        >
                        Close
                    </Button>
                    <Button
                        type="submit"
                        inputClasses={{ 'btn': true, 'btn-primary': true }}
                        disabled={this.props.loading}>
                        <Spinner space="right" show={this.props.loading} />
                        Create
                    </Button>
                </ControlGroup>                
            </div>
        </fieldset>;

        return (
            <Modal
                header="Schedule a Task"
                show={this.props.show}
                onClose={ (this.props.onModelClose) ? this.props.onModelClose : CActions.hideCreateNew }
                groupClasses={{'model_design2': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>

                <form onSubmit={this.onSubmit.bind(this)}>
                    <div className="calender_wrapper">
                    <BigCalendar
                        localizer={localizer}
                        events={this.state.events}
                        startAccessor="start"
                        endAccessor="end"
                        defaultView="day"
                        getNow={() => DateHelper.getDateFormat(`${this.state.task_date} ${this.state.task_time}`, 'DD MMM, YYYY hh:mm a')}
                        scrollToTime={ DateHelper.getDateFormat(`${this.state.task_date} ${this.state.task_time}`, 'DD MMM, YYYY hh:mm a')}
                        views={['day']}
                        messages={{
                                date: 'Date',
                                time: 'Time',
                                event: 'Event',
                                allDay: 'All Day',
                                week: 'Week',
                                work_week: 'Work Week',
                                day: 'Day',
                                month: 'Month',
                                previous: 'Back',
                                next: 'Next',
                                yesterday: 'Yesterday',
                                tomorrow: 'Tomorrow',
                                today: 'Today',
                                agenda: 'Agenda',
                                noEventsInRange: 'There are no events in this range.',
                                showMore: total => `+${total} more`,
                            }}
                    />
                    </div>
                    {formElements}
                </form>
            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;


module.exports = CreateNewForm;
