'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const CommonFunctions = require('../../../../../helpers/common-functions');

const initialState = {
    hydrated: false,
    loading: false,
    nationality_loading: false,
    showFetchFailure: false,
    showSaveSuccess: false,
    error: undefined,
    hasError: {},
    help: {},
    enquiry_types:[],
    driving_experience_data: [],
    experience_data: [],
    country_data:[],
    emirate_data: [],
    vehicle_type: []
};

const reducer = function (state = initialState, action) {

    switch (action.type) {
        
        case Constants.GET_ENQUIRY_RESULTS:
            return ObjectAssign({}, state, {
                loading: true
            }); 
            break;
        case Constants.GET_ENQUIRY_RESULTS_RESPONSE:
            const enquiryValidation = ParseValidation(action.response);
            const enquirydata = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {
                loading: false,
                enquiry_types: enquirydata ? enquirydata : []
            });
            break;

        case Constants.GET_DRIVING_EXPERIENCE_RESULTS:
            return ObjectAssign({}, state, {
                nationality_loading: true
            }); 
            break;
        case Constants.GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE:
            
            const experienceValidation = ParseValidation(action.response);
            
            const experiencedata = (action.response && action.response.data) ? action.response.data : [];
            
            return ObjectAssign({}, state, {
                driving_experience_data: state.driving_experience_data.length > 0 ? state.driving_experience_data : experiencedata ? experiencedata : [],
                experience_data: experiencedata ? experiencedata : [],
                nationality_loading: false
            });
            break;

        case Constants.GET_COUNTRY_RESULTS:
            return ObjectAssign({}, state, {
                country_data: []
            });
            break;

        case Constants.GET_COUNTRY_RESULTS_RESPONSE:

            return ObjectAssign({}, state, {
                country_data: action.response.data
            });
            break;
        case Constants.GET_VEHICLE_TYPE:
            return ObjectAssign({}, state, {
                vehicle_type: []
            });
            break;

        case Constants.GET_VEHICLE_TYPE_RESPONSE:

            return ObjectAssign({}, state, {
                vehicle_type: action.response.data
            });
            break;
        case Constants.GET_NATIONALITY_RESULTS:
            return ObjectAssign({}, state, {
                nationality_data: []
            });
            break;
        case Constants.GET_NATIONALITY_RESULTS_RESPONSE:                    
            const stateUpdates = {
                nationality_data: action.response ? action.response.data : []
            };
            return ObjectAssign({}, state, stateUpdates);
            break;
        case Constants.GET_EMIRATES:
            return ObjectAssign({}, initialState, {
                emirate_data: []
            });            
            break;
        case Constants.GET_EMIRATES_RESPONSE:                
            return ObjectAssign({}, initialState, {
                emirate_data:action.response.data
            });
            break;        
        default:
            return state;
            break;
    }
};


module.exports = reducer;
