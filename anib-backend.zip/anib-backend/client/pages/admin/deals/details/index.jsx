'use strict';
const Actions = require('./actions');
const BasicDetailsForm = require('./basic-details-form.jsx');
const CommonActions = require('../../common-store/action');
const DeleteForm = require('./delete-form.jsx');
const PipelineDetails = require('./pipeline/index.jsx');
const DealInfo = require('./deal-info/index.jsx');
const AssignDetailsForm = require('./assign-details-form.jsx');
const CommonFunctions = require('../../../../../client/helpers/common-functions');
const CustomerDetailsForm = require('../../customers/details/customer-info/index');
const DrivingDetailsForm = require('../../customers/details/driving-detail/index');
const PropTypes = require('prop-types');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Store = require('./store');
const TaskForm = require('./task-form');


const Link = ReactRouter.Link;
const propTypes = {
    history: PropTypes.object,
    match: PropTypes.object
};

const Helmet = ReactHelmet.Helmet;

class DetailsPage extends React.Component {
    constructor(props) {

        super(props);
        CommonActions.getDetails(this.props.match.params.id);
        this.state = Store.getState();
    }

    componentDidMount() {
        
        Actions.getDetails(this.props.match.params.id);
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentWillUnmount() {

        Actions.resetStore();
        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    

    render() {
        
        const {
            customer_name,
            vehicle_brand
        } = this.state.dealDetails;
        
        const name = (customer_name && customer_name !== '') ? CommonFunctions.toTitleCase(customer_name, 2) + ' (' + vehicle_brand + ')' :  vehicle_brand;

        return (
            <section className="page-container">
                <Helmet>
                    <title>{ CommonFunctions.toTitleCase(name) }</title>
                </Helmet>
                <div className="container">
                    <div className="breadcums">
                        <ul className="reset">
                            <li><Link to="/admin">Dashboard</Link></li>
                            <li><Link to="/admin/deals">Enquiry</Link></li>
                            <li><span className="capitalize">{!this.state.dealDetails.hydrated ? 'loading..' : name}</span></li>
                        </ul>
                        <button style={{ 'display': 'none' }} onClick={ (e) => { Actions.showDeleteModal() } } className="btns outline-danger" data-toggle="modal" data-target="#delete"><i className="fa fa-trash"></i> Delete</button>
                    </div>
                    <div className="single-page-content">
                        <div className="row">
                            <div className="col-md-4">
                                <BasicDetailsForm
                                    deal_id = {this.props.match.params.id}
                                    {...this.state.dealDetails}
                                />
                                <CustomerDetailsForm
                                    ref={(c) => (this.customerForm = c)}
                                    customer_id = {this.state.dealDetails.customer_id}
                                    deal_id = {this.props.match.params.id}
                                    viewCustomer = {true}
                                />

                                <DeleteForm
                                    history={this.props.history}
                                    id={this.props.match.params.id}
                                    {...this.state.delete} />
                                <DrivingDetailsForm
                                    customer_id={this.state.dealDetails.customer_id}
                                />
                                <DealInfo
                                    common_data={this.state.common}
                                    deal_id={this.props.match.params.id}
                                    {...this.state.dealDetails}
                                />
                            </div>
                            <div className="col-md-8">
                                <div className="white-box">
                                    <AssignDetailsForm
                                        history={this.props.history}
                                        deal_id={this.props.match.params.id}
                                        user_id={this.state.dealDetails.user_id}
                                        user_name={this.state.dealDetails.user_name}
                                        {...this.state.dealDetails} />
                                    <PipelineDetails
                                        history={this.props.history}
                                        id={this.props.match.params.id}
                                        deal_data={this.state.dealDetails}
                                        {...this.state} />
                                </div>
                                <div className="white-box mt-30">
                                    <TaskForm
                                        history={this.props.history}
                                        deal_id={this.props.match.params.id}
                                        {...this.state.taskDetails} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}

DetailsPage.propTypes = propTypes;


module.exports = DetailsPage;
