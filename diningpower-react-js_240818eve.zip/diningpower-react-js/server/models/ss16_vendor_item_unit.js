/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorItemUnit', {
    vendorItemUnitId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'vendor_item_unit_id'
    },
    unitName: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'unit_name'
    },
    status: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '1',
      field: 'status'
    }
  }, {
    tableName: 'ss16_vendor_item_unit'
  });
};
