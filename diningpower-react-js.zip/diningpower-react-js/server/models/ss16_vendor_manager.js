/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorManager', {
    managerId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'manager_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    managerName: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'manager_name'
    },
    managerEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'manager_email'
    },
    managerStatus: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'yes',
      field: 'manager_status'
    }
  }, {
    tableName: 'ss16_vendor_manager'
  });
};
