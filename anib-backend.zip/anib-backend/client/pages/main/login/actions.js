/* global window */
'use strict';
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const ForgotStore = require('./forgot/store');
const LoginStore = require('./home/store');
const LogoutStore = require('./logout/store');
const Qs = require('qs');
const ResetStore = require('./reset/store');


class Actions {
    static forgot(data) {

        ApiActions.post(
            '/user/forgot-password',
            data,
            ForgotStore,
            Constants.FORGOT,
            Constants.FORGOT_RESPONSE
        );
    }

    static getUserCreds() {

        if (!global.window) {
            return;
        }

        ApiActions.get(
            '/api/users/my',
            undefined,
            LoginStore,
            Constants.GET_USER_CREDS,
            Constants.GET_USER_CREDS_RESPONSE,
            (err, response) => {

                if (!err) {
                    const query = Qs.parse(window.location.search.substring(1));

                    if (query.returnUrl) {
                        window.location.href = query.returnUrl;
                    }
                    else if (response && response.roles) {
                        if (response.roles.admin) {
                            window.location.href = '/admin/deals';
                        }
                        else {
                            window.location.href = '/account';
                        }
                    }
                }
            }
        );
    }

    static login(data) {

        ApiActions.post(
            '/api/login',
            data,
            LoginStore,
            Constants.LOGIN,
            Constants.LOGIN_RESPONSE,
            (err, response) => {

                if (!err) {
                    document.cookie = `token=${response.authHeader}` 
                    
                    const query = Qs.parse(window.location.search.substring(1));

                    if (query.returnUrl) {
                        window.location.href = query.returnUrl;
                    }
                    else if (response && response.user) {
                        if (response.user.roles.admin) {
                            window.location.href = '/admin/deals';
                        }
                        else {
                            window.location.href = '/account';
                        }
                    }
                }
            }
        );
    }

    static logout() {

        ApiActions.delete(
            '/api/logout',
            undefined,
            LogoutStore,
            Constants.LOGOUT,
            Constants.LOGOUT_RESPONSE,
            (err, response) => {

                if (!err) {
                    this.deleteCookie("token", null, -1);
                }
            }
        );
    }

    static reset(data) {

        ApiActions.post(
            '/api/login/reset',
            data,
            ResetStore,
            Constants.RESET,
            Constants.RESET_RESPONSE
        );
    }

    static deleteCookie(name, value, minutes) {
       var expires = "";
       if (minutes) {
          var date = new Date();
          date.setTime(date.getTime() + (minutes * 60 * 1000));
          expires = "; expires=" + date.toGMTString();
       }

       document.cookie = name + "=" + value + expires;
    }
}


module.exports = Actions;
