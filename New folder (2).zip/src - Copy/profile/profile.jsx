import React, {Component} from 'react';
/* Import Components */


class Profile extends Component{
  


    render() {

        return(
            <div>
       
       sadhsdfjsjdjh


        </div>
              )

        }

}

export default Profile;