'use strict';
const ClassNames = require('classnames');
const ControlGroup = require('./control-group.jsx');
const ObjectAssign = require('object-assign');
const PropTypes = require('prop-types');
const React = require('react');
const renderHTML = require('react-render-html');
import Select from 'react-select';

const propTypes = {
    children: PropTypes.node,
    defaultValue: PropTypes.string,
    disabled: PropTypes.bool,
    hasError: PropTypes.bool,
    help: PropTypes.string,
    inputClasses: PropTypes.object,
    hideLabel: PropTypes.bool,
    label: PropTypes.string,
    multiple: PropTypes.string,
    name: PropTypes.string,
    onChange: PropTypes.func,
    size: PropTypes.string,
    defaultValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    prependElement : PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    prependElementNotString : PropTypes.bool,
    appendElement: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    appendElementNotString : PropTypes.bool,
    isKeyEnable: PropTypes.bool,
    isMulti: PropTypes.bool,
};
const defaultProps = {
    type: 'text'
};


class ReactSelectControl extends React.Component {
    
    constructor(props){
        super(props);
        
        this.state = {
          value: this.props.defaultValue ? this.props.defaultValue : this.props.value
        }

        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(data) {
        
        let response;
        if (this.props.isMulti) {
            
            let value = '';
            
            if (data.length > 0) {
                let combineData = [];
                data.map((data_value, data_index) => {
                    combineData.push(data_value.value);

                });

                value = combineData.toString();
            } 

            this.setState({
                value: value
            });

            response = value;
        } else {
            this.setState({
              value: data.value
            });

            response = data.value;
        }

        this.props.onChange ? this.props.onChange(response) : null;
    }

    value() {

        return this.state.value;
    }

    render() {

        const inputClasses = ClassNames(ObjectAssign({
            'form-control': true
        }, this.props.inputClasses));
        
        const options = [
          { value: 'chocolate', label: 'Chocolate' },
          { value: 'strawberry', label: 'Strawberry' },
          { value: 'vanilla', label: 'Vanilla' }
        ]

        let initialValue = [];
        this.props.options.map((data, index) => {
            
            if(data.value == this.props.defaultValue) {
                initialValue.push({ label: data.label, value: data.value });
            }
        });

        


        return (
            <ControlGroup
                hasError={this.props.hasError}
                label={this.props.label}
                hideLabel={this.props.hideLabel}
                groupClasses={this.props.groupClasses}
                labelClasses={this.props.labelClasses}
                labelFor={this.props.id}
                help={this.props.help}>

                <div className="side-input right-side">
                    {(this.props.prependElement && this.props.prependElementNotString) ? (this.props.prependElement) : ''}
                    {(this.props.prependElement && !this.props.prependElementNotString) ? (renderHTML(this.props.prependElement)) : ''}
                    <Select 
                        ref={(c) => (this.input = c)}
                        options={this.props.options}
                        setValue={this.props.defaultValue ? this.props.defaultValue : this.props.value}
                        defaultValue={ this.props.defaultValue ? this.props.defaultValue : this.props.value }
                        defaultValue={ initialValue }
                        name={this.props.name}
                        isLoading={this.props.disabled}
                        onChange={(e) => {this.handleChange(e)}}
                        isMulti={this.props.isMulti}
                        />
                    { (this.props.appendElement && this.props.appendElementNotString) ? (this.props.appendElement) : '' }
                    { (this.props.appendElement && !this.props.appendElementNotString) ? (renderHTML(this.props.appendElement)) : ''}
                </div>
            </ControlGroup>
        );
    }
}

ReactSelectControl.propTypes = propTypes;
ReactSelectControl.defaultProps = defaultProps;


module.exports = ReactSelectControl;
