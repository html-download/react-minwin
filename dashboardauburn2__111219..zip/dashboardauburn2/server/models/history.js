'use strict';
const Joi = require('joi');
const moment = require('moment-timezone');
const Config = require('../../config.js');
const MongoModels = require('mongo-models');

class History extends MongoModels {
    static create(response, callback) {

        const document = {
            log:response,
            timeCreated: moment().tz(Config.get('/timeZone'))._d,
            time:moment().tz(Config.get('/timeZone')).format("HH:mm")
        };

        this.insertOne(document, (err, docs) => {

            if (err) {
                return callback(err);
            }

            callback(null, docs[0]);
        });
    }  
    static findByDate(date, callback) {

        const query = {  };

        this.findOne(query, callback);
    } 
    static findHistory(condition) {
        return this.find(condition);
    } 
}


History.collection = 'history';


History.schema = Joi.object({       
    log: Joi.object(),    
    timeCreated: Joi.date()
});




module.exports = History;
