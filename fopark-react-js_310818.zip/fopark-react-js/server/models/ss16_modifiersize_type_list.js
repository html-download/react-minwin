/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16ModifiersizeTypeList', {
    typeId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'type_id'
    },
    ingredientName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'ingredient_name'
    },
    sizeModifier: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '2',
      field: 'size_modifier'
    },
    itemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_id'
    },
    price: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'price'
    },
    sortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort_order'
    },
    ingredientsTypeListStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'ingredients_type_list_status'
    },
    ingredientsTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'ingredients_type_id'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    defaultModifierList: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '2',
      field: 'default_modifier_list'
    }
  }, {
    tableName: 'ss16_modifiersize_type_list'
  });
};
