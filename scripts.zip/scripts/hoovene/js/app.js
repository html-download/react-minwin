
/* Custom Scrolling */    
  /*$(document).ready(function() {    
        
    var nice = $("html").niceScroll();    
    });*/
  /*Model Scrolling Issues*/
$(document).ready(function(){
  $(".close_open").click(function(){
    $("body").addClass("modal_open");
  });
  $(".modal .close, .modal-backdrop").click(function(){
    $("body").removeClass("modal_open").css({"padding-right":"0px"});
  });
});
/* Message Model */
function modal_open(message, seconds, modal_name) {
    $('#'+modal_name+'_message').html(message);
    $("#"+modal_name).modal("toggle"); 
    setTimeout(function(){
      $("#"+modal_name).modal('hide');

    }, seconds);
}

/*/*Home Page*/
/*$(function(){
  $('nav ul li').hover(
    function () {
      $('ul', this).slideDown(150);
    }, 
    function () {
      $('ul', this).slideUp(150);     
    }
  );
});*/
$(window).scroll(function(){
    var sticky = $(".hme-header"),
    scroll = $(window).scrollTop();

    if (scroll > 80)
      {
        sticky.addClass('fixed');
        $(".hme-header.fixed").slideDown('slow');
      } 
    else
    {
      sticky.removeClass('fixed');
      $(".hme-header.fixed").slideUp('slow');
    }
});
$(document).ready(function(){
  $(".error_validate").css({"display":"none"});
  var shop_list = [];
});
/* Mobile Filter Section*/    
  $(document).ready(function(){   
    $(".mob_sort_toggle").click(function(){   
      $(".list_lft, .list_rgt").toggleClass('filter_block');    
    });   
  });

/*for video*/
var vid = document.getElementById("bgvid");
    var pauseButton = document.querySelector("#polina button");

    if (window.matchMedia('(prefers-reduced-motion)').matches) {
      vid.removeAttribute("autoplay");
      vid.pause();
      pauseButton.innerHTML = "Paused";
    }

    function vidFade() {
    vid.classList.add("stopfade");
    }
    if (vid) {
      vid.addEventListener('ended', function()
      {
      /*only functional if "loop" is removed */
      vid.pause();
      /*to capture IE10*/
      vidFade();
      }); 
    }
    

    if(pauseButton){
        pauseButton.addEventListener("click", function() {
        vid.classList.toggle("stopfade");
        if (vid.paused) {
          vid.play();
          pauseButton.innerHTML = "Pause";
        } else {
          vid.pause();
          pauseButton.innerHTML = "Paused";
        }
        });
    }

/*locate option*/
function initialize() {
  var address = (document.getElementById('selectbox-city-list2'));
  if (address) {
      var autocomplete = new google.maps.places.Autocomplete(address);
      autocomplete.setTypes(['geocode']);
      google.maps.event.addListener(autocomplete, 'place_changed', function() {
      var place = autocomplete.getPlace();
          /*console.log("place changed");
          console.log(place);
          console.log(place.geometry.location.lat());
          console.log(place.geometry.location.lng());*/
          $('#iplatitudeval').val(place.geometry.location.lat());
          $('#iplongitudeval').val(place.geometry.location.lng());

          $('#customer_latitude').val(place.geometry.location.lat());
          $('#customer_longitude').val(place.geometry.location.lng());
          var latlng = new google.maps.LatLng(place.geometry.location.lat(),place.geometry.location.lng());
          load_map_fun(latlng, 12, 'map-canvas');
          if (!place.geometry) {
              return;
          }

      var address = '';
      if (place.address_components) {
          address = [
              (place.address_components[0] && place.address_components[0].short_name || ''),
              (place.address_components[1] && place.address_components[1].short_name || ''),
              (place.address_components[2] && place.address_components[2].short_name || '')
              ].join(' ');
      }
      //codeAddress();
    });
  }
}
function codeAddress() {
  geocoder = new google.maps.Geocoder();
    var address = document.getElementById("selectbox-city-list2").value;
    geocoder.geocode({ 'address': address}, function(results, status) {
      if (status == google.maps.GeocoderStatus.OK) {
        var user_srch_lat = results[0].geometry.location.lat();
        var user_srch_lan = results[0].geometry.location.lng();
        if (user_srch_lat !='' && user_srch_lan !='') {
          $('#iplatitudeval').val(user_srch_lat);
          $('#iplongitudeval').val(user_srch_lan);
        } else {
          $('#iplatitudeval').val('');
          $('#iplongitudeval').val('');
        }
      } 
      else {
        $('#error_id').html("Please enter Location");
      }
    });
  }
google.maps.event.addDomListener(window, 'load', initialize);
$(document).on('blur',  '#selectbox-city-list2',function () {
  if ($('#selectbox-city-list2').val() == '') {
      $('#iplatitudeval').val('');
      $('#iplongitudeval').val('');
    } else {
      codeAddress();
    }
});




function getLocation() {
    var startPos;
    var iplatitudeval;
    var iplongitudeval;
    var geoSuccess = function(position) {
      startPos = position;
      console.log(startPos);
      var iplatitudeval   = startPos.coords.latitude;
      var iplongitudeval  = startPos.coords.longitude;

      document.getElementById('iplatitudeval').value  = iplatitudeval;
      document.getElementById('iplongitudeval').value = iplongitudeval;
      codeLatLng(iplatitudeval, iplongitudeval)
    };
    var geoError = function(error) {
      //console.log('Error occurred. Error code: ' + error.code);
      // error.code can be:
      //   0: unknown error
      //   1: permission denied
      //   2: position unavailable (error response from location provider)
      //   3: timed out
    };
    navigator.geolocation.getCurrentPosition(geoSuccess, geoError);
    codeLatLng(iplatitudeval, iplongitudeval)
}
function codeLatLng(lat, lng) {
    geocoder = new google.maps.Geocoder();
    var latlng = new google.maps.LatLng(lat, lng);
    geocoder.geocode({'latLng': latlng}, function(results, status) {
        console.log(results);
        var checked = true;
      if (status == google.maps.GeocoderStatus.OK) {
        if (results[1]) {
          document.getElementById('iplatitudeval').value  = lat;
          document.getElementById('iplongitudeval').value = lng;
          document.getElementById('selectbox-city-list2').value = results[0].formatted_address;
          codeLatLngAssign(lat, lng, checked);
        } else {
           document.getElementById('iplatitudeval').value  = '';
           document.getElementById('iplongitudeval').value = '';
           document.getElementById('selectbox-city-list2').value = '';
           document.getElementById('error_id').value       = 'No results found';
        }
      } else {
        document.getElementById('iplatitudeval').value  = '';
        document.getElementById('iplongitudeval').value = '';
        document.getElementById('selectbox-city-list2').value = '';
        document.getElementById('error_id').value       = "Geocoder failed due to: " + status;
      }
    });
  }

/*Listing page*/
function shopDetail() {
    $('#shopDiv').html('');
    /*Category*/
    var category_id = '';
    $('.food_type_filter_category label :checkbox:checked').each(function () {
      category_id += (this.checked ? $(this).val()+"," : "");
    });
    category_id = category_id.substring(0,(category_id.length-1));

    /*Delivery Time*/
    var delivery_time = '';
    $('.food_type_filter_delivery_time label :radio:checked').each(function () {
      delivery_time += (this.checked ? $(this).val()+"," : "");
    });
    delivery_time = delivery_time.substring(0,(delivery_time.length-1));

    /*Rating*/
    var rating = '';
    $('.food_type_filter_rating label :checkbox:checked').each(function () {
      rating += (this.checked ? $(this).val()+"," : "");
    });
    rating = rating.substring(0,(rating.length-1));

    /*Mini Order*/
    var mini_order = '';
    $('.food_type_filter_mini_order label :radio:checked').each(function () {
      mini_order += (this.checked ? $(this).val()+"," : "");
    });
    mini_order = mini_order.substring(0,(mini_order.length-1));

    /*Online Payment*/
    var online_payment = '';
    $('.food_type_filter_online_payment label :radio:checked').each(function () {
      online_payment += (this.checked ? $(this).val()+"," : "");
    });
    online_payment = online_payment.substring(0,(online_payment.length-1));

    /*Pure Vegetarian*/
    var pure_vegetarian = '';
    $('.food_type_filter_pure_vegetarian label :radio:checked').each(function () {
      pure_vegetarian += (this.checked ? $(this).val()+"," : "");
    });
    pure_vegetarian = pure_vegetarian.substring(0,(pure_vegetarian.length-1));

    /*Cuisines*/
    var cuisines = '';
    $('.food_type_filter_cuisines label :checkbox:checked').each(function () {
      cuisines += (this.checked ? $(this).val()+"," : "");
    });
    cuisines = cuisines.substring(0,(cuisines.length-1));

    /*Sort*/
    var sort = '';
    $('.food_type_filter_sort label :radio').each(function () {
      if (this.checked) {
          $(this).closest('label') .css('color','rgb(255, 40, 81)');
      } else {
          $(this).closest('label') .css('color','#1b1f3a');
      }
      sort += (this.checked ? $(this).val()+"," : "");
    });
    sort = sort.substring(0,(sort.length-1));

    
    /*Search Dish*/
    var search_dish = '';
    $('.list_search_dish_sec :input').each(function () {
      search_dish += $(this).val();
    });

    $('#start_iteration').val(0);
    $('#vendor_per_page').val(6);
    $.ajax({
              //async     : false, 
              url       : base_url + "/shop_details",
              type      : "POST",
              data      : {cuisines: cuisines, category_id:category_id, delivery_time:delivery_time, rating:rating, mini_order:mini_order, online_payment:online_payment, pure_vegetarian:pure_vegetarian, sort:sort, search_dish:search_dish,deals :$('#deals').val()},
              success   : function(data){
                  $('#shopListValues').val('');
                  $('#shopDiv').html('');
                  $('#shopListValues').val(data);
                  
                   
              },
              beforeSend: function () {
                  loading(1);
              },
              complete : function() {
                  loading(0);
              },
              error     : function(data) {
                $('#shopListValues').val('');
                $('#shopDiv').html('');
                $('#shopListValues').val('[]');
                console.log(data);return false;
              }
          }).done(function(){
               /*Total Chef Count*/
              if ($('#shopListValues').val().length > 2) {
                    count_chef($.parseJSON($('#shopListValues').val()).length);
                        } else {
                           $("#total_restaurent").html(0);
                        }
                    shopDesign();

          });
  }
function shopDesign() {
   var shopListArray    = new Array();
   var start_iteration  = $('#start_iteration').val();
   var vendor_per_page  = $('#vendor_per_page').val();
   var end_iteration    = 0;
   var end_iteration_cal= 0;
   shopListArray        = $.parseJSON($('#shopListValues').val());

   if (shopListArray.length < parseInt(vendor_per_page)) {
      end_iteration     = shopListArray.length;
   } else {
      end_iteration_cal = shopListArray.length - (parseInt(start_iteration) + 1);
      if (end_iteration_cal > parseInt(vendor_per_page)) {
        end_iteration   = parseInt(start_iteration) + parseInt(vendor_per_page);
      } else {
        end_iteration   = parseInt(start_iteration)+end_iteration_cal+1;
      }
   }
   htmlString           = '';

   if (shopListArray.length > 0) {
      if (end_iteration != start_iteration) {
        loading(1);
        for (var i = start_iteration; i < end_iteration; i++) {
            var avg_review = Math.round(shopListArray[i]['avg_rating']);
            var discount_tooltip = '';
            if (objSize(shopListArray[i]['voucher_data']) > 0) {
                if (shopListArray[i]['voucher_data']['discount_type'] == 1 ) {
                    var discount_val = currency_code+' '+shopListArray[i]['voucher_data']['amount']+'/-';
                } else {
                    var discount_val = shopListArray[i]['voucher_data']['amount']+'%';
                }
                discount_tooltip += discount_val+' Off. Use code '+shopListArray[i]['voucher_data']['promocode'];
                htmlString += '<div class="bg_white list_item">';
            } else {
                htmlString += '<div class="bg_white">';
            }
            
            htmlString += '<div class="list_user_section col-md-12 col-sm-12 col-xs-12 pad0">';
            if (discount_tooltip != '') {
                htmlString += '<div class="list_user_photo col-md-3 col-sm-3 col-xs-12 pad0 text-center" data-toggle="tooltip" data-placement="top" data-original-title="'+discount_tooltip+'">';
            } else {
                htmlString += '<div class="list_user_photo col-md-3 col-sm-3 col-xs-12 pad0 text-center">';
            }
            htmlString += '<img src="'+shopListArray[i]['image_url']+'" alt="'+shopListArray[i]['shop_name']+'" title="'+shopListArray[i]['shop_name']+'">';
            htmlString += '</div>';
            htmlString += '<div class="list_user_detail col-md-9 col-sm-9 col-xs-12 pad0">';
            if ($('#deals').val()==1) {
                htmlString += '<h4><a style="color: #313448;" href="'+base_url+'/deals/'+shopListArray[i]['vendor_slug']+'">'+shopListArray[i]['shop_name']+'</a></h4>';
            } else {
                htmlString += '<h4><a style="color: #313448;" href="'+base_url+'/chef/'+shopListArray[i]['vendor_slug']+'">'+shopListArray[i]['shop_name']+'</a></h4>';
            }
            htmlString += '<a class="star pop_star chef_star stary'+avg_review+'"></a>';
                          if (shopListArray[i]['shop_status'] != 'closed') {
                            if (shopListArray[i]['busy_status'] == 'No') {
                              var shop_status   = available_lan;
                              var status_css    = 'green_status';
                            } else {
                              var shop_status   = busy_lan;
                              var status_css    = 'busy_status';
                            }
                          } else {
                            var shop_status   = close_lan;
                            var status_css    = 'close_status';
                          } 
            htmlString += '<p class="status">'+status_lan+' : <a class="'+status_css+'" href="javascript:;">'+shop_status+'</a></p>';
            htmlString += '<p class="desp more">'+shopListArray[i]['vendor_brief']+'</p>';
            htmlString += '<p class="select_item">'+cuisines_lan+' : '+shopListArray[i]['cuisines']+'</p>';
            htmlString += '</div>';
            htmlString += '</div>';
            htmlString += '<div class="list_user_product_section col-md-12 col-sm-12 col-xs-12 pad0">';
            htmlString += '<ul class="list-inline">';
            if (shopListArray[i]['delivery_fee'] == 0) {
                var delivery_fee = "<span style='color:green;padding-left: 2px;'>*free</span>";
            } else {
                var delivery_fee = shopListArray[i]['delivery_fee']+' '+currency_code;
            }
            htmlString += '<li><a class="delivery_fee" href="javascript:;"> '+delivery_fee_lan+' : '+delivery_fee+' </a></li>';
            htmlString += '<li><a class="preparation" href="javascript:;"> '+prep_time_lan+' : '+shopListArray[i]['pickup_time']+mins_lan+'</a></li>';
            htmlString += '<li><a class="delivery_time" href="javascript:;"> '+delivers_in_lan+' '+shopListArray[i]['delivery_in']+mins_lan+'</a></li>';
            htmlString += '<li><a class="mini_order" href="javascript:;"> '+minimum_order_lan+' : '+shopListArray[i]['min_order_value']+'</a></li>';
            htmlString += '<li><a class="mini_order" href="javascript:;"> '+vendor_max+' : '+shopListArray[i]['remaining_order']+'</a></li>';
                         var payment_status   = '';
                         if (shopListArray[i]['online_payment_available'] == "2") {
                            payment_status  += online_payment_and_cod_lan;
                         } else if (shopListArray[i]['online_payment_available'] == "1") {
                            payment_status  += online_payment_lan;
                         } else {
                            payment_status  += cod_lan;
                         }
            htmlString += '<li><a class="payment" href="javascript:;"> '+payment_lan+' : '+payment_status+' </a></li>';
            htmlString += '</ul>';
            htmlString += '<div class=" col-md-12 col-sm-12 col-xs-12 pad0">';
            htmlString += '<input type="hidden" name="fav_'+shopListArray[i]['vendor_id']+'" id="fav_'+shopListArray[i]['vendor_id']+'" value="'+shopListArray[i]['is_favourite']+'">';
            htmlString += '<input type="hidden" name="key_'+shopListArray[i]['vendor_id']+'" id="key_'+shopListArray[i]['vendor_id']+'" value="'+shopListArray[i]['vendor_key']+'">';
                        if (customer_key == '') {
                            htmlString += '<div data-toggle="tooltip" data-placement="top" data-original-title="'+fav_tooltip_lan+'" class="heart pull-left favourites" id="'+shopListArray[i]['vendor_id']+'">';
                        } else {
                            htmlString += '<div class="heart pull-left favourites" id="'+shopListArray[i]['vendor_id']+'">';
                        }
                          if (shopListArray[i]['is_favourite'] == 0) {
                              htmlString += '<img src="'+theme_path+'heartin_blank.png" alt="Favourite">';
                          } else {
                              htmlString += '<img src="'+theme_path+'heartin.png" alt="Favourite">';
                          }
            htmlString += '</div>';
            if ($('#deals').val()==1) {
                htmlString += '<a href="'+base_url+'/deals/'+shopListArray[i]['vendor_slug']+'" class="rectangle_btn rounded_grad_btn pull-left">'+menu_lan+'</a>';
            } else {
                htmlString += '<a href="'+base_url+'/chef/'+shopListArray[i]['vendor_slug']+'" class="rectangle_btn rounded_grad_btn pull-left">'+menu_lan+'</a>';
            }
            htmlString += '<div class="distance_shape pull-right">';
            htmlString += '<p class="text-right distance_img"><img src="'+theme_path+'distance_img.png"></p>';
            if (lan_dir == 2) {
                htmlString += '<p class="text-right">km '+shopListArray[i]['distance_in_km']+" : "+distance_lan+'</p>';
            } else {
                htmlString += '<p class="text-right">'+distance_lan+' : '+shopListArray[i]['distance_in_km']+" km"+'</p>';
            }
            htmlString += '</div>';
            htmlString += '</div>';
            htmlString += '</div>';
            htmlString += '</div>';
        }
    }
        $('#start_iteration').val(end_iteration);
        loading(0);
        $('#shopDiv').append(htmlString);
        showmoreFunction();
        $('[data-toggle="tooltip"]').tooltip();
   } else {
        htmlString += '<div class="bg_white text-center chef_empty"><img src="'+theme_path+'chef_empty3.png" alt="Chef Empty" title=""><h4> We do not operate in this area currently </h4><a href="/users/request-area"> Request This Area </a></div>';
        
        $('#start_iteration').val(end_iteration);
        loading(0);
        $('#shopDiv').html(htmlString);
        showmoreFunction();
        $('[data-toggle="tooltip"]').tooltip();
    }  
}
var objSize = function(obj) {
    var count = 0;
    
    if (typeof obj == "object") {
    
        if (Object.keys) {
            count = Object.keys(obj).length;
        } else if (window._) {
            count = _.keys(obj).length;
        } else if (window.$) {
            count = $.map(obj, function() { return 1; }).length;
        } else {
            for (var key in obj) if (obj.hasOwnProperty(key)) count++;
        }
        
    }
    
    return count;
};
var number    = {param:0};
function count_chef(value){
    var display   = document.getElementById("total_restaurent");
    var duration  = 0.8;
    number        = {param:0};
    TweenLite.to(number, duration, {param:"+="+value, roundProps:"param", onUpdate:update, onComplete:'', ease:Linear.easeNone});
} 
function update() {
  var display   = document.getElementById("total_restaurent");
  display.innerHTML = number.param;
}
function showmoreFunction() {
  var showChar      = 100;
  var ellipsestext  = "...";
  var moretext      = more_lan;
  var lesstext      = less_lan;
  
  $('.more').each(function(index) {
    var content     = $(this).html();
    if(content.length > showChar && $(this).children().length == 0) {
        var c = content.substr(0, showChar);
        var h = content.substr(showChar-1, content.length - showChar);

        var html = c + '<span class="moreelipses">'+ellipsestext+'</span>&nbsp;<span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">'+moretext+'</a></span>';

        $(this).html(html);
    }

  });

  $(".morelink").click(function(){
    if($(this).hasClass("less")) {
      $(this).removeClass("less");
      $(this).html(moretext);
    } else {
      $(this).addClass("less");
      $(this).html(lesstext);
    }
    $(this).parent().prev().toggle();
    $(this).prev().toggle();
    return false;
  });
}
function UrlExists(shop_logo, shop_name)
{
    var s       = '';
    $.ajax({
      async   : false,
      type    : "GET",
      url     : base_url + "/image_check",
      data    : {shop_logo: shop_logo, shop_name: shop_name},
      success : function(data){
              s = data;
      },
      error   : function(data){
              s = no_image;
      },
    });
    return s;
}
$(document).on("click", ".favourites", function(){
    $element    = $(this);
    param       = $('#key_'+$($element).attr("id")).val();
    fav_value   = $('#fav_'+$($element).attr("id")).val();
    if (fav_value == 0) {
        $(this).html('<img src="'+theme_path+'heartin.png" alt="Favourite">');
        $('#fav_'+$($element).attr("id")).val(1);
    } else {
        $(this).html('<img src="'+theme_path+'heartin_blank.png" alt="Favourite">');
        $('#fav_'+$($element).attr("id")).val(0);
    }
    if (customer_key != "") {
      loading(1);
      $.ajax({
          url     : base_url+"/shop/favourites",
          type    : "post",
          data    : {param: param},
          success : function(data){
              loading(0);
              return false;
          },
          error   : function(data){
              loading(0);
              return false;
          },
      });
    }
    
});
function loading(key) {
    if (key == 1) {
        var over = '<div id="overlay"><img id="loading" src="/frontend/web/images/app_img/loader-1.gif"></div>';
        $(over).appendTo('body');
    } else {
        $('#overlay').remove();
    }
}

function Opendiv(pkey,skey){

    $element    = $(this);
    var value   = $('#quantity_cal_val1').html();
    $request    = $.ajax({
                          url         : base_url + "/add-cart",
                          beforeSend  : function(){
                            loading(1);
                          },
                          complete    : function(){
                            loading(0);
                          },
                          type        : 'POST',
                          dataType    : 'json',
                          data        : { s: skey, p: pkey, quantity:value, div_type:'mini_cart', deals:$('#deals').val(), instruction:$('#instruction').val()},
                          success     : function(response){
                            $('#cartDiv').html('');
                            if(response.status=='ok'){
                              $('#quantity_cal_val1').text(1);
                              $('#cartDiv').html(response.carthtml);
                              $('#add_cart_model').modal('hide');
                            }
                          },
                          error     : function(xhr){
                          }
                        });
}
$('[data-toggle="ajaxModal"]').on('click', function(e) {
    e.preventDefault(); 
    $element    = $(this);
    var value   = $('#quantity_cal_val1').html();
    var $data   = { s:$(this).attr('data-r_skey'),p:$(this).attr('data-r_pkey'), value:value, div_type: 'mini_cart', deals:$('#deals').val()}
    $.ajax({
          url         : base_url + "/add-cart-ingredients",
          beforeSend  :function(){
            loading(1);
          },
          complete    : function(){
            loading(0);
          },
          type        :'POST',
          dataType    :'json',
          data        : $data,
          success     :function(response){
            if(response.status=='ok'){
               $('#add_cart_model .modal-body').html(response.html);
               $('#add_cart_model').modal('toggle');
            }
              else{
                window.location.reload(true);
            }
          },
          error       :function(xhr){
            //alert('Error occured '+xhr.status+' '+xhr.statusText);
          }
    });
 });

window.cartAjaxModal = function(e, r_skey, r_pkey, div_type) {
  var value   = 1;
  var $data   = { s:r_skey,p:r_pkey, value:value, div_type:div_type, deals:$('#deals').val()}
  $.ajax({
        url         : base_url + "/add-cart-ingredients",
        beforeSend  :function(){
          loading(1);
        },
        complete    : function(){
          loading(0);
        },
        type        :'POST',
        dataType    :'json',
        data        : $data,
        success     :function(response){
          if(response.status=='ok'){
             $('#add_cart_model .modal-body').html(response.html);
             $('#add_cart_model').modal('toggle');
          }
            else{
              window.location.reload(true);
          }
        },
        error       :function(xhr){
          //alert('Error occured '+xhr.status+' '+xhr.statusText);
        }
  });
}
window.cartRemoveAjaxModal = function(e, r_skey, r_pkey, div_type) {
  var value   = 1;
  var $data   = { s:r_skey,p:r_pkey, value:value, div_type:div_type}
  $.ajax({
        url         : base_url + "/remove-cart-ingredients",
        beforeSend  :function(){
          loading(1);
        },
        complete    : function(){
          loading(0);
        },
        type        :'POST',
        dataType    :'json',
        data        : $data,
        success     :function(response){
          if(response.status=='ok'){
             $('#add_cart_model .modal-body').html(response.html);
             $('#add_cart_model').modal('toggle');
          }
            else{
              window.location.reload(true);
          }
        },
        error       :function(xhr){
          //alert('Error occured '+xhr.status+' '+xhr.statusText);
        }
  });
}
function plusButtonFunction(id) {
  if (id == 'check_minus1') {
      var value = $('#quantity_cal_val1').html();
      $('#quantity_cal_val1').html(valueCheckMinus(value));
  } else if (id == 'check_plus1') {
      var value = $('#quantity_cal_val1').html();
      $('#quantity_cal_val1').html(valueCheckPlus(value));
  } else if (id == 'check_minus2') {
      var value = $('#quantity_cal_val2').html();
      $('#quantity_cal_val2').html(valueCheckMinus(value));
      $('#quantity_cal_val1').html(valueCheckMinus(value));
  } else if (id == 'check_plus2') {
      var value = $('#quantity_cal_val2').html();
      $('#quantity_cal_val2').html(valueCheckPlus(value));
      $('#quantity_cal_val1').html(valueCheckPlus(value));
  }
  // body...
}
function valueCheckPlus(value) {
    if (parseInt(value) > 0) {
        return parseInt(value)+1;
    } else {
        return parseInt(value);
    }
}
function valueCheckMinus(value) {
    if (parseInt(value) > 1) {
        return parseInt(value)-1;
    } else {
        return parseInt(value);
    }
}
function submitAddtoacart(type) {
    var ingredients_count = $('#ingredients_count').val();
  
    for (var i = 0; i < ingredients_count; i++) {
      var ingredients_key = '';
      ingredients_key     = $('#ingredients_'+i).val();
      maxmin_value        = $('#maxmin_'+i).val().split(',');
      min_value           = maxmin_value[0];
      max_value           = maxmin_value[1];
      var selected = [];
      $('.ingredients_div_'+i+' .check_box_sec input[type=checkbox]').each(function() {
         if ($(this).is(":checked")) {
             selected.push($(this).attr('name'));
         }
      });
      if (selected.length < min_value || selected.length > max_value) {
          $('.ingredients_label_'+i).css('display','block');
          return false;
      } else {
          $('.ingredients_label_'+i).css('display','none');
      }
    }
    var $data   = $('#ingredient_form').serialize()+'&'+$.param({quantity: $('#quantity_cal_val1').html(), instruction: $('#instruction').val(), div_type: type});
    $request    = $.ajax({
        beforeSend  :function(){
          loading(1);
        },
        complete    : function(){
          loading(0);
        },
        url         : base_url+"/add-cart",
        type        :'POST',
        dataType    :'json',
        data        : $data,
        success     :function(response){
          //$('#cartDiv').html('');
          if(response.status=='ok'){
            $('.checkboxes_slected_div input:checkbox').attr('checked',false);
            $('#quantity_cal_val1').text(1);
            $('#cartDiv').html(response.carthtml);
            $('#add_cart_model').modal('hide');
          } else {
            $('#error_div').css('display','block');
            $('#error_div').css('color','red');
            $('#error_div').html(response.message);
          }
        },
        error       :function(xhr){
          alert('Error occured '+xhr.status+' '+xhr.statusText);
        }
    });
}
function cartPlus(vendor_key, item_key, action, type = '', cart_item_id) {
   if (action == 'remove') {if(!confirm('Are you sure want to remove this item?')){return false;}}
   $.ajax({
            beforeSend  :function(){
              loading(1);
            },
            complete    : function(){
              loading(0);
            },
            //async       : false,
            url         : base_url+"/cart-plus",
            type        :'POST',
            dataType    :'json',
            data        : {vendor_key:vendor_key, item_key:item_key, action:action, type:type, cart_item_id:cart_item_id, deals : $('#deals').val()},
            success     :function(response){
              $('#cartDiv').html('');
              if(response.status=='ok'){
                $('#cartDiv').html(response.carthtml);
                $('#add_cart_model').modal('hide');
              }
            },
            error       :function(xhr){
              alert('Error occured '+xhr.status+' '+xhr.statusText);
            }
        });
}
$(document).on("click", "#checkout_button", function(){
    var myElem = document.getElementById('inputcartcheckfield');
    if (myElem == null) {
      alert("Your cart is empty!");
      return false;
    } else {
      if ($('#deals').val() != 0) {
          window.location.href = base_url+"/deals/checkout";
      } else{
          window.location.href = base_url+"/checkout";
      }
      
    }
    

});

/*validation for all pages*/
$(function() {
   $.validator.addMethod(
        "regex",
        function(value, element, regexp) {
            var re = new RegExp(regexp);
            return this.optional(element) || re.test(value);
        },
        "Please Provide a valid input."
  );
});
$("#find_shop_form").validate({
      rules: {
        City: {
          required: true,
        },
      },
      
  });
$("#find_innershop_form").validate({
      rules: {
        City: {
          required: true,
        },
      },
      
  });
$("#subscribe_form").validate({
      rules: {
        email: {
          required: true,
          email:true,
        },
      },
      
  });
$("#signup_form").validate({
      rules: {
        customer_name: {
          required: true,
          "regex":/^[A-Za-z0-9]+$/,
        },
        customer_last_name: {
          required: false,
          "regex":/^[A-Za-z0-9]+$/,
        },
        customer_email: {
          required: true,
          email:true,
        },
        customer_mobile: {
          required: true,
          "regex":/^[0-9]+$/,
          minlength: 7,
          maxlength: 16,
        },
        customer_password: {
          required: true,
          "regex":/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])\S{8,12}$/,
        },
        customer_password2: {
          required: true,
          equalTo: "#customer_password",
        },
        term_condition1:{
          required:true,
        },
        term_condition2:{
          required:true,
        },
      },
      messages: {
                    term_condition1: "Please accept terms and condition 1",
                    term_condition2: "Please accept terms and condition 2",
                    customer_password:{
                        "regex": "Password accept minmum length of 8 and contaning at least 1 Upper, Lower and numeric character (a-z,A-Z,0-9,!@#$%^&*)"
                    }
                },
     submitHandler: function() {
        
        var country_code  = $("#customer_dial_code").val();
        var mobile_number = country_code+$("#customer_mobile").val();
        $.ajax({
            async : false,
            url: base_url + "/users/signup",
            type: "POST",
            data: {customer_name: $("#customer_name").val(), customer_last_name: $("#customer_last_name").val(), customer_password: $("#customer_password").val(), customer_email: $("#customer_email").val(), customer_mobile: mobile_number, signup_phone: $("#customer_mobile").val()},
            beforeSend: function(){
                $("#signup_button").attr('disabled','disabled');
                $("#signup_div").html(canvas);
            },
            complete: function(){
                $("#signup_button").removeAttr('disabled');
                $("#signup_div").html('');
            },
            dataType: "json",
            success: function(data){
                if(parseInt(data['httpcode']) != 200)
                {
                    $.each(data['error'], function(key, value){
                        $("label[for='"+key+"']").html(value);
                        $("label[for='"+key+"']").css('display', 'block');
                        $("#"+key).removeClass('valid');
                        $("#"+key).addClass('error_validate');
                    });
                }
                else {
                  $('#signup').modal('hide');
                  $('#verify').modal('toggle');
                }
                    
            }
        });
      }
      
});
$("#signup_otp_form").validate({
      rules: {
        signup_otp: {
          required: true,
        },
      },
     submitHandler: function() {
        
        var signup_otp  = $("#signup_otp").val();
        $.ajax({
            url: base_url + "/users/confirm_otp",
            type: "POST",
            data: {signup_otp: signup_otp},
            beforeSend: function(){
                $("#signup_otp_button").attr('disabled','disabled');
                $("#signup_otp_div").html(canvas);
            },
            complete: function(){
                $("#signup_otp_button").removeAttr('disabled');
                $("#signup_otp_div").html('');
            },
            dataType: "json",
            success: function(data){
                if(parseInt(data['httpcode']) != 200)
                {
                    $.each(data['error'], function(key, value){
                        $("label[for='"+key+"']").html(value);
                        $("label[for='"+key+"']").css('display', 'block');
                        $("#"+key).removeClass('valid');
                        $("#"+key).addClass('error_validate');
                    });
                }
                else 
                    window.location.href = base_url;
            }
        });
      }
      
});
$("#login_form").validate({
      rules: {
        email_id: {
          required: true,
          email:true,
        },
        password: {
          required: true,
        },
      },
     submitHandler: function() {
        
        if($("#checkbox-1-1").prop("checked")){
            if($.isNumeric($("#email_id").val())){
                $param = {customer_mobile: $("#email_id").val(),customer_email:"", customer_password: $("#password").val(), rememeber_me: 1};
            }else{
                $param = {customer_email: $("#email_id").val(),customer_mobile:"", customer_password: $("#password").val(), rememeber_me: 1};
            }
        }else{
            if($.isNumeric($("#email_id").val())){
                $param = {customer_mobile: $("#email_id").val(),customer_email:"", customer_password: $("#password").val()};
            }else{
                $param = {customer_email: $("#email_id").val(),customer_mobile:"", customer_password: $("#password").val()};
            }
        }
        $.ajax({
            url: base_url + "/users/login",
            type: "post",
            data: $param,
            beforeSend: function(){
              $("#login_button").attr('disabled','disabled');
              $("#login_div").html(canvas);
            },
            complete: function(){
              $("#login_button").removeAttr('disabled');
              $("#login_div").html('');
            },
            dataType: "json",
            success: function(data){
                $("#login_form").find(".errors").html("");
                if(parseInt(data['httpcode']) != 200)
                {
                    $.each(data['error'], function(key, value){
                        $("label[for='password']").html(value);
                        $("label[for='password']").css('display', 'block');
                        $("#password").removeClass('valid');
                        $("#password").addClass('error_validate');
                    });
                }
                else
                    location.reload();
            }
        });
      }
      
});

$(".login_forgot").click(function(){
  $('#login').modal('toggle');
  $('#forgot-password').modal('toggle');
});

$("#forgot_password_form").validate({
      rules: {
        email_id: {
          required: true,
          email:true,
        },
      },
     submitHandler: function() {
        var email = $("#forgot_email_id").val();
        $param = {customer_email: email};
        $.ajax({
            url: base_url + "/users/forgot_password",
            type: "post",
            data: $param,
            beforeSend: function(){
              $("#reset_button").attr('disabled',true);
              $("#login_div").html(canvas);
            },
            complete: function(){
              $("#reset_button").attr('disabled', false);
              $("#login_div").html('');
            },
            dataType: "json",
            success: function(data){
                $("#forgot_password_form").find(".errors").html("");
                if(parseInt(data['httpcode']) != 200)
                {
                        $("label[for='forgot_email_id']").html(data['error']);
                        $("label[for='forgot_email_id']").css('display', 'block');
                        $("#forgot_email_id").removeClass('valid');
                        $("#forgot_email_id").addClass('error_validate');
                }
                else
                    location.reload();
            }
        });

     }
});

$("#edit_profile_form").validate({
      rules: {
        customer_name: {
          required: true,
          "regex":/^[A-Za-z0-9]+$/,
        },
        customer_last_name: {
          required: false,
          "regex":/^[A-Za-z0-9]+$/,
        },
        customer_email: {
          required: false,
          email:true,
        },
        customer_mobile: {
          required: false,
          "regex":/^[0-9 +]+$/,
          minlength: 7,
          maxlength: 16,
        },
      },
     submitHandler: function() {
        if (confirm('Are you sure want to submit?')) {
           form.submit();
        }  
         
     },
      
});
$("#change_password_form").validate({
      rules: {
        customer_password: {
          required: true,
          minlength: 8,
        },
        customer_password2: {
          required: true,
          equalTo: "#customer_password",
        },
      },
      
     submitHandler: function() {
        if (confirm('Are you sure want to submit?')) {
           form.submit();
        }  
         
     },
});

$("#checkout_form").validate({
      rules: {
        saved_address: {
          required: function(element) {
                        if( $("#customer_key").val().length > 0 ){
                            return true;
                        }else{
                            return false;
                        }
                      },
        },
        customer_name: {
          required: function(element) {
                        if( $("#customer_key").val().length > 0 ){
                            return false;
                        }else{
                            return true;
                        }
                      },
          "regex":/^[A-Za-z0-9]+$/,
        },
        customer_last_name: {
          required: false,
          "regex":/^[A-Za-z0-9]+$/,
        },
        customer_email: {
          required: function(element) {
                        if( $("#customer_key").val().length > 0 ){
                            return false;
                        }else{
                            return true;
                        }
                      },
          email:true,
        },
        customer_mobile: {
          required: function(element) {
                        if( $("#customer_key").val().length > 0 ){
                            return false;
                        }else{
                            return true;
                        }
                      },
          "regex":/^[0-9]+$/,
          minlength: 7,
          maxlength: 16,
        },
        selected_address: {
          required: function(element) {
                        if( $("#customer_key").val().length > 0 ){
                            return false;
                        }else{
                            return true;
                        }
                      },
        },
        flat_no: {
          required: function(element) {
                        if( $("#customer_key").val().length > 0 ){
                            return false;
                        }else{
                            return true;
                        }
                      },
        },
        pickup_date: {
          required: function(element) {
                        if( $("#delivery_timing").val() == 1){
                            return false;
                        }else{
                            return true;
                        }
                      },
        },
        pickup_time: {
          required: function(element) {
                        if( $("#delivery_timing").val() == 1){
                            return false;
                        }else{
                            return true;
                        }
                      },
        },
        term_condition1:{
          required:true,
        },
      },
      messages: {
                    saved_address: "Please select any one address",
                    term_condition1: "Please accept terms and condition",
      },
      submitHandler: function() {
	   loading(1);
        var email_error   = 1;
        var mobile_error  = 1;
        var address_error = 1;
        var delivery_error= 1;
        /*Email id check*/
        $.ajax({
            async : false,
            url: base_url + "/shop/email_existence",
            type: "post",
            data: {"email": $('#customer_email').val()},
            beforeSend: function(){
              loading(1);
            },
            complete: function(){
              loading(0);
            },
            dataType: "json",
            success: function(data){
                if(parseInt(data) == 1) {
                  $("label[for='customer_email']").html("email id is already exist!");
                  $("label[for='customer_email']").css('display', 'block');
                  $("#customer_email").removeClass('valid');
                  $("#customer_email").addClass('error_validate');
                  email_error = 1;
                } else {
                  email_error = 0;
                }
            }
        });
        /*Mobile number check*/
        var country_code  = $("#selected-dial-code").val();
        var mobile_number = country_code+$("#customer_mobile").val();
        $.ajax({
            async : false,
            url: base_url + "/shop/mobile_existence",
            type: "post",
            data: {"mobile": mobile_number},
            beforeSend: function(){
              loading(1);
            },
            complete: function(){
              loading(0);
            },
            dataType: "json",
            success: function(data){
                if(parseInt(data) == 1) {
                  $("label[for='customer_mobile']").html("mobile number is already exist!");
                  $("label[for='customer_mobile']").css('display', 'block');
                  $("#customer_mobile").removeClass('valid');
                  $("#customer_mobile").addClass('error_validate');
                  mobile_error = 1;
                } else {
                  mobile_error = 0;
                }
            }
        });
        /*Saved Address check*/
        var myElem = document.getElementById('checking_address_book');
        if ($("#customer_key").val().length > 0 && myElem != null) {
          alert("Please add address to the address book!");
          address_error = 1;
          loading(0);
          return false;
        } else {
          address_error = 0;
        }
        /*delivery address check*/
        if ($("#customer_key").val().length == 0) {
            var customer_latitude  = $("#customer_latitude").val();
            var customer_longitude = $("#customer_longitude").val();
            $.ajax({
                async : false,
                url: base_url + "/shop/vendor_details",
                type: "post",
                data: {customer_latitude: customer_latitude, customer_longitude: customer_longitude},
                beforeSend: function(){
                  loading(1);
                },
                complete: function(){
                  loading(0);
                },
                dataType: "json",
                success: function(data){
                    if (Object.keys(data).length > 0) {
                        if (data[0]["delivery_area"] == 1) {
                            if (data[0]["timeslot_start_time"] != null) {
                                delivery_error = 0;
                            } else {
                                alert("This chef is closed now!");
                                delivery_error = 1;
                                return false;
                            }
                        } else {
                            alert("Your address is out of delivery area!");
                            delivery_error = 1;
                            return false;
                        }
                    } else {
                        alert("This chef is not found!");
                        delivery_error = 1;
                        return false; 
                    }
                }
            });
        } else {
            delivery_error = 0;
        }
	     loading(0);
        if (mobile_error == 0 && email_error == 0 && address_error == 0 && delivery_error == 0) {
            var myElem = document.getElementById('inputcartcheckfield');
            if (myElem == null) {
              alert("Your cart is empty!");
              return false;
            } else {
              if (document.getElementById('inputcartcheckfield').value == 1) {
                  alert("Your cart value is less then minimum order value!");
              } else {
                if (confirm('Are you sure do you want submit?')) {
                    form.submit();
                } else {
                  return false;
                }
              }
               
            }
        } else {
          return false;
        }
        
      }
      
});
$("#address_book_add").validate({
      rules: {
        selected_address: {
          required: true,
        },
        address_type_id: {
          required: true,
        },
        street_name: {
          required: true,
        },
        company: {
          required: true,
        },
        flat_no: {
          required: true,
        },
        apartment: {
          required: true,
        },
        city: {
          required: true,
        },

      },
     submitHandler: function() {
        if (confirm('Are you sure want to submit?')) {
           form.submit();
        }  
         
     },
});
$("#address_book_update").validate({
      rules: {
        selected_address_update: {
          required: true,
        },
        address_type_id: {
          required: true,
        },
        street_name: {
          required: true,
        },
        company: {
          required: true,
        },
        flat_no: {
          required: true,
        },
        apartment: {
          required: true,
        },
        city: {
          required: true,
        },
        // flat_no_update: {
        //   required: true,
        // },
      },
     submitHandler: function() {
        if (confirm('Are you sure want to update?')) {
           form.submit();
        }  
         
     },
});
$("#became_chef_form").validate({
      rules: {
        vendor_contact_name: {
          required: true,
          "regex":/^[A-Za-z0-9\._]+$/,
        },
        vendor_contact_email: {
          required: true,
          email:true,
        },
        vendor_contact_number: {
          required: true,
          "regex":/^[0-9]+$/,
          minlength: 7,
          maxlength: 16,
        },
        vendor_contact_alt_number: {
          required: true,
          "regex":/^[0-9]+$/,
          minlength: 7,
          maxlength: 16,
        },
        locations: {
          required: true,
        },
        vendor_contact_address: {
          required: true,
        },
        short_description: {
          required: true,
        },
        term_condition1:{
          required:true,
        },
        term_condition2:{
          required:true,
        },
      },
      messages: {
                    term_condition1: "Please accept terms and condition 1",
                    term_condition2: "Please accept terms and condition 2",
                },
     submitHandler: function() {
        var country_code  = $("#selected-dial-code").val();
        var mobile_number = country_code+$("#vendor_contact_number").val();
        $.ajax({
            url: base_url + "/become-a-chef",
            type: "POST",
            data: {vendor_contact_name: $("#vendor_contact_name").val(), vendor_contact_last_name: $("#vendor_contact_last_name").val(), vendor_contact_email: $("#vendor_contact_email").val(), vendor_country_code : $('#vendor_dial_code').val() ,vendor_contact_number: $("#vendor_contact_number").val(), alt_country_code : $('#vendor_alt_dial_code').val(), vendor_contact_alt_number: $("#vendor_contact_alt_number").val(), locations: $("#locations").val(), vendor_contact_address: $("#vendor_contact_address").val(), vlatitude: $("#vendor_contact_lat").val(), vlangitude: $("#vendor_contact_lang").val(), short_description: $("#short_description").val(), mobile_number : $("#vendor_contact_number").val(), country_code:country_code, country: $("#country").val()},
            beforeSend: function(){
                $("#become_chef_button").attr('disabled','disabled');
                $("#become_chef_div").html(canvas);
            },
            complete: function(){
                $("#become_chef_button").removeAttr('disabled');
                $("#become_chef_div").html('');
            },
            dataType: "json",
            success: function(data){
                if(parseInt(data['httpcode']) != 200)
                {
                    $.each(data['error'], function(key, value){
                        $("label[for='"+key+"']").html(value);
                        $("label[for='"+key+"']").css('display', 'block');
                        $("#"+key).removeClass('valid');
                        $("#"+key).addClass('error_validate');
                    });
                }
                else 
                    location.reload();
            }
        });
      }
      
});

$("#became_pilot_form").validate({
    rules: {
        pilot_contact_name: {
          required: true,
        },
        pilot_contact_email: {
          required: true,
          email:true,
        },
        pilot_contact_number: {
          required: true,
          "regex":/^[0-9]+$/,
        },
      },
      messages: {
                   
            pilot_contact_name: {
              required: 'required',
            },
            pilot_contact_email: {
              required: "required",
              email:"enter valid email",
            },
            pilot_contact_number: {
              required: "required",
              "regex":"enter valid Mobile Number",
            },

      },
     submitHandler: function() {
        $.ajax({
            url: base_url + "/pilot_signup",
            type: "POST",
            data: {pilot_contact_name: $("#pilot_contact_name").val(), pilot_contact_last_name: $("#pilot_contact_last_name").val(), pilot_contact_email: $("#pilot_contact_email").val(), pilot_country_code : $('#pilot_dial_code').val() ,pilot_contact_number: $("#pilot_contact_number").val() ,short_description: $("#short_descriptions").val()},
            beforeSend: function(){
                $("#became_pilot_button").attr('disabled','disabled');
                $("#become_pilot_div").html(canvas);
            },
            complete: function(){
                $("#became_pilot_button").removeAttr('disabled');
                $("#become_pilot_div").html('');
            },
            dataType: "json",
            success: function(data){
               if(parseInt(data['httpcode']) != 200)
                {
                    $.each(data['error'], function(key, value){
                        $("label[for='"+key+"']").html(value);
                        $("label[for='"+key+"']").css('display', 'block');
                        $("#"+key).removeClass('valid');
                        $("#"+key).addClass('error_validate');
                    });
                } else 
                    location.reload();
                
            }
        });
      }
      
});

$("#review_form").validate({
      rules: {
        review_title: {
          required: true,
        },
        review_text:{
          required: true,
        },
      },
     submitHandler: function() {
        if ($('#rating').val() == '') {
            $("label[for='rating']").html('Please select stars to review');
            $("label[for='rating']").css('display', 'block');
            $("#rating").removeClass('valid');
            $("#rating").addClass('error_validate');
            return false;
        }
        if (confirm('Are you sure want to submit?')) {
            $.ajax({
                    url         : base_url+"/shop/write-review",
                    type        : "post",
                    data        : $('#review_form').serialize(),
                    beforeSend  : function(){
                        loading(1);
                    },
                    complete    : function(){
                        loading(0);
                    },
                    dataType    : "json",
                    success     : function(data){
                        if(data['httpcode'] == 405){
                          $("label[for='rating']").html('Rating has already been given');
                          $("label[for='rating']").css('display', 'block');
                          $("#rating").removeClass('valid');
                          $("#rating").addClass('error_validate');
                          return false;
                        } else {      
                          $("label[for='rating']").css('display', 'none');
                          $('#review_form')[0].reset();
                          $("#RatingModal .modal-content").append("<div class='review_success alert-success alert fade in'>Your rating will get activated soon.</div>").delay(5000).queue(function(next){       
                            $(".review_success").remove();
                            $('#RatingModal').hide();
                            window.location.reload();
                          });
                        }
                    },
                    error:function(xhr){
                    
                    },
              });
        }  
      },
});
$("#recipe").validate({
      rules: {
        recipe_name: {
          required: true,
        },
        prep_time:{
          required: true,
          "regex":/^[0-9]+$/,
        },
        ingredients_needed:{
          required: true,
        },
        'attach[]':{
          required:false,
          extension: "png|jpg|gif",
        }
      },
      messages: {
                    'attach[]': "Please select .jpg, .png, .gif file",
                },
     submitHandler: function() {
        if (confirm('Are you sure want to submit?')) {
           form.submit();
        }  
         
     },
});

/*Loading Canvas*/
var M = Math,
    PI = M.PI,
    TWOPI = PI * 2,
    HALFPI = PI / 2,
    canvas = document.createElement( 'canvas'),
    ctx = canvas.getContext( '2d' ),
    width = canvas.width = 350,
    height = canvas.height = 350,
    cx = width / 2,
    cy = height / 2,
    count = 40,
    sizeBase = 0.1,
    sizeDiv = 5,
    tick = 0;

ctx.translate( cx, cy );

(function loop() {
  requestAnimationFrame( loop );  
  ctx.clearRect( -width / 2, -height / 2, width, height );
  ctx.fillStyle = '#fff';  
  var angle = tick / 8,
      radius = -50 + M.sin( tick / 15 ) * 100,
      size;
  
  for( var i = 0; i < count; i++ ) {
    angle += PI / 64;
    radius += i / 30;
    size = sizeBase + i / sizeDiv;
    
    ctx.beginPath();
    ctx.arc( M.cos( angle ) * radius, M.sin( angle ) * radius, size, 0, TWOPI, false );
    ctx.fillStyle = 'hsl(200, 70%, 50%)';
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc( M.cos( angle ) * -radius, M.sin( angle ) * -radius, size, 0, TWOPI, false );
    ctx.fillStyle = 'hsl(320, 70%, 50%)';
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc( M.cos( angle + HALFPI ) * radius, M.sin( angle + HALFPI ) * radius, size, 0, TWOPI, false );
    ctx.fillStyle = 'hsl(60, 70%, 50%)';
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc( M.cos( angle + HALFPI ) * -radius, M.sin( angle + HALFPI ) * -radius, size, 0, TWOPI );
    ctx.fillStyle = 'hsl(0, 0%, 100%)';
    ctx.fill();
  }
  
  tick++;
})();


/*/* Listing page Description

$(document).ready(function(){
  $(".bg_white").click(function(){
    alert("hai");
    $(".listing_section .list_user_section .list_user_detail .desp").toggleClass("desp_open");
  });
});*/

