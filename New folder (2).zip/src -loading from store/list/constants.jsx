module.exports = require('flux-constants')([
  "GET_PROFILE_RESPONSE",
]);
