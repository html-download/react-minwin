<?php include ('inc/header.php'); ?>

<div class="page_banner style3 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Contact us</h1>
		<h2 class="head small wow fadeInUp">Please let us know the following so that we can help you out better :-)</h2>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey floating_label pad0">
	<div class="container">
		<div class="contact_form">
			<form id="contactform" class="col-sm-8" method="post" onsubmit="return false;" name="contactform" >
				<h3 class="mb30">We'd love to hear from you</h3>
				<div class="row">
					<div class="col-sm-6">
						<label for="contact_name" class="icon">Your Name <span class="pull-right text-danger error contact_name"></span>				
							<input type="text" id="contact_name" name="contact_name" placeholder="Enter Your Name" class="form-control" required="required">
							<i class="fa fa-user"></i>
						</label>
					</div>					
					<div class="col-sm-6">
						<label for="contact_email" class="icon">Your Email <span class="pull-right text-danger error contact_email"></span>
							<input type="email" id="contact_email" name="contact_email" placeholder="Enter Your Email id" class="form-control" required="required">
							<i class="fa fa-envelope-o"></i>
						</label>
					</div>
				</div>
				
				<label for="contact_tel">Phone Number <span class="pull-right text-danger error contact_tel"></span>
					<input type="tel" id="contact_tel" name="contact_tel" placeholder="Enter Your Phone Number" class="form-control" required="required">
				</label>
				
				<label for="contact_message">Drop Your Queries Here <span class="pull-right text-danger error contact_message"></span>
					<textarea placeholder="Enter Your Messages" id="contact_message" name="contact_message" class="form-control" required="required"></textarea>
				</label>
				<input type="hidden" id="contact_url" name="contact_url" value="">
				<input type="hidden" id="contact_country" name="contact_country" value="">
				<input type="hidden" id="contact_tel_code" name="contact_tel_code" value="">
				<input type="hidden" id="contact_page" name="contact_page" value="contact">
				<input type="submit" id="contact_button" value="Submit" class="btn">

			</form>
			
			<div class="col-sm-4">				
				<ul class="reset contact">
					<li class="pl0"><h3>Contact Information</h3></li>
					<li>
						<i class="fa fa-map-marker"></i>
						<address>
							<?php echo $address; ?>
						</address>						
					</li>
					<li>
						<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>" target="_blank" title="WhatsApp Your Requirement"><?php echo $mobile; ?>
						<i class="fa fa-whatsapp"></i></a>
					</li>
					<li>
						<a href="mailto:<?php echo $email; ?>" title="<?php echo $email; ?>"><?php echo $email; ?>
						<i class="fa fa-envelope-o"></i></a>
					</li>
					<li class="pl0"><h3>Social Network</h3></li>
					<li class="social_links">
						<a href="<?php echo $facebook; ?>" target="_blank"><i class="fa fa-facebook"></i></a>
						<a href="<?php echo $twitter; ?>" target="_blank"><i class="fa fa-twitter"></i></a>
						<a href="<?php echo $linkedin; ?>" target="_blank"><i class="fa fa-linkedin"></i></a>
					</li>
				</ul>				
			</div>
		</div> <!--contact_form-->
	</div> <!--container-->
</section> <!--page_banner-->

<?php include('inc/footer.php');?>