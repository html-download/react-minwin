'use strict';
const Actions = require('../actions.js');

const Alert = require('../../../../../components/alert.jsx');
const Button = require('../../../../../components/form/button.jsx');
const ControlGroup = require('../../../../../components/form/control-group.jsx');
const CommonHelper = require('../../../../../helpers/common-functions');
const LinkState = require('../../../../../helpers/link-state.js');
const Modal = require('../../../../../components/modal.jsx');
const ReactRouter = require('react-router-dom');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../../components/form/spinner.jsx');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const TextAreaControl = require('../../../../../components/form/textarea-control.jsx');
const ReactSelectControl = require('../../../../../components/form/react-select-control.jsx');

const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    note: PropTypes.string,
    add_modal_show: PropTypes.bool,
    note: PropTypes.string
};


class CreateNoteForm extends React.Component {
    constructor(props) {

        super(props);

        this.els = {};
        this.state = {
            note: ''
        };
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            note: nextProps.note
        });
    }

    componentDidUpdate() {

        if (this.props.add_modal_show && this.state.note && this.state.note.length === 0) {
            this.els.note.focus();
        }
    }

    onSubmit(event) {

        event.preventDefault();
        event.stopPropagation();
        
        Actions.createNoteNew({
            note: this.els.note.value(),
            deal_id: this.els.deal_id.value()
        }, this.props.id);
    }

    render() {

        let alert;

        if (this.props.error) {
            alert = <Alert
                type="danger"
                message={this.props.error}
            />;
        }

        const formElements = <fieldset>
            {alert}
            <div className="form-box-horizandal">
                <ReactSelectControl
                    ref={(c) => (this.els.deal_id = c)}
                    name="deal_id"
                    label="Deal"
                    defaultValue={this.state.deal_id}
                    /* onChange={ (e) => { }} */
                    disabled={ this.props.loading }
                    groupClasses={ { 'rq': true } }
                    inputClasses={ { 'select-modal': true } }
                    labelClasses={ { 'left-side': true, 'control-label': false, 'req': true } }
                    options={CommonHelper.getOptionData(this.props.deals_data, 'deal_key', 'deal_number')}
                />
                <TextAreaControl
                    ref={(c) => (this.els.note = c)}
                    name="note"
                    label="Note"
                    defaultValue={this.state.note}
                    onChange={LinkState.bind(this)}
                    disabled={this.props.loading}
                    groupClasses={{'rq': true}}
                    inputClasses={{'height-5': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true }}
                />
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'actions': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn': true, 'btn-white': true }}
                        disabled={this.props.loading}
                        onClick={(e) => {Actions.hideNoteModal()}}
                    >
                    Close
                    </Button>
                    <Button
                        type="submit"
                        inputClasses={{ 'btn': true, 'btn-primary': true }}
                        disabled={this.props.loading}>

                        <Spinner space="right" show={this.props.loading} />
                        Create
                    </Button>
                </ControlGroup>
            </div>
        </fieldset>;

        return (
            <Modal
                header="New Note"
                show={this.props.note_modal_show}
                onClose={Actions.hideNoteModal}
                groupClasses={{'model_design1': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>

                <form onSubmit={this.onSubmit.bind(this)}>
                    {formElements}
                </form>
            </Modal>
        );
    }
}

CreateNoteForm.propTypes = propTypes;


module.exports = CreateNoteForm;
