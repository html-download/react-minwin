'use strict';
const Config = require('../../../../../config.js');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const Actions = require('./actions');
const SelectControl = require('../../../../components/form/select-control.jsx');

const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array
};


class Results extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};

        this.state = {
            id: props.id,
            user_id: props.user_id,
            user_name: props.user_name,
            editable_field: props.editable_field
        };

        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);
        this.getUserOptions = this.getUserOptions.bind(this);
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            id: nextProps.id,
            user_id: nextProps.user_id,
            user_name: nextProps.user_name,
            editable_field: nextProps.editable_field
        });

        //(this.input[nextProps.editable_field]) ? this.input[nextProps.editable_field].focus() : null;
    }

    submitCustomer(event, field_name) {
        

        event.preventDefault();
        event.stopPropagation();

        let value = (this.input[field_name]) ? this.input[field_name].value() : undefined;

        const id = this.props.editable_field;
        const data = {
            'attribute_key': field_name,
            'attribute_value': value
        };


        value ? Actions.saveDealDetails(id, data, this.props.history, this.props.searchData) : null;
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

    }

    addEditable(field) {

        Actions.addEditable(field)
    }

    getUpdateButton(field){
        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field) }} className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) }} className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        )
    }

    getLabelContent(name, field, value, type) {

        return (
            <div className="form-gp">
                <div className="side-input">
                    { 
                        (value && value !== '') ? (
                            <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{value}</a>
                        ) : (
                            <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable(field) }} >+Add</a>
                        )
                    }
                </div>
            </div>
        );
    }

    getUserOptions() {

        const user_datas = this.props.user_data ? this.props.user_data : [];
        
        if (user_datas.length === 0) { 
            return null;
        }
        let data = user_datas.map((user_data, index) => {

            return <option 
                        key={`user_data-option-${index}`} 
                        value={user_data.user_key}
                        data-tokens={`${user_data.first_name}`}>
                        {`${user_data.first_name}`}
                    </option>;
        });

        return data;
    }

    getTableData(id, value, isAlignedRight, title) {

        return (
            <td title={title} onClick={(e) => {this.props.history.push(`/admin/deals/${id}`)}} style={{ 'textAlign' : isAlignedRight ? 'right' : 'left'}}>{value}</td>
        );
    }    

    getStatusTextTableData(id, paid_status, deal_status) {
        
            return <td onClick={(e) => {this.props.history.push(`/admin/deals/${id}`)}}>
                <label className="status pink">{paid_status}</label>
                { 
                    deal_status === 1 ? 
                    <label className="status yellow">Policy not issued</label> : 
                    <label className="status green">Active</label>
                }
            </td>;
    }

    getCustomerTableData(id, value) {
        
        return id !== null && value !== null ? (
            <td><Link to={`/admin/customers/${id}`}>{value}</Link></td>
        ) : <td>New Customer</td>;
    }

    getUserTableData(user_id, user_name, deal_key) {

        const formElements = <td>
            {
                this.state.editable_field === deal_key ? (
                    <SelectControl
                        ref={(c) => (this.input.user_id = c)}
                        name="user_id"
                        hideLabel={true}
                        defaultValue={user_id}
                        groupClasses={{'form-group': false, 'form-gp': true}}
                        labelClasses={{'control-label': true, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('user_id')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        { this.getUserOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Assigned to:', deal_key, user_name, 'select')
            }
            
        </td>;

        return formElements;
    }

    render() {

        const rows = (this.props.data && this.props.data.length > 0) ? this.props.data.map((record) => {
            return (
                <tr className="c-pointer" key={record.deal_key}>
                    { this.getTableData(record.deal_key, record.deal_number) }
                    { this.getTableData(record.deal_key, record.stage) }
                    { this.getStatusTextTableData(record.deal_key, record.deal_payment_status_text, record.deal_status) }
                    { this.getTableData(record.deal_key, record.vehicle_brand) }
                    { this.getCustomerTableData(record.customer_id, record.customer_name) }                    
                    { this.getTableData(record.deal_key, record.vehicle_insured_value, true) }
                    { this.getUserTableData(record.user_id, record.user_name, record.deal_key) }
                    { this.getTableData(record.deal_key, record.created_at, false, record.created_date_time) }
                    { this.getTableData(record.deal_key, record.modified_at, false, record.modified_date_time) }
                </tr>
            );
        }) : this.props.list_loading ? (
            <tr key='0'>
                <td colSpan={9} className="text-center">
                    loading...
                </td>
            </tr>
        ) : (
            <tr key='0'>
                <td colSpan={9} className="text-center">
                    No record(s) found!
                </td>
            </tr>
        );

        return (
            <div className={`table-responsive`}>{/*${this.props.list_loading ? 'loader-table' : ''}*/}
                <table className="table table-hover white_table">
                    <thead>
                        <tr>
                            <th>Enquiry Number</th>
                            <th>Stage</th>
                            <th>Status</th>
                            <th>Vehicle</th>
                            <th>Customer</th>                            
                            <th style={{ 'textAlign' : 'right'}}>SUM INSURED (AED)</th>
                            <th>User</th>
                            <th>Created On</th>
                            <th>Updated On</th>
                        </tr>
                    </thead>
                    {
                        this.props.list_loading ? (
                            <tbody>
                                <tr key='0'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='1'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='2'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='3'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='4'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>

                            </tbody>
                        ) : (
                            <tbody>
                                {rows}
                            </tbody>
                        )
                    }
                </table>
            </div>
        );
    }
}

Results.propTypes = propTypes;


module.exports = Results;
