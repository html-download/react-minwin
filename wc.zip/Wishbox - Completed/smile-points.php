<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- Smile page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi star2"></i>
            <h2>Smile Points</h2>
            <p>Total smile points and transaction history</p>
          </div>
          <div class="white-30 smile-page">
             <!-- smile wrap -->
            <div class="smile-wrap">
                <div class="smile-point text-center">
                    <i class="fi smile"></i>
                    <p>Total Smile Points</p>
                    <h3>440</h3>
                </div>
                <div class="promo-code">
                    <span>10 Smile points value = <span class="code">QR 20</span></span>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit duis iaculis, consectetur 
adipiscing elit duis iaculis sagittis blandit.</p>
<div class="input-group">
                  <input type="text" class="form-control" placeholder="PROMO CODE">
                  <div class="input-group-append">
                    <button class="btn" type="button">APPLY</button>
                  </div>
                </div>
                </div>
            </div>
              <!-- smile wrap -->
              <div class="transaction-wrap">
                    <h3>Transaction History</h3>
                    <div class="trans-history">
                        <!--trans-history--->
                        <div class="or-details">
                    <!-- div -->
                    <div>
                    ID
                      <span class="pinks">#smile001</span>
                    </div>
                    <div>
                     Order ID
                      <span>#000280441</span>
                    </div>
                     <div>
                     Date & Time
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                     <div>
                     Points
                      <span>+ 40</span>
                    </div>
                     <div>
                    Balance
                      <span>440</span>
                    </div>
                 
                  </div>
                 
                    <div class="or-details reduce">
                   
                    <div>
                    ID
                      <span class="pinks">#smile001</span>
                    </div>
                    <div>
                     Order ID
                      <span>#000280441</span>
                    </div>
                     <div>
                     Date & Time
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                     <div>
                     Points
                      <span class="minus-point">- 40</span>
                    </div>
                     <div>
                    Balance
                      <span>440</span>
                    </div>
                 
                  </div>
                     <div class="or-details">
                   
                    <div>
                    ID
                      <span class="pinks">#smile001</span>
                    </div>
                    <div>
                     Order ID
                      <span>#000280441</span>
                    </div>
                     <div>
                     Date & Time
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                     <div>
                     Points
                      <span>+ 40</span>
                    </div>
                     <div>
                    Balance
                      <span>440</span>
                    </div>
                 
                  </div>
                   <div class="or-details reduce">
                   
                    <div>
                    ID
                      <span class="pinks">#smile001</span>
                    </div>
                    <div>
                     Order ID
                      <span>#000280441</span>
                    </div>
                     <div>
                     Date & Time
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                     <div>
                     Points
                      <span class="minus-point">- 20</span>
                    </div>
                     <div>
                    Balance
                      <span>440</span>
                    </div>
                 
                  </div>
                     <div class="or-details">
                   
                    <div>
                    ID
                      <span class="pinks">#smile001</span>
                    </div>
                    <div>
                     Order ID
                      <span>#000280441</span>
                    </div>
                     <div>
                     Date & Time
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                     <div>
                     Points
                      <span>+ 40</span>
                    </div>
                     <div>
                    Balance
                      <span>440</span>
                    </div>
                 
                  </div>
                   <div class="or-details reduce">
                   
                    <div>
                    ID
                      <span class="pinks">#smile001</span>
                    </div>
                    <div>
                     Order ID
                      <span>#000280441</span>
                    </div>
                     <div>
                     Date & Time
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                     <div>
                     Points
                      <span class="minus-point">- 20</span>
                    </div>
                     <div>
                    Balance
                      <span>440</span>
                    </div>
                 
                  </div>
                    <!--trans-history end--->
                    </div>
              </div>
           </div>
        <!-- smile page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>