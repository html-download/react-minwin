import React, { Component } from 'react';
import Toggle from 'react-toggle';

class ZoneList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            zones: []
        }
        this.params = {
            //fopark_url: 'http://localhost:5001',
            fopark_url: 'https://api6.fopark-api.com',
            fopark_key: '85be2342d3d0008fc76a448cee6febbd641d83053069c0a3'
    };
        this.handleToggle = this.handleToggle.bind(this);
    }
    handleToggle(event){
        localStorage.setItem(`${event.target.name}_selected`, event.target.checked);
    }
    componentDidMount() {
        fetch(`${this.params.fopark_url}/client/zones?name=auburn`, {
            'headers': new Headers({
                'X-api-key': this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    const zones = Object.keys(result.zones).map( (zone) => {
                        const returnZone = result.zones[zone];
                        returnZone.selected = localStorage.getItem(`${result.zones[zone]['name']}_selected`);
                        if(typeof returnZone.selected === 'string'){
                            if(returnZone.selected === 'false'){
                                returnZone.selected = false;
                            }
                            if(returnZone.selected){
                                returnZone.selected = true;
                            }
                        }
                        if(returnZone.selected === null){
                            returnZone.selected = true;
                        }
                        switch(result.zones[zone]['name']){
                            case 'a':
                                returnZone.color = 'rgb(232, 228, 2)';
                                break;
                            case 'b':
                                returnZone.color = 'rgb(69, 255, 25)';
                                break;
                            case 'c':
                                returnZone.color = 'rgb(1, 34, 112)';
                                break;
                            case 'ada':
                                returnZone.color = 'rgb(18, 90, 214)';
                                break;
                            default:
                                returnZone.color = 'rgb(211, 170, 23)';
                                break;
                        }
                        return returnZone;
                    });
                    this.setState({
                        isLoaded: true,
                        zones: zones
                    });
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            );
    }

    render() {
        const { error, isLoaded, zones } = this.state;

        if(error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if(!isLoaded) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else {
            return (
                <div className="my-3 p-3 bg-white rounded box-shadow">
                    <h6 className="border-bottom border-gray pb-2 mb-0">
                        <div>Select Zones</div>
                    </h6>
                    <p className="text-center">Unless noted with a lot, all zones other than Accessible are open to the public after 5pm.</p>
                    { Object.keys(zones).map( (zone) => {
                        return (
                            <div className="media text-muted pt-3" key={zones[zone]['id']}>
                                <div className="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
                                    <label className="d-flex justify-content-between align-items-center w-100">
                                        <strong className="text-gray-dark" style={{'color': zones[zone].color}}><h4>{zones[zone]['name'].toUpperCase()}</h4></strong>
                                        <Toggle
                                            defaultChecked={this.state.zones[zone].selected}
                                            icons={false}
                                            onChange={this.handleToggle}
                                            name={zones[zone]['name']}
                                        />
                                    </label>
                                </div>
                            </div>
                    )})}
                    <div style={{
                        textAlign: 'right'
                    }}>
                        <button type="button" className="btn btn-primary" onClick={this.props.history.goBack}>Save</button>
                    </div>
                </div>
            );
        }
    }
}

export default ZoneList;