/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorZonePickup', {
    zoneId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'zone_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      field: 'vendor_id'
    },
    zoneName: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'zone_name'
    },
    mileStart: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'mile_start'
    },
    mileEnd: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'mile_end'
    },
    serviceFeeDollarPickup: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'service_fee_dollar_pickup'
    },
    serviceFeePercentagePickup: {
      type: "DOUBLE(10,3)",
      allowNull: false,
      field: 'service_fee_percentage_pickup'
    },
    minAvgMinsPickup: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'min_avg_mins_pickup'
    },
    maxAvgMinsPickup: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'max_avg_mins_pickup'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    }
  }, {
    tableName: 'ss16_vendor_zone_pickup'
  });
};
