'use strict';
const FluxConstant = require('flux-constant');

module.exports = FluxConstant.set([
    'CREATE_NEW',
    'HIDE_CREATE_NEW',
    'CREATE_NEW_RESPONSE',
    'GET_DEALS_RESULTS',
    'GET_DEALS_RESULTS_RESPONSE',
    'GET_CUTOMER_RESULTS',
    'GET_CUTOMER_RESULTS_RESPONSE',
    'UPDATE_DATE_FIELD',
    'SET_EVENTS',
]);
