<?php $title = 'On demand delivery management software and system' ?>
<?php $description = 'On demand delivery management software to focus on providing solutions for any transport operation system like school bus tracking, courier dispatch system, employee transportation software, etc.,' ?>
<?php $keywords = 'online delivery software, school bus management software, courier dispatch system, employee transport management, school bus tracking software' ?>


<?php include ("header.php")?>


<section class="subbanner abouts techno portfolioPage text-center">
<div class="container">
<h1>About Us</h1>
</div>
</section>


<section class="aboutUs">
<div class="container">

<div class="row">

<div class="col-md-7">

<h3>About Us</h3>
<p>Online delivery software is one of the products of Technoduce info solution Pvt Ltd company. We provide an end to end delivery dispatch solutions for any deliverables like the taxi, courier, fleet management, restaurant and much more giving clear visibility over their business. We make your delivery operations simplified and easier. Our products help in increasing your deliveries and reduce customer complaints, we ensure you repeat business.</p>


</div>


<div class="col-md-5">

<div class="ceo">

<img src="img/technoduce.png" class="img-responsive" alt="technoduce">


</div>


</div>

</div>
<p class="marTop">The company has successfully launched several products such as <a href="https://www.technoduce.com/restaurant-menu-ordering-application" target="_blank">FoodPurby </a>(Food ordering system), <a href="https://www.pakodus.com" target="_blank">Pakodus</a> (Food ordering and delivery system), <a href="https://www.croplataxi.com" target="_blank">CroplaTaxi</a> (Taxi dispatch system), <a href="http://www.croplachat.com" target="_blank">CroplaChat</a> (In-App messaging). And now the <a href="/" target="_blank">online delivery software</a> (Delivery application software) providing the complete solution for any deliverable industries.   </p>



</div>
</section>



<!-- footer form -->





<section class="getintouch text-center">
<div class="container">
<h2>Looking for online delivery management software?</h2>
<p class="sub">Our mission is to make your delivery more productive with less effort. <br> To keep your project ideas confidential, we can sign an NDA document.  </p>
<?php include ("contact-form.php");?>
</div>
</section>


<?php include ("footer.php")?>