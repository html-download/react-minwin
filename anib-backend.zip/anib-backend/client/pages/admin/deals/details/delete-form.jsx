'use strict';
const Actions = require('./actions');
const Modal = require('../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');


const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    delete_modal_show: PropTypes.bool,

};


class CreateNewForm extends React.Component {
    constructor(props) {
        super(props);

        this.handleSubmit = this.handleSubmit.bind(this); 
    }

    handleSubmit(e) {
        e.preventDefault();
        e.stopPropagation();

        Actions.delete(this.props.id, this.props.history);
    }

    render() {

        return (
            <Modal
                header={false}
                show={this.props.delete_modal_show}
                onClose={Actions.hideDeleteModal}
                groupClasses={{'alert-modal show': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>
                <div>
                    <h3>Delete</h3>
                    <p>Do you want to delete this Deal?</p>
                    <div className="text-right">
                        <button type="button" className="btn no-shadow" onClick={(e) => {Actions.hideDeleteModal()}}>Cancel</button>
                        <button type="button" className="btn  no-shadow colored" onClick={ (e) => {this.handleSubmit(e)} }>Submit</button>
                    </div>
                </div>
            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;


module.exports = CreateNewForm;
