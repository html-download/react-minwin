'use strict';
const Config = require('../../config');

module.exports = {
    _userIdentity : function () {
        try {
            if (sessionStorage === undefined) {
                var sessionStorage = null;
            }

            if (localStorage === undefined) {
                var localStorage = null;
            }
            const tokens = sessionStorage.getItem('user');

            if (tokens === null) {
                const tokens = localStorage.getItem('user');
            }

            if (tokens !== null) {
                return JSON.parse(tokens);
            }

            return null;
        } catch (e) {
            //console.log(e.message);
            return null;
        }
    },
    _checkUserIdentity : function(){
        try {
            
            var storageVar = sessionStorage.getItem('user');

            if (storageVar === null) {
                storageVar = localStorage.getItem('user');
            }

            if (storageVar !== undefined && storageVar !== null) {
                return true;
            }
            return false;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },
    _checkAcceptTerms : function(){
        try {
            
            var storageVar = localStorage.getItem(`terms_${this._checkUserToken()}`);

            if (storageVar !== undefined && storageVar !== null) {
                return true;
            }
            return false;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },
    _checkUserToken : function(){
        return Config.get('/apiToken'); 
    },
    _checkUserAddress : function(){
        try {
            var storageToken = localStorage.getItem(`address_${this._checkUserToken()}`);

            if (storageToken !== undefined && storageToken !== null) {
                var userStorage = JSON.parse(storageToken);
                return userStorage;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _checkCurrentAddress : function(){
        try {
            var storageToken = localStorage.getItem(`current_address_${this._checkUserToken()}`);

            if (storageToken !== undefined && storageToken !== null) {
                var userStorage = JSON.parse(storageToken);
                return userStorage;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _checkSavedAddress : function(){
        try {
            var storageToken = localStorage.getItem(`saved_address_${this._checkUserToken()}`);
            if (storageToken !== undefined && storageToken !== null) {
                var userStorage = JSON.parse(storageToken);
                return userStorage;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _checkIsLot : function(){
        try {
            var storageToken = localStorage.getItem(`isLot${this._checkUserToken()}`);

            if (storageToken !== undefined && storageToken !== null) {
                var userStorage = JSON.parse(storageToken);
                return userStorage;
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    apiUrl : Config.get('/apiUrl'),
    googleApiKey : Config.get('/googleApiKey'),
    client : Config.get('/client'),
    defaultZones : Config.get('/defaultZones'),
    _getLocation : function(href) {
        var l = document.createElement("a");
        l.href = href;
        return l;
    },
    _getHostName : function (href) {
        var l = this._getLocation(href);
        return l.hostname;
    },
    _pad : function (num) { 
      return ("0"+num).slice(-2);
    },
    _getTimeFromDate : function (timestamp) {
      var date = new Date(timestamp * 1000);
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var seconds = date.getSeconds();
      return this._pad(hours)+":"+this._pad(minutes)/*+":"+pad(seconds)*/;
    }
};
