/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Category', {
    categoryId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'category_id'
    },
    categoryKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'category_key'
    },
    parentCategoryId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'parent_category_id'
    },
    categoryName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'category_name'
    },
    shortDescription: {
      type: DataTypes.STRING(512),
      allowNull: false,
      field: 'short_description'
    },
    categoryIcon: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'category_icon'
    },
    categoryUrl: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'category_url'
    },
    categoryAllowSale: {
      type: DataTypes.ENUM('yes','no','Deleted'),
      allowNull: false,
      defaultValue: 'yes',
      field: 'category_allow_sale'
    },
    sort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    categoryMetaTitle: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'category_meta_title'
    },
    categoryMetaKeywords: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'category_meta_keywords'
    },
    categoryMetaDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'category_meta_description'
    },
    slug: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'slug'
    },
    level: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'level'
    },
    categoryImage: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'category_image'
    },
    startTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'start_time'
    },
    endTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'end_time'
    }
  }, {
    tableName: 'ss16_category'
  });
};
