'use strict';
const Boom = require('boom');
const Config = require('../../config');
const NodeLocalStorage = require('../../client/helpers/nodelocal-storage-access');

const internals = {};


internals.applyRoutes = function (server, next) {

    server.route({
        method: 'DELETE',
        path: '/logout',
        config: {
            auth: {
                mode: 'try',
                strategy: 'session'
            },
            plugins: {
                'hapi-auth-cookie': {
                    redirectTo: false
                }
            }
        },
        handler: function (request, reply) {
            
            let id = request.auth.credentials.id;
            
            NodeLocalStorage.removeItem(`user${id}`);
            
            request.cookieAuth.clear();

            reply({ success: true });

        }
    });


    next();
};


exports.register = function (server, options, next) {

    server.dependency(['auth'], internals.applyRoutes);

    next();
};


exports.register.attributes = {
    name: 'logout'
};
