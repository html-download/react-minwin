'use strict';

var fs = require('fs');
var path = require('path');
var Sequelize = require('sequelize');
var basename = path.basename(__filename);
const Config = require('../../config.js');
var env = process.env.NODE_ENV || 'development';
var config = Config.get('/mysqlEnvironment');
var db = {};
var _db = {};
const Op = Sequelize.Op;

var dialectOptions = {
   supportBigNumbers: true,
   bigNumberStrings: true
}

if (process.env.NODE_ENV == 'production') {
   dialectOptions.socketPath = '/var/lib/mysql/mysql.sock';
}

if (config.use_env_variable) {
    var sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
    //var sequelize = new Sequelize(config.database, config.username, config.password, config);
    var sequelize = new Sequelize(config.database, config.username, config.password, {
       host: config.host,
       logging: false,
       dialect: 'mysql',
       dialectOptions: dialectOptions,
       operatorsAliases: Op, // use Sequelize.Op
       pool: {
           max: 5,
           min: 0,
           acquire: 30000,
           idle: 10000
       }
    });
}

sequelize.authenticate().then(function(err) {
    if (err) {
        console.log('There is connection in ERROR MySql Database');
    } else {
        console.log('MySql Database connection has been established successfully!');
    }
});

fs
    .readdirSync(__dirname)
    .filter(file => {
        return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
    })
    .forEach(file => {
        var model = sequelize['import'](path.join(__dirname, file));
        db[model.name] = model;
    });

Object.keys(db).forEach(modelName => {
    if (db[modelName].associate) {
        db[modelName].associate(db);
    }
});

_db.sequelize = sequelize;
_db.Sequelize = Sequelize;
_db.models = db;
// module.exports = _sequelize;
module.exports = _db;