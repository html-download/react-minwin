<?php
	$company = '
	<li><a href="'.$baseurl.'about-us" title="About Us">About Us <span>Detail about Technoduce</span> <i class="fa fa-user-o"></i></a></li>
	<li><a href="'.$baseurl.'company/our-team" title="Our Team">Our Team <span>Subject matter experts</span> <i class="fa fa-users"></i></a></li>
	<li><a href="'.$baseurl.'company/clients" title="Clients">Clients <span>100% customer satisfaction</span> <i class="fa fa-smile-o"></i></a></li>
	<li><a href="'.$baseurl.'company/testimonial" title="Testimonials">Testimonials <span>Our client&#39;s feedback</span> <i class="fa fa-comments"></i></a></li>
	<li><a href="'.$baseurl.'company/careers" title="Careers">Careers <span>Submit your resume</span> <i class="fa fa-suitcase"></i></a></li>';

	$webServices ='
	<li><a href="'.$baseurl.'angularjs-development" title="AngularJS Application Development">AngularJS Development</a></li>
	<li><a href="'.$baseurl.'react-js-development" title="ReactJS Application Development">ReactJS Development</a></li>
	<li><a href="'.$baseurl.'full-stack-web-development" title="Full Stack Application Development">Full Stack Development</a></li>
	<li><a href="'.$baseurl.'node-js-development" title="NodeJS Application Development">NodeJS Development</a></li>
	<li><a href="'.$baseurl.'ecommerce-application-development" title="E-commerce Application Development">E-commerce Development</a></li>';

	$mobileServices ='
	<li><a href="'.$baseurl.'mobile-application-development" title="Mobile Application Development">Mobile App Development</a></li>
	<li><a href="'.$baseurl.'android-application-development" title="Android Application Development">Android App Development</a></li>
	<li><a href="'.$baseurl.'iphone-application-development" title="iOS Application Development">iOS App Development</a></li>
	<li><a href="'.$baseurl.'react-native-app-development" title="React Native Application Development">React Native Development</a></li>';

	$hireDevelopers ='
	<li><a href="'.$baseurl.'hire-android-developer" title="Hire Android Developers">Hire Android Developers</a></li>
	<li><a href="'.$baseurl.'hire-iphone-developer" title="Hire iPhone Developers">Hire iPhone Developers</a></li>
	<li><a href="'.$baseurl.'hire-angularjs-developer" title="Hire AngularJS Developers">Hire AngularJS Developers</a></li>
	<li><a href="'.$baseurl.'hire-react-js-developer" title="Hire ReactJS Developers">Hire ReactJS Developers</a></li>
	<li><a href="'.$baseurl.'hire-react-native-developer" title="Hire React Native Developers">Hire React Native Developers</a></li>
	<li><a href="'.$baseurl.'hire-full-stack-developer" title="Hire Full Stack Developers">Hire Full Stack Developers</a></li>
	<li><a href="'.$baseurl.'hire-php-developer" title="Hire PHP Developers">Hire PHP Developers</a></li>
	<li><a href="'.$baseurl.'hire-node-js-developer" title="Hire NodeJS Developers">Hire NodeJS Developers</a></li>';

	$products ='
	<li><a href="'.$baseurl.'restaurant-menu-ordering-application" title="FoodPurby">FoodPurby <span>Food ordering system</span> <i class="fa fa-cutlery"></i></a></li>
	<li><a href="http://www.croplataxi.com" title="Grobino">Grobino <span>Ecommerce Application system</span> <i class="fa fa-shopping-cart"></i></a></li>
	<li><a href="https://www.onlinedeliverysoftware.com" title="Online Delivery Software">Online Delivery Software <span>Delivery Management System</span><i class="fa fa-laptop"></i></a></li>';

	$resources ='
	<li><a href="'.$baseurl.'blog" title="Blog">Blog <span>Latest news</span> <i class="fa fa-rss"></i></a></li>
	<li><a href="'.$baseurl.'case-study" title="Case studies">Case studies <span>Success of a company</span> <i class="fa fa-book"></i></a></li>
	<li><a href="'.$baseurl.'tools-and-technology" title="Tech Stack">Tech Stack <span>Tools and Technology</span> <i class="fa fa-laptop"></i></a></li>
	<li><a href="'.$baseurl.'white-paper" title="White paper">White paper <span>Research and data collection</span> <i class="fa fa-database"></i></a></li>
	<li><a href="'.$baseurl.'confidentiality" title="Confidentiality">Confidentiality <span>Tools and Technology</span> <i class="fa fa-lock"></i></a></li>';
?>