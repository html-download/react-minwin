'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {
    loading: false,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    smtp_host: undefined,
    smtp_port: undefined,
    smtp_username: undefined,
    smtp_password: undefined,
    smtp_encryption: undefined
};
const reducer = function (state, action) {

    if (action.type === Constants.SEND_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SEND_MESSAGE_RESPONSE) {
        const validation = ParseValidation(action.response);

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        });
    }

    if (action.type === Constants.TOGGLE_PASSWORD) {
        return ObjectAssign({}, state, {
            show_change_password: action.checked
        });
    }


    if (action.type === Constants.GET_CONFIG_RESULT_RESPONSE) {

        if (action.response.status === 200) {
            return ObjectAssign({}, state, {
                smtp_host: action.response.data.smtp_setting.smtp_host,
                smtp_port: action.response.data.smtp_setting.smtp_port,
                smtp_username: action.response.data.smtp_setting.smtp_username,
                smtp_password: action.response.data.smtp_setting.smtp_password,
                smtp_encryption: action.response.data.smtp_setting.smtp_encryption
            });
        }
    }

    return state;
};


module.exports = Redux.createStore(reducer, initialState);
