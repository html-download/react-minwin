'use strict';
const Actions = require('./actions');
const Alert = require('../../../../../components/alert.jsx');
const Store = require('./store');
const PropTypes = require('prop-types');
const React = require('react');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const TextControl = require('../../../../../components/form/text-control.jsx');
const DateHelper = require('../../../../../helpers/date-time');

const propTypes = {
    customer_id: PropTypes.string,
    customer_driving_profile_key: PropTypes.string
};


class DrivingDetails extends React.Component {

    constructor(props) {

        super(props);
        this.props.customer_id ? Actions.getDrivingDetails(this.props.customer_id) : Actions.changeLoader();
        this.state = Store.getState();
        this.input = {};
        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);
        this.datePicker = this.datePicker.bind(this);
        this.getDrivingExperienceOptions = this.getDrivingExperienceOptions.bind(this);
    }

    componentDidMount() {
        
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentDidUpdate(prevProps, prevStates) {

        prevProps.customer_id !== this.props.customer_id ? Actions.getDrivingDetails(this.props.customer_id) : null;
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    addEditable(field) {
        
        Actions.addEditable(field);
    }

    datePicker(date,field) {
        
        Actions.datePicker(date,field);
    }
    
    submitCustomer(event, field_name) {
        
        event.preventDefault();
        event.stopPropagation();
        
        let value = (this.input[field_name]) ? this.input[field_name].value() : undefined;

        switch (field_name) {
            case 'uae_license_issue_date':
                value = this.state.uae_license_issue_date;
                value = value !== '' ? DateHelper._getDbFormat(value) : undefined;
                break;
            case 'first_license_issue_date':
                value = this.state.first_license_issue_date;
                value = value !== '' ? DateHelper._getDbFormat(value) : undefined;
                break;
            case 'driver_dob':
                value = this.state.driver_dob;
                value = value !== '' ? DateHelper._getDbFormat(value) : undefined;
                break;
        }

        const data = {
            'attribute_key': field_name,
            'attribute_value': value,
            'customer_id': this.props.customer_id,
            'customer_driving_profile_key': this.props.customer_driving_profile_key ? this.props.customer_driving_profile_key : ''
        };
        value ? Actions.saveDrivingDetails(data) : null;
    }

    getDrivingExperienceOptions() {

        const first_licence_age_data = this.state.first_licence_age_data ? this.state.first_licence_age_data : [];
        
        if (first_licence_age_data.length === 0) { 
            return null;
        }
        return first_licence_age_data.map((value, index) => {

            return <option key={`driving-option-${index}`} value={value.type} data-tokens={`${value.type}`}> {`${value.label}`} </option>;
        });
    }

    getCountryOptions() {

        const countries = this.state.country_data ? this.state.country_data : [];
        
        if (countries.length === 0) {
            return null;
        }
        const data = countries.map((value, index) => {

            return <option key={`nationality-option-${index}`} value={value.country_key} data-tokens={`${value.country_key}`}> {`${value.country_name}`} </option>;
        });

        return data;
    }

    getUpdateButton(field) {
        
        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field) }} className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) }} className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        );
    }

    getLabelContent(name, field, value, type) {

        return (
            <div className="form-gp">
                <label className="side req">{name}</label>
                <div className="side-input">
                    { 
                        (value && value !== '') ? (
                            <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }}> {value}</a>
                        ) : (
                            <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable(field) }} > +Add</a>
                        )
                    }
                </div>
            </div>
        );
    }   

    render() {
        
        const alerts = [];

        if (this.state.error) {
            alerts.push(<Alert
                key="danger"
                type="danger"
                message={this.state.error}
            />);
        }
        
        const formElements = <fieldset>
            {alerts}

            {
                this.state.editable_field === 'driver_name' ? (
                    <TextControl
                        ref={(c) => (this.input.driver_name = c)}
                        name="driver_name"
                        label="Driver Name"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.driver_name}
                        help={this.state.help.driver_name}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('driver_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.driver_name}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Driver Name', 'driver_name', this.state.driver_name, 'text')
            }

            {
                this.state.editable_field === 'first_license_country_id' ? (
                    <SelectControl
                        ref={(c) => (this.input.first_license_country_id = c)}
                        name="first_license_country_id"
                        label="First Licence Country"
                        disabled={this.state.loading}
                        defaultValue={this.state.first_license_country_id}
                        hasError={this.state.hasError.first_license_country_id}
                        help={this.state.help.first_license_country_id}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('first_license_country_id')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        { this.getCountryOptions() }
                    </SelectControl>
                ) : this.getLabelContent('First Licence Country', 'first_license_country_id', this.state.first_license_country_name, 'select')
            }
            {
                this.state.editable_field === 'first_license_age' ? (
                    <SelectControl
                        ref={(c) => (this.input.first_license_age = c)}
                        key={'first_license_age'}
                        name="first_license_age"
                        label="First Licence Age"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.first_license_age}
                        help={this.state.help.first_license_age}
                        groupClasses={{ 'form-group': true, 'form-gp': true }}
                        labelClasses={{ 'control-label': false, 'side': true }}
                        inputClasses={{ 'form-control': true, 'add-forms': true, 'select-modal': true }}
                        appendElement={this.getUpdateButton('first_license_age')}
                        appendElementNotString={true}
                        defaultValue={this.state.first_license_age}
                    >   
                        <option value="">Select Option</option>
                        { this.getDrivingExperienceOptions() }
                    </SelectControl>
                ) : this.getLabelContent('First Licence Age', 'first_license_age', this.state.first_license_age_text, 'select')
            }                        

            {
                this.state.editable_field === 'license_number' ? (
                    <TextControl
                        ref={(c) => (this.input.license_number = c)}
                        name="license_number"
                        label="License Number"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.license_number}
                        help={this.state.help.license_number}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('license_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.license_number}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('License Number', 'license_number', this.state.license_number, 'text')
            }

            {
                this.state.editable_field === 'first_license_issue_date' ? (
                    <TextControl
                        ref={(c) => (this.input.first_license_issue_date = c)}
                        name="first_license_issue_date"
                        label="First Licence Issue Date"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.first_license_issue_date}
                        help={this.state.help.first_license_issue_date}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('first_license_issue_date')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.first_license_issue_date !== undefined ? DateHelper._getDefaultFormat(this.state.first_license_issue_date) : ''}
                        onChange={(e) => { this.datePicker(e,'first_license_issue_date')}}
                        isDatePicker={true}
                        maxDate={ new Date() }
                    />
                ) : this.getLabelContent('First Licence Issue Date', 'first_license_issue_date', this.state.first_license_issue_date, 'text')
            }

            {
                this.state.editable_field === 'uae_license_issue_date' ? (
                    <TextControl
                        ref={(c) => (this.input.uae_license_issue_date = c)}
                        name="uae_license_issue_date"
                        label="UAE Licence Issue Date"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.uae_license_issue_date}
                        help={this.state.help.uae_license_issue_date}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('uae_license_issue_date')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.uae_license_issue_date !== undefined ? DateHelper._getDefaultFormat(this.state.uae_license_issue_date) : ''}
                        onChange={(e) => { this.datePicker(e,'uae_license_issue_date')}}
                        isDatePicker={true}
                        maxDate={ new Date() }
                    />
                ) : this.getLabelContent('UAE Licence Issue Date', 'uae_license_issue_date', this.state.uae_license_issue_date, 'text')
            }

            {
                this.state.editable_field === 'uae_license_age' ? (
                    <TextControl
                        ref={(c) => (this.input.uae_license_age = c)}
                        name="uae_license_age"
                        label="UAE Licence Age"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.uae_license_age}
                        help={this.state.help.uae_license_age}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('uae_license_age')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.uae_license_age}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('UAE Licence Age', 'uae_license_age', this.state.uae_license_age, 'text')
            }

            {
                this.state.editable_field === 'driver_dob' ? (
                    <TextControl
                        ref={(c) => (this.input.driver_dob = c)}
                        name="driver_dob"
                        label="Driver Date of Birth"
                        disabled={this.state.loading}
                        hasError={this.state.hasError.driver_dob}
                        help={this.state.help.driver_dob}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('driver_dob')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.driver_dob !== undefined ? DateHelper._getDefaultFormat(this.state.driver_dob) : ''}
                        onChange={(e) => { this.datePicker(e,'driver_dob') }}
                        isDatePicker={true}
                        maxDate={ new Date() }
                    />
                ) : this.getLabelContent('Driver Date of Birth', 'driver_dob', this.state.driver_dob, 'text')
            }

        </fieldset>;
        return (
            
            <div className={ `white-box mt-25 ${this.state.hydrating ? 'loader-tab-content' : ''}` }>
                
                <h5 className="mb-3 f18">Driving Info</h5>

                <form>
                    {formElements}
                </form>

            </div>
        );
    }
}

DrivingDetails.propTypes = propTypes;


module.exports = DrivingDetails;
