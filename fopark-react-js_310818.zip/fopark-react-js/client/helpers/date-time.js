'use strict';
const moment = require('moment');

module.exports = {
    _emailDateTemplate : function () {
        try {
            var day = moment().format("MMM DD, YYYY h:mmA");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    }
};
