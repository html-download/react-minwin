
<footer>
<section class="footer_form">
	<div class="container">
		<h2 class="head wow fadeInUp">Empower your restaurant business with <span>Ontabee</span>!</h2>
		<p class="wow fadeInUp">Increase your revenue volume using our food ordering software.</p>
		
		<form id="tryfooter" method="post" name="tryfooter" action="<?php echo $baseurl;?>signup" class="wow fadeInUp">
			<h5>Try Ontabee</h5>			
			<label>
				<i class="fa fa-user-o"></i>
				<input type="text" name="try_name" placeholder="Your name" class="form-control" required="required">
			</label>
			<label>
				<i class="fa fa-envelope-o"></i>
				<input type="email" name="try_email" placeholder="Your email" class="form-control" required="required">
			</label>
			<input type="hidden" value=""  name="try_url">
			<input type="submit" class="btn" value="Try Ontabee for FREE">
		</form>	
	</div> <!--container-->
</section> <!--footer_form-->

<section class="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<h4>Contact Us</h4>
				<ul class="reset contact">
					<li>
						<i class="fa fa-map-marker"></i></a>
						<address>
							<?php echo $address; ?>
						</address>						
					</li>
					<li>
						<a href="skype:<?php echo $skype; ?>?call" title="Call us using Skype"><?php echo $skype; ?><i class="fa fa-skype"></i></a>
					</li>
					<li>
						<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>&text=hi" target="_blank" title="WhatsApp Your Requirement"><?php echo $mobile; ?>
						<i class="fa fa-whatsapp"></i></a>
					</li>
					<li>
						<a href="mailto:<?php echo $email; ?>" title="<?php echo $email; ?>"><?php echo $email; ?>
						<i class="fa fa-envelope-o"></i></a>
					</li>
				</ul>
			</div>

			<div class="col-sm-3">
				<h4>Our Competitors</h4>
				<ul class="reset menu" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>gloriafood-alternative">GloriaFood Alternative</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>ordering-co-alternative">Ordering.Co Alternative</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>chownow-alternative">ChowNow Alternative</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>menudrive-alternative">MenuDrive Alternative</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>limetray-alternative">LimeTray Alternative</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>oddle-alternative">Oddle Alternative</a></li>
					<?php /*<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>facebook-ordering">Facebook Ordering</a></li>*/?>
				</ul>
			</div>

			<div class="col-sm-3">
				<h4>Company</h4>
				<ul class="reset menu" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>about-us">About us</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>features">Features</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>pricing">Pricing</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>case-studies">Case Studies</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>tools-and-technology">Tools and Technology</a></li>
					<!-- <li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>blog">Blog</a></li> -->
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>contact">Contact Us</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>integration">Integration</a></li>
				</ul>
			</div>

			<div class="col-sm-3 last">
				<h4>Help</h4>
				<ul class="reset menu" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>faq">FAQ</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>knowledge-base">Knowledge Base</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>terms-and-conditions">Terms & Conditions</a></li>
					<li itemprop="name"><a itemprop="url" href="<?php echo $baseurl;?>privacy-policy">Privacy Policy</a></li>
				</ul>
			</div>
		</div>
		
		<div class="copyright">
			<div class="col-xs-4">&copy; <?php echo date("Y");?> Ontabee. All rights reserved.</div>
			<div class="col-xs-4 social_links">
				<a href="<?php echo $facebook; ?>" target="_blank"><i class="fa fa-facebook"></i></a>
				<a href="<?php echo $twitter; ?>" target="_blank"><i class="fa fa-twitter"></i></a>
				<a href="<?php echo $linkedin; ?>" target="_blank"><i class="fa fa-linkedin"></i></a>
			</div>
			<div class="col-xs-4 text-right">Enjoy the rest of your <b><?php echo date("l");?></b>!</div>			
		</div>
	</div> <!--container-->
</section> 
<div id="cookies" style="display:none">
  <p>Our website uses cookies. By continuing we assume your permission to deploy cookies, as detailed in our <a href="<?php echo $baseurl;?>privacy-policy">privacy policy</a>.
  <span class="cookie-accept" title="Okay, close">Ok</span></p>
  </div><!--footer-->
</footer>

</div>

<div id="modal_form" class="modal fade" role="dialog" data-backdrop="static">
	<div class="modal-dialog modal-sm">
		<a class="close" data-dismiss="modal"><i class="fa fa-close"></i></a>
		<div class="modal-body floating_label">
			<h4>Get to know our product</h4>
			<form method="post" name="request_form" onsubmit="return false;" id="request_form">								
				<label for="demo_name" class="icon">Your Name<span class="pull-right text-danger error demo_name"></span>				
					<input type="text" id="demo_name" name="demo_name" placeholder="Enter Your Name" class="form-control" required="required">
					<i class="fa fa-user"></i>
				</label>

				<label for="demo_email" class="icon">Your Email<span class="pull-right text-danger error demo_email"></span>
					<input type="email" id="demo_email" name="demo_email" placeholder="Enter Your Email id" class="form-control" required="required">
					<i class="fa fa-envelope-o"></i>
				</label>

				<label for="demo_tel">Phone Number<span class="pull-right text-danger error demo_tel"></span>
					<input type="tel" id="demo_tel" name="demo_tel" placeholder="Enter Your Phone Number" class="form-control" required="required">
				</label>
				<input type="hidden" id="demo_url" name="demo_url" value="">
				<input type="hidden" id="demo_country" name="demo_country" value="">
				<input type="hidden" id="demo_tel_code" name="demo_tel_code" value="">
				
				<input class="btn pull-right" type="submit" id="demobutton" value="Submit">
			</form>
		</div>
	</div><!--modal-dialog-->
</div><!--modal_form-->

<!-- JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="/js/jquery.min.js"></script>
<script src="/js/plugins.js"></script>
<script src="/js/custom.js"></script> 


<?php /* if($url[1] == 'signup'){ ?>
	<script>
		//Chat Box
		window.setTimeout(function(){
			LC_API.open_chat_window({source:'eye catcher'});
			return false;
		}, 180000);
	</script>
<?php } */ ?>

<!-- <span id="chat_box"><a onclick="LC_API.open_chat_window({source:'eye catcher'});return false"></a></span> -->

<script>
	$(document).ready(function() {


	$('.cookie-accept').click(function () { //on click event
	  days = 182; //number of days to keep the cookie
	  myDate = new Date();
	  myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
	  //creates the cookie: name|value|expiry
	  document.cookie = "cookiename=cookievalue; expires = " + myDate.toGMTString();
	  $("#cookies").slideUp("slow"); //jquery to slide it up
	});

	function request_form() {
	            $("form[name='request_form']").validate({
                    rules: {
                        demo_name: "required",
                        demo_email: {
                            required: true,
                            email: true
                        },
                        demo_tel: {
                            required: true,
                            number:true,
                            minlength: 5
                        },
                    },
                    messages: {
                        demo_name: {
                            required: "Enter your name",
                        },
                        demo_email: {
                            required: "Enter your email",
                            email: "Enter a valid email"
                        },
                        demo_tel: {
                            required: "Enter your phone number",
                            number: "Enter a valid phone number",
                            minlength: "Enter a valid phone number"
                        },

                    },
                    submitHandler: function(form) {
                        //**form.submit();
                        request_form_submit(1);
                    }
                });
            }
            request_form();
            checkCookie();
        });
	
	function accessCookie(cookieName)
    {
      var name = cookieName + "=";
      var allCookieArray = document.cookie.split(';');
      for(var i=0; i<allCookieArray.length; i++)
      {
        var temp = allCookieArray[i].trim();
        if (temp.indexOf(name)==0)
        return temp.substring(name.length,temp.length);
   	  }
    	return "";
    }

	function checkCookie()
    {
      var user = accessCookie("cookiename");
      if(user == undefined || user == '') {
      		$('#cookies').removeAttr("style");
      }
    }
	


	//Plans
	function request_form_submit(id) {
        var data = $('#request_form').serialize();
        $.ajax({
            url: "/mail/demo-form",
            data: data,
            type: "POST",
            dataType: "json",
            beforeSend: function() {
                $("#demobutton").parent().prepend("<div class='request_loading'><img src='/images/loader.gif'/></div>");
                $('#demobutton').attr("disabled", "disabled");
            },
            complete: function() {
                $('#demobutton').removeAttr("disabled");
                $(".request_loading").remove();
            },
            success: function(result) {
                if (result.httpcode == 400) {
                    $.each(result['error'], function(key, value) {
                        $("#request_form").find("." + key).html(value);
                        if(value != '' ) {
	                        $("#request_form").find("." + key).addClass('validerr');
	                        $("#request_form").find("." + key).removeAttr('style');
                    	}
                    });
                } else if (result.httpcode == 405) {
                    $("#request_form").find(".demo_tel").html(result['error']);
                } else {
                   window.location.href = "/demo";
                }
            },
        });
    }


    //Plans
	function contact_request_form_submit(id) {
        var data = $('#contactform').serialize();
        $.ajax({
            url: "/mail/contact-form",
            data: data,
            type: "POST",
            dataType: "json",
            beforeSend: function() {
                $("#contact_button").parent().prepend("<div class='request_loading'><img src='/images/loader.gif'/></div>");
                $('#contact_button').attr("disabled", "disabled");
            },
            complete: function() {
                $('#contact_button').removeAttr("disabled");
                $(".request_loading").remove();
            },
            success: function(result) {
                if (result.httpcode == 400) {
                    $.each(result['error'], function(key, value) {
                        $("#contactform").find("." + key).html(value);
                        if(value != '' ) {
	                        $("#contactform").find("." + key).addClass('validerr');
	                        $("#contactform").find("." + key).removeAttr('style');
                    	}
                    });
                } else if (result.httpcode == 405) {
                    $("#contactform").find(".contact_tel").html(result['error']);
                } else {
                   window.location.href = "/thankyou";
                }
            },
        });
    }


    function signup_form_submit(id) {
        var data = $('#signup').serialize();
        $.ajax({
            url: "/mail/signup?env=dev",
            data: data,
            type: "POST",
            dataType: "json",
            beforeSend: function() {
                $("#signupbutton").parent().prepend("<div class='request_loading'><img src='/images/loader.gif'/></div>");
                $('#signupbutton').attr("disabled", "disabled");
            },
            complete: function() {
                $('#signupbutton').removeAttr("disabled");
                $(".request_loading").remove();
            },
            success: function(result) {
                if (result.httpcode == 400) {
                    $.each(result['error'], function(key, value) {
                        $("#signup").find("." + key).html(value);
                        if(value != '' ) {
	                        $("#signup").find("." + key).addClass('validerr');
	                        $("#signup").find("." + key).removeAttr('style');
                    	}
                    });
                } else if (result.httpcode == 405) {
                    $("#signup").find(".fa_tel").html(result['error']);
                } else {
                   window.location.href = "/thankyou";
                }
            },
        });
    }

 
        

	$('.plans a.monthly').click(function() {
		$('#monthly').html('<span class="symbol">$</span> <?php echo $price;?> <span class="usd">/ Month</span>');
	});
	$('.plans a.annual').click(function() {
		$('#monthly').html('<span class="symbol">$</span> <?php echo $price;?>0 <span class="usd">/ Year</span>');
	});	
</script>

<!-- Start of LiveChat (www.livechatinc.com) code -->
<script type="text/javascript">
window.__lc = window.__lc || {};
window.__lc.license = 9467500;
(function() {
  var lc = document.createElement('script'); lc.type = 'text/javascript'; lc.async = true;
  lc.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'cdn.livechatinc.com/tracking.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
<noscript>
<a href="https://www.livechatinc.com/chat-with/9467500/" rel="nofollow">Chat with us</a>,
powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a>
</noscript>
<!-- End of LiveChat code -->

</body>
</html>