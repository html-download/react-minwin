/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16ModifiersizeOptionList', {
    optionId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'option_id'
    },
    itemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_id'
    },
    typeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'type_id'
    },
    modifiersizeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modifiersize_id'
    },
    price: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'price'
    },
    sortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort_order'
    },
    ingredientsTypeListStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'ingredients_type_list_status'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_modifiersize_option_list'
  });
};
