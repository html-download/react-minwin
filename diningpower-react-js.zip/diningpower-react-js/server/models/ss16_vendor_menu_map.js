/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorMenuMap', {
    menumapId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'menumap_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'vendor_id'
    },
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'menu_id'
    },
    sortVendormenu: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort_vendormenu'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_vendor_menu_map'
  });
};
