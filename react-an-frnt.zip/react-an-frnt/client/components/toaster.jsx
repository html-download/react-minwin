const PropTypes = require('prop-types');
const React = require('react');
const Toaster = require('react-toastify');

//reference url : https://fkhadra.github.io/react-toastify/

const Toast = Toaster.toast;
const ToastContainer = Toaster.ToastContainer;

const propTypes = {
    position: "bottom-right",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: false,
    pauseOnHover: false,
    draggable: false,
};

class ToasterCom extends React.Component {
    constructor(props) {
        super(props);

        this.success = this.success.bind(this);
        this.warning = this.warning.bind(this);
        this.info = this.info.bind(this);
        this.error = this.error.bind(this);

    }
    componentDidMount(){
        //console.log('test')
    }
    success(msg) {
        Toast.success(msg, propTypes);
    }
    warning(msg) {
        Toast.warning(msg, propTypes);
    }
    info(msg) {
        Toast.info(msg, propTypes);
    }
    error(msg) {
        Toast.error(msg, propTypes);
    }
    render() {
        return (
            <ToastContainer
                position="bottom-right"
                autoClose={5000}
                hideProgressBar
                newestOnTop={false}
                closeOnClick={false}
                rtl={false}
                pauseOnVisibilityChange={false}
                draggable={false}
                pauseOnHover={false}
                />
        );
    }
}

module.exports = ToasterCom;
