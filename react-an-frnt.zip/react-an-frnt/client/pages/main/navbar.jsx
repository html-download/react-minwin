'use strict';
const ClassNames = require('classnames');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const ReactSelectControl = require('../../components/form/react-select-control.jsx');

const Link = ReactRouter.Link;
const propTypes = {
    location: PropTypes.object
};


class Navbar extends React.Component {
    constructor(props) {

        super(props);

        this.state = {
            navBarOpen: false,
            scrollingLock: false
        };
         this.handleScroll = this.handleScroll.bind(this);
    }

    componentWillReceiveProps() {

        this.setState({ navBarOpen: false });
    }



handleScroll() {

  if (window.scrollY > 100) {
    this.setState({
      scrollingLock: true
    });
  } else if (window.scrollY < 100) {    
    this.setState({
      scrollingLock: false
    });
  }

}


    isPathActive(pathPattern) {

        let isActive = false;

        if (typeof pathPattern === 'string') {
            isActive = this.props.location.pathname === pathPattern;
        }
        else {
            isActive = this.props.location.pathname.match(pathPattern);
        }

        return ClassNames({
            active: isActive
        });
    }

    toggleMenu() {

        this.setState({ navBarOpen: !this.state.navBarOpen });
    }

    componentDidMount(){
    window.addEventListener('scroll', this.handleScroll);
    
}

    render() {

        const navBarCollapse = ClassNames({
            'navbar-collapse': true,
            collapse: !this.state.navBarOpen
        });

        return (
            <header className={this.state.scrollingLock ? "header scrolled" : "header"}>
                <div className="container">
                    <Link to="/" className="logo-round">
                        <img src="/public/media/images/logo.png" />
                    </Link>
                 
                    <div className="row">
                        <div className="col-md-6">
                            <a href="tel:+971 600 525502" className="text-white res">Any Needs : +971 600 525502</a>
                        </div>
                        <div className="col-md-6">
                            <div className="navigation">
                                <ul>
                                    <li className="res"><Link to="/about">About us</Link></li>
                                    <li className="res"><Link to="/contact">Contact Us</Link></li>
                                    <li className="select">
                                        <ReactSelectControl
    ref={(c) => (this.language = c)}
    name="language"
    hideLable={true}
    onChange={() => {}}
    groupClasses={{'rq': true}}
    inputClasses={{'select-modal': true}}
    labelClasses={{'left-side': true, 'control-label': false}}
    isSearch={false}
    options={[{
        label: 'English',
        value: 'en'
    }, {
        label: 'Arabic',
        value: 'ar'
    }]}
/> 
                                    </li>
                                </ul>
                            </div>
                              
                        </div>
                    </div>
                </div>
            </header>
        );
    }
}

Navbar.propTypes = propTypes;


module.exports = Navbar;
