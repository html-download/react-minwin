'use strict';
const ToasterContainer = require('../components/toaster.jsx');
const Toaster = new ToasterContainer();

module.exports = {
    success: function (msg) {
        try {
            Toaster.success(msg);
            return true;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },

    warning: function (msg) {
        try {
            Toaster.warning(msg);
            return true;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },

    info: function (msg) {
        try {
            Toaster.info(msg);
            return true;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },

    error: function (msg) {
        try {
            Toaster.error(msg);
            return true;
        } catch (e) {
            //console.log(e.message);
            return false;
        }
    },

};
