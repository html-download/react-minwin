'use strict';
const Redux = require('redux');
const Results = require('./reducers/results');
const Details = require('./reducers/policy-details');


module.exports = Redux.createStore(
    Redux.combineReducers({
        results: Results,
        details: Details
    })
);
