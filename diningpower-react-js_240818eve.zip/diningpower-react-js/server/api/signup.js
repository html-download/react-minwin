'use strict';
const Async = require('async');
const Boom = require('boom');
const Shortid = require('shortid');
const Config = require('../../config');
const Joi = require('joi');
const models = require('../models');
const Bcrypt = require('bcrypt');
const Uuid = require('uuid');

const DateTimeHelper = require('../../client/helpers/date-time');

const internals = {};


internals.applyRoutes = function(server, next) {
    const User = models.models.ss16Customer;
    //const Session = models.models.session;
    /*const Account = server.plugins['hapi-mongo-models'].Account;
    const Session = server.plugins['hapi-mongo-models'].Session;
    const User = server.plugins['hapi-mongo-models'].User;*/
    //const User = models.models.ss16Customer;


    server.route({
            method: 'POST',
            path: '/signup',
            config: {
                plugins: {
                    'hapi-auth-cookie': {
                        redirectTo: false
                    }
                },
                /*auth: {
                    mode: 'try',
                    strategy: 'session'
                },*/
                validate: {
                    payload: {
                        email: Joi.string().email().required().label('Email'),
                        name: Joi.string().required().label('First Name'),
                        last_name: Joi.string().token().required().label('Last Name'),
                        password: Joi.string().regex(/^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9.,-@]+)$/).required().label('Password'),
                        terms: Joi.string().required().label('Terms and Conditions')
                    }
                },
                pre: [{
                    assign: 'emailCheck',
                    method: async function(request, reply) {
                        try {
                            const conditions = {
                                customer_email: request.payload.email
                            };

                            let user = await User.find({ where: conditions, raw: true });

                            if (user) {
                                return reply(Boom.conflict('Email already exist!. Try different.'));
                            }

                            reply(true);

                        } catch (e) {
                            if (err) {
                                console.log("err", err);
                                return reply(e);
                            }
                        }
                    }
                }]
            },
            handler: function(request, reply) {
                const mailer = request.server.plugins.mailer;
                let payload = request.payload;
                const key = Uuid.v4();

                Async.auto({
                        salt: function (done) {
                            Bcrypt.genSalt(10, done);
                        },
                        hash: ['salt', function (results, done) {
                            Bcrypt.hash(payload.password, results.salt, done);
                        }],
                        activationHash: ['salt', function (results, done) {
                            Bcrypt.hash(key, results.salt, done);
                        }],
                        user: ['salt', 'hash', 'activationHash', function(results, done) {
                            
                            let customer_data = {
                                "customerKey": Shortid.generate(),
                                 "customerName": payload.name,
                                 "customerLastName": payload.last_name,
                                 "customerEmail": payload.email,
                                 "passwordHash": results.hash,
                                 "customerStatus": 'Active',
                                 "customerActivationStatus": 0,
                                 "customerActivationKey": results.activationHash,
                                 "createdDatetime": new Date(),
                                 "modifiedDatetime": new Date()
                            };
                            User.create(customer_data).then(function(user){
                                done(null,user.toJSON());
                            });
                        }],
                        welcome: ['salt', 'hash', 'activationHash', 'user', function (results, done) {
                            const emailOptions = {
                                subject: 'Your ' + Config.get('/projectName') + ' account',
                                to: {
                                    name: payload.name,
                                    address:payload.email
                                }
                            };

                            const template = 'welcome';
                            
                            let emailData =  {
                                 "customerName": payload.name,
                                 "customerLastName": payload.name,
                                 "customerEmail": payload.email,
                                 "passwordHash":payload.password,
                                 "createdDatetime": DateTimeHelper._emailDateTemplate(),
                                 "modifiedDatetime": new Date(),
                                 "baseUrl": Config.get('/baseUrl'),
                                 baseHref: Config.get('/baseUrl') + '/login/activation',
                                 key: results.activationHash
                            };
                            mailer.sendEmail(emailOptions, template, emailData, (err) => {
                                if (err) {
                                    console.warn('sending welcome email failed:', err.stack);
                                }
                            });

                            done();
                        }]/*,
                        session: ['user', function (results, done) {
                            //Session.create(results.user.customerId.toString(), done);
                        }]*/
                }, (err, results) => {
                    console.log("results", results);
                    console.log("err", err);

                    if (err) {
                        return reply(err);
                    }

                    const user = results.user;
                    const credentials = user.customer_email + ':'/* + results.session.key*/;
                    const authHeader = 'Basic ' + new Buffer(credentials).toString('base64');
                    const result = {
                        user: {
                            _id: user.customerId,
                            username: user.customerEmail,
                            email: user.customerEmail,
                            roles: 1
                        },
                        session: user,//results.session,
                        authHeader
                    };

                    request.cookieAuth.set(result);
                    reply(result);
                });
        }
    });


next();
};


exports.register = function(server, options, next) {

    server.dependency(['mailer'], internals.applyRoutes);

    next();
};


exports.register.attributes = {
    name: 'signup'
};