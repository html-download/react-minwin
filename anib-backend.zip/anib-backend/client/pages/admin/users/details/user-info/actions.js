/* global window */
'use strict';
const ApiActions = require('../../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../../helpers/toaster');


class Actions {

    static getUserDetails(id, renderDom = false) {
        
        ApiActions.get(
            `/user/${id}`,
            undefined,
            Store,
            Constants.CUSTOMER_DETAILS,
            Constants.CUSTOMER_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        document.getElementById('userNameBreadCrumb').innerHTML = response.data.username;
                    }
                }
            }
        );
    }
    static changeLoader() {

        Store.dispatch({
            type: Constants.DISABLE_LOADER
        });
    }

    static saveUserDetails(id, data) {
        
        ApiActions.post(
            `/user/attribute-save/${id}`,
            data,
            Store,
            Constants.CUSTOMER_DETAILS,
            Constants.CUSTOMER_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.removeEditable(data.attribute_key);
                        Toaster.success('User details has been updated.');
                    }
                }
            }
        );
    }    

    static updateDOB(date) {

        Store.dispatch({
            type: Constants.UPDATE_DOB,
            date: date
        });

    }      
   
    static addEditable(field) {
        
        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });

    } 

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });

    }         
    
    static datePicker(date,field) {

        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD,
            date: date,
            field:field
        });

    }
}


module.exports = Actions;
