<?php $title = 'Foodspotting, Seamless, Urbanspoon, takeaway, savored clone script ' ?>
<?php $description = 'We provide ready-made clone script as like Foodspotting, Seamless, Urbanspoon, takeaway, savored to run your restaurant business. Check our portfolios and live demo.' ?>
<?php $keywords = 'Foodspotting clone, Seamless clone, Urbanspoon clone, takeaway clone, savored clone' ?>

            <?php include ("header.php")?>

                <section class="subbanner portfolioPage text-center">
                    <div class="container">
                        <h1>Ordering and delivery app portfolio </h1>
                    </div>
                </section>

                <div class="portfolioContent">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="portfolioImageInner">

                                    <img src="img/portfolio/16.jpg" class="img-responsive" alt="food ordering system bangalore">
                                    <a href="/contact-us"><span class="knOWn">Know More <i class="fa fa-arrow-right" aria-hidden="true"></i></span></a>
                                    <span class="cricleOver"></span>

                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="portfolioImageInner">

                                    <img src="img/portfolio/ju3an.jpg" class="img-responsive" alt="food ordering delivery software">
                                    <a href="/contact-us"><span class="knOWn">Know More <i class="fa fa-arrow-right" aria-hidden="true"></i></span></a>
                                    <span class="cricleOver"></span>

                                </div>
                            </div>

                            <div class="col-md-4">

                                <div class="portfolioImageInner">
                                    <img src="img/portfolio/foodazon.jpg" class="img-responsive" alt="ordering online system restaurant kerala">
                                    <a href="/contact-us"><span class="knOWn">Know More <i class="fa fa-arrow-right" aria-hidden="true"></i></span></a>

                                    <span class="cricleOver"></span>

                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="portfolioImageInner">

                                    <img src="img/portfolio/songo.jpg" class="img-responsive" alt="food order takeaway system">
                                    <a href="/contact-us"><span class="knOWn">Know More <i class="fa fa-arrow-right" aria-hidden="true"></i></span></a>
                                    <span class="cricleOver"></span>

                                </div>
                            </div>

                            <div class="col-md-4">

                                <div class="portfolioImageInner">

                                    <img src="img/portfolio/neo.jpg" class="img-responsive" alt="online ordering delivery system">
                                    <a href="/contact-us"><span class="knOWn">Know More <i class="fa fa-arrow-right" aria-hidden="true"></i></span></a>
                                    <span class="cricleOver"></span>

                                </div>

                            </div>

                        </div>

                    </div>
                </div>

                <section class="getintouch text-center">
                    <div class="container">
                        <h2>Looking for online pickup & delivery software?</h2>
                        <p class="sub">Our mission is to make your delivery more productive with less effort.
                            <br> To keep your project ideas confidential, we can sign an NDA document. </p>
                        <?php include ("contact-form.php");?>
                    </div>
                </section>

<?php include ("footer.php")?>