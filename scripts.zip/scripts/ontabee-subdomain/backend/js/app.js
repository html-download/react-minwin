/**
 * Initializing the global Saddid App variable
 *
 * @param {type} window
 * @returns {undefined}
 *
 * @author A Vijay <vijay.a@technoduce.com>
 */
(function(window){
    var CoreApp, Core;
    if (window.Package) {
        CoreApp = Core = {};
    } else {
        window.CoreApp = {};
        window.Core = {};
    }
})(window);


CoreApp = {
    prototype : {
        session: sessionStorage
    },

    /**
     * Google map API KEY
     */
    MAP_KEY : 'AIzaSyCDKBu1aPoiFQX0tCZUJJ2I8_JRW7f_vmU',

    /**
     * Default lat lon for map load
     */
    DEFAULT_MAP_LOCATION : { lat: 11.024999, lng: 76.903801 },

    DEFAULT_MAP_ZOOM: 13,

    DECIMAL_PRECISION: 2,
    /**
     *
     * @param config
     */
    mapConfig: function (config) {
        return $.extend(
            config,
            {
                zoom: CoreApp.DEFAULT_MAP_ZOOM,
                disableDefaultUI: true
            }
        );
    },
    /**
     * Dark / Light color pair
     * @link: https://material.io/guidelines/style/color.html#color-color-palette
     *
     * [ 400, 100 ]
     */
    colors: [
        ['#EF5350', '#FFCDD2'], // Red
        ['#EC407A', '#F8BBD0'], // Pink
        ['#AB47BC', '#E1BEE7'], // Purple

        ['#7E57C2', '#D1C4E9'], // Deep Purple
        ['#5C6BC0', '#C5CAE9'], // Indigo
        ['#42A5F5', '#BBDEFB'], // Blue

        ['#29B6F6', '#B3E5FC'], // Light Blue
        ['#26C6DA', '#B2EBF2'], // Cyan
        ['#26A69A', '#B2DFDB'], // Teal

        ['#66BB6A', '#C8E6C9'], // Green
        ['#9CCC65', '#DCEDC8'], // Light Green
        ['#D4E157', '#F0F4C3'], // Lime

        ['#FFEE58', '#FFF9C4'], // Yellow
        ['#FFCA28', '#FFECB3'], // Amber
        ['#FFA726', '#FFE0B2'], // Orange

        ['#FF7043', '#FFCCBC'], // Deep Orange
        ['#8D6E63', '#D7CCC8'], // Brown
        ['#BDBDBD', '#F5F5F5'], // Grey

        ['#78909C', '#CFD8DC']  // Blue Grey
    ],
    
    CURRENCY : 'KWD',
    AVAILABILITY_TIMER: 60 * 1000,

    /**
     *
     */
    IDLE_COUNT: 0,
    /**
     *
     */
    AVAILABILITY_URL: false,
    /**
     *
     *
     */
    init: function () {
        CoreApp.initStateListener();
        CoreApp.updateUserState();
    },
    updateUserState: function () {
        CoreApp.ajax({
            url  : CoreApp.AVAILABILITY_URL,
            data : { count : CoreApp.IDLE_COUNT },
            done : function () {
                setTimeout(CoreApp.updateUserState, CoreApp.AVAILABILITY_TIMER);
            }
        });
    },
    /**
     * @link: https://stackoverflow.com/questions/667555/detecting-idle-time-in-javascript-elegantly
     */
    initStateListener: function () {
        $(document).on('click mousemove scroll', function (e) {
            CoreApp.IDLE_COUNT = 0;
        });

        setInterval(function () {
            CoreApp.IDLE_COUNT++;
        }, 1000);
    },
    /**
     * This method is used to perform the jQuery ajax functionality
     *
     * @param options
     * @param overlay
     * @returns {*}
     */
    ajax: function(options, overlay){
        if( overlay !== false ){
            CoreApp.overlay();
        }
        $('.progress').addClass('show');

        if( options.processData === undefined ){
            options.processData = true;
        }
        if( options.contentType === undefined ){
            options.contentType = 'application/x-www-form-urlencoded; charset=UTF-8';
        }

        var jqxhr;
        if ( options.method !== undefined && options.method.toLowerCase() === 'get' ){
            // jqxhr = $.get( options.url , options.data, options.contentType, options.processData, function() {});
            jqxhr = $.get.call(this, options);
        }else{
            // jqxhr = $.post( options.url , options.data, options.contentType, options.processData, function() {});
            jqxhr = $.post.call(this, options);
        }

        typeof options.done === "function" ? jqxhr.done(options.done): null;
        typeof options.fail === "function" ? jqxhr.fail(function(data){ options.fail(data); }): jqxhr.fail(CoreApp.defaultFail);
        typeof options.always === "function" ? jqxhr.always(options.always): null;

        jqxhr.always(function(){
            if( overlay !== false ){
                CoreApp.overlay(false);
            }

            $('.progress').removeClass('show');
        });
        return jqxhr;
    },

    /**
     * This is an default ajax fail callback, when ever CoreApp.ajax is used for asynchronous call
     * @param data
     */
    defaultFail : function(data){
        if ( data.status = 403 ) {
            data.statusText = data.responseText;
        }
        CoreApp.error(data.statusText);
    },
    /**
     *
     * @param input
     * @returns {number}
     */
    checkboxBoolToInt : function ( input ) {
        return input === true ? 1 : 2;
    },
    /**
     *
     * @param input
     * @returns {number}
     */
    boolToInt : function ( input ) {
        return input === true ? 1 : 0;
    },

    /**
     *
     * @param input
     * @returns {boolean}
     */
    intToBool : function ( input ) {
        return parseInt(input) === 1;
    },

    /**
     * This method will check whether the given value is not undefined if so
     * returns the value else defaultValue
     * @param value
     * @param defaultValue
     * @returns {*}
     */
    isDef : function (value, defaultValue) {
        return value !== undefined ? value : defaultValue;
    },

    /**
     * Functions for updating image of file field
     */
    updateImageField : function () {
        $('.img-input-wrapper').each(function () {
            $(this).find('img').attr('src', $(this).find('img').attr('data-src'));
        });
    },

    /**
     * @param object
     * @returns {number}
     */
    getObjectLength : function ( object ) {
        var length = 0;
        for( var key in object ) {
            if( object.hasOwnProperty(key) ) {
                ++length;
            }
        }
        return length;
    },
    /**
     * @link http://stackoverflow.com/a/3710226/5798881
     *
     * @param jsonStr
     * @returns {boolean}
     */
    isValidJsonStr : function (jsonStr) {
        if (typeof jsonStr !== 'string') {
            return false;
        }
        try{
            JSON.parse(jsonStr);
        } catch (e) {
            return false;
        }
        return true;
    },
    /**
     *
     * @param key
     * @returns {boolean}
     */
    isSession : function (key) {
        return this.prototype.session.getItem(key) !== null;
    },
    /***
     *
     * @param key
     * @param value
     */
    setSession: function (key, value) {
        return this.prototype.session.setItem(key, value);
    },
    /**
     *
     * @param key
     */
    session : function (key) {
        return this.prototype.session.getItem(key);
    },
    /**
     *
     * @param key
     */
    removeSession : function (key) {
        return this.prototype.session.removeItem(key);
    },
    /**
     *
     */
    clearSession: function () {
        return this.prototype.session.clear();
    },

    info: function (options) {

        if( typeof options === 'string'){
            options = { title: options };
        }
        $.gritter.add({
            title: "Info",
            text: options.title,
            fade_out_speed : 100,
            time : 2000,
            class_name:"color primary"
        });
    },
    error: function (options) {
        if( typeof options === 'string'){
            options = { title: options };
        }

        $.gritter.add({
            title: "Failed",
            text: options.title,
            fade_out_speed : 100,
            time : 2000,
            class_name:"color danger"
        });
    },

    success: function (options) {
        if( typeof options === 'string'){
            options = { title: options };
        }

        $.gritter.add({
            title: "Success",
            text: options.title,
            fade_out_speed : 100,
            time : 2000,
            class_name:"color success"
        });
    },

    /**
     * @link http://stackoverflow.com/a/1026087/5798881
     *
     * @param string
     * @returns {string}
     */
    ucFirst: function (string) {
        if( string === undefined ){
            return 'undefined';
        }
        return string.charAt(0).toUpperCase() + string.slice(1);
    },

    overlay: function (show) {
        if ( show === undefined ) {
            show = true;
        }
        var overlayEle = $('body .overlay');

        if(show) {
            overlayEle.addClass('show');
        }else{
            overlayEle.fadeOut(400, function () {
                $(this).removeClass('show');
            });
        }
    },

    initTimePicker: function () {
        // Timepicker
        $(".timepicker").timepicker({
            minuteStep: 1,
            maxHours : 24
        });
    },
    initTooltip: function () {
        $('[data-toggle="tooltip"]').tooltip();
    },
    /**
     * @link: http://stackoverflow.com/a/25867340/5798881
     */
    log: function () {
        console.log.apply(console, Array.prototype.slice.call(arguments));
    },
    warn: function () {
        console.warn.apply(console, Array.prototype.slice.call(arguments));
    },


    toFixed: function (float) {
        return parseFloat(float).toFixed(this.DECIMAL_PRECISION);
    },


    handleInvalidServerResponse: function (json) {
        if( typeof json === 'string'){
            CoreApp.error('Invalid Response');
            return false;
        }

        if( json.error !== undefined && CoreApp.getObjectLength(json.error) !== 0 ){
            CoreApp.log(json.error);
            for ( var error in json.error) {
                CoreApp.error(json.error[error][0]);
            }
            return false;
        }

        if(json.msg === undefined || json.msg.length === 0){
            json.msg = CoreApp.ERROR.DEFAULT_MSG;
        }
        CoreApp.error(json.msg);
    },

    /**
     * @link: http://stackoverflow.com/a/3855394/5798881
     */
    queryString: {},
    queryStringRefresh: function () {
        var a = window.location.search.substr(1).split('&');
        if (a === "") return {};
        var b = {};
        for (var i = 0; i < a.length; ++i)
        {
            var p=a[i].split('=', 2);
            if (p.length !== 2) continue;
            b[p[0]] = decodeURIComponent(p[1].replace(/\+/g, " "));
        }
        CoreApp.queryString = b;
        return this;
    },

    /**
     *
     * @param options
     */
    pagination: function(options){

        if( options.selector === undefined || options.pageCount === undefined || options.page === undefined ){
            throw new Error('Required param missing');
        }


        options.page = parseInt(options.page) - 1;

        var selector = $(options.selector), paginationHtml, page,
            li, pageSpan = 3, halfPageSpan = pageSpan / 2, edges = 2,
            interval;

        if( selector[0] === undefined ){
            throw new Error('Unable to find the dom');
        }
        if( parseInt(options.pageCount) <= 1 ){
            selector.html('');
            return;
        }

        if( !selector.hasClass('pagination') ){
            selector.addClass('pagination');
        }
        draw();

        function draw(){
            paginationHtml = $('<ul />').addClass('reset');
            interval = getInterval();

            // Starting pagination links
            for (page = 0; page < Math.min(edges, interval.start); page++) {
                preparePage(page);

            }
            if (edges < interval.start && (interval.start - edges !== 1)) {
                preparePage(0, true);
            } else if (interval.start - edges === 1) {
                preparePage(edges);
            }

            // Intermediate pagination links
            for (page = interval.start; page < interval.end; page++) {
                preparePage(page);

            }

            // Ending pagination links
            if (options.pageCount - edges > interval.end && (options.pageCount - edges - interval.end !== 1)) {
                preparePage(0, true);
            } else if (options.pageCount - edges - interval.end === 1) {
                preparePage(interval.end);
            }
            for (page = Math.max(options.pageCount - edges, interval.end); page < options.pageCount; page++) {
                preparePage(page);
            }

            prepare();
            selector.html(paginationHtml);
        }

        function prepare() {
            li = $('<li class="action"> \
                    <a >First</a>\
                    <a class="icon"><i class="fa fa-angle-left"></i></a>\
                </li>');

            li.find('a:first-child').click(function (e) {
                if( options.page !== 0 ){
                    onPageSelect(0, e);
                }

            });
            li.find('a:last-child').click(function (e) {
                if( options.page > 0 ){
                    onPageSelect(options.page - 1, e);
                }
            });
            paginationHtml.prepend(li);

            li = $('<li class="action"> \
                        <a class="icon"><i class="fa fa-angle-right"></i></a>\
                        <a >Last</a>\
                    </li>');

            li.find('a:first-child').click(function (e) {
                if( options.page < options.pageCount - 1){
                    onPageSelect(options.page + 1, e);
                }
            });
            li.find('a:last-child').click(function (e) {
                if( options.page !== options.pageCount ){
                    onPageSelect(options.pageCount - 1, e);
                }
            });
            paginationHtml.append( li );
        }

        function getInterval() {
            return {
                start: Math.ceil(options.page > halfPageSpan ? Math.max(Math.min(options.page - halfPageSpan, options.pageCount - pageSpan), 0) : 0),
                end: Math.ceil(options.page > halfPageSpan ? Math.min(options.page + halfPageSpan, options.pageCount) : Math.min(pageSpan, options.pageCount))
            }
        }

        function preparePage(page, ellipse){
            page = page < 0 ? 0 : (page < options.pageCount ? page : options.pageCount - 1);

            li = $("<li></li>");

            if( ellipse === true ){
                li.text('...');
            }else {
                li.append($('<a />').text(page + 1));
                if( page === options.page ){
                    li.find('a').addClass('active');
                }
                li.find('a').click(function (event) {
                    onPageSelect(page, event);
                });
            }

            paginationHtml.append(li);
        }

        function onPageSelect(page, event){
            if( options.page === page ){
                return;
            }
            options.page = page;
            draw();

            options.onPageClick.apply(this, [page + 1, event]);
        }
    },
    /**
     * @link https://gist.github.com/mathewbyrne/1280286
     * @param text
     */
    slugify: function ( text ) {
        return text.toString().toLowerCase()
            .replace(/\s+/g, '-')           // Replace spaces with -
            .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
            .replace(/\-\-+/g, '-')         // Replace multiple - with single -
            .replace(/^-+/, '')             // Trim - from start of text
            .replace(/-+$/, '');            // Trim - from end of text
    },
    ERROR : {
        DEFAULT_MSG : 'Unable perform the action'
    }
};

Core = Object.assign({}, CoreApp);
(function ($) {
    $(document).ready(function () {

        CoreApp.queryStringRefresh();

        var $this, file;
        $(document).on('change', '.img-input-wrapper input[type="file"]', function () {
            $this = $(this);
            file = $this[0].files[0];
            if (file !== undefined && file.type.match(/^image\/(gif|png|jpeg|svg\+xml)$/)) {
                /**
                 * @link http://stackoverflow.com/a/4459419/5798881
                 */
                var reader = new FileReader();

                reader.onload = function (e) {
                    $this.parents('.img-input-wrapper').find('img').attr('src', e.target.result);
                    $this.parents('.img-input-wrapper').find('.img-input-action').text('change');
                };
                reader.readAsDataURL(file);
            }else{
                CoreApp.updateImageField();
            }
        });


        var $fieldGrp;
        $(document).on('click', '.password-field-group .pwd-viewer-toggle', function () {
            $this = $(this);
            $fieldGrp = $this.closest('.password-field-group');

            if ( $fieldGrp.hasClass('pwd-visible') ) {
                $fieldGrp.removeClass('pwd-visible');

                $fieldGrp.find('input').attr('type', 'password');
                $this.removeClass('mdi-eye-off').addClass('mdi-eye');
            } else {
                $fieldGrp.addClass('pwd-visible');

                $fieldGrp.find('input').attr('type', 'text');
                $this.removeClass('mdi-eye').addClass('mdi-eye-off');
            }

        });
    });

    if (!HTMLCanvasElement.prototype.toBlob) {
        Object.defineProperty(HTMLCanvasElement.prototype, 'toBlob', {
            value: function (callback, type, quality) {

                var binStr = atob( this.toDataURL(type, quality).split(',')[1] ),
                    len = binStr.length,
                    arr = new Uint8Array(len);

                for (var i = 0; i < len; i++ ) {
                    arr[i] = binStr.charCodeAt(i);
                }

                callback( new Blob( [arr], {type: type || 'image/png'} ) );
            }
        });
    }

})(jQuery);