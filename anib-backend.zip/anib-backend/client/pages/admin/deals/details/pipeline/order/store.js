'use strict';
const Constant =  require('./constants');
const ObjectAssign = require('object-assign');
const Redux = require('redux');
const ParseValidation = require('../../../../../../helpers/parse-validation');

const initialState = {   
    loading: false,
    order_save_loading: false,
    product_hydrated: true,
    success: false,
    error: undefined,
    hasError: {},
    help: {}, 
    is_quote_collapsed: false,
    quote_data: {},
    is_quote_modal_open: false,
    deal_quote_key: undefined,
    deal_quote_document : [],
    submit_event: undefined,
    load_create_policy: false
};


let validation;
let result;
const reducer = function (state = initialState, request) {

    switch (request.type) {

        case Constant.CHOOSE_POLICY_DETAILS:
            return ObjectAssign({}, state, {
                load_create_policy : true,
                order_save_loading: true
            });
            break;
        case Constant.CHOOSE_POLICY_DETAILS_RESPONSE:

            if (request.response.status !== 200) {
                return ObjectAssign({}, state, {
                    load_create_policy : false,
                    order_save_loading: false
                });
                break;
            }
            
        case Constant.GET_DEAL_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                loading : true
            });
            break;

        case Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE:

            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : {};
            
            return ObjectAssign({}, state, {
                loading: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                quote_data: result
            });
            break;

        case Constant.GET_PRODUCT_DETAILS:
            return ObjectAssign({}, state, {
                product_hydrated : true
            });
            break;

        case Constant.GET_PRODUCT_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                product_hydrated: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                product_data: result
            });

            break;
        case Constant.GET_DEAL_QUOTE_DOCU_DETAILS:
            return ObjectAssign({}, state, {
                deal_quote_document : []
            });
            break;

        case Constant.GET_DEAL_QUOTE_DOCU_DETAILS_RESPONSE:
            validation = ParseValidation(request.response);
            result = (request.response && request.response.data) ? request.response.data : [];                        
            if (request.response.status === 200) {
                return ObjectAssign({}, state, {
                    deal_quote_document: request.response.data
                });
            }
            break;

        case Constant.TOGGLE_QUOTE:
            return ObjectAssign({}, state, {
                is_quote_collapsed : (state.is_quote_collapsed) ? false : true
            });
            break;

        case Constant.UPDATE_DATE:

            let stat = state;

            if (request.field === 'policy_expire_date') {
                stat.quote_data.policy_expire_date = request.date
                
                return ObjectAssign({}, state, stat);
            }

            stat.quote_data.policy_start_date = request.date;
            
            return ObjectAssign({}, state, stat);
            break;

        case Constant.OPEN_QUOTE_MODAL:
            return ObjectAssign({}, state, {
                is_quote_modal_open: true,
                deal_quote_key: request.deal_quote_key,
                submit_event: request.submit_event
            });
            break;
        case Constant.HIDE_QUOTE_MODAL:
            return ObjectAssign({}, state, { 
                is_quote_modal_open: false,
                deal_quote_key: undefined,
                submit_event: undefined
            });
            break;
        
        case Constant.GET_DEAL_QUOTE_DETAILS:
            return state;
            break;
        case Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE:
            if (request.response.status === 200) {
                return ObjectAssign({}, state, {
                    deal_quote_document: request.response.data
                });
            }
            break;

        case Constant.UPDATE_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                order_save_loading : true
            });
            break;

        case Constant.UPDATE_QUOTE_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                order_save_loading: false
            });

            break;

        default:
            return ObjectAssign({}, state);
            break;
    }           
};
module.exports = Redux.createStore(reducer);


