'use strict';
const Delete = require('./reducers/delete');
const Details = require('./reducers/details');
const Redux = require('redux');
const Password = require('./reducers/password');
const TaskDetails = require('./reducers/task-details');
const Common = require('./reducers/common');
const DealCreate = require('./reducers/deal-create');


module.exports = Redux.createStore(
    Redux.combineReducers({
        delete: Delete,
        details: Details,
        password: Password,
        taskDetails: TaskDetails,
        common : Common,
        dealCreate: DealCreate
    })
);
