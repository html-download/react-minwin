'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');
const Config = require('../../../../config.js');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    show: PropTypes.bool,
    show_info_window : PropTypes.bool,
    saveStallValue : PropTypes.func
};


class ModalForm extends React.Component {
    renderNewCloseButton() {
        return <button className="show_hide"><i className="fa fa-bars"></i></button>;
    }
    render() {
        let marker = this.props.stallMarkerArray;
        return (
            <Modal
                id="modal_info_window"
                header={`Stall Number - ${this.props.stallMarkerArray.stallNumber ? this.props.stallMarkerArray.stallNumber : 'NULL'}`}
                footer={false}
                renderNewCloseButton={<button className={this.props.show_info_window ? 'show_hide open' : 'show_hide'} onClick={()=>{ Actions.toggleInfoWindowModal()}}><i className="fa fa-bars"></i></button>}
                show={true}
                onClose={Actions.hideInfoWindowModal}
                modalDialogClasses={{'modal-sm' : true}}
                backdropClasses={{'modal-backdrop' : false}}
                modalClasses={{'right' : true, 'fade' : true, 'in':true, 'open' : this.props.show_info_window}}>
                <div className="modal-table">
                    <div className="modal-center">
                        <ul className="reset zone-info">
                            <li>
                                <div className="form-group">
                                    <i className="fa fa-clock-o"></i>
                                    
                                        {(this.props.stallMarkerArray.duration === 0 || this.props.stallMarkerArray.duration === '-') ? (
                                            <span  className="green" id={`occupancy_duration_${this.props.stallMarkerArray.stallNumber}`}> 
                                                <b>NO VEHICLE PARKED</b>
                                            </span>
                                            ) : (
                                            <span className="red" id={`occupancy_duration_${this.props.stallMarkerArray.stallNumber}`}> 
                                                <b>DURATION OF STAY : </b>
                                                {this.props.stallMarkerArray.duration} mins
                                            </span>
                                        )}
                                </div>
                            </li>
                            <li className="info_window_popup veh_pic2">
                                <div className="form-group">
                                    <div className="clearfix mb12"></div>
                                    <div className="form-group flag">
                                        <input id={`info_window_popup_reserved_${this.props.stallMarkerArray.stallNumber}`} name="checkbox" type="checkbox" className="hide"  
                                        defaultChecked={this.props.stallMarkerArray.reserve_flag === 1} 
                                        key={`${Math.floor((Math.random() * 1000))}-min`} />
                                        <label htmlFor={`info_window_popup_reserved_${this.props.stallMarkerArray.stallNumber}`} className="checkbox">Reserved</label>
                                    </div> 
                                </div>
                            </li>
                            <div className="zone_img veh_pic2">
                                <img id={`img1_${this.props.stallMarkerArray.stallNumber}`} src="/public/media/images/312fe6d1-31b0-4c63-858b-ffd7717cefa7.png" alt="" style={{float: "left"}}/>
                                <p className="entry-date">ENTRY : <span id={`entry_time_${this.props.stallMarkerArray.stallNumber}`}>-</span> </p>
                            </div>
                            <div className="zone_img veh_pic3">
                                <img id={`img2_${this.props.stallMarkerArray.stallNumber}`} src="/public/media/images/312fe6d1-31b0-4c63-858b-ffd7717cefa7.png" alt="" style={{float: "left"}}/>
                                <p className="entry-date">CURRENT <span id={`current_time_${this.props.stallMarkerArray.stallNumber}`}>-</span> </p>
                            </div>
                        </ul>
                        <div className="action mb0 text-center w100" style={{ 'display' : this.props.stallMarkerArray.stallNumber ? 'block' : 'none'}}>
                            <button className="btn grey" onClick={()=>{ Actions.toggleInfoWindowModal()}}>HIDE in App</button>
                            <button className="btn" onClick={(event)=>{ this.props.saveStallValue(event, marker.stallNumber, marker.lat, marker.lng, marker.lot_name, marker.stallNumber, true)}} >Save</button>
                            
                        </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
