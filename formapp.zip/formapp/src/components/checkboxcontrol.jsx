import React from 'react';  

import PropTypes from 'prop-types'; 
import ClassName from 'classnames';

const Checkbox = (props) => {

  let groupClasses = ClassName(Object.assign({
    'form-group' : true
  }, props.groupClasses));

  let lableClasses = ClassName(Object.assign({
    'checkbox' : true
  }, props.labelClasses ));

  let inputClasses = ClassName(Object.assign({
    'checkbox' : true
  }), props.inputClasses)

  return( 
   
    <div className={groupClasses}>
     <label>{props.title}</label>
     <div className="d-block">
      {(props.options.length === 0 || props.options === undefined) ? null : props.options.map((option, index) => {
        return (
          <div className="d-inline" key={index}>
           <input

              className={inputClasses}
              id = {props.type + index}
              name={props.name}
              onChange={props.onChange}
              value={option}
              type={props.type} />

          <label  htmlFor={props.type + index} className={lableClasses}>
           {option}
          </label>

          </div>

        );
         
      })}
      </div>
    </div>
  
);

}

Checkbox.propTypes={
 name: PropTypes.string,
  title: PropTypes.string,
  type: PropTypes.oneOf(['checkbox', 'radio']),
  options: PropTypes.array,
  onChange: PropTypes.func
};



export default Checkbox;