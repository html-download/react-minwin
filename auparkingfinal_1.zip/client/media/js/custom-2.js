//Fixed Header  
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".site_header").addClass("fixed");
    } else {
        $(".site_header").removeClass("fixed");
    }		
});

jQuery(document).ready(function(){
	jQuery('.scrollbar-inner').scrollbar();
});

new WOW().init();

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
    $('[rel="tooltip"]').tooltip();
});

//floating_label
$(document).on('focus active', '.floating_label .input-group ',function(){
	$(this).addClass('focus');

});
$(document).on('blur', '.floating_label .input-group',function(){
	//$('label[for='+$(this).attr('id')+']').removeClass('focus');
    $(this).removeClass('focus');

});

//Current Page
$(document).ready(function() {
    $("[href]").each(function() {
    if (this.href == window.location.href) {
        $(this).addClass("active");
        }
    });
});

// Date Time Picker
$(".datetime").datetimepicker({		
	format: "dd-M-yyyy - HH:ii P",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

//Select
var config = {
  '.chosen-select1'           : {},
  '.chosen-select-deselect'  : {allow_single_deselect:true},
  '.chosen-select-no-single' : {disable_search_threshold:10},
  '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
  '.chosen-select'           : {disable_search: true}
}
for (var selector in config) {
  $(selector).chosen(config[selector]);
}

//Mini Cart

$(".site_header .cart").click(function(){
    $("#mini_cart").fadeIn();
    $("#mini_cart").addClass("open");
    $("body").addClass("modal_open");
    $("#item_detail").fadeOut();
    $("#item_detail").removeClass("open");
    $(".item_detail .loading").show();
});
$(".close_cart").click(function(){
    $("#mini_cart").fadeOut();
    $("#mini_cart").removeClass("open");
    $("body").removeClass("modal_open");
});

//Item Detail
$(".item .cart").click(function(){
    window.setTimeout(function(){ $('.item_detail .loading').fadeOut(); }, 2000);
    $("#item_detail").fadeIn();
    $("#item_detail").addClass("open");
    $("body").addClass("modal_open");
});
$(".close_detail").click(function(){
    $(".item_detail .loading").show();
    $("#item_detail").fadeOut();
    $("#item_detail").removeClass("open");
    $("body").removeClass("modal_open");
});


$(".mini_cart, .item_detail").on('click', function(event) {
    event.stopPropagation();
});

//Modal
$(".modal_change").click(function(){
	$("body").addClass("modal_open");
});
$(".modal .close").click(function(){
	$("body").removeClass("modal_open");
});

//Side Menu Active
$('.side_menu a').click(function() {
    $('.side_menu a.active').removeClass('active');
    $('.loader').fadeIn();
    window.setTimeout(function(){ $('.loader').fadeOut(); }, 2000);
    $(this).addClass('active');
});

//Checkbox Show hide
$('input.target').on('change', function() {
    var source = $(this);
    var target = $('#' + source.attr('data-target'));
    if ($('input[data-target='+source.attr('data-target')+']:checked').length) target.slideDown();
    else target.slideUp();
});

//Alert Box
$(".actions .remove").click(function(){
    $(".actions .item").slideUp(150);
	$(this).next('.item').slideDown(150);
});
$(document).on("click", ".actions .item .btn" , function(){
	$(this).parents('.item').slideUp(150);
});
$('body').on('click', function (e) {
    $(".actions .item").slideUp(150);
});
$(".actions .remove").on('click', function(event) {
    event.stopPropagation();
});

//Sticky Sidebar
(function(){var c,f;c=this.jQuery||window.jQuery;f=c(window);c.fn.stick_in_parent=function(b){var A,w,B,n,p,J,k,E,t,K,q,L;null==b&&(b={});t=b.sticky_class;B=b.inner_scrolling;E=b.recalc_every;k=b.parent;p=b.offset_top;n=b.spacer;w=b.bottoming;null==p&&(p=0);null==k&&(k=void 0);null==B&&(B=!0);null==t&&(t="is_stuck");A=c(document);null==w&&(w=!0);J=function(a){var b;return window.getComputedStyle?(a=window.getComputedStyle(a[0]),b=parseFloat(a.getPropertyValue("width"))+parseFloat(a.getPropertyValue("margin-left"))+
parseFloat(a.getPropertyValue("margin-right")),"border-box"!==a.getPropertyValue("box-sizing")&&(b+=parseFloat(a.getPropertyValue("border-left-width"))+parseFloat(a.getPropertyValue("border-right-width"))+parseFloat(a.getPropertyValue("padding-left"))+parseFloat(a.getPropertyValue("padding-right"))),b):a.outerWidth(!0)};K=function(a,b,q,C,F,u,r,G){var v,H,m,D,I,d,g,x,y,z,h,l;if(!a.data("sticky_kit")){a.data("sticky_kit",!0);I=A.height();g=a.parent();null!=k&&(g=g.closest(k));if(!g.length)throw"failed to find stick parent";
v=m=!1;(h=null!=n?n&&a.closest(n):c("<div />"))&&h.css("position",a.css("position"));x=function(){var d,f,e;if(!G&&(I=A.height(),d=parseInt(g.css("border-top-width"),10),f=parseInt(g.css("padding-top"),10),b=parseInt(g.css("padding-bottom"),10),q=g.offset().top+d+f,C=g.height(),m&&(v=m=!1,null==n&&(a.insertAfter(h),h.detach()),a.css({position:"",top:"",width:"",bottom:""}).removeClass(t),e=!0),F=a.offset().top-(parseInt(a.css("margin-top"),10)||0)-p,u=a.outerHeight(!0),r=a.css("float"),h&&h.css({width:J(a),
height:u,display:a.css("display"),"vertical-align":a.css("vertical-align"),"float":r,"position":"static"}),e))return l()};x();if(u!==C)return D=void 0,d=p,z=E,l=function(){var c,l,e,k;if(!G&&(e=!1,null!=z&&(--z,0>=z&&(z=E,x(),e=!0)),e||A.height()===I||x(),e=f.scrollTop(),null!=D&&(l=e-D),D=e,m?(w&&(k=e+u+d>C+q,v&&!k&&(v=!1,a.css({position:"fixed",bottom:"",top:d}).trigger("sticky_kit:unbottom"))),e<F&&(m=!1,d=p,null==n&&("left"!==r&&"right"!==r||a.insertAfter(h),h.detach()),c={position:"",width:"",top:""},a.css(c).removeClass(t).trigger("sticky_kit:unstick")),
B&&(c=f.height(),u+p>c&&!v&&(d-=l,d=Math.max(c-u,d),d=Math.min(p,d),m&&a.css({top:d+"px"})))):e>F&&(m=!0,c={position:"fixed",top:d},c.width="border-box"===a.css("box-sizing")?a.outerWidth()+"px":a.width()+"px",a.css(c).addClass(t),null==n&&(a.after(h),"left"!==r&&"right"!==r||h.append(a)),a.trigger("sticky_kit:stick")),m&&w&&(null==k&&(k=e+u+d>C+q),!v&&k)))return v=!0,"static"===g.css("position")&&g.css({position:"relative"}),a.css({position:"absolute",bottom:b,top:"auto"}).trigger("sticky_kit:bottom")},
y=function(){x();return l()},H=function(){G=!0;f.off("touchmove",l);f.off("scroll",l);f.off("resize",y);c(document.body).off("sticky_kit:recalc",y);a.off("sticky_kit:detach",H);a.removeData("sticky_kit");a.css({position:"",bottom:"",top:"",width:""});g.position("position","");if(m)return null==n&&("left"!==r&&"right"!==r||a.insertAfter(h),h.remove()),a.removeClass(t)},f.on("touchmove",l),f.on("scroll",l),f.on("resize",y),c(document.body).on("sticky_kit:recalc",y),a.on("sticky_kit:detach",H),setTimeout(l,
0)}};q=0;for(L=this.length;q<L;q++)b=this[q],K(c(b));return this}}).call(this);

$(function() {
	return $("[data-sticky_column]").stick_in_parent({
		parent: "[data-sticky_parent]"
	});
});


// responsive

//Mobile Menu


$(".mobile_nav").on('click', function() {
    $(".site_menu").fadeToggle();
    $(".site_menu").toggleClass("open");
    $(this).toggleClass("open");
    $("body").toggleClass("open");

    $("#mini_cart").fadeOut();
    $("#mini_cart").removeClass("open");

    $("#item_detail").fadeOut();
    $("#item_detail").removeClass("open");
    $(".mobile_nav").addClass('closeopen');
    $(".btn_close").show();

});

$(".btn_filter").on('click', function() {
    $(".side_menu").fadeToggle();
    $(".side_menu").toggleClass("open");
    $(this).toggleClass("open");
    $("body").toggleClass("open");
    $(".mobile_nav").addClass('closeopen');
    $(".btn_close").show();
});

$("a.btn_close, .side_menu li a, .site_menu li a").on('click', function() {
    $(".side_menu").fadeOut().removeClass("open");
    $(".site_menu").fadeOut().removeClass("open");
    $("body").removeClass("open");
    $("a.btn_close").hide();
    $(".mobile_nav").removeClass('closeopen');

});

$(".site_header .cart").on('click', function() {
    $(".site_menu").fadeOut().removeClass("open");
    $(".side_menu").fadeOut().removeClass("open");
    $("a.btn_close").hide();
    $(".mobile_nav").removeClass('closeopen');
});






$('#accordion').on('shown.bs.collapse', function () {
    var panel = $(this).find('.in');
    $('html, body').animate({
        scrollTop: panel.offset().top-200
    }, 500);
});



//Rating
jQuery(function() {
    jQuery('.starbox').each(function() {
        var starbox = jQuery(this);
        starbox.starbox({
            average: starbox.attr('data-start-value'),
            changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
            ghosting: starbox.hasClass('ghosting'),
            autoUpdateAverage: starbox.hasClass('autoupdate'),
            buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
            stars: starbox.attr('data-star-count') || 5
        }).bind('starbox-value-changed', function(event, value) {
            if(starbox.hasClass('random')) {
                var val = Math.random();
                starbox.next().text('Random: '+val);
                return val;
            } else {
                $('input[name="rating"]').val(value);
            }
        }).bind('starbox-value-moved', function(event, value) {
            $('input[name="rating"]').val(value);
        });
    });
});

// popup gallery
$('.gallery a').magnificPopup({
  type: 'image',
  mainClass: 'mfp-with-zoom', 
    gallery: {

    enabled: true
  },
  zoom: {
    enabled: true, 
    duration: 300, 
    easing: 'ease-in-out', 
    opener: function(openerElement) {
          return openerElement.is('img') ? openerElement : openerElement.find('img');
    }
  }

});