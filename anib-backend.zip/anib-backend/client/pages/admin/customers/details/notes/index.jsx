'use strict';
const CommonHelper = require('../../../../../helpers/common-functions');
const React = require('react');


class Notes extends React.Component {

    constructor(props) {

        super(props);
        this.state = {
            notes : props.notes
        };
    }     


    render() {

        return (
            <div className="box">
                <div className="icon"><i className="fa fa-sticky-note-o"></i></div>
                <h6 title={this.props.note}>{CommonHelper.wordTruncate(this.props.note, 250)}</h6><p>{this.props.created_at} by {this.props.first_name} {this.props.last_name}</p>
                <a href="javascript:" onClick={ (e) => this.props.deleteFun(this.props.deal_note_key)  } className="remove"><i className="fa fa-trash"></i> Remove</a>
            </div>
        );
    }
}

module.exports = Notes;