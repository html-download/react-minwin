'use strict';
const ReactRouter = require('react-router-dom');
const History = require('history');
const history = History.createHashHistory;

const Actions = require('./actions');
const CreateNewForm = require('./create-new-form.jsx');
const FilterForm = require('./filter-form.jsx');
const Paging = require('../../../../../components/paging.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactHelmet = require('react-helmet');
const Results = require('./results.jsx');
const Store = require('./store');
const Qs = require('qs');
const ObjectAssign = require('object-assign');

const apiUrl = 'https://api6.fopark-api.com';

const Helmet = ReactHelmet.Helmet;

const propTypes = {
    history: PropTypes.object,
    location: PropTypes.object
};


class SearchPage extends React.Component {
    constructor(props) {

        super(props);

        this.els = {};
        this.state = Store.getState();
    }

    componentWillReceiveProps(nextProps) {
        const query = {client_name:this.props.match.params.id};

        if (this.props.match.params.id !== undefined) {
            Actions.getLotResults(query);
        }
    }

    componentDidMount() {
        const query = {client_name:this.props.match.params.id};

        if (this.props.match.params.id !== undefined) {
            Actions.getLotResults(query);
        } 

        Actions.getClientResults({});
        
        /*$('.selectpicker').selectpicker();
        $('.selectpicker').selectpicker({ style: 'btn-info', size: 4 });*/


        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    onFiltersChange(event) {

        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }

        //Actions.changeSearchQuery(this.els.filters.state, this.props.history);
    }

    onPageChange(page) {

        this.els.filters.changePage(page);
    }

    onNewClick() {
        Actions.showCreateNew();
    }
    handleChange(event) {
        const query = {client_name:event.target.value};
        if (event.target.value !== undefined) {
            Actions.getLotResults(query);
        } 

        this.props.history.push(`/lots-details/${event.target.value}`);

        this.setState({value: event.target.value});
    }
    render() {
        const data = this.state.results.clients === undefined ? (
            <option></option>
        ) : this.state.results.clients.map((record, index) => {
            return (
                <option value={record.client_name}>{record.client_name}</option>
            )
        });
        return (
            <div className="content-wrapper">
                <Helmet>
                    <title>Lots Management</title>
                </Helmet>
                <section className="content">
                    <div className="box">
                        <div className="box-header with-border">
                            <h1 className="box-title">Lots</h1>
                        </div> 
                        <FilterForm
                            ref={(c) => (this.els.filters = c)}
                            loading={this.state.results.loading}
                            query={Qs.parse(this.props.location.search.substring(1))}
                            onChange={this.onFiltersChange.bind(this)}
                        />
                        <div className="box-body">
                            <div className="row">
                                <div className="col-md-4">
                                    <a role="button" title="Add New" className="btn mb15" ref={(c) => (this.els.createNew = c)} onClick={this.onNewClick.bind(this)}><i className="fa fa-plus-circle"></i> Add New</a>
                                </div>
                                <div className="col-md-4">
                                </div>
                                <div className="col-md-4">
                                    <div className="form-group">
                                        <select className="form-control" title="Choose Client" onChange={this.handleChange.bind(this)} value={this.props.match.params.id}>
                                            <option>Please select client</option>
                                            {data}
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                            
                            <Results data={this.state.results.data} param={this.props.match.params.id} />
                        </div> 
                        {/*<Paging
                            ref={(c) => (this.els.paging = c)}
                            pages={this.state.results.pages}
                            items={this.state.results.items}
                            loading={this.state.results.loading}
                            onChange={this.onPageChange.bind(this)}
                        />*/}
                        <CreateNewForm
                            history={this.props.history}
                            location={this.props.location}
                            clients={data}
                            {...this.state.createNew}
                        />
                    </div> 
                </section>
              </div>
        );
    }
}

SearchPage.propTypes = propTypes;


module.exports = SearchPage;
