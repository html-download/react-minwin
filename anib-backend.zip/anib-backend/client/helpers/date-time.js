'use strict';
const moment = require('moment-timezone');
const Config = require('../../config.js');

module.exports = {
    _emailDateTemplate : function () {
        try {
            var day = moment().tz(Config.get('/timeZone')).format("MMM DD, YYYY h:mmA");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _historicalDateFormat : function (date) {
        try {
            var day = moment(date).format("DD-MM-YYYY");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getTimeStringFromDateString : function (dateString) {
        try {
            var day = moment(dateString).tz(Config.get('/timeZone')).format("h:mm a");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getLotMessageDate : function (dateString) {
        try {
            var day = moment(dateString).format("MM/DD/YYYY");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getLotMessageTime : function (dateString) {
        try {
            var day = moment(dateString).format("h:mm A");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getDefaultFormat: function(dateString) {
        
        try {
            var day = moment(dateString, "DD MMM, YYYY").toDate();
            return day;
        } catch (e) {
            console.log(e.message);
            return '';
        }
    },
    _getDefaultTimeFormat: function(dateString) {
        
        try {

            return moment(moment(dateString,'HH:mm').toDate()).format('hh:mm a').toString();
        } catch (e) {
            console.log(e.message);
            return '';
        }
    },

    getCurrentDate: function() {

        try {
            var day = moment().format("DD MMM, YYYY").toString();
            return day;
        } catch (e) {
            console.log(e.message);
            return '';
        }
    },

    getDateFormat: function(dateString, format) {

        try {
            
            var day = moment(dateString, format).toDate();
            return day;
        } catch (e) {
            return moment().toDate();
        }
    },

    getEventFormat: function(dateString, format, interval) {

        try {
            
            if (interval) {
                var day = moment(dateString, format).add(interval, 'minute').toDate();
                return day;
            }

            var day = moment(dateString, format).toDate();
            return day;

        } catch (e) {
            return moment();
        }
    },

    getCurrentTime: function() {

        try {
            return moment().format('hh:mm a').toString();
        } catch (e) {
            console.log(e.message);
            return '';
        }
    },

    _getDefaultFormat2: function(dateString) {
        
        try {            
            let day = moment(dateString, "DD-MMM-YYYY").toDate();
            return day;
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },

    _changeDefaultFormat: function(dateString) {
        
        try {
            var day = moment(dateString).format("DD MMM, YYYY").toString();
            return day;
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },


    _changeFormat: function(dateString,dateFormat) {
        
        try {            
            return moment(dateString).format(dateFormat).toString();
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },

    _changeDefaultFormat2: function(dateString) {
        
        try {
            var day = moment(dateString).format("DD-MMM-YYYY").toString();
            return day;
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },

    _getDbFormat: function(dateString) {
        
        try {

            return moment(dateString,'DD-MMM-YYYY').format('YYYY-MM-DD').toString();
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },

    _getDbTimeFormat: function(dateString) {
        
        try {

            return moment(dateString,'hh:mm A').format('HH:mm').toString();
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },

    _getDateFormat: function(dateString) {
        
        try {
            const year = moment(dateString,'DD-MMM-YYYY').format('YYYY').toString();
            if (year.length === 4) {
                const momentDate = moment(dateString);            
                return momentDate.isValid();
            }
            return false;
        } catch (e) {
            console.log(e.message);
            return '';
        }

    },

    getMinutesFromHour: function(hour){
        try {
            var hms = hour;   // your input string
            var a = hms.split(':'); // split it at the colons

            var minutes = (+a[0]) * 60 + (+a[1]); 

            return minutes ? minutes : 30;
        } catch (e) {
            return 30;
        }
    }
};
