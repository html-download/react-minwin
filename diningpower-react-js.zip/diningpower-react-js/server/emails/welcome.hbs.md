<html lang="en-US">
  <head> 
    <meta charset="UTF-8" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  </head>
<body style="background:#f1f1f1;margin: 0">
<table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="padding:20px; font-family: Arial,Helvetica Neue,Helvetica,sans-serif;  font-size:14px; color:#424242; line-height:20px;">
<tbody>
 <tr>
   <td width="100%" valign="top">
     <table cellpadding="0" cellspacing="0" border="0" align="center" style="max-width:625px; margin:0 auto; width: 100%;">
       <tbody><td>
		     <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center">
		       <tbody>
				 <tr>
				   <td>
				     <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="background-color:#ffffff; ">
				     <tbody>
					   <tr valign="top">
						 <table cellpadding="0" cellspacing="0" width="100%" border="0" style="background-color:#fff; padding:20px 20px 10px 20px">
						  <tr>
						    <td>
						      <table cellpadding="0" cellspacing="0" width="100%" border="0" style="background-color: #fff;">
									<tr>
										<td>
											<table cellpadding="0" cellspacing="0" width="100%" border="0">
												<td style="padding:15px 0; text-align:left;border: 1px dashed #666; border-left: 0; border-right: 0;">
													<img src="{{baseUrl}}/public/media/icons/logo.png" height="80">
												</td>
												<td style="padding:15px 0px; text-align:right;border: 1px dashed #666; border-left: 0; border-right: 0;">
													<p style="margin:0px 0px 5px 0px;">Date: {{ createdDatetime }}</p>
												</td>
											</table>
										</td>
									</tr>
									<tr>
										<td style="padding:15px 0;">
											<p style="margin:0px 0px 10px 0px; font-family: OpenSans;">Hello <b>{{customerName}}</b>,</p>
												<p style="margin:0px 0px 10px 0px; font-family: OpenSans;">Welcome to <b>Dining Power!!</b></p>
												<p style="margin:0px 0px 10px 0px; font-family: OpenSans;">We’re so happy to have you here.</p>
												<p style="margin:0px 0px 10px 0px; font-family: OpenSans;"><a href="{{baseHref}}/{{customerEmail}}/{{key}}" style="  color: #f6a11e;  font-weight: 600;  text-decoration: inherit;"> click here</a> to activate the account.</p>
									    </td>
									</tr>
								</table>
								</td>							
							</tr>
						 </table>						 
					   </tr>
					 </tbody>
				     </table>
				   </td>
				 </tr>
		       </tbody>
		     </table>
		   </td>
	     </tr>	
       </tbody>
     </table>
   </td>
 </tr>
</tbody>
</table>
</body>
</html>