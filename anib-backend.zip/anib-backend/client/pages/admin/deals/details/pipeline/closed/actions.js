'use strict';
const Store = require('./store');
const Constant =  require('./constants');
const ApiActions = require('../../../../../../actions/api');

class Actions {
    
    static toggleQuote() {
            
        Store.dispatch({
            type : Constant.TOGGLE_QUOTE
        });
    }

    static getDealQuote(id) {
        
        if (id) {
            this.getPolicyDetails(id);
            ApiActions.get(
                `/deal-quote/${id}`,
                undefined,
                Store,
                Constant.GET_DEAL_QUOTE_DETAILS,
                Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE
            );
        }
    }

    static getPolicyDetails(id) {
                
        ApiActions.get(
            `/policy/${id}`,
            undefined,
            Store,
            Constant.GET_POLICY_DETAILS,
            Constant.GET_POLICY_DETAILS_RESPONSE
        );
    }

    static openPolicyModal() {

        Store.dispatch({
            type : Constant.OPEN_POLICY_MODAL
        });
    }
    static hideViewModal() {

        Store.dispatch({
            type : Constant.HIDE_POLICY_MODAL
        });
    }


    static getProduct() {

        ApiActions.get(
            `/underwriter`,
            undefined,
            Store,
            Constant.GET_PRODUCT_DETAILS,
            Constant.GET_PRODUCT_DETAILS_RESPONSE
        );
    }

    static saveQuoteDetails(data) {
        
        ApiActions.post(
            `/deal-quote`,
            data,
            Store,
            Constant.SAVE_QUOTE_DETAILS,
            Constant.SAVE_QUOTE_DETAILS_RESPONSE
        );
    }

    static updateQuoteDetails(id, data, toggle, updateOrderId) {

    	updateOrderId(false);
        
        ApiActions.put(
            `/deal-quote/${id}`,
            data,
            Store,
            Constant.UPDATE_QUOTE_DETAILS,
            Constant.UPDATE_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    toggle(3)
                }
                toggle(4 , false, id)
            }
        );
    }
}

module.exports = Actions;