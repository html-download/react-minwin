"use strict";
const React = require("react");
const ReactHelmet = require("react-helmet");
const ReactRouter = require("react-router-dom");
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

const Link = ReactRouter.Link;
const Helmet = ReactHelmet.Helmet;

class ChoosePolicyPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false
    };
    this.toggle = this.toggle.bind(this);
  }

    toggle() {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  }

  componentDidMount() {    
    window.scrollTo(0, 0);
  }

  render() {
    return (
      <section>
        <Helmet>
          <title>Choose Policy</title>
        </Helmet>
        <section className="empty-banner" />

        <section className="light_bg padding-50 choose_policy">
          <div className="container">
            <div className="white-box-shadow text-center">
              <h2 className="blue-heading text-center">Choose Policy</h2>
              <div className="box-container">
                <div className="info-box">
                  <h3 className="text-green">Hi ilan!</h3>
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard
                  </p>
                </div>
                <div className="form-box">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Quotation reference number</label>
                        <input
                          type="text"
                          className="form-control"
                          value="1550474750"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Vehicle</label>
                        <input
                          type="text"
                          className="form-control"
                          value="2019 Bentley BENTAYGA6.0 L FIRST EDITION SUN"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Email</label>
                        <input
                          type="email"
                          className="form-control"
                          value="ilan@anib.com"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group mb-number">
                        <label>Mobile Number</label>
                        <label className="mb-fly">+971</label>
                        <input
                          type="tel"
                          className="form-control"
                          value="600 525502"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Date of Birth</label>
                        <input
                          type="text"
                          className="form-control datePicker"
                          data-position="top left"
                          value="27/February/2019"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label>Nationality</label>
                        <input
                          type="text"
                          className="form-control"
                          value="United Arab Emirates"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="white-box-shadow text-center">
              <h2 className="white-bg-heading" />
            </div>
          </div>
        </section>
        <section className="light_bg compare pb-40">
          <div className="container">
            <div className="white-box-shadow text-center">
              <h2 className="text-center">Compare in more details</h2>
              <div className="compare-detail">
                <div className="row">
                  <div className="col-sm-4">
                    <div className="compare_desc">
                      <div className="compare_check">
                        <div className="check-group">
                          <input
                            id="compare_chk"
                            className="hidden"
                            type="checkbox"
                          />
                          <label className="checkbox" htmlFor="compare_chk">
                            Compare
                          </label>
                        </div>
                        <span className="comp_img">
                          <img src="/public/media/images/c1.png" />
                        </span>
                      </div>
                      <div className="compare_select text-center">
                        <h5>Union Insurance Silver Garage</h5>
                        <span>AED 15,803</span>
                        <button
                          className="btn btn-primary comp_btn"
                          onClick={this.toggle}
                        >
                          Select
                        </button>
                      </div>
                      <ul className="comp_points">
                        <li className="grey heading">
                          Vehicle Insured Value: AED 15,803
                        </li>
                        <li>
                          Driver Cover, Passenger Cover{" "}
                          <i
                            className="fa fa-info info"
                            aria-hidden="true"
                            data-toggle="tooltip"
                            title="info"
                          />
                        </li>
                        <li>
                          Third Party Liability: UAE Only{" "}
                          <i
                            className="fa fa-info info"
                            aria-hidden="true"
                            data-toggle="tooltip"
                            title="info"
                          />
                        </li>
                        <li>Cover for rent a car</li>
                        <li>
                          Roadside Assistance <span>Free</span>
                        </li>
                        <li>Natural Calamities</li>
                        <li>Replacement of Vehicle (5 Days)</li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-sm-4">
                    <div className="compare_desc">
                      <div className="compare_check">
                        <div className="check-group">
                          <input
                            id="compare_chk1"
                            className="hidden"
                            type="checkbox"
                          />
                          <label className="checkbox" htmlFor="compare_chk1">
                            Compare
                          </label>
                        </div>
                        <span className="comp_img">
                          <img src="/public/media/images/c2.png" />
                        </span>
                      </div>
                      <div className="compare_select text-center">
                        <h5>Oriental Insurance</h5>
                        <span>AED 15,803</span>
                        <button
                          className="btn btn-primary comp_btn"
                          onClick={this.toggle}
                        >
                          Select
                        </button>
                      </div>
                      <ul className="comp_points">
                        <li className="grey heading">
                          Vehicle Insured Value: AED 15,803
                        </li>
                        <li>
                          Driver Cover, Passenger Cover{" "}
                          <i
                            className="fa fa-info info"
                            aria-hidden="true"
                            data-toggle="tooltip"
                            title="info"
                          />
                        </li>
                        <li>
                          Third Party Liability: UAE Only{" "}
                          <i
                            className="fa fa-info info"
                            aria-hidden="true"
                            data-toggle="tooltip"
                            title="info"
                          />
                        </li>
                        <li>Cover for rent a car</li>
                        <li>
                          Roadside Assistance <span>Free</span>
                        </li>
                        <li>Natural Calamities</li>
                        <li>Replacement of Vehicle (5 Days)</li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-sm-4">
                    <div className="compare_desc">
                      <div className="compare_check">
                        <div className="check-group">
                          <input
                            id="compare_chk2"
                            className="hidden"
                            type="checkbox"
                          />
                          <label className="checkbox" htmlFor="compare_chk2">
                            Compare
                          </label>
                        </div>
                        <span className="comp_img">
                          <img src="/public/media/images/c3.png" />
                        </span>
                      </div>
                      <div className="compare_select text-center">
                        <h5>Adamjee Insurance Garge</h5>
                        <span>AED 15,803</span>
                        <button
                          className="btn btn-primary comp_btn"
                          onClick={this.toggle}
                        >
                          Select
                        </button>
                      </div>
                      <ul className="comp_points">
                        <li className="grey heading">
                          Vehicle Insured Value: AED 15,803
                        </li>
                        <li>
                          Driver Cover, Passenger Cover{" "}
                          <i
                            className="fa fa-info info"
                            aria-hidden="true"
                            data-toggle="tooltip"
                            title="info"
                          />
                        </li>
                        <li>
                          Third Party Liability: UAE Only{" "}
                          <i
                            className="fa fa-info info"
                            aria-hidden="true"
                            data-toggle="tooltip"
                            title="info"
                          />
                        </li>
                        <li>Cover for rent a car</li>
                        <li>
                          Roadside Assistance <span>Free</span>
                        </li>
                        <li>Natural Calamities</li>
                        <li>Replacement of Vehicle (5 Days)</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="compare-btn text-center">
            <Link to="/policy-compare">
              <button
                className="btn btn-primary"
              >              
                Compare
              </button>
              </Link>
            </div>
          </div>
        </section>

        <Modal isOpen={this.state.modal} toggle={this.toggle} modalClassName="quote-summary">
          <ModalHeader toggle={this.toggle}>
          Union Insurance Silver Garage
          <p>AED 1,170</p>
          <button type="button" className="btn btn-primary">
                        Proceed
                    </button>
          </ModalHeader>
          <ModalBody>
            <div className="policy">
                        <h5>Policy Feature Summary</h5>
                    </div>
                    <ul className="policy-points">
                        <li>Third Party Liability: <span>UAE Only</span></li>
                        <li>Third Party Damage Limit: <span>Upto AED 3.5 Million</span></li>
                        <li>Damage To Your Vehicle: <span>UAE &amp; Oman</span></li>
                    </ul>
                    <div className="policy">
                        <h5>What's Included</h5>
                    </div>
                    <ul className="policy-points">
                        <li>Involuntary Loss Of Employment Insurance: Included </li>
                        <li>Riots/Strikes/MD:<span> Included</span></li>
                        <li>Valet Parking Theft Cover: <span>Included</span></li>
                        <li>Windscreen Damage: <span>Upto AED 1,000</span></li>
                        <li>Replacement of Locks:<span> Upto AED 1,000</span></li>
                        <li>Taxi Fare: <span>Upto AED 100</span></li>
                        <li>Ambulance Service:<span> Included</span></li>
                        <li>Taxi Fare: <span>Upto AED 100</span></li>
                        <li>Ambulance Service: <span>Included</span></li>
                    </ul>
                    <div className="policy">
                        <h5>What's Not Included</h5>
                    </div>
                    <ul className="policy-points not-included">
                        <li>Third Party Liability:<span> UAE Only</span></li>
                        <li>Third Party Damage Limit: <span>Upto AED 3.5 Million</span></li>
                        <li>Damage To Your Vehicle: <span>UAE &amp; Oman</span></li>
                    </ul>
          </ModalBody>
        </Modal>

      </section>
    );
  }
}

module.exports = ChoosePolicyPage;
