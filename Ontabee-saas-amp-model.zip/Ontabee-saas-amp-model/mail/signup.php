<?php 

  if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
  $ip = $_SERVER['HTTP_CLIENT_IP'];
  } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
  $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  } else {
  $ip = $_SERVER['REMOTE_ADDR'];
  }
  $ip = '106.51.48.24';
  $record = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));

  session_start();
  require_once('../PHPMailer/PHPMailerAutoload.php');
  
  if(isset($_POST) && !empty($_POST))
  {
    $error = 0;
    $signup_validation['fa_name'] = $signup_validation['fa_email'] = $signup_validation['fa_tel'] = $signup_validation['fa_category'] = '';
    
    if(empty($_POST['fa_name']) && $_POST['fa_name'] == '') {
      $error = 1;
      $signup_validation['fa_name'] = "Name cannot empty";
    } 
    
    if(empty($_POST['fa_email']) && $_POST['fa_email'] == '') {
      $error = 1;
      $signup_validation['fa_email'] = "Email cannot empty";
    } else if($_POST['fa_email'] != '' && !preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $_POST['fa_email'])){
      $error = 1;
      $signup_validation['fa_email'] = "Email is invalid";
    } 
    
    if(empty($_POST['fa_tel']) && $_POST['fa_tel'] == '') {
      $error = 1;
      $signup_validation['fa_tel'] = "Phone Number cannot empty";
    } else if($_POST['fa_tel'] != '' && !preg_match("/^[0-9 +-]{5,20}$/", $_POST['fa_tel'])){
      $error = 1;
      $signup_validation['fa_tel'] = "Phone Number is invalid";
    }
    
    if(empty($_POST['fa_category']) && $_POST['fa_category'] == '') {
      $error = 1;
      $signup_validation['fa_category'] = "Category cannot empty";
    } 

    if(empty($_POST['fa_rn']) && $_POST['fa_rn'] == '') {
      $error = 1;
      $signup_validation['fa_rn'] = "Restaurant Name cannot empty";
    } 
    
    if($error == 1){
      echo json_encode([ 'httpcode' => 400 ,'error' => $signup_validation]); die;
    } else if($error == 0 && $_POST['fa_tel'] != ''){
  
    function generatePasswordHash($password, $cost = 13)
    {
        if (function_exists('password_hash')) {
            /** @noinspection PhpUndefinedConstantInspection */
            return password_hash($password, PASSWORD_DEFAULT, ['cost' => $cost]);
        }

        $salt = generateSalt($cost);
        $hash = crypt($password, $salt);
        // strlen() is safe since crypt() returns only ascii
        if (!is_string($hash) || strlen($hash) !== 60) {
            throw new Exception('Unknown error occurred while generating hash.');
        }

        return $hash;
    }

    function generateRandomString($length = 10) {
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0; $i < $length; $i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }
      return $randomString;
    }

if(isset($_POST) && !empty($_POST))
{
    $password_plain = strtolower(generateRandomString($length = 8));
    $pass_hash = generatePasswordHash($password_plain);
    $activation_key = generateRandomString($length = 16);
    
    try{
          $pdo  = new PDO("mysql:host=192.168.1.181;dbname=ontabee_domains", "techdevelop", "&$2fra*2!4gs#4");
          //$pdo  = new PDO("mysql:host=localhost;dbname=ontabee_domains", "ontabee_domuser", "Hp7bgUAVWeTuUCgM");

    if(!$pdo)
      exit("Database not connected");
    }
    catch(Exception $e)
    {
      //var_dump($e);
    }

    $__useLibreSSL = null;
    $__randomFile = null;


    global $pdo;

    $domain = strtolower(preg_replace("/[^a-zA-Z0-9'-]+/", '', $_POST['fa_rn']));
    $category = $_POST['fa_category'];
    $query = $pdo->prepare("SELECT count(*) FROM domains WHERE sub_domain LIKE :name");
    $query->bindParam(":name", $domain, FILTER_SANITIZE_STRING);
    $query->execute();

    $sub_domain = $domain;
    $count = $query->fetchColumn();
    if(!$count) {
      
    }
    else {
      $domain = $domain . $count;
      //header("Location: /thankyou?success=100");
    }

    $dateTime = DateTime::createFromFormat('Y-m-d H:i:s', date('Y-m-d H:i:s'));
    $createdDateTime = ($dateTime->format('Y-m-d H:i:s'));
    $dateTime->add(new DateInterval('P7D'));
    $expiryDate = ($dateTime->format('Y-m-d'));
    $query = $pdo->prepare("INSERT INTO domains(name, email, country_name, mobile, password, domain,category, sub_domain, version, activation_key, status, expiry_date, created_datetime) VALUES(:name, :email, :country_code, :mobile, :password, :domain, :category, :sub_domain, :version, :activation_key, :status, :expiry_date, :created_datetime)");

    $query->bindParam(":name", $_POST['fa_name'], FILTER_SANITIZE_STRING);
    $query->bindParam(":email", $_POST['fa_email'], FILTER_SANITIZE_EMAIL);
    $query->bindParam(":country_code", $_POST['fa_dial']);
    $query->bindParam(":mobile", $_POST['fa_tel']);
    $query->bindParam(":password", $pass_hash, FILTER_SANITIZE_STRING);
    $query->bindParam(":domain", $domain, FILTER_SANITIZE_STRING);
    $query->bindParam(":category", $category, FILTER_SANITIZE_STRING);
    $query->bindParam(":sub_domain", $sub_domain, FILTER_SANITIZE_STRING);
    $query->bindValue(":version",  1);
    $query->bindValue(":activation_key",  $activation_key, FILTER_SANITIZE_NUMBER_INT);
    $query->bindValue(":status", 2);
    $query->bindValue(":expiry_date", $expiryDate);
    $query->bindValue(":created_datetime", $createdDateTime);
    $stmt = $query->execute();
    if (!$stmt) { 
        //print_r($query->errorInfo()); 
        //exit;
    } 
  

    $mailer = new PHPMailer();
    $mailer->isSMTP();
    $mailer->Host = 'smtp.gmail.com';
    $mailer->Port = 465;
    $mailer->SMTPSecure = 'ssl';
    $mailer->SMTPAuth = true;
    $mailer->Username = 'sales@ontabee.com';
    $mailer->Password = 'BEEsales@33';
    $mailer->setFrom('sales@ontabee.com', 'Ontabee SaaS');
    $mailer->addAddress('sales@ontabee.com');
    $mailer->CharSet = 'UTF-8';
    $mailer->Subject = 'Inquiry - Ontabee SaaS - '. $_POST["for_name"] . ' - ' . $_POST["fa_name"];
    $mailer->Subject = $domain . ' - Ontabee - You’re in :) | PLUS, a quick question...';
    $mailer->Body = '
    <!DOCTYPE HTML>
    <html lang="en-US">
    <head> 
      <meta charset="UTF-8" />
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet" type="text/css"/>
      <style>
        @import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700");
        body{font-family: "Roboto", sans-serif;}
      </style>
    </head>
    <body style="background:#e6e7ea">
    
    <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="padding:30px 15px; font-family: "Roboto"; font-size:14px; color:#333; line-height:20px;">
    <tbody>
     <tr>
       <td width="100%" valign="top" style="padding:35px 15px;">
        <table cellpadding="0" cellspacing="0" border="0" align="center" style="max-width:600px; margin:0 auto; width: 100%;">
          <tbody>
            <td>
              <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="box-shadow: 0px 0px 25px rgba(0, 0, 0, 0.15); border-top-left-radius:8px; border-top-right-radius:8px">
              <tbody>
              <tr>
                <td valign="middle" style="background-color:#fff; padding:15px 20px 10px 20px; border-top-left-radius:8px; border-top-right-radius:8px;">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center">
                    <tbody>
                      <tr>
                        <td><a href="https://www.ontabee.com"><img src="https://www.ontabee.com/images/logo.png" alt="Ontabee" height="50"></a></td>
                        <td style="text-align:right; padding-top:4px;">
                          <a href="https://www.facebook.com/Ontabee-149066152475073/"><img src="https://www.ontabee.com/images/facebook.png" style="margin:2px"></a>
                          <a href="https://twitter.com/ontabee"><img src="https://www.ontabee.com/images/twitter.png" style="margin:2px"></a>
                          <a href="https://www.linkedin.com/company/ontabee/"><img src="https://www.ontabee.com/images/linkedin.png" style="margin:2px"></a>
                        </td>
                      </tr>            
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td style="padding:40px 20px 60px 20px; text-align:center; background: url(https://www.ontabee.com/images/banner_small.jpg) no-repeat bottom; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">
                    <h1 style="font-size: 26px; font-weight:300; line-height:normal; margin:0px;">Free Online <b style="color: #FC8019; font-weight: 400;">Food</b> Ordering System <span style="display: block; text-transform: none; margin-top: 10px;">For Restaurant Business</span></h1>
                </td>
              </tr>
              <tr>
                <td style="background-color:#fff; padding:20px">
                  <p style="margin:0px 0px 10px 0px;">Hey '. $_POST["fa_name"] .', </p>
                  <p style="margin:0px 0px 10px 0px;">I really appreciate you joining us at Ontabee, and I know you’ll love it when you see how easy it is to use Ontabee.</p>
                  <p style="margin:0px 0px 10px 0px;">We built Ontabee to help small businesses grow, and I hope that we can achieve that for you.</p>
                  <p style="margin:0px 0px 10px 0px;">If you wouldn’t mind, I’d love it if you answered one quick question: Why did you sign up for Ontabee?</p>
                  <p style="margin:0px 0px 10px 0px;">I’m asking because knowing what made you sign up is really helpful for us in making sure that we’re delivering on what our users want. Just hit “reply” and let me know.</p>
                  <p style="margin:0px;">By the way, Please check your details below.</p>            
                </td>
              </tr>
              <tr>
                <td style="background-color:#f3f3f3; padding:20px;">
                  <h3 style="font-weight: 500; font-size:18px; margin:0px">Your demo account details on <span style="color: #FC8019;">Ontabee.com</span></h3>
                </td>
              </tr>
              <tr>
                <td style="background:#f3f3f3; padding:0px 20px 20px 20px;">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0" style="border-collapse: collapse; background-color:#fff">                    
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Activation Link</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">
                          <a href="https://www.ontabee.com/activation?activation_key=' . $activation_key .'" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #7ab338; margin-top:2px">Click here to Activate</a>
                          <span style="display:block; color:#666; font-weight:400; margin-top:5px; font-size:13px">Please click on above button to activate your account.</span>
                      </td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Your Domain</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $domain .'.ontabee.com</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Admin Login</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $domain .'.ontabee.com/admin</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Username</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">admin1</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Password</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">admin</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_name"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Email</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_email"] .'</td>
                    </tr>    
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Phone Number</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_dial"] .' ' . $_POST["fa_tel"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Country</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_country"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Referer</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_SESSION["referer"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Category</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_category"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">IP</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_request . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">City</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_city . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Region</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_region . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Region Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_regionName . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Country Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_countryName . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Continent Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_continentName . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Latitude</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_latitude . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Longitude</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_longitude . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Time Zone</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_timezone . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Customer App Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=j1qWh_N5IxI" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Delivery App Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=favN6OgqGi4" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Back-end Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=mAqgAeku_10" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                  </table>
                </td>                    
              </tr>        
              <tr>
                <td valign="middle" style="background-color:#FC8019; color:#fff; padding:15px 20px; border-bottom-left-radius:8px; border-bottom-right-radius:8px">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0">
                    <tr>
                      <td><span style="font-weight:300; font-size:13px">Best Regards,</span><br>Rajesh Prabhu S <span style="font-weight:300; font-size:12px">(CEO, Ontabee)</span></td>
                      <td style="text-align:right; padding-left:15px;">
                        <span style="font-weight:300; font-size:13px">For more information</span><br>
                        <a style="color:#fff; text-decoration:none">sales@ontabee.com</a>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </tbody>
            </table>
            </td>
          </tr> 
            <tr>
              <td valign="middle" style="padding:20px 20px; text-align:center; color:#666; font-size:13px">
                <p style="margin:0px 0px 15px 0px">Questions? The Ontabee team is always here to help. <br>Contact sales@ontabee.com and we&apos;ll get back to you soon.</p>
                &copy; '. date('Y') .' Ontabee. All rights reserved.
              </td>
            </tr>
          </tbody>
        </table>
       </td>
      </tr>
    </tbody>
    </table>
    
    </body>
    </html>
    ';
    $mailer->AltBody = 'This is a plain-text message body';
    
    $mailerCustomer = new PHPMailer();
    $mailerCustomer->isSMTP();
    $mailerCustomer->Host = 'smtp.gmail.com';
    $mailerCustomer->Port = 465;
    $mailerCustomer->SMTPSecure = 'ssl';
    $mailerCustomer->SMTPAuth = true;
    $mailerCustomer->Username = 'sales@ontabee.com';
    $mailerCustomer->Password = 'BEEsales@33';
    $mailerCustomer->setFrom('sales@ontabee.com', 'Ontabee SaaS');
    $mailerCustomer->addAddress($_POST["fa_email"]);
    $mailerCustomer->CharSet = 'UTF-8';
    $mailerCustomer->Subject = 'Inquiry - Ontabee SaaS - '. $_POST["for_name"] . ' - ' . $_POST["fa_name"];
    $mailerCustomer->Subject = $domain . ' - Ontabee - You’re in :) | PLUS, a quick question...';
    $mailerCustomer->Body = '
    <!DOCTYPE HTML>
    <html lang="en-US">
    <head> 
      <meta charset="UTF-8" />
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet" type="text/css"/>
      <style>
        @import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700");
        body{font-family: "Roboto", sans-serif;}
      </style>
    </head>
    <body style="background:#e6e7ea">
    
    <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="padding:30px 15px; font-family: "Roboto"; font-size:14px; color:#333; line-height:20px;">
    <tbody>
     <tr>
       <td width="100%" valign="top" style="padding:35px 15px;">
        <table cellpadding="0" cellspacing="0" border="0" align="center" style="max-width:600px; margin:0 auto; width: 100%;">
          <tbody>
            <td>
              <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="box-shadow: 0px 0px 25px rgba(0, 0, 0, 0.15); border-top-left-radius:8px; border-top-right-radius:8px">
              <tbody>
              <tr>
                <td valign="middle" style="background-color:#fff; padding:15px 20px 10px 20px; border-top-left-radius:8px; border-top-right-radius:8px;">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center">
                    <tbody>
                      <tr>
                        <td><a href="https://www.ontabee.com"><img src="https://www.ontabee.com/images/logo.png" alt="Ontabee" height="50"></a></td>
                        <td style="text-align:right; padding-top:4px;">
                          <a href="https://www.facebook.com/Ontabee-149066152475073/"><img src="https://www.ontabee.com/images/facebook.png" style="margin:2px"></a>
                          <a href="https://twitter.com/ontabee"><img src="https://www.ontabee.com/images/twitter.png" style="margin:2px"></a>
                          <a href="https://www.linkedin.com/company/ontabee/"><img src="https://www.ontabee.com/images/linkedin.png" style="margin:2px"></a>
                        </td>
                      </tr>            
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td style="padding:40px 20px 60px 20px; text-align:center; background: url(https://www.ontabee.com/images/banner_small.jpg) no-repeat bottom; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">
                    <h1 style="font-size: 26px; font-weight:300; line-height:normal; margin:0px;">Free Online <b style="color: #FC8019; font-weight: 400;">Food</b> Ordering System <span style="display: block; text-transform: none; margin-top: 10px;">For Restaurant Business</span></h1>
                </td>
              </tr>
              <tr>
                <td style="background-color:#fff; padding:20px">
                  <p style="margin:0px 0px 10px 0px;">Hey '. $_POST["fa_name"] .', </p>
                  <p style="margin:0px 0px 10px 0px;">I really appreciate you joining us at Ontabee, and I know you’ll love it when you see how easy it is to use Ontabee.</p>
                  <p style="margin:0px 0px 10px 0px;">We built Ontabee to help small businesses grow, and I hope that we can achieve that for you.</p>
                  <p style="margin:0px 0px 10px 0px;">If you wouldn’t mind, I’d love it if you answered one quick question: Why did you sign up for Ontabee?</p>
                  <p style="margin:0px 0px 10px 0px;">I’m asking because knowing what made you sign up is really helpful for us in making sure that we’re delivering on what our users want. Just hit “reply” and let me know.</p>
                  <p style="margin:0px;">By the way, Please check your details below.</p>            
                </td>
              </tr>
              <tr>
                <td style="background-color:#f3f3f3; padding:20px;">
                  <h3 style="font-weight: 500; font-size:18px; margin:0px">Your demo account details on <span style="color: #FC8019;">Ontabee.com</span></h3>
                </td>
              </tr>
              <tr>
                <td style="background:#f3f3f3; padding:0px 20px 20px 20px;">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0" style="border-collapse: collapse; background-color:#fff">                    
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Activation Link</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">
                          <a href="https://www.ontabee.com/activation?activation_key=' . $activation_key .'" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #7ab338; margin-top:2px">Click here to Activate</a>
                          <span style="display:block; color:#666; font-weight:400; margin-top:5px; font-size:13px">Please click on above button to activate your account.</span>
                      </td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Your Domain</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $domain .'.ontabee.com</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Admin Login</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $domain .'.ontabee.com/admin</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Username</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">admin1</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Password</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">admin</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_name"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Email</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_email"] .'</td>
                    </tr>    
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Phone Number</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_dial"] .' ' . $_POST["fa_tel"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Country</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_country"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Referer</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_SESSION["referer"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Category</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["fa_category"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Customer App Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=j1qWh_N5IxI" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Delivery App Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=favN6OgqGi4" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Back-end Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=mAqgAeku_10" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                  </table>
                </td>                    
              </tr>        
              <tr>
                <td valign="middle" style="background-color:#FC8019; color:#fff; padding:15px 20px; border-bottom-left-radius:8px; border-bottom-right-radius:8px">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0">
                    <tr>
                      <td><span style="font-weight:300; font-size:13px">Best Regards,</span><br>Rajesh Prabhu S <span style="font-weight:300; font-size:12px">(CEO, Ontabee)</span></td>
                      <td style="text-align:right; padding-left:15px;">
                        <span style="font-weight:300; font-size:13px">For more information</span><br>
                        <a style="color:#fff; text-decoration:none">sales@ontabee.com</a>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </tbody>
            </table>
            </td>
          </tr> 
            <tr>
              <td valign="middle" style="padding:20px 20px; text-align:center; color:#666; font-size:13px">
                <p style="margin:0px 0px 15px 0px">Questions? The Ontabee team is always here to help. <br>Contact sales@ontabee.com and we&apos;ll get back to you soon.</p>
                &copy; '. date('Y') .' Ontabee. All rights reserved.
              </td>
            </tr>
          </tbody>
        </table>
       </td>
      </tr>
    </tbody>
    </table>
    
    </body>
    </html>
    ';
    $mailerCustomer->AltBody = 'This is a plain-text message body';
    $mailerCustomer->send();

    if(!$mailer->Send())
    {
      echo json_encode([ 'httpcode' => 405 ,'error' => "Mailer Error: " . $mailer->ErrorInfo]); die;
    }
    else
    {

      /*$curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://technoduce-info-solutions-pvt-ltd-sandbox.chargify.com/subscriptions.json",
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_USERPWD => "e17RQqgJFZJo0x7ECjNyROljwxFcEAwzqy2eKG0yPRY:x",
      CURLOPT_POSTFIELDS => "{\"subscription\":{
    \"product_handle\":\"premium\",\"customer_attributes\":{
    \"first_name\":\"Test\",\"last_name\":\"User\",
    \"email\":\"user@example.com\"},\"credit_card_attributes\":{
    \"full_number\":\"1\",\"expiration_month\":\"10\",
    \"expiration_year\":\"2020\"}}}",
      CURLOPT_HTTPHEADER => array(
        "content-type: application/json"
      ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);
    if ($err) {
      //print_r("cURL Error #:" . $err);
      //exit;
    }*/

      $_SESSION['msg'] = 1; 
      echo json_encode([ 'httpcode' => 200]); die;
			/*header("Location: /thankyou");*/
    }
  }
}
}