/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Profile', {
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'user_id'
    },
    profileKey: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'profile_key'
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'name'
    },
    publicEmail: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'public_email'
    },
    gravatarEmail: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'gravatar_email'
    },
    gravatarId: {
      type: DataTypes.STRING(32),
      allowNull: true,
      field: 'gravatar_id'
    },
    location: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'location'
    },
    website: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'website'
    },
    bio: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'bio'
    }
  }, {
    tableName: 'ss16_profile'
  });
};
