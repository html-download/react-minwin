'use strict';
const Async = require('async');
const Boom = require('boom');
const Config = require('../config');
const NodeLocalStorage = require('../client/helpers/nodelocal-storage-access');

const internals = {};


internals.applyStrategy = function (server, next) {

    server.auth.strategy('session', 'cookie', {
        password: Config.get('/cookieSecret'),
        cookie: Config.get('/projectName'),
        isSecure: false,
        redirectTo: '/login',
        appendNext: 'returnUrl',
        validateFunc: function (request, data, callback) {
            
            Async.auto({
                session: function (done) {

                    let storageData = NodeLocalStorage.getItem(`user${data.user._id}`);
                    storageData = JSON.parse(storageData);
                    
                    if (storageData && storageData._id === data.user._id) {
                        done(null, true);
                    } else{
                        done(null, false);
                    }
                }
            }, (err, results) => {

                if (err) {
                    return callback(err);
                }

                if (!results.session) {
                    return callback(null, false);
                }

                let result = { 
                    id: data.user._id
                };

                result.scope = ['admin'];

                callback(null, Boolean(true), result);
            });
        }
    });


    next();
};


internals.preware = {
    ensureNotRoot: {
        assign: 'ensureNotRoot',
        method: function (request, reply) {

            if (request.auth.credentials.user.username === 'root') {
                const message = 'Not permitted for root user.';

                return reply(Boom.badRequest(message));
            }

            reply();
        }
    },
    ensureAdminGroup: function (groups) {

        return {
            assign: 'ensureAdminGroup',
            method: function (request, reply) {
                console.log("ensure admin group");
                if (Object.prototype.toString.call(groups) !== '[object Array]') {
                    groups = [groups];
                }

                const groupFound = groups.some((group) => {

                    return request.auth.credentials.roles.admin.isMemberOf(group);
                });

                if (!groupFound) {
                    const message = `Missing admin group membership to [${groups.join(' or ')}].`;

                    return reply(Boom.badRequest(message));
                }

                reply();
            }
        };
    }
};


exports.register = function (server, options, next) {

    server.dependency([], internals.applyStrategy);

    next();
};


exports.preware = internals.preware;


exports.register.attributes = {
    name: 'auth'
};
