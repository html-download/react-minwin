//Fixed Header  
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".site_header").addClass("fixed");
    } else {
        $(".site_header").removeClass("fixed");
    }		
});

new WOW().init();

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});

//floating_label
$(document).on('focus active', '.floating_label .form-control',function(){
	$('label[for='+$(this).attr('id')+']').addClass('focus');
});
$(document).on('blur', '.floating_label .form-control',function(){
	$('label[for='+$(this).attr('id')+']').removeClass('focus');
});

//Current Page
$(document).ready(function() {
    $("[href]").each(function() {
    if (this.href == window.location.href) {
        $(this).addClass("current_page");
        }
    });
});

//Select
var config = {
  '.chosen-select'           : {},
  '.chosen-select-deselect'  : {allow_single_deselect:true},
  '.chosen-select-no-single' : {disable_search_threshold:10},
  '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
  '.chosen-select1'           : {disable_search: true}
}
for (var selector in config) {
  $(selector).chosen(config[selector]);
}

//Modal
$(".modal_change").click(function(){
	$("body").addClass("modal_open");
});
$(".modal .close").click(function(){
	$("body").removeClass("modal_open");
});

//contact page form
$(document).ready(function() {
$.validator.addMethod("phone1", function(value, element) {
		return /^[0-9 +-]{5,20}$/.test(value);
}); 
  
$("form[name='contactform']").validate({
validClass: "successclass",
 rules:{
   contact_name:"required",
   contact_email:{
		required:true,
		email:true
	},
	contact_tel:{
		required:true,
		//number:true,
	   phone1:true,
		minlength:5
	},
	contact_message:"required"
 },
 messages: {
contact_name: {
   required: "Enter your name",                         
},
contact_email: {
   required: "Enter your email",
   email:"Enter a valid email"                  
},

contact_tel : {
   required: "Enter your phone number",
   phone1: "Enter a valid phone number",
   minlength:"Enter a valid phone number"
},

contact_message : {
   required: "Enter your message"            
},

},
 submitHandler: function(form) { 
  //form.submit();
   contact_request_form_submit(1);
// var googleResponsecon = jQuery('#contactform #g-recaptcha-response').val();
//     if (!googleResponsecon) {
//          $("#contactform .g-recaptcha").append("<label class='error'>Please fill up the captcha</label>");
//         return false;
//     } else {
//         form.submit();
//     }
 }
});
  
var page_urlnew = window.location.href;  
$("#contact_url").val(page_urlnew); 

$("#contact_tel").intlTelInput({   
    initialCountry: "auto",
	separateDialCode: true,  
	geoIpLookup: function(callback) {
		$.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
		var countryCode = (resp && resp.country) ? resp.country : "";
		callback(countryCode);
	});
	},
 });

var datapopupcountry = $('#contactform .intl-tel-input .country-list li.active').find(".country-name").text();
var datapopupdial = $('#contactform .intl-tel-input .country-list li.active').find(".dial-code").text();
$("#contact_country").val(datapopupcountry);  
$("#contact_tel_code").val(datapopupdial);

$("#contact_tel").on("countrychange", function(e, countryData) {
	$("#contact_tel_code").val("+" + countryData.dialCode);    
	$("#contact_country").val(countryData.name);
	}); 
});
// end contact

//demo page form
$(document).ready(function() {
	$.validator.addMethod("phone1", function(value, element) {
			return /^[0-9 +-]{5,20}$/.test(value);
	}); 
	  
	/*$("form[name='demoform']").validate({
	validClass: "successclass",
	 rules:{
	   demo_name:"required",
	   demo_email:{
			required:true,
			email:true
		},
		demo_tel:{
			required:true,
		   phone1:true,
			minlength:5
		}
	 },
	messages: {
	demo_name: {
	   required: "Enter your name",                         
	},
	demo_email: {
	   required: "Enter your email",
	   email:"Enter a valid email"                  
	},
	
	demo_tel : {
	   required: "Enter your phone number",
	   phone1: "Enter a valid phone number",
	   minlength:"Enter a valid phone number"
	},	
	},
	 submitHandler: function(form) { 
	  form.submit();
	// var googleResponsecon = jQuery('#demoform #g-recaptcha-response').val();
	//     if (!googleResponsecon) {
	//          $("#demoform .g-recaptcha").append("<label class='error'>Please fill up the captcha</label>");
	//         return false;
	//     } else {
	//         form.submit();
	//     }
	 }
	});*/
	  
	var page_urlnew = window.location.href;  
	$("#demo_url").val(page_urlnew); 
	
	$("#demo_tel").intlTelInput({   
		initialCountry: "auto",
		separateDialCode: true,  
		geoIpLookup: function(callback) {
			$.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
			var countryCode = (resp && resp.country) ? resp.country : "";
			callback(countryCode);
		});
		},
	 });
	
	var datapopupcountry = $('#demoform .intl-tel-input .country-list li.active').find(".country-name").text();
	var datapopupdial = $('#demoform .intl-tel-input .country-list li.active').find(".dial-code").text();
	$("#demo_country").val(datapopupcountry);  
	$("#demo_tel_code").val(datapopupdial);
	
	$("#demo_tel").on("countrychange", function(e, countryData) {
		$("#demo_tel_code").val("+" + countryData.dialCode);    
		$("#demo_country").val(countryData.name);
		}); 
	});
// end demo

$(document).ready(function() {  
	$("form[name='tryheader']").validate({
	 rules:{
	   try_email:{
			required:true,
			email:true
		},     
			   },     
	 messages: {           
	try_email: {
	   required: "Please enter your email",
	   email:"Enter a valid email"                  
	},
},

submitHandler: function(form) { 
  form.submit();  
 }
});  

$("form[name='tryfooter']").validate({
 rules:{
	try_name:{
		required:true
	}, 
   try_email:{
		required:true,
		email:true
	},     
		   },     
 messages: {           
 try_name: {
   required: "Enter your name"
},try_email: {
   required: "Enter your email",
   email:"Enter a valid email"
},
},

submitHandler: function(form) { 
  form.submit();  
 }
});  

$("form[name='alternative']").validate({
 rules:{
	try_name:{
		required:true
	}, 
	try_email:{
		required:true,
		email:true
	},     
		   },     
 messages: {           
 try_name: {
   required: "Enter your name"
},try_email: {
   required: "Enter your email",
   email:"Enter a valid email"
},
},

submitHandler: function(form) { 
  form.submit();  
 }
}); 

var page_tryUrl = window.location.href;  
   $("input[name*='try_url']").val(page_tryUrl); 
});
//  footer try end

// contact page form
$(document).ready(function() {  
   $("form[name='signup']").validate({
     validClass: "successclass",
		 rules:{
			fa_name:"required",
			fa_email:{
				required:true,
				email:true
			},
			fa_tel:{
				required:true,
				number:true,
			    minlength:5
			},
			fa_rn:"required"
		 },
		 messages: {
		fa_name: {
		   required: "Enter your name",                         
	   },
		fa_email: {
		   required: "Enter your email",
		   email:"Enter a valid email"                  
	   },
		fa_tel : {
		   required: "Enter your phone",
		   number: "Enter a valid phone",
		   minlength:"Enter a valid phone"
		},
		fa_rn : {
		   required: "Enter your restaurant name"            
		},

},
submitHandler: function(form) { 
//form.submit();  
signup_form_submit(1);
  // var googleResponsecon = jQuery('#signup #g-recaptcha-response').val();
  //   if (!googleResponsecon) {
  //        $("#signup .g-recaptcha").append("<label class='error'>Please fill up the captcha</label>");
  //       return false;
  //   } else {
  //       form.submit();
  //   }

 }
});
  
var page_faurl = window.location.href;  
$("#fa_url").val(page_faurl); 

$("#fa_tel").intlTelInput({   
	initialCountry: "auto",
	separateDialCode: true,  
	geoIpLookup: function(callback) {
		$.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
		var countryCode = (resp && resp.country) ? resp.country : "";
		callback(countryCode);
	});
	},
});

var datafacountry = $('#signup .intl-tel-input .country-list li.active').find(".country-name").text();
var datafadial = $('#signup .intl-tel-input .country-list li.active').find(".dial-code").text();
$("#fa_country").val(datafacountry);  
$("#fa_dial").val(datafadial);

$("#fa_tel").on("countrychange", function(e, countryData) {
	$("#fa_dial").val("+" + countryData.dialCode);    
    $("#fa_country").val(countryData.name);
    }); 
});
// end contact

// nospace
$("input#fa_rn").on({
  keydown: function(e) {
    if (e.which === 32)
      return false;
  },
  change: function() {
    this.value = this.value.replace(/\s/g, "");
  }
});

// alternative validation
$("#premium_form").validate({
 rules:{
   pre_email:{
		required:true,
		email:true
	},  
	 pre_res_name:{
		required:true                    
	},     
		   },     
 messages: {           
	pre_email: {
	   required: "Enter your email",
	   email:"Enter a valid email"                  
	},
	pre_res_name: {
	   required: "Enter your name",   
	},
},
submitHandler: function(form) { 
	form.submit();
}
}); 

/*equal height*/
setHeights	= function()
{
	var $list		= $( '.equal, .steps' ),
		$items		= $list.find( '.height, .content' );
		
	$items.css( 'height', 'auto' );
	var perRow = Math.floor( $list.width() / $items.width() );
	if( perRow == null || perRow < 2 ) return true;
	for( var i = 0, j = $items.length; i < j; i += perRow )
	{
		var maxHeight	= 0,
			$row		= $items.slice( i, i + perRow );

		$row.each( function()
		{
			var itemHeight = parseInt( $( this ).outerHeight() );
			if ( itemHeight > maxHeight ) maxHeight = itemHeight;
		});
		$(window).on('load', $row.css( 'height', maxHeight ));
	}
};	
$(document).ready(function(){
	setHeights();
	$( window ).on( 'resize', setHeights );
});

window.addEventListener("wheel", function(e) {
    setHeights();
    console.log('setHeights');
});
$(document).mousemove(function(event){
	setHeights();
});

//Carousel
jQuery(document).ready(function($) {
	$('.screens').owlCarousel({
	center: true,
	nav:true,
	dots:false,
	items: 2,
	loop: true,
	autoplay:true,
    autoplayTimeout:3000,
	margin: 10,
	responsive: {
	  800: {
		items: 4
	  }
	}
	});
});

jQuery(document).ready(function($) {
	$('.screens1').owlCarousel({	
	nav:true,
	dots:false,
	items: 1,
	loop: true,
	autoplay:true,
    autoplayTimeout:3000
	});
});

// //Loader
// $(function() {
// 	$("#loader").delay(2500).fadeOut('slow');
// });
// var elem = document.getElementById("color_logo");
// var width = 1;
// var id = setInterval(frame, 15);
// function frame() {
// 	if (width >= 140) {
// 	  clearInterval(id);
// 	} else {
// 	  width++;
// 	  elem.style.width = width + 'px';
// 	}
// }

//Mobile Footer
$(function() {
	$('.footer h4').click(function() {
		$(this).next('.reset').slideToggle();
		$(this).toggleClass("open");
		return false;
	});
});

//Mobile Menu
$("#mobile_nav").on('click', function() {
   $(".site_menu").fadeToggle();
   $(".site_menu").toggleClass("open");
   $(this).toggleClass("open");
   $("body").toggleClass("open");
});

$(".site_menu a.link, .site_menu, .submenu a").on('click', function() {
   $(".site_menu").fadeOut();
   $(".site_menu").removeClass("open");
   $("#mobile_nav").removeClass("open");
   $("body").removeClass("open");
});

$(function() {
	$('.site_menu a.sublink').click(function() {
		$(this).next('.submenu, ul').slideToggle();
		$(this).toggleClass("open");
		return false;
	});
});

function resize() {
    if ($(window).width() < 801) {
		$('.site_menu').removeClass('open');
		$('.site_menu').hide();
		$('body').removeClass('open');
    }
}
$(document).ready( function() {
    $(window).resize(resize);
    resize();
});

//Plans
$('.plans a.monthly').click(function() {	
	$('a.monthly').addClass('active');
	$('a.annual').removeClass('active');
});
$('.plans a.annual').click(function() {		
	$('a.annual').addClass('active');
	$('a.monthly').removeClass('active');
});

//Responsive Tabs
$(document).ready( function() {
    $.each($('.nav-tabs.responsive li'), function(i,j){
		var a = $(this).find('a').clone();
		var id = a.attr('href');
		a.insertBefore(id);
	})
});

$(function() {
	$('.tab-content a.tab').click(function(e) {
		$(this).next('.tab-pane').slideToggle();
		$(this).toggleClass("open");
		return false;
	});
});

//Chat Box
// window.setTimeout(function(){
// 	LC_API.open_chat_window({source:'eye catcher'});
// 	return false;
// }, 30000);

//Calculation
$( function() {
	//Portal Calculation
    $("#price_slider").slider({
		range: "min",
		min: 100,
		value:200,
		max: 1500,
		step: 10,
		slide: function( event, ui ) {
			$("#price").text(ui.value).attr("data-price",ui.value);
			priceUpdate();
		}
    });
	
	$("#commission_slider").slider({
		range: "min",
		min: 0,
		value:5,
		max: 30,
		step: 1,
		slide: function( event, ui ) {			
			$("#commission").text(ui.value).attr("data-commission",ui.value);
			priceUpdate();
		}
    });
	
	function priceUpdate() {
		$price = $("#price").attr('data-price');
		$commission = $("#commission").attr('data-commission');
		$monthly = parseInt($price)*parseInt($commission)/100;
		$yearly = parseInt($price)*parseInt($commission)/100*10;
		$('#monthly').html($monthly);
		$('#yearly').html($yearly);
	}	

	//Server Calculation
	$("#ram_slider").slider({
		range: "min",
		min: 1,
		value:1,
		max: 4,
		step: 1,
		slide: function( event, ui ) {
			var ram = ui.value;
			switch(ui.value) {
				case 1:
					ram = '2';
					$("#user").text("100").attr("data-user","100");					
					$("#user_slider").slider('value', ui.value);
					$('#amount').text("22");
					break;
				case 2:
					ram = '4';
					$("#user").text("200").attr("data-user","200");
					$("#user_slider").slider('value', ui.value);
					$('#amount').text("39");
					break;
				case 3:
					ram = '8';
					$("#user").text("400").attr("data-user","400");
					$("#user_slider").slider('value', ui.value);
					$('#amount').text("73");
					break;
				case 4:
					ram = '16';
					$("#user").text("1600").attr("data-user","1600");
					$("#user_slider").slider('value', ui.value);
					$('#amount').text("140");
					break;
			}
			$("#ram").text(ram).attr("data-ram",ram);
		}
	});
	
	$("#user_slider").slider({
		range: "min",
		min: 1,
		value:1,
		max: 4,
		step: 1,
		slide: function( event, ui ) {
			var user = ui.value;
			switch(ui.value) {
				case 1:
					user = '100';
					$("#ram").text("2").attr("data-ram","2");
					$("#ram_slider").slider('value', ui.value);
					$('#amount').text("22");
					break;
				case 2:
					user = '200';
					$("#ram").text("4").attr("data-ram","4");
					$("#ram_slider").slider('value', ui.value);
					$('#amount').text("39");
					break;
				case 3:
					user = '400';
					$("#ram").text("8").attr("data-ram","8");
					$("#ram_slider").slider('value', ui.value);
					$('#amount').text("73");
					break;
				case 4:
					user = '1600';
					$("#ram").text("16").attr("data-ram","16");
					$("#ram_slider").slider('value', ui.value);
					$('#amount').text("140");
					break;
			}
			$("#user").text(user).attr("data-user",user);
		}
	});
} );

$('.cookie-accept').click(function () { //on click event
	
  days = 182; //number of days to keep the cookie
  myDate = new Date();
  myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
  //document.cookie = "comply_cookie = comply_yes; expires = " + myDate.toGMTString(); //creates the cookie: name|value|expiry
  document.cookie = "cookiename=cookievalue"
  $("#cookies").slideUp("slow"); //jquery to slide it up
});


//---

document.getElementById("cookie-accept").onclick = function(e) {

  days = 182; //number of days to keep the cookie
  myDate = new Date();
  myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
  //document.cookie = "comply_cookie = comply_yes; expires = " + myDate.toGMTString(); //creates the cookie: name|value|expiry
  document.cookie = "cookiename=cookievalue"
  document.getElementById("cookies").parentNode.removeChild(elem);
}