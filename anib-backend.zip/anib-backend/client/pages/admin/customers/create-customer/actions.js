/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const CommonFunctions = require('../../../../helpers/common-functions');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../helpers/toaster');
const Qs = require('qs');


class Actions {

    static getNationalityResults() {
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }

    static createNew(data, history, searchData, returnAction) {

        ApiActions.post(
            '/customer',
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {                

                if (!err) {                    
                    Toaster.success('Customer saved successfully!');
                    returnAction.hideCreateCustomer();                    
                    history.push(`/admin/customers/${response.data.customer_key}`);
                }
            }
        );
    }

    static updateDOB(date) {
        
        Store.dispatch({
            type: Constants.UPDATE_DOB,
            date: date
        });
    }

    static getUserTypes() {
        
        ApiActions.get(
            '/user/types',
            undefined,
            Store,
            Constants.GET_USER_TYPES,
            Constants.GET_USER_TYPES_RESPONSE
        );
    }
    static getUsers() {
        
        ApiActions.get(
            '/user',
            undefined,
            Store,
            Constants.GET_USERS,
            Constants.GET_USERS_RESPONSE
        );
    }
}


module.exports = Actions;
