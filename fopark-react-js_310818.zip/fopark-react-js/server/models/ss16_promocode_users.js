/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16PromocodeUsers', {
    promocode: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'promocode'
    },
    users: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'users'
    }
  }, {
    tableName: 'ss16_promocode_users'
  });
};
