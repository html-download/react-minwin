const Actions = require('./actions');
const PropTypes = require('prop-types');
const React = require('react');
const Store = require('./store');
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';


const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
};


class PipelinePage extends React.Component {

    constructor(props) {

        super(props);

        this.toggle = this.toggle.bind(this);
        this.getLoadTab = this.getLoadTab.bind(this);
        this.state = Store.getState();
    }

    componentDidMount() {
        
        Actions.getPipelineDetails();
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

    }

    componentWillReceiveProps(nextProps) {
        if(this.props.dealDetails.pipeline_id !== nextProps.dealDetails.pipeline_id) {
            this.toggle(nextProps.dealDetails.pipeline_id);
        }        
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    toggle(tab, url = false, id = false) {
        if (this.state.activeTab !== tab) {
            Actions.toggleTab(tab, url, id);
        }
    }

    updateOrderId(id = false) {
        Actions.updateOrderId(id);
    }

    getLoadTab(isContent = false){
        const {
            pipeline_data,
            activeTab,
            pipeline_loading
        } = this.state;

        const data = pipeline_data ? pipeline_data : [];

        if (data.length === 0) {
            return null;
        }

        let response = data.map((value, index) => {
            if (isContent) {

                let content;
                let slug = value['slug'] ? value['slug'] : '';
                
                try {

                    const PipelineComponent = require(`./${slug}/index`);
                        
                    content = <PipelineComponent 
                            key={`pipeline-component-${index}`}
                            pipelineData={value}
                            propertyData={this.props}
                            stateData={this.state}
                            id={this.props.id}
                            deal_data={this.props.deal_data}
                            toggle={this.toggle}
                            updateOrderId={this.updateOrderId}
                            view_url={this.state.view_url}
                            order_id={this.state.order_id}
                            deal_payment_status={this.props.dealDetails.deal_payment_status}
                        />
                    
                } catch (e) {
                    content = (
                        <div className="under-construction">
                            <img src="/public/media/images/under-cons.jpg" className="img-responsive" />
                            <h3>Sorry! We are Under Scheduled Maintenance</h3>
                            <p>Our website is currently undergoing scheduled maintenance, will be right back in a few minutes.</p>
                            <p>Thank you for your patience.</p>
                        </div>
                    )
                }

                return  (
                    <TabPane tabId={value['sort_no']} key={`pipeline-content-${index}`}>
                        {content}
                    </TabPane>
                )
            }

            let greenCondition = this.state.activeTab === 5 ? true : this.state.activeTab > value['sort_no'];
            return  (
                    <NavItem key={`pipeline-tab-${index}`} className={classnames({ active: this.state.activeTab === value['sort_no'], green: greenCondition  })}>
                        <NavLink
                          onClick={() => { this.toggle(value['sort_no']); }}
                        >
                          { value['pipeline_name'] }
                        </NavLink>
                    </NavItem>
                );
        });

        return response;
    }

    render() {

        if (this.state.pipeline_loading) {
            return (
                <div class="wizard-links loader-tab">
                    <ul class="reset">
                        <li class="active"></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </div>
            );
        }



        return (
          <div className={classnames({  })}>
            
            <Nav tabs className={classnames({ 'reset': true, 'wizard-links': true })}>
                {this.getLoadTab()}
            </Nav>
            
            <TabContent activeTab={this.state.activeTab} className={classnames({ 'tab-content': true })}>
                {this.getLoadTab(true)}
            </TabContent>
          
          </div>
        );
      }
}

PipelinePage.propTypes = propTypes;


module.exports = PipelinePage;
