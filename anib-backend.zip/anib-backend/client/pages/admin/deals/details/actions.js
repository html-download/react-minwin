/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const Constants = require('./constants');
const CommonAction = require('../../common-store/action');
const Store = require('./store');
const Toaster = require('../../../../helpers/toaster');


class Actions {

    static getDetails(id, loadAnotherData = true) {
        
        this.getNotes(id);
        this.getDealDocu(id);
        this.getDealTask(id);

        ApiActions.get(
            `/deal/${id}`,
            undefined,
            Store,
            Constants.GET_DEAL_DETAILS,
            Constants.GET_DEAL_DETAILS_RESPONSE
        );
    }

    static getEmirates() {

        ApiActions.get(
            '/emirate',
            undefined,
            Store,
            Constants.GET_EMIRATES,
            Constants.GET_EMIRATES_RESPONSE
        );
    }


    static getVehicleTypes() {
        
        ApiActions.get(
            '/deal/vehicle-type',
            undefined,
            Store,
            Constants.GET_VEHICLE_TYPE,
            Constants.GET_VEHICLE_TYPE_RESPONSE
        );
    }


    static getNationalityResults() {
        
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }

    static getEnquiryTypes() {
        
        ApiActions.get(
            '/deal/enquiry-type',
            undefined,
            Store,
            Constants.GET_ENQUIRY_RESULTS,
            Constants.GET_ENQUIRY_RESULTS_RESPONSE
        );
    }

    

    static getDrivingExperience() {
        
        ApiActions.get(
            '/customer-driving-profile/license-age-list',
            undefined,
            Store,
            Constants.GET_DRIVING_EXPERIENCE_RESULTS,
            Constants.GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE
        );
    }

    static saveDetails(id, data) {

        ApiActions.post(
            `/customer/attribute-save/${id}`,
            data,
            Store,
            Constants.SAVE_DETAILS,
            Constants.SAVE_DETAILS_RESPONSE
        );
    }

    static saveDealDetails(id, data) {
        
        ApiActions.post(
            `/deal/attribute-save/${id}`,
            data,
            Store,
            Constants.SAVE_DEAL_DETAILS,
            Constants.SAVE_DEAL_DETAILS_RESPONSE,
            (err, response) => {

                if (!err && response.status === 200) {
                    switch (data.attribute_key) {
                        case 'year_id':
                            CommonAction.getVehicleBrand(response.data.year_key);
                            break;
                        case 'vehicle_brand_id':
                            CommonAction.getVehicleBrandModel(response.data.vehicle_brand_key);
                            break;
                        case 'vehicle_brand_model_id':
                            CommonAction.getVehicleBrandModel(response.data.vehicle_brand_model_id);
                            break;
                        case 'vehicle_brand_model_id':
                            CommonAction.getCartTrim(response.data.vehicle_brand_model_id);
                            break;
                    }
                }
            }
        );
    }    

    static saveDealCustomerDetails(id, data) {

        ApiActions.post(
            `/deal/deal-customer-attribute-save/${id}`,
            data,
            Store,
            Constants.SAVE_CUSTOMER_DETAILS,
            Constants.SAVE_CUSTOMER_DETAILS_RESPONSE
        );
    }    

    static hideDetailsSaveSuccess() {

        Store.dispatch({
            type: Constants.HIDE_DETAILS_SAVE_SUCCESS
        });
    }

    static delete(id, history) {

        ApiActions.delete(
            `/customer/delete/${id}`,
            undefined,
            Store,
            Constants.DELETE,
            Constants.DELETE_RESPONSE,
            (err, response) => {

                if (!err) {
                    
                    history.push('/admin/customers');

                    window.scrollTo(0, 0);
                }
            }
        );
    }

    static addEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });

    } 

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });

    } 

    static showDeleteModal() {

        Store.dispatch({
            type: Constants.DELETE_MODAL_SHOW
        });

    } 

    static hideDeleteModal() {

        Store.dispatch({
            type: Constants.DELETE_MODAL_HIDE
        });

    }

    static addTaskModal() {

        Store.dispatch({
            type: Constants.ADD_TASK_MODAL_SHOW
        });
    }

    static hideTaskModal() {

        Store.dispatch({
            type: Constants.ADD_TASK_MODAL_HIDE
        });

    }

    static getDealTask(id) {

        ApiActions.get(
            `/task?task_status=1&deal_id=${id}`,
            undefined,
            Store,
            Constants.GET_DEAL_TASK_RESULT,
            Constants.GET_DEAL_TASK_RESULT_RESPONSE
        );
    }

    static deleteTask(task_key, id) {

        ApiActions.delete(
            `/task/${task_key}`,
            undefined,
            Store,
            Constants.REMOVE_TASK,
            Constants.REMOVE_TASK_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.getDealTask(id);
                        Toaster.success('Task Has been deleted..');
                    }
                }
            }
        );
    }

    
    static deleteNote(note_key, id) {

        ApiActions.delete(
            `/deal-note/${note_key}`,
            undefined,
            Store,
            Constants.REMOVE_NOTE,
            Constants.REMOVE_NOTE_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.getNotes(id);
                        Toaster.success('Note Has been deleted..');
                    }
                }
            }
        );
    }

    

    static getNotes(id) {
                
        ApiActions.get(
            `/deal-note?deal_id=${id}`,
            undefined,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE
        );
    }
    
    static deleteDocu(docu_key, id) {

        ApiActions.delete(
            `/deal-document/${docu_key}`,
            undefined,
            Store,
            Constants.REMOVE_DOCUMENT,
            Constants.REMOVE_DOCUMENT_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.getDealDocu(id);
                        Toaster.success('Document Has been deleted..');
                    }
                }
            }
        );
    }

    static getDealDocu(id) {
        
        ApiActions.get(
            `/deal-document?deal_id=${id}`,
            undefined,
            Store,
            Constants.GET_DEAL_DOCU_DETAILS,
            Constants.GET_DEAL_DOCU_DETAILS_RESPONSE
        );
    }
    
    static addNoteModal() {

        Store.dispatch({
            type: Constants.ADD_NOTE_MODAL_SHOW
        });
    }

    static hideNoteModal() {

        Store.dispatch({
            type: Constants.ADD_NOTE_MODAL_HIDE
        });
    }

    static createNote(data) {

        ApiActions.post(
            '/deal-note',
            data,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.hideNoteModal();
                        this.getNotes(data.deal_id);
                        Toaster.success('Note Has been created..');
                    }
                }
            }
        );
    }

    static updateDOB(date) {

        Store.dispatch({
            type: Constants.UPDATE_DOB,
            date: date
        });

    }

    static datePicker(date,field) {

        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD,
            date: date,
            field:field
        });

    }

    static datePickerDealInfo(date,field) {
        
        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD_DEAL_INFO,
            date: date,
            field:field
        });

    }
    static resetStore() {

        Store.dispatch({
            type: Constants.RESET_STORE
        });

    } 
}


module.exports = Actions;
