'use strict';
const FluxConstant = require('flux-constant');

module.exports = FluxConstant.set([
    
    'GET_ROLE',
    'GET_ROLE_RESPONSE',
    'UPDATE_ROLE',
    'UPDATE_ROLE_RESPONSE'
]);
