<?php include ('inc/header.php'); ?>

<div class="site_page full_row">
    <section class="offers listing_offers">
        <div class="offers_listing owl-carousel owl-theme">
            <div class="item">
                <a href="grocery-detail"><img src="assets/img/grocery/offers1.jpg"> 
                    <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="grocery-detail"><img src="assets/img/grocery/offers2.jpg"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="grocery-detail"><img src="assets/img/grocery/offers3.jpg"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="grocery-detail"><img src="assets/img/grocery/offers4.jpg"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="grocery-detail"><img src="assets/img/grocery/offers2.jpg"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
            <div class="item">
                <a href="grocery-detail"><img src="assets/img/grocery/offers3.jpg"> <span class="off">50% <span>OFFER</span></span></a>
            </div> <!--item-->
        </div> <!--offers_listing-->
    </section> <!--offers-->

    <section id="sorting" class="sorting full_row">
        <div class="pull-left">
            <ul class="category_menu">
                <li><a href="restaurant"><i class="fi shop"></i><span>Restaurants</span></a></li>
                <li><a href="grocery" class="active"><i class="fi grocery"></i><span>Grocery</span></a></li>
                <li><a href="laundry"><i class="fi laundry"></i><span>Laundry</span></a></li>
                <li><a href="others"><i class="fi tools"></i><span>Others</span></a></li>
            </ul> <!--category_menu-->
        </div>

        <div class="pull-right">
            <span class="filter-toggle"><i class="fi slider"></i> Filter</span>
            <select class="selectpicker hide">
                <option>Popularity</option>
                <option>Rating</option>
                <option>Distance</option>
            </select>
        </div>
    </section> <!--sorting-->

    <section class="listing full_row">
        <div class="filter-overlay"></div>
        <div class="filters" >
            
            <h3><span class="close-filter"><i>&times;</i> Filters</span> <span class="reset">Reset all</span></h3>
            
            <h4 class="mb0 full_row"><a data-toggle="collapse" href="#filter_1">Ratings</a></h4>
            <ul id="filter_1" class="filter collapse show ratings">
                <li>
                    <input id="r1" type="checkbox" class="hide" checked>
                    <label for="r1" class="checkbox"><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i> <span>20</span></label>
                </li>
                <li>
                    <input id="r2" type="checkbox" class="hide">
                    <label for="r2" class="checkbox"><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i><i class="lni-star-filled"></i> <span>20</span></label>
                </li>
                <li>
                    <input id="r3" type="checkbox" class="hide" checked>
                    <label for="r3" class="checkbox"><i class="lni-star-filled"><i class="lni-star-filled"></i><i class="lni-star-filled"></i></i> <span>20</span></label>
                </li>
                <li>
                    <input id="r4" type="checkbox" class="hide">
                    <label for="r4" class="checkbox"><i class="lni-star-filled"><i class="lni-star-filled"></i></i> <span>20</span></label>
                </li>
                <li>
                    <input id="r5" type="checkbox" class="hide">
                    <label for="r5" class="checkbox"><i class="lni-star-filled"></i> <span>20</span></label>
                </li>
            </ul>

            <h4 class="mb0 full_row"><a data-toggle="collapse" href="#filter_2">Brand</a></h4>
            <ul id="filter_2" class="filter collapse show">
                <li>
                    <input id="c1" type="checkbox" class="hide">
                    <label for="c1" class="checkbox">24 Mantra Organic <span>20</span></label>
                </li>
                <li>
                    <input id="c2" type="checkbox" class="hide" checked>
                    <label for="c2" class="checkbox">Cornitos <span>20</span></label>
                </li>
                <li>
                    <input id="c3" type="checkbox" class="hide">
                    <label for="c3" class="checkbox">DCC Delicious <span>20</span></label>
                </li>
                <li>
                    <input id="c4" type="checkbox" class="hide" checked>
                    <label for="c4" class="checkbox">Supermart <span>20</span></label>
                </li>
                <li>
                    <input id="c5" type="checkbox" class="hide">
                    <label for="c5" class="checkbox">Happilo <span>20</span></label>
                </li>
                <li>
                    <input id="c6" type="checkbox" class="hide" checked>
                    <label for="c6" class="checkbox">Origo Fresh <span>20</span></label>
                </li>
                <li>
                    <input id="c7" type="checkbox" class="hide">
                    <label for="c7" class="checkbox">Arabic <span>20</span></label>
                </li>
                 <li>
                    <input id="c4" type="checkbox" class="hide" checked>
                    <label for="c4" class="checkbox">Supermart <span>20</span></label>
                </li>
                <li>
                    <input id="c5" type="checkbox" class="hide">
                    <label for="c5" class="checkbox">Happilo <span>20</span></label>
                </li>
                <li>
                    <input id="c6" type="checkbox" class="hide" checked>
                    <label for="c6" class="checkbox">Origo Fresh <span>20</span></label>
                </li>
                <li>
                    <input id="c7" type="checkbox" class="hide">
                    <label for="c7" class="checkbox">Arabic <span>20</span></label>
                </li>
            </ul>
<button class="btn btn-filters">Show Restaurants</button>       
        </div> <!--filters-->

        <div class="vendor_list" >
            <div class="vendor_search full_row">
                <h2>Showing <b>100</b> Grocery Store(s) in <b>Abu Hamour</b></h2>

                <div class="form-group icon">
                    <label for="vendor_search"><i class="la la-search"></i></label>
                    <input id="vendor_search" type="text" class="form-control" placeholder="Ex - Store Name, Item, Category...">
                </div> <!--form-group-->
            </div> <!--vendor_search-->

            <div class="filter_list full_row">
                <span>Cornitos  <i class="fi close"></i></span>
                <span>DCC Delicious  <i class="fi close"></i></span>
                <span>Supermart  <i class="fi close"></i></span>
                <span class="clear">Clear All</span>
            </div> <!--filter_list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner1.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>                            
                        </div> <!--img-->

                      <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                            </p>
                        </div>
                         <!--vendor_info-->
                        <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner2.jpg)">
                            
                            <p><span class="red">Will be closed in 30 Min</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>                           
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Far Better Foods</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->

                   <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner3.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Grocer’S Goodness</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->

                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->


               <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner1.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner2.jpg)">
                            
                            <p><span class="red">Will be closed in 30 Min</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Far Better Foods</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->

                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner3.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Grocer’S Goodness</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->

                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner4.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

               <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner1.jpg)">
                            
                            
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner2.jpg)">
                            <p><span class="red">Will be closed in 30 Min</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Far Better Foods</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->

                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner3.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Grocer’S Goodness</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->

                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner4.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

               <div class="list">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner1.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner2.jpg)">
                            <p><span class="red">Will be closed in 30 Min</span></p>
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Far Better Foods</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner3.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Grocer’S Goodness</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->

                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner4.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->


               <div class="list closed">
                <div class="info full_row">
                    <span class="fav" data-toggle="tooltip" title="Add to Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner1.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Cashew Nuts, Almonds, Dates & Raisins</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

            <div class="list closed">
                <div class="info full_row">
                    <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>
                    <a href="grocery-detail" class="full_row">
                        <div class="img" style="background-image:url(assets/img/grocery/vendor-banner4.jpg)">
                            <span class="location"><i class="fi pin3"></i> Abu Hamour</span>
                        </div> <!--img-->

                        <div class="vendor_info full_row">
                            <p class="review grey"> <span class="promoted">Promoted</span> <span><i class="lni-star-filled"></i>4.5</span></p>
                            <h3>Goodness Grocery</h3>
                            <p class="desc grey">Diner, Breakfast, Burgers, Sandwiches</p>
                            <p class="price">
                                <span>35-40 min</span>
                                <span>Min QR 30</span>
                                
                            </p>
                        </div> <!--vendor_info-->
                           <!-- vendor footer -->
                        <div class="ventor_footer full_row">
                            <div class="float-left icons">
                                <i class="fi delivery-truck"></i>
                                <i class="fi roast-chicken"></i>
                                <i class="fi milk-bottle"></i>
                                <i class="fi fish2"></i>
                            </div>
                            <div class="float-right offer"><i class="fi discount"></i>40% Off</div>
                        </div>
                        <!-- vendor footer -->
                    </a>
                </div> <!--info-->
            </div> <!--list-->

        

            <div class="list loader">
                <img src="assets/img/loader.svg">
            </div> <!--list-->
        </div> <!--vendor_list-->
    </section> <!--listing-->
</div> <!--site_page-->

<?php include ('inc/footer.php'); ?>

<script type="text/javascript">
    $(document).ready(function(){

            $('.offers_listing').owlCarousel({
        loop: true,
        margin: 20,     
        mouseDrag: false,
        dots: false,
        responsiveClass: true,
        nav: true,
        responsive: {
          0: {
            items: 1,
            stagePadding: 50
          },
          640: {
            items: 1,
            stagePadding: 50
          },
          1000: {
            items: 4
          },
          1500: {
            items: 5
          }
        }
    });

        });
</script>