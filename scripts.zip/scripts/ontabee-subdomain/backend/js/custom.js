//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});

jQuery(document).ready(function(){
		jQuery('.scrollbar-inner').scrollbar();
});

//popover
$(document).ready(function(){
    $('[data-toggle="popover"]').popover(); 
    $('.clockpicker').clockpicker({
        placement: 'top',
        align: 'left',
        autoclose: true,
        format: 'HH:mm'
    });
});

$("[data-toggle=popover]").popover({
	html: true,
    content: function () {
        var targetId = $(this).attr('data-target');
        return $(targetId).html();
    }
});

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});

$(document).on("click", ".popover .btn" , function(){
	$(this).parents(".popover").popover('hide');
});

//scrollingTabs
$('.nav-tabs').scrollingTabs();

//Placeholder
$(document).ready(function(){
	if(!Modernizr.input.placeholder){
		$('[placeholder]').focus(function() {
		  var input = $(this);
		  if (input.val() == input.attr('placeholder')) {
			input.val('');
			input.removeClass('placeholder');
		  }
		}).blur(function() {
		  var input = $(this);
		  if (input.val() == '' || input.val() == input.attr('placeholder')) {
			input.addClass('placeholder');
			input.val(input.attr('placeholder'));
		  }
		}).blur();
		$('[placeholder]').parents('form').submit(function() {
		  $(this).find('[placeholder]').each(function() {
			var input = $(this);
			if (input.val() == input.attr('placeholder')) {
			  input.val('');
			}
		  })
		});
	}
});

//Select
var config = {
  '.chosen-select'           : {},
  '.chosen-select-deselect'  : {allow_single_deselect:true},
  '.chosen-select-no-single' : {disable_search_threshold:10},
  '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
  '.chosen-select1'           : {disable_search: true}
}
for (var selector in config) {
  $(selector).chosen(config[selector]);
}

// Date Time Picker
$(".datetime").datetimepicker({
	format: "dd MM yyyy - hh:ii",
	autoclose: true,
	showMeridian: true,
	todayBtn: true,
	//pickerPosition: "bottom-right"
});

$(".datepicker").datetimepicker({
	format: "dd-mm-yyyy",
	autoclose: true,
	todayBtn: true,
	minView: 2,
	endDate: "+0d",
	//pickerPosition: "bottom-right"
});

var startDate;
$("#startdate").datetimepicker({
	format: "dd MM yyyy - hh:ii",
	autoclose: true,
	showMeridian: true,
	todayBtn: true,
	startDate:"+0d"
});
$("#enddate").datetimepicker({
   	format: "dd MM yyyy - hh:ii",
	autoclose: true,
	showMeridian: true,
	todayBtn: true,
	startDate:"+0d"
});
	

//$(".datetime").datetimepicker("setDate", new Date());

//Show Hide
$(window).on('load', function(){
	$('.show_hide').on('click', function () {
		$('.targetDiv').hide();				
		$('#div_' + $(this).data('target')).show();		
	});	
});

//Radio Show hide
$('input[type="radio"]').click(function(){
	var inputValue = $(this).attr("value");
	var targetBox = $("." + inputValue);
	$(".targetDiv").not(targetBox).slideUp();
	$(targetBox).slideDown();
});

//Mobile Menu
$(".mobile_nav a").on('click', function() {
   $(".site_menu").toggleClass('open');
   $("body").toggleClass('menu_active');
   $(this).toggleClass("active");   
});

function loading() {
	var elem = document.getElementById("loading");
	var width = 1;
	var id = setInterval(frame, 15);
	function frame() {
		if (width >= 280) {
		  clearInterval(id);
		  $('.alert.top').removeClass("active");
		} else {
		  width++;
		  elem.style.width = width + 'px';
		}
	}
}
	
$('.alert.top .fa').on('click', function () {
	$('.alert.top').removeClass("active");	
});	
/*
Removing Auto Hide Alert option
window.setTimeout(function() {
    $(".alert").slideUp(500, function() {
        $(this).remove();
    });
}, 3000);
*/
//Sub Menu
$('.menu_action').click(function(){
	$("body").toggleClass("open");
});

//Loader
window.setTimeout(function(){
	$("#loader").hide();
}, 0.2);

function myfunction() 
{
	$(".table-responsive .chosen-single").click(function (e) {
		e.stopPropagation();
		$(".table-responsive").toggleClass('open');
	});
	$(document).click(function (e) {
		$(".table-responsive").removeClass('open');
	});
}
myfunction();

//Search Keyword
$(document).ready(function(){
    $(".search_product").keyup(function(){
        var count = 0; 
        
        try {
          var filter = ( $(this).val() != '' ) ? $(this).val() : '';
          var regex = new RegExp(filter, "gi");
        } catch(e) {
          var filter = ( $(this).val() != '' ) ? '\\'+$(this).val() : ''; 
          var regex = new RegExp(filter, "gi");
        }
        
        $("#loaditem li").each(function(){     
            if ($(this).text().search(regex) < 0) {
              $(this).fadeOut('fast');
            } else {
              $(this).show();
              count++;
            }
        });
    });
});