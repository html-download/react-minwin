/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AuthItemChild', {
    parent: {
      type: DataTypes.STRING(64),
      allowNull: false,
      primaryKey: true,
      field: 'parent'
    },
    child: {
      type: DataTypes.STRING(64),
      allowNull: false,
      primaryKey: true,
      field: 'child'
    }
  }, {
    tableName: 'ss16_auth_item_child'
  });
};
