import React from 'react'; 
import PropTypes from 'prop-types'; 
import ClassName from 'classnames';

const Select = (props) => {

	let groupClasses = ClassName(Object.assign({
		'form-group' : true
	}, props.groupClasses));
	
	let lableClasses = ClassName(Object.assign({
		'checkbox' : true
	},props.labelClasses ));

	let inputClasses = ClassName(Object.assign({
		'form-control' : true
	}), props.inputClasses)

return(

	<div className={groupClasses}>
		<label htmlFor={props.name}>{props.title}</label>
			<select
			className={inputClasses}
			name ={props.name}
			value={props.value}
			onChange={props.onChange} >

				<option value="" disabled>{props.placeholder}</option>
				{props.options.map(option => {
				return (
					<option
					key={option}
					value={option}
					label={option}>{option}

				</option>

			)

			})}
			</select>
				
			
	</div>)

	

}

Select.propTypes = {  
  name:PropTypes.string,
  option: PropTypes.array,
  value: PropTypes.string,
  onChange: PropTypes.func,
  placeholder: PropTypes.string
};

export default Select;