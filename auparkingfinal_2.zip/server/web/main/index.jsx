//'use strict';
const PropTypes = require('prop-types');
const React = require('react');


const propTypes = {
    markup: PropTypes.node,
    helmet: PropTypes.object,
    state: PropTypes.object
};

class MainPage extends React.Component {
    render() {

        return (
            <html>
                <head>
                    {this.props.helmet.title.toComponent()}
                    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                    {this.props.helmet.meta.toComponent()}
                    <link rel="stylesheet" href="/public/core.min.css" />
                    <link rel="stylesheet" href="/public/pages/main.min.css" />
                    <link rel="shortcut icon" href="/public/media/images/favicon.png" />
                    <script src="/public/media/js/jquery-3.3.1.min.js"></script>
                    {this.props.helmet.link.toComponent()}
                </head>
                <body className="hold-transition skin-blue fixed sidebar-mini">
                        <div id="app-mount"
                            dangerouslySetInnerHTML={{
                                __html: this.props.markup
                            }}
                         />
                        <script id="app-state"
                            dangerouslySetInnerHTML={{
                                __html: this.props.state
                            }}
                        />
                    <div id="lot_extention" className="modal fade custom" role="dialog">
                      <div className="modal-dialog modal-sm">

                        <div className="modal-content">
                         
                          <div className="modal-body">
                            <h4>Poultry Science Front</h4>
                            <a className="lot_info">Lot is 15% is full. You have a great chane of getting a spot</a>
                            <a className="btn">View Lot Map</a>
                            <a className="btn">Get Driving Direction</a>
                            <a className="btn" data-dismiss="modal">Go Back</a>
                          </div>
                        </div>

                      </div>
                    </div>
                    {/*<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDNlIS2XVNFDl-FS3HfSaEWAIzm4-t66Lw&libraries=places"></script>*/}
                    <script src="/public/pages/main.min.js"></script>
                    <script src="/public/media/js/adminlte.min.js"></script>
                    <script src="/public/media/js/bootstrap.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.5/js/bootstrap-select.min.js"></script>
                    <script src="/public/media/js/wow.min.js"></script>
                    <script src="/public/media/js/smooth-scrollbar.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
                    <script src="/public/media/js/theme-custom.js"></script>
                    <script src="/public/media/js/custom.js"></script>
                    <script> Scrollbar.initAll(); </script>
                </body>
            </html>
        );
    }
}


MainPage.propTypes = propTypes;


module.exports = MainPage;
