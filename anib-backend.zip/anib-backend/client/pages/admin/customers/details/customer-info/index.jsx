'use strict';
const Actions = require('./actions');
const Store = require('./store');
const Alert = require('../../../../../components/alert.jsx');
const CommonFunctions = require('../../../../../../client/helpers/common-functions');
const PropTypes = require('prop-types');
const DateHelper = require('../../../../../helpers/date-time');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const TextArea = require('../../../../../components/form/textarea-control');
const TextControl = require('../../../../../components/form/text-control.jsx');
const ReactSelectControl = require('../../../../../components/form/react-select-control');
const CommonHelper = require('../../../../../helpers/common-functions');

const propTypes = {
    customer_id: PropTypes.string,
    callback_fun: PropTypes.any,
    deal_id:PropTypes.string
};

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;

class CustomerDetailsForm extends React.Component {

    constructor(props) {

        super(props);
        (this.props.customer_id) ? Actions.getCustomerDetails(this.props.customer_id, true) : Actions.changeLoader();
        Actions.getUserTypes();
        Actions.getUsers();
        this.input = {};
        this.state = Store.getState();
        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);
        this.getNationalityOptions = this.getNationalityOptions.bind(this);
        this.updateDOB = this.updateDOB.bind(this);
        this.customerInfo = this.customerInfo.bind(this);
        this.checkMobileNumber = this.checkMobileNumber.bind(this);
        
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentDidUpdate(prevProps, prevState) {

        prevProps.customer_id !== this.props.customer_id ? Actions.getCustomerDetails(this.props.customer_id) : null;
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    submitCustomer(event, field_name) {
                
        event.preventDefault();
        event.stopPropagation();        

        let value = (this.input[field_name]) ? this.input[field_name].value() : undefined; 
        if (field_name === 'dob') {
            value = this.state.dob;
            value = value !== '' ? DateHelper._getDbFormat(value) : undefined 
        }
        
        const id = this.props.customer_id;
        const data = {
            'attribute_key': field_name,
            'attribute_value': value
        };        
        if (id) {
            value ? Actions.saveCustomerDetails(id, data) : null;
        } else if (this.props.deal_id) {
            Actions.saveDealCustomerDetails(this.props.deal_id,data);
        }
    }

    addEditable(field) {

        Actions.addEditable(field);
    }

    getUpdateButton(field) {

        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field) }} className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) }} className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        );
    }

    getLabelContent(name, field, value, type) {

        return (
            <div className="form-gp">
                <label className="side req">{name}</label>
                <div className="side-input">
                    { 
                        (value && value !== '') ? (
                            <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{ value }</a>
                        ) : (
                            <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable(field) }} >+Add</a>
                        )
                    }
                </div>
            </div>
        );
    }

    getNationalityOptions() {

        const nationalitys = this.state.nationality_data ? this.state.nationality_data : [];
        
        if (nationalitys.length === 0) { 
            return null;
        }
        return nationalitys.map((nationality, index) => {

            return <option key={`nationality-option-${index}`} value={nationality.nationality_key} data-tokens={`${nationality.nationality_name}`}> {`${nationality.nationality_name}`} </option>;
        });
    }

    getEmirateOptions() {

        const emirates = this.state.emirate_data ? this.state.emirate_data : [];
        
        if (emirates.length === 0) { 
            return null;
        }
        return emirates.map((emirate, index) => {

            return <option key={`emirate-option-${index}`} value={emirate.emirate_key} data-tokens={`${emirate.emirate_name}`}> {`${emirate.emirate_name}`} </option>;
        });
    }

    updateDOB(date) {

        Actions.updateDOB(date);
    }

    customerInfo() {
                        
        return {
            firstName: this.state.first_name,
            lastName: this.state.last_name,
            dateOfBirth: this.state.dob,
            nationality: this.state.nationality_id,
            emailAddress: this.state.email,
            mobileNo: this.state.mobile_number,
            gender: this.state.gender,
            poBox: this.state.po_box,
            emiratesID: this.state.emirate_id,
            adressLine1: this.state.address,
            adressLine2: this.state.address
        };
    }


    checkMobileNumber(e) {

        let inputValue = e.target.value;
        let mobileNumber  = inputValue.replace(/\D/g,'');
        e.target.value = mobileNumber.substring(0, 10);
    }
    
    render() {

        const alerts = [];
        

        if (this.state.error) {
            alerts.push(<Alert
                key="danger"
                type="danger"
                message={this.state.error}
            />);
        }

        const roleFormElements = this.state.user_roles ? this.state.user_roles.map((value, index) => {

            return (

                this.state.editable_field === value.column_name ? (
                    <ReactSelectControl
                        ref={(c) => (this.input[value.column_name] = c)}
                        key={ value.column_name }
                        name="value.label"
                        label={value.label}
                        onChange={() => {}}
                        hasError={this.state.hasError[value.column_name]}
                        help={this.state.help[value.column_name]}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        inputClasses={{'select-modal': true}}
                        appendElement={this.getUpdateButton(value.column_name)}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={ this.state[value.column_name] } 
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                        options={ CommonHelper.getOptionData(this.state.users,'user_key','username') }
                    />
                ) : this.getLabelContent(value.label, value.column_name, this.state[value.column_label], 'select')
            );
        }) : '';

        const formElementsCommon = <div>
            {
                this.state.editable_field === 'mobile_number' ? (
                    <TextControl
                        ref={(c) => (this.input.mobile_number = c)}
                        name="mobile_number"
                        label="Phone"
                        hasError={this.state.hasError.mobile_number}
                        help={this.state.help.mobile_number}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('mobile_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.mobile_number}
                        onChange={ (e) => this.checkMobileNumber(e) }
                    />
                ) : this.getLabelContent('Phone', 'mobile_number', this.state.mobile_number, 'text')
            }
            
            {
                this.state.editable_field === 'email' ? (
                    <TextControl
                        ref={(c) => (this.input.email = c)}
                        name="email"
                        label="Email"
                        hasError={this.state.hasError.email}
                        help={this.state.help.email}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('email')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.email}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Email', 'email', this.state.email, 'text')
            }
        </div>;
        const formElementsCorporate = <div>
            {
                this.state.editable_field === 'short_name' ? (
                    <TextControl
                        ref={(c) => (this.input.short_name = c)}
                        name="short_name"
                        label="Short Name"
                        hasError={this.state.hasError.short_name}
                        help={this.state.help.short_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('short_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.short_name}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Short Name', 'short_name', this.state.short_name, 'text')
            }
            
            {
                this.state.editable_field === 'vat_reg_no' ? (
                    <TextControl
                        ref={(c) => (this.input.vat_reg_no = c)}
                        name="vat_reg_no"
                        label="Vat Reg No"
                        hasError={this.state.hasError.vat_reg_no}
                        help={this.state.help.vat_reg_no}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('vat_reg_no')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.vat_reg_no}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Vat Reg No', 'vat_reg_no', this.state.vat_reg_no, 'text')
            }
            {
                this.state.editable_field === 'phone_number' ? (
                    <TextControl
                        ref={(c) => (this.input.phone_number = c)}
                        name="phone_number"
                        label="Phone Number"
                        hasError={this.state.hasError.phone_number}
                        help={this.state.help.phone_number}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('phone_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.phone_number}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Phone Number', 'phone_number', this.state.phone_number, 'text')
            }
            {
                this.state.editable_field === 'website' ? (
                    <TextControl
                        ref={(c) => (this.input.website = c)}
                        name="website"
                        label="Website"
                        hasError={this.state.hasError.website}
                        help={this.state.help.website}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('website')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.website}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Website', 'website', this.state.website, 'text')
            }
            {
                this.state.editable_field === 'fax' ? (
                    <TextControl
                        ref={(c) => (this.input.fax = c)}
                        name="fax"
                        label="Fax"
                        hasError={this.state.hasError.fax}
                        help={this.state.help.fax}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('fax')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.fax}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Fax', 'fax', this.state.fax, 'text')
            }
            {
                this.state.editable_field === 'ho_country' ? (
                    <TextControl
                        ref={(c) => (this.input.ho_country = c)}
                        name="ho_country"
                        label="HO Country"
                        hasError={this.state.hasError.ho_country}
                        help={this.state.help.ho_country}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('ho_country')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.ho_country}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('HO Country', 'ho_country', this.state.ho_country, 'text')
            }
            {
                this.state.editable_field === 'city' ? (
                    <TextControl
                        ref={(c) => (this.input.city = c)}
                        name="fax"
                        label="City"
                        hasError={this.state.hasError.city}
                        help={this.state.help.city}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('city')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.city}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('City', 'city', this.state.city, 'text')
            }
            {
                this.state.editable_field === 'country' ? (
                    <TextControl
                        ref={(c) => (this.input.country = c)}
                        name="country"
                        label="Country"
                        hasError={this.state.hasError.country}
                        help={this.state.help.country}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('country')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.country}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Country', 'country', this.state.country, 'text')
            }
            {
                this.state.editable_field === 'location' ? (
                    <TextControl
                        ref={(c) => (this.input.location = c)}
                        name="location"
                        label="Location"
                        hasError={this.state.hasError.location}
                        help={this.state.help.location}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('location')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.location}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Location', 'location', this.state.location, 'text')
            }
        </div>;
        
        const formElementsInduvidual = <div>
            {
                this.state.editable_field === 'arabic_first_name' ? (
                    <TextControl
                        ref={(c) => (this.input.arabic_first_name = c)}
                        name="arabic_first_name"
                        label="Arabic First Name"
                        hasError={this.state.hasError.arabic_first_name}
                        help={this.state.help.arabic_first_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('arabic_first_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.arabic_first_name}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Arabic First Name', 'arabic_first_name', this.state.arabic_first_name, 'text')
            }

            {
                this.state.editable_field === 'last_name' ? (
                    <TextControl
                        ref={(c) => (this.input.last_name = c)}
                        name="last_name"
                        label="Last Name"
                        hasError={this.state.hasError.last_name}
                        help={this.state.help.last_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('last_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.last_name}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Last Name', 'last_name', this.state.last_name, 'text')
            }
            {
                this.state.editable_field === 'arabic_last_name' ? (
                    <TextControl
                        ref={(c) => (this.input.arabic_last_name = c)}
                        name="arabic_last_name"
                        label="Arabic Last Name"
                        hasError={this.state.hasError.arabic_last_name}
                        help={this.state.help.arabic_last_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('arabic_last_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.arabic_last_name}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Arabic Last Name', 'arabic_last_name', this.state.arabic_last_name, 'text')
            }

            {
                this.state.editable_field === 'nationality_id' ? (
                    <SelectControl
                        ref={(c) => (this.input.nationality_id = c)}
                        name="nationality_id"
                        label="Nationality"
                        defaultValue={this.state.nationality_id}
                        hasError={this.state.hasError.nationality_id}
                        help={this.state.help.nationality_id}
                        disabled={this.state.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('nationality_id')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        { this.getNationalityOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Nationality', 'nationality_id', this.state.nationality_name, 'select')
            }

            {
                this.state.editable_field === 'gender' ? (
                    <SelectControl
                        ref={(c) => (this.input.gender = c)}
                        name="gender"
                        label="Gender"
                        defaultValue={this.state.gender}
                        hasError={this.state.hasError.gender}
                        help={this.state.help.gender}
                        disabled={this.state.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('gender')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        <option value={1}>Male</option>
                        <option value={2}>Female</option>
                    </SelectControl>
                ) : this.getLabelContent('Gender', 'gender', (this.state.gender == 1) ? 'Male' : 'Female' , 'select')
            }

            {
                this.state.editable_field === 'dob' ? (
                    <TextControl
                        ref={(c) => (this.input.dob = c)}
                        name="dob"
                        label="DOB"
                        hasError={this.state.hasError.dob}
                        help={this.state.help.dob}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('dob')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.dob !== undefined ? DateHelper._getDefaultFormat(this.state.dob) : ''}
                        onChange={(e) => { this.updateDOB(e)}}
                        isDatePicker={true}
                        maxDate={ new Date() }
                    />
                ) : this.getLabelContent('DOB', 'dob', this.state.dob, 'text')
            }
            {
                this.state.editable_field === 'address' ? (
                    <TextArea
                        ref={(c) => (this.input.address = c)}
                        name="address"
                        label="Address"
                        hasError={this.state.hasError.address}
                        help={this.state.help.address}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('address')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.address !== undefined ? this.state.address : ''}
                    />
                ) : this.getLabelContent('Address', 'address', this.state.address, 'textarea')
            }
            {
                this.state.editable_field === 'po_box' ? (
                    <TextControl
                        ref={(c) => (this.input.po_box = c)}
                        name="po_box"
                        label="PO Box"
                        hasError={this.state.hasError.po_box}
                        help={this.state.help.po_box}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('po_box')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.po_box !== undefined ? this.state.po_box : ''}
                    />
                ) : this.getLabelContent('PO Box', 'po_box', this.state.po_box, 'text')
            }
            {
                this.state.editable_field === 'emirate_id' ? (
                    <TextControl
                        ref={(c) => (this.input.emirate_id = c)}
                        name="emirate_id"
                        label="Emirate ID"
                        hasError={this.state.hasError.emirate_id}
                        help={this.state.help.emirate_id}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('emirate_id')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.emirate_id !== undefined ? this.state.emirate_id : ''}
                    />
                ) : this.getLabelContent('Emirate ID', 'emirate_id', this.state.emirate_id, 'text')
            }            
        </div>;        

        const customerLogo = <div> 
        {
            (this.state.customer_type === 1) ? 
                (this.state.editable_field === 'first_name' && this.state.name !== '') ? (
                    <TextControl
                        ref={(c) => (this.input.first_name = c)}
                        name="first_name"
                        hideLabel={true}
                        hasError={this.state.hasError.first_name}
                        help={this.state.help.first_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('first_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.first_name}
                        onChange={(e) => {}}
                    />
                ) : (
                    <h4 className="capitalize" onClick={(e) => { this.addEditable('first_name') }}> { this.state.first_name ? CommonFunctions.toTitleCase(this.state.first_name) : (
                        <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable('first_name') }} >+Add</a>
                    ) } </h4>
                ) : 
                (                    
                    (this.state.editable_field === 'company_name'  && this.state.company_name !== '') ? (
                        <TextControl
                            ref={(c) => (this.input.company_name = c)}
                            name="company_name"
                            hideLabel={true}
                            hasError={this.state.hasError.company_name}
                            help={this.state.help.company_name}
                            disabled={this.state.loading}
                            validation={true}
                            groupClasses={{'form-group': true, 'form-gp': true}}
                            labelClasses={{'control-label': false, 'side': true}}
                            inputClasses={{'form-control': true, 'add-forms': true}}
                            appendElement={this.getUpdateButton('company_name')}
                            appendElementNotString={true}
                            isKeyEnable={true}
                            defaultValue={this.state.company_name}
                            onChange={(e) => {}}
                        />
                    ) : (
                        <h4 className="capitalize" onClick={(e) => { this.addEditable('company_name') }}> 
                            { 
                                this.state.company_name ? CommonFunctions.toTitleCase(this.state.company_name) : (
                                    <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable('company_name') }} >+Add</a>
                                ) 
                            } 
                        </h4>
                    )
                )
        }
        </div>;

        return (
            
            <div className={ `white-box mt-25 ${this.state.hydrating ? 'loader-tab-content' : ''}` }>
                <Helmet>
                    <title>{ CommonFunctions.toTitleCase(name) }</title>
                </Helmet>
                <div className="customer-box">
                    <div className="icon capitalize">
                        { this.state.name !== ' ' ? CommonFunctions.toGetLetters(this.state.name, 2) : 'New' }
                    </div>
                        {                        
                            customerLogo                        
                        }
                        {
                            (this.props.viewCustomer && this.props.customer_id) ? <Link to={`/admin/customers/${this.props.customer_id}` } className="add-forms editable editable-click editable-empty"> View </Link> : ''
                        }
                    <span>Customer</span>
                </div>
                <form>
                    <fieldset>
                        {alerts}
                        {formElementsCommon}
                        {
                            (this.state.customer_type == 1) ? formElementsInduvidual : formElementsCorporate
                        }
                        {/* roleFormElements */}
                        {
                            /* this.state.editable_field === 'source' ? (
                                <TextControl
                                    ref={(c) => (this.input.source = c)}
                                    name="source"
                                    label="Source"
                                    hasError={this.state.hasError.source}
                                    help={this.state.help.source}
                                    disabled={this.state.loading}
                                    validation={true}
                                    groupClasses={{'form-group': true, 'form-gp': true}}
                                    labelClasses={{'control-label': false, 'side': true}}
                                    inputClasses={{'form-control': true, 'add-forms': true}}
                                    appendElement={this.getUpdateButton('source')}
                                    appendElementNotString={true}
                                    isKeyEnable={true}
                                    defaultValue={this.state.source !== undefined ? this.state.source : ''}
                                />
                            ) : this.getLabelContent('Source', 'source', this.state.source, 'text') */
                        }
                    </fieldset>
                </form>
            </div>
        );
    }
}

CustomerDetailsForm.propTypes = propTypes;


module.exports = CustomerDetailsForm;
