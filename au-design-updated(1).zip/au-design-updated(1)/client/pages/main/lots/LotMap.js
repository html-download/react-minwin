import React, {Component} from 'react';
import CircularProgressbar from 'react-circular-progressbar';
import { withScriptjs, withGoogleMap, GoogleMap, Marker, GroundOverlay, InfoWindow } from "react-google-maps";
import { compose, withStateHandlers, withHandlers } from "recompose";

const { MarkerWithLabel } = require("react-google-maps/lib/components/addons/MarkerWithLabel");
const { MarkerClusterer } = require("react-google-maps/lib/components/addons/MarkerClusterer");

import GeoLocation from 'react-geolocation';
const PropTypes = require('prop-types');
const Actions = require('./actions.js');
const ModalForm = require('./map-modal-form.jsx');
const LocationSearchInput = require('./auto-complete-form.jsx');
const Store = require('./store');
const UserIdentity = require('../../../helpers/user-identity');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();

const propTypes = {
    onNewClick:   PropTypes.func
};
//const MapComponent = withScriptjs(withGoogleMap( props => (
const MapComponent = compose(
  withStateHandlers((index) => ({
    isOpen: false,
    showInfo: '0',
    iconSize: new google.maps.Size(40, 43)
  }), {
    onToggleOpen: ({ isOpen }) => (index) => ({
      isOpen: !isOpen,
      index: 2
    }),
    showInfo: ({ showInfo, isOpen }) => (a, lat, lng) => ({
      isOpen: true,
      showInfoIndex: a,
      showInfoLat: lat,
      showInfoLng: lng
    })
  }),
  withScriptjs,
  withGoogleMap
)(props =>
        <GoogleMap
            ref={props.onMapMounted}
            defaultCenter={props.defaultCenter}
            defaultZoom={props.defaultZoom}
            defaultMapTypeId={ google.maps.MapTypeId.SATELLITE }
            defaultTilt={0}
            center={props.center}
            zoom={props.zoom}
            options={{draggable:true}}
            onBoundsChanged={props.onBoundsChanged}
            defaultOptions={{
                scrollwheel: false,
                disableDefaultUI: false,
                zoomControl: true,
                draggable: false
            }}
        >
            
            {props.markers.map( marker => {
                let lat = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.lot_id &&  props.showInfoLat !== undefined) ? props.showInfoLat : marker.lat;
                let lng = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.lot_id &&  props.showInfoLng !== undefined) ? props.showInfoLng : marker.lng;
                return (
                    <Marker
                        key={marker.lot_id}
                        position={{'lat': lat, 'lng': lng}}
                        defaultAnimation={(marker.is_user) ? google.maps.Animation.BOUNCE : true}
                        icon={{ url : `/public/media/images/icons/${marker.icon}`/*, scaledSize : props.iconSize*/}}
                        defaultLabel={(marker.is_user) ? '' : (marker.status) ? `${marker.percentage}%` : ''}
                        labelStyle={{paddingBottom: '20px'}}
                        draggable={false} 
                        onClick={() => { props.showInfo(marker.lot_id, marker.lat, marker.lng) }}
                        //onDragEnd={(event) => { props.showInfo(marker.lot_id, event.latLng.lat(), event.latLng.lng());}}
                    >
                        { props.isOpen && props.showInfoIndex === marker.lot_id && 
                            <InfoWindow id="info{props.showInfoIndex}">
                                <div>
                                    <ul className="reset lot_map">
                                        <img src={ `/public/media/images/thumnail/auburn/${marker.lot_name}.png`} alt=""/>
                                        <li onClick={((e) => props.onNewClick(e, marker.lot_name, marker.entrance_coords, marker.title, marker.percentage, marker.color, marker.status))}>
                                            <p className="lname">{(marker.is_user) ? marker.title : marker.title}</p>
                                            {(marker.is_user) ? '' : (
                                                <p className="lat_long">
                                                    { marker.distance_from_location !== undefined ? (
                                                     <label> {parseFloat(marker.distance_from_location).toFixed(2)} miles away</label>
                                                     ) : '' }
                                                    {
                                                        (!marker.is_user) ? (
                                                            <a className='' id={marker.lot_name} ><i className="fa fa-angle-right" aria-hidden="true"></i></a>
                                                        ) : '' 
                                                    }
                                                </p>
                                            )}
                                        </li>
                                        
                                    </ul>
                                </div>
                            </InfoWindow>
                        }
                    </Marker>
                )
            })}
            <GeoLocation />
        </GoogleMap>
);

class LotMap extends Component {
    constructor(props) {
        super(props);
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.els = {};
    }
    render(){
        return (
            <div>
                <MapComponent
                    googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${UserIdentity.googleApiKey}&libraries=places`}
                    loadingElement={<div style={{ height: `100%`}} />}
                    containerElement={<div id="map_view"/>}
                    mapElement={<div style={{ height: `100%` }} />}
                    defaultCenter={{
                        'lat': 32.6063355,
                        'lng': -85.4905577
                    }}
                    defaultZoom={17}
                    center={this.props.center}
                    zoom={this.props.zoom}
                    markers={this.props.markers}
                    draggable={false} 
                    onNewClick={this.props.onNewClick}
                >
                </MapComponent>
                <ModalForm 
                    selected={this.props.selected}
                    selectedLatLng={this.props.selectedLatLng}
                    show={this.props.show}
                    onHide={this.props.onHide}
                    title={this.props.title}
                    percentage={this.props.percentage}
                    color={this.props.color}
                    lot_status={this.props.lot_status}
                    {...this.props.createNew}
                />
                <div className="box-view box6">
                    <a onClick={this.props.currentAddressGet} className="text-center"> 
                        <img src={`/public/media/images/icons/current_loc.png`} alt="Current Location" /> 
                    </a>
                </div>  
            </div>
        )
    }
}

//LotMap.propTypes = propTypes;

export default LotMap;