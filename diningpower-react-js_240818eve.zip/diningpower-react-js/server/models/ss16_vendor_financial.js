/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorFinancial', {
    financialId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'financial_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    billingArea: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'billing_area'
    },
    billingStoreNumber: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'billing_store_number'
    },
    billingLine1: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'billing_line1'
    },
    billingLine2: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'billing_line2'
    },
    billingAddress: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'billing_address'
    },
    billingSuite: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_suite'
    },
    billingCity: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_city'
    },
    billingState: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_state'
    },
    billingZip: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'billing_zip'
    },
    billingPhone: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_phone'
    },
    billingPaymentName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'billing_payment_name'
    },
    paymentMethod: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '1',
      field: 'payment_method'
    },
    achBankAccount: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'ach_bank_account'
    },
    achRouting: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'ach_routing'
    },
    achBankName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'ach_bank_name'
    },
    achImagePath: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'ach_image_path'
    },
    paymentCycle: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'payment_cycle'
    },
    paymentCycleStart: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'payment_cycle_start'
    },
    restaurantType: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'restaurant_type'
    },
    billingNotes: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'billing_notes'
    },
    pos: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'pos'
    },
    showRestaurant: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'show_restaurant'
    },
    apiAccess: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'api_access'
    },
    restaurantAccount: {
      type: DataTypes.INTEGER(6).UNSIGNED.ZEROFILL,
      allowNull: false,
      field: 'restaurant_account'
    },
    salesTax: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      defaultValue: '0.000',
      field: 'sales_tax'
    },
    mealsTax: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'meals_tax'
    },
    otherTax: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'other_tax'
    },
    salesTaxCalculation: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'sales_tax_calculation'
    },
    mealsTaxCalculation: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'meals_tax_calculation'
    },
    otherTaxCalculation: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'other_tax_calculation'
    },
    salesTaxRate: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'sales_tax_rate'
    },
    mealsTaxRate: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'meals_tax_rate'
    },
    otherTaxRate: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'other_tax_rate'
    },
    delDpCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_dp_commission'
    },
    delDpCalculateOnTax: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_dp_calculate_on_tax'
    },
    salesTaxCommission: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'sales_tax_commission'
    },
    delDpAllowCash: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'del_dp_allow_cash'
    },
    delDpCashCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_dp_cash_commission'
    },
    delDpCashMinOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'del_dp_cash_min_order'
    },
    delDpCardCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_dp_card_commission'
    },
    delDpCardCommissionOnTax: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_dp_card_commission_on_tax'
    },
    delDpTaxrate: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_dp_taxrate'
    },
    delDpCommissionnotes: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'del_dp_commissionnotes'
    },
    delDpCommissionCalcPrice: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '1',
      field: 'del_dp_commission_calc_price'
    },
    delDpShowPrice: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '1',
      field: 'del_dp_show_price'
    },
    delRCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_r_commission'
    },
    delRCalculateOnTax: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_r_calculate_on_tax'
    },
    mealsTaxCommission: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'meals_tax_commission'
    },
    delRAllowCash: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'del_r_allow_cash'
    },
    delRCashCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_r_cash_commission'
    },
    delRCashMinOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'del_r_cash_min_order'
    },
    delRCardCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_r_card_commission'
    },
    delRCardCommissionOnTax: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_r_card_commission_on_tax'
    },
    delRTaxrate: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_r_taxrate'
    },
    delRCommissionnotes: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'del_r_commissionnotes'
    },
    delRCommissionCalcPrice: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'del_r_commission_calc_price'
    },
    delRShowPrice: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'del_r_show_price'
    },
    delPCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_p_commission'
    },
    delPCalculateOnTax: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_p_calculate_on_tax'
    },
    otherTaxCommission: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'other_tax_commission'
    },
    delPAllowCash: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'del_p_allow_cash'
    },
    delPCashCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_p_cash_commission'
    },
    delPCashMinOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'del_p_cash_min_order'
    },
    delPCardCommission: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'del_p_card_commission'
    },
    delPCardCommissionOnTax: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_p_card_commission_on_tax'
    },
    delPTaxrate: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'del_p_taxrate'
    },
    delPCommissionnotes: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'del_p_commissionnotes'
    },
    delPCommissionCalcPrice: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'del_p_commission_calc_price'
    },
    delPShowPrice: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'del_p_show_price'
    },
    mailStatement1: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'mail_statement1'
    },
    mailStatement2: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'yes',
      field: 'mail_statement2'
    }
  }, {
    tableName: 'ss16_vendor_financial'
  });
};
