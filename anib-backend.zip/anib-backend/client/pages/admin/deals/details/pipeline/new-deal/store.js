'use strict';
const Constant =  require('./constants');
const ObjectAssign = require('object-assign');
const Redux = require('redux');
const ParseValidation = require('../../../../../../helpers/parse-validation');
const Async = require('async');

const initialState = {
    loading: false,
    list_loading: false,
    product_hydrated: true,
    success: false,
    error: undefined,
    hasError: {},
    help: {},    
    is_deal_collapsed : false,
    is_quote_create_collapsed : false,
    is_modal_active : false,
    is_policy_modal_active:false,
    quote_data: [],
    is_empty: true,
    is_create: false,
    product_data: [],
    product_data_loading: true,
    policy_plans:[],
    selected_plans:[],
    deal_quote_request_key: undefined,
    insurence_product_image:'',
};

let validation;
let result;

/* is_quote_create_collapsed */

const reducer = function (state = initialState, request) {

    switch (request.type) {

        case Constant.GET_PRODUCT_DETAILS:
            return ObjectAssign({}, state, {
                product_data : []
            });
            break;

        case Constant.GET_PRODUCT_DETAILS_RESPONSE:
                                    
            return ObjectAssign({}, state, {
                product_data: (request.response && request.response.data) ? request.response.data : [],
                product_data_loading: false
            });

            break;

        case Constant.GET_UNDERWRITER_TRIM_RESPONSE:
                                  
            let data = (request.response && request.response.data) ? request.response.data : [];

            let underwriters = state.product_data;
            /* underwriters.forEach(function(underwriter, i){
                if(underwriter.underwriter_key === request.request_data.underwriter_key) {
                    underwriters[i]['vehicle_brand_trim'] = data;
                }
            }); */

            Async.forEachOf(underwriters, (underwriter, index, callback) => {
                if(underwriter.underwriter_key === request.request_data.underwriter_key) {
                    underwriters[index]['vehicle_brand_trim'] = data;
                }
            });  

            return ObjectAssign({}, state, {
                product_data: underwriters
            });

                break;
        case Constant.GET_DEAL_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                list_loading : true
            });
            break;

        case Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                list_loading: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                quote_data: result,
                is_empty: result.length > 0 ? false : true,
                product_hydrated: true,
                is_modal_active: false,
            });
            break;

        case Constant.SAVE_QUOTE_DETAILS:
            return ObjectAssign({}, state, {
                loading : true
            });
            break;

        case Constant.SAVE_QUOTE_DETAILS_RESPONSE:
            
            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                loading: false,
                is_quote_create_collapsed: request.response.status === 200 ? false : true,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                is_create: (request.response.status === 200) ? false : true
            });

            break;        

        case Constant.TOGGLE_DEAL:
            
            return ObjectAssign({}, state, {
                is_deal_collapsed : (state.is_deal_collapsed) ? false : true,
                is_quote_create_collapsed : false
            });
            break;

        case Constant.TOGGLE_QUOTE:
            return ObjectAssign({}, state, {
                is_quote_create_collapsed : (state.is_quote_create_collapsed) ? false : true,                
                is_deal_collapsed : false
            });
            break;
        
        case Constant.OPEN_QUOTE_MODAL:
        
            return ObjectAssign({}, state, {
                is_modal_active : true
            });
            break;
        case Constant.HIDE_QUOTE_MODAL:
        
            return ObjectAssign({}, state, {
                is_modal_active : false
            });
            break;

        case Constant.TOGGLE_CREATE:
            return ObjectAssign({}, state, {
                is_create: true
            });
            break;
        case Constant.OPEN_POLICY_MODAL:
            return ObjectAssign({}, state, {
                is_policy_modal_active: true
            });
            break;
        case Constant.CLOSE_POLICY_MODAL:
            return ObjectAssign({}, state, {
                policy_plans:[],
                is_policy_modal_active: false
            });
            break;
        case Constant.OPEN_POLICY_LIST:
        
            return ObjectAssign({}, state, {
                is_policy_modal_active : false,
                deal_quote_request_key: undefined
            });
            break;
        case Constant.OPEN_POLICY_LIST_RESPONSE:
                                                        
            return ObjectAssign({}, state, {
                policy_plans: (request.response.data && request.response.data.plans && request.response.data.plans.plans && request.response.data.plans.plans.length > 0 ) ? request.response.data.plans.plans : [],
                selected_plans: (request.response.data && request.response.data.selected_plan && request.response.data.selected_plan.length > 0 ) ? request.response.data.selected_plan : [],
                deal_quote_request_key: request.response.data.deal_quote_request_key,
                is_policy_modal_active : true,
                insurence_product_image: (request.response.data && request.response.data.insurence_product_image) ? request.response.data.insurence_product_image : ''
            });            
            break;
        case Constant.CHANGE_POLICY_RESULT:
                                            
            return ObjectAssign({}, state, {
                is_policy_modal_active : false,
                policy_plans: [],                
                deal_quote_request_key: undefined
            });
            break;
        case Constant.CHANGE_POLICY_RESULT_RESPONSE:
                                            
            return ObjectAssign({}, state, {
                is_policy_modal_active : false,
                policy_plans: [],
                deal_quote_request_key: undefined
            });
            break;

        case Constant.ADD_POLICY:
                                            
            return ObjectAssign({}, state, {
                plans : request.value
            });
            break;
        case Constant.CHECK_INSURENCE_STATUS:
        
            return ObjectAssign({}, state, {
                loading: false,
                success: undefined,
                error: undefined,
                hasError: undefined,
                help: undefined
            });
            break;

        case Constant.CHECK_INSURENCE_STATUS_RESPONSE:

            validation = ParseValidation(request.response);

            result = (request.response && request.response.data) ? request.response.data : [];
            
            return ObjectAssign({}, state, {
                loading: false,
                success: !request.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                is_create: true
            });
            break;
        default:
            return ObjectAssign({}, state);
            break;
    }           
};
module.exports = Redux.createStore(reducer);


