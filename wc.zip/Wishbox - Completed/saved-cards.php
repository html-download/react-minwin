<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- acc page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi credit-card1"></i>
            <h2>Saved Cards</h2>
            <p>Manage your Debit / Credit cards</p>
          </div>
          <div class="white-30">
            <div class="saved-cards">
              <div class="cs-row">
                <ul class="full">
                  <li>
                    <div class="box-card add-new-address">
                      <a href="" class="d-tables">
                      <span class="d-table-cell">
                      <i class="fi plus-circle2"></i>
                      Add New Card
                      </span>
                      </a>
                    </div>
                  </li>
                  <li>
                    <div class="box-card">
                      <span class="title">card number</span>
                      <span class="answer">****   ****   ****   ****  4563</span>
                      <span class="title">valid through</span>
                      <span class="answer">10/25</span>
                      <img src="assets/img/visa.png" class="img-card-type">
                      <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                    </div>
                  </li>
                  <li>
                    <div class="box-card">
                      <span class="title">card number</span>
                      <span class="answer">****   ****   ****   ****  4563</span>
                      <span class="title">valid through</span>
                      <span class="answer">10/25</span>
                      <img src="assets/img/ms-card.png" class="img-card-type">
                      <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                    </div>
                  </li>
                  <li>
                    <div class="box-card">
                      <span class="title">card number</span>
                      <span class="answer">****   ****   ****   ****  4563</span>
                      <span class="title">valid through</span>
                      <span class="answer">10/25</span>
                      <img src="assets/img/visa.png" class="img-card-type">
                      <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                    </div>
                  </li>
                  <li>
                    <div class="box-card">
                      <span class="title">card number</span>
                      <span class="answer">****   ****   ****   ****  4563</span>
                      <span class="title">valid through</span>
                      <span class="answer">10/25</span>
                      <img src="assets/img/ms-card.png" class="img-card-type">
                      <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<!-- alert modal -->
<div id="remove_modal" class="modal alert_modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <h3>Remove</h3>
      <p>Do you want remove this?</p>
      <div class="buttons-flex">
        <button class="btns" data-dismiss="modal">No</button> <button class="btns">Yes</button>
      </div>
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!-- alert modal -->
<?php include ('inc/footer.php'); ?>