<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/angular-logo.png" alt="AngularJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Top Rated <br>Android App Development Company</h1>
      <p class="desc animated fadeInUp mb30">Re-usable code compact Android app development from professional developers who handle the tools and technologies as per current trend</p>
      <a href="<?php echo $baseurl;?>contactus" class="btn green animated fadeInUp">Get a free quote</a>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="half green">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right white">
        <h2 class="head style1 line white">Android app development</h2>
        <h3 class="head_desc">Fabricating Modern Applications With Simple Technology</h3>
        <p>Technoduce is one of the notable Android application development company which has been utilizing contemporary technologies for developing world-class applications according to industry standards. Our innovative applications have dynamic and intuitive user interfaces which make them preferable to the end users. We design and develop applications as per individual needs and requirements such that it reaches the maximum audience, thus delivering satisfaction to all sides.</p>
        <p class="mb0">We are the creators of most wonderful apps in Android platform that has been satisfying the clients. Wide range of services are provided by us which gives variety for the customers to choose. All our Android application development services are quality-consistent and cost-effective. Technoduce takes pride in creating wonderful apps in the Android platform, which have been complemented by several of our clients from across the globe. Wide range of services are provided by us which gives variety for the customers to choose. All our Android application development services are quality-consistent and cost-effective.</p>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="dark">
	<div class="container white">
    <div class="row">
      <div class="col_6 pl30 pull_right diagram">
        <amp-img src="https://192.168.1.149:444/images/angular-development.png" alt="AngularJS Development" width="460" height="450" layout="responsive"></amp-img>
      </div>

      <div class="col_6 pr30">
        <h2 class="head style1 line">Android app developement tools & technologies</h2>
        <p class="head_desc mb20">Technoduce uses the best methods to deliver highly productive Android applications. Here are some of the technological tools that we use:</p>        
        <ul class="lists mb0">
          <li>Language- Java</li>
          <li>Android Versions - 4.0 to 6.0 (Marshmallow)</li>
          <li>Tools - Android Studio</li>
          <li>Databases - SQLite, Realm, GreenDao</li>
          <li>API - REST API(Node.JS, PHP )</li>
          <li>OS - Windows Family , Ubuntu</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="grey">
	<div class="container">
    <h2 class="head style1 line">Our Android app services include</h2>
    <ul class="features style1 col4 reset">
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Android application development</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Android games development</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Third party application integration</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Business applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Communication applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Travel applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Banking applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Sports applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Shopping applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Support and maintenance services</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Android social networking applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Location based services</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Porting and migration to other platforms</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Entertainment applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Utility and productivity applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Multimedia applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Education applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Healthcare applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Web applications</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span></span>
        </div>
      </li>
    </ul>
  </div> <!--container-->
</section>

<section class="dark">
  <div class="container text-center white">
    <h2 class="head style1">Our mobile app development process flow</h2>
    <p class="md mb40">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit vulputate urna sit amet, consectetur adipiscing elit.</p>
    <amp-img src="https://www.technoduce.com/images/site/inner_flow.png" alt="AngularJS Development" width="917" height="313" style="max-width:917px; margin:0 auto" layout="responsive"></amp-img>
  </div> <!--container-->
</section>

<section>
	<div class="container">
    <div class="row">
      <div class="col_6 pl30 pull_right diagram">
        <amp-img src="https://192.168.1.149:444/images/angular-development.png" alt="AngularJS Development" width="460" height="450" layout="responsive"></amp-img>
      </div>

      <div class="col_6 pr30">
        <h2 class="head style1 line">Our strength?</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit sit amet, consectetur adipiscing elit.</p>
        <ul class="lists mb0">
          <li>We have a team of highly qualified professionals who are well versed in developing applications in Android platform. Our applications meet the industry standard strictly adhering to quality.</li>          
          <li>We have expertise in code re-usability</li>
          <li>We provide an array of service in Android platform which includes games development, social networking applications, communication apps and much more.</li>
          <li>You can rely on us to develop customized application as per your choice and need.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="half green">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right white">
        <h2 class="head style1 line white">Field experience</h2>
        <p class="mb30">We have been in the industry since 2011 and have earned reputable customers with our customized service. Our professionals have leading 6+ years experience in Android development. Our projects have impressed our clients who have endorsed us for clarity and consistency.</p>

        <h2 class="head style1 line white">Customization</h2>
        <p>We provide customization services for developing Android apps that suits your need. You can have custom about page, splash screen, logo, background color/image, buttons and much more</p>
      </div>
    </div>
  </div> <!--container-->
</section>

<section>
	<div class="container md text-center">
    <h2 class="head style1">Hire Android app developers</h2> 
    <p class="mb20">You can build your projects comfortably and cost-effectively by hiring our Android developers. We have skilled Android developers with varied experience ranging between 2 to 6+ years who can be useful for your project development. Hire Android developers based on hourly, weekly, monthly, or on flat rate basis. We follow a single point contact with effective communication and good turn around time. Hire us to develop your projects within your budget.</p>
    <a href="<?php echo $baseurl;?>contactus" class="btn green">Hire our Android developer</a>
  </div> <!--container-->
</section>

<section class="section grey text-center portfolio">
	<div class="container">
		<h2 class="head style1">Android app development portfolios</h2>
		<p class="md mb40">Our past projects speak a lot about the Company's commitment to maintaining quality in developing innovative Android applications. <br>Check out a couple of them here:</p>
		<div class="row">
			<div class="col_3">
				<a href="https://192.168.1.149:444//portfolio/caterninja.html" target="_blank">
					<amp-img src="https://192.168.1.149:444/images/food-dashboard.png" alt="food dashboard" width="987" height="410" layout="responsive"></amp-img>
				</a>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<?php include ('inc/footer.php'); ?>