'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'GET_ROLES',
    'GET_ROLES_RESPONSE'
]);
