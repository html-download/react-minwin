//Fixed Header
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".site_header").addClass("fixed");
    } else {
        $(".site_header").removeClass("fixed");
    }		
});

//Animation
new WOW().init();

//Placeholder
$(window).load(function(){
	if(!Modernizr.input.placeholder){
		$('[placeholder]').focus(function() {
		  var input = $(this);
		  if (input.val() == input.attr('placeholder')) {
			input.val('');
			input.removeClass('placeholder');
		  }
		}).blur(function() {
		  var input = $(this);
		  if (input.val() == '' || input.val() == input.attr('placeholder')) {
			input.addClass('placeholder');
			input.val(input.attr('placeholder'));
		  }
		}).blur();
		$('[placeholder]').parents('form').submit(function() {
		  $(this).find('[placeholder]').each(function() {
			var input = $(this);
			if (input.val() == input.attr('placeholder')) {
			  input.val('');
			}
		  })
		});
	}
});

//carousel
$(document).ready(function() {
  $("#logos").owlCarousel({
    loop: true,
	items: 5,
	dots:false,
	nav:false,
	responsiveClass:true,
	responsive:{
		240:{ items:1 },
        641:{ items:3 },
        900:{ items:5 }
    }
  }); 
  $("#testimonial").owlCarousel({
    loop: true,
	items: 1,
	dots:false,
	nav:false
  });
});

//Header Menu
window.onload=function(){
// Cache selectors
var lastId,
    topMenu = $("#site_menu"),
    topMenuHeight = topMenu.outerHeight()+80,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function(){
      var item = $($(this).attr("href"));
      if (item.length) { return item; }
    });

// Bind click handler to menu items
// so we can get a fancy scroll animation
menuItems.click(function(e){
  var href = $(this).attr("href"),
      offsetTop = href === "#" ? 1 : $(href).offset().top-topMenuHeight+1;
  $('html, body').stop().animate({ 
      scrollTop: offsetTop
  }, 300);
  e.preventDefault();
});

// Bind to scroll
$(window).scroll(function(){
   // Get container scroll position
   var fromTop = $(this).scrollTop()+topMenuHeight;
   
   // Get id of current scroll item
   var cur = scrollItems.map(function(){
     if ($(this).offset().top < fromTop)
       return this;
   });
   // Get the id of the current element
   cur = cur[cur.length-1];
   var id = cur && cur.length ? cur[0].id : "";
   
   if (lastId !== id) {
       lastId = id;
       // Set/remove active class
       menuItems
         .parent().removeClass("active")
         .end().filter("[href='#"+id+"']").parent().addClass("active");
   }                   
});
}

//Mobile filter
$("#mobile_nav").on('click', function(event) {
	$("body").addClass('menu_open');
});
$("#menu_close, .site_menu li a").on('click', function(event) {
	$("body").removeClass('menu_open');
});