/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Meals', {
    mealId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'meal_id'
    },
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'menu_id'
    },
    itemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_id'
    },
    mealName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: '',
      field: 'meal_name'
    },
    mealPeriodType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'meal_period_type'
    },
    mealDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'meal_description'
    },
    sort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort'
    },
    fromDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'from_date'
    },
    toDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'to_date'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    },
    availabilityStatus: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'availability_status'
    }
  }, {
    tableName: 'ss16_meals'
  });
};
