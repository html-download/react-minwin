<?php include ('inc/header.php'); ?>

<div class="cms_page full_row">
	<div class="page_banner">
		<div class="container">
			<h1 class="head wow fadeInUp">Terms & Conditions</h1>
		</div> <!--container-->
	</div> <!--page_banner-->
	
	<div class="container">
		<div class="cms_content">
			<p><b>Ontabee </b>(hereinafter referred to as <b>"Company"</b>, <b>"We"</b>, <b>"Us"</b>, or <b>"Our"</b>) owns and maintains the website, <a href="/" target="_blank">www.ontabee.com</a>, (“Website”). The Company provides Online restaurant ordering services through the Website wherein the Company provides a secure platform offering database storage, compute power, content delivery and other functionality to various Subscribers (as defined below) (<b>“Products”</b>).</p>

			<p>By using the Website or the Products, you (<b>“User,” “You,” or “Your”, “Yourself”</b> which shall mean and include, where the context so requires, its successors, permitted assigns, legal heirs, and representatives) are agreeing to be bound by the following terms and conditions (<b>“Terms of Use”</b>). In the event You do not agree to accept and abide by the Terms of Use, please do not access or use this Website or any pages thereof and please do not avail of any of the Products offered on or through the Website.</p>

			<p>Please note that by clicking on the <b>“ACCEPT”</b> icon and using the Website, it will be deemed that You have read and understood the Terms of Use and that You agree to accept and abide by such Terms of Use.</p>

			<p>The Company may make changes, without prior notification, to the Terms of Use from time to time at the Company’s sole discretion, including, augmenting or enhancing the Products, releasing new tools or imposing additional charges for access to or use of the Product. The revised Terms of Use shall be made available on the Website. You are requested to regularly visit the Website to view the most current Terms of Use. The Website may require You to provide Your consent to the updated Terms of Use in a specified manner before any further use of the Website and/or the Products is permitted. If no such separate consent is sought, Your continued use of the Website or the Product, following changes to the Terms of Use, will constitute Your acceptance of those changes. If You do not agree to the modified Terms of Use, Your only recourse would be to cease using the Website and the Products.</p>


			<h3>1) Registration and Account Information</h3>

			<p>1.1. The Products shall be available to the Subscribers through a registration process, whereby You will be required to furnish certain information and details, including Your name, e-mail address and any other information deemed necessary (<b>“Account Information”</b>). Based on the information provided by You, an account (<b>“Account”</b>) with the Website would be created for Your use of the Website and Products. For the purposes of these Terms of Use “Subscriber” shall mean to include an individual, company, sole proprietorship, partnership or such other entity organized as per the laws of the territory where it is situated that is registered on the Website and has purchased the Products from the Company.</p>

			<p>1.2. You will receive a password for Your Account upon completing the Website's registration process. You are responsible for maintaining the confidentiality of the password and Account and are fully responsible for all activities that occur under Your password or Account. You agree to (a) immediately notify the Website of any unauthorized use of Your password or Account or any other breach of security, and (b) ensure that You exit from Your Account at the end of each session. The Website shall not be liable for any loss or damage of information arising from Your failure to comply with the maintenance of Your Account or password. You may be held liable for losses incurred by the Company due to an authorized or unauthorized use of Your Account Information or password as a result of Your failure in keeping Your Account Information secure and confidential.</p>


			<p>1.3. You expressly agree that Your Account Information will be complete, accurate and up-to-date.</p>

			<p>1.4. The Company may at any given point of time require that You change Your Account Information or certain parts of Your Account Information at any time without assigning any reasons.</p>

			<p>1.5. In consideration of Your use of the Products, You represent that You are eligible in accordance with the applicable laws to enter into a binding contract and are not a person barred from receiving services under the laws as applicable in India. You also agree to provide true, accurate, current and complete information about Yourself as prompted by the Website's registration form. If You provide any information that is untrue, inaccurate, not current or incomplete (or becomes untrue, inaccurate, not current or incomplete), or the Company has reasonable grounds to suspect that such information is untrue, inaccurate, not current or incomplete, the Company has the right to suspend or terminate Your account and refuse any and all current or future use of the Website or the Products (or any portion thereof).</p>

			<p>1.6. Upon completion of the registration process and obtaining an Account with the Website, You agree that the understanding provided herein between You and the Company constitutes a binding agreement between the parties.</p>

			<p>1.7. On completion of the registration, the Company shall customize the dashboard provided to You to reflect Your branding as provided by You to the Company. Accordingly, You hereby provide a limited, royalty-free license to the Company to use your trademark, logo, and design to customize Your Account.</p>


			<h3>2) Subscription</h3>

			<p>If You wish to use the Products, You will be required to subscribe to the same upon payment of such Subscription Fee (<b>“Subscription”</b>). Based on the term during which the Products are required by You, you will be required to pay a fee notified to you during the time of Your registration (<b>“Subscription Fee”</b>).</p>

			<p>Based on the category of Subscription and the term of the proposed subscription, You will be required to make online payments through Your credit card or debit card or net banking account or cash card or via any other mode made available for making payments through mediums as authorized in Your territory and as provided by the Company for availing the Products. The facility for online payments through credit cards or debit cards or net banking account or cash card or any other mode is available for selected credit cards, debit cards, net banking accounts and cash cards only. If You wish to avail the Products after the expiry of the initial term of Subscription, You shall, prior to the expiry of such term, recharge of Your account with the then prevailing subscription fees.</p>


			<p>You must use the credit card and/or debit card and/or net banking account and/or cash card that You are authorized to use (<b>“PaymentCard”</b>). You confirm and acknowledge that You are aware of the fact that when making any online payment through Your Payment Card, You may be directed to the payment gateway page. The payment gateway may redirect You to another website(s) maintained or controlled by third parties, and the Company does not control such third party website(s) and hence is not responsible for any transactions on such website(s). The Company will not be liable for any fraud on or in relation to Your Payment Card, and the Company will not entertain or address any such grievances or issues. You are requested to communicate all grievances related to such issues to Your bank who has issued such Payment Card. The Company shall not be responsible for any dispute or difference relating to the online payment made by You through your Payment Card or any other mode available. Further, the Company will not be responsible for any financial loss, inconvenience or mental agony resulting from misuse of Your Payment Card or associated details. </p>


			<p>Payments once made by Payment Card or via any other mode available shall not be refunded under any circumstances. You are hereby advised to keep details of Your Payment Card details confidential and do not share any such details with any other third party.</p>

			<p>You are responsible for ensuring that the Payment Card associated with Your Subscription is up to date, that the information posted in connection with it is accurate. If the Company cannot charge Your Payment Card, we may cancel Your Subscription and You may lose access to the Product and any data associated with Your Subscription.</p>

			<p>Prior to the subscription to the Product, You hereby represent that You have availed the Product for a trial period and You are aware of the functionalities of the Product. Subsequent to subscription, the Company shall not be liable for any claims with respect to Product not being in compliance with the specific requirement of the User.</p>

			<p>Prices of current Services are subjected to change.  But the changed pricing will not affect the pricing plan of existing users of our product.</p>

			<p>If your bandwidth usage exceeds 500 MB/month or significantly exceeds the average bandwidth usage (as determined solely by Ontabee) of other Ontabee customers, we reserve the right to immediately hold your account or throttle your file hosting until you can reduce your bandwidth consumption.</p>


			<h3>3) Prohibited Use</h3>

			<p>The Products may be used only for lawful purposes. You are prohibited from using any robot, spider or any other data mining technology or automatic or manual process to monitor, cache, extract data from, copy or distribute the intellectual property, proprietary material or other user content on the cloud infrastructure of the Company.</p>


			<h3>4) Personal Information</h3>

			<p>Personal information You provide to the Company for the Subscription and use of the Products is governed by the Company’s Privacy Policy located at <a href="/privacy-policy" target="_blank">https://www.ontabee.com/privacy-policy</a> Your election to use the Products indicates Your acceptance of the terms of the Company’s Privacy Policy.</p>

			<h3>5) Intellectual Property Rights</h3>


			<p>You acknowledge that the Company owns all right, title and interest in and to the Products, including without limitation all intellectual property rights including, with respect to the applications associated with the Products (“CompanyProprietaryRights”). Further, it is hereby clarified that You shall not be provided any access to the source code of the Product and accordingly, You will not be permitted to copy, reproduce, alter, modify, or create derivative works of the Product. You also agree that You will not use any robot, spider, another automated device to monitor or copy any content from the Product.</p>

			<p>The Company is the sole owner of the Company marks, service marks, trade name and any other marks used by the Company (except the trademarks and logos owned by the Subscriber) (collectively “Trademarks”). You agree not to interfere with Our rights in the Trademarks, including challenging Our use, registration or application to register the Trademarks, anywhere in the world, and that You will not harm, misuse, or bring into disrepute any of the Trademarks. The goodwill derived from using the Trademarks or any part thereof shall inure exclusively to the benefit of the Company.</p>


			<p>All Trademarks, domain name, trade dress including the look, feel and design of the Product, interfaces, etc., and the selection and arrangements thereof is the property of the Company unless otherwise indicated. All this is protected by copyright, trademark and other applicable intellectual property laws and may not be used by You, except as permitted by the Company.</p>


			<p>The Product is operated by and is the sole property of the Company. The Product is protected by copyrights, trademarks, and other intellectual property rights that are owned by the Company or by other parties that have licensed such material to the Company. Modification of the Product and other materials or use of the Product or other materials for any purpose other than for the purpose as agreed to between the parties is a violation of the said patents, copyrights, trademarks and other intellectual proprietary rights, and is expressly prohibited.</p>


			<h3>6) Warranties And Limitations</h3>

			<p>You understand and acknowledge that the Product is provided to You by the Company on an “as is” and “as available basis”. Your use of the Product shall be at Your own risk. The Company provides no express warranties, guarantees, or conditions related to the Product. To the extent permitted by law, the Company disclaims any implied warranties including those of merchantability, fitness for a particular purpose, workmanlike effort, and non-infringement. Without limiting the generality of the foregoing, the Company does not warrant that the Product will be accurate, error-free, virus-free, timely, secure or uninterrupted or that it will meet any specific requirements of a Subscriber.</p>

			<p>While the Company will take commercially reasonable endeavors to make the service through the Product is available 24 (twenty-four) hours per day and 5 (five) days per week excluding weekends (except for planned maintenance), the Company disclaims all responsibility and liability for the availability, security or reliability of the Product.</p>

			<h3>7) Indemnification</h3>

			<p>You agree to defend, indemnify and hold harmless the Company, Our officers, directors, employees, and agents, from and against any and all claims, damages, obligations, losses, liabilities, costs or debt, and expenses (including but not limited to attorney's fees) arising from:</p>

			<ul class="list1">
				<li>Your unauthorized use of and access to the Product;</li>
				<li>Your violation of any term of these Terms of Use or any other Company policy;</li>
				<li>Your violation of any third-party right, including without limitation any intellectual property right or privacy right;</li>
				<li>or as a result of any threatening, libelous, obscene, harassing or offensive material uploaded/transmitted by You on the cloud infrastructure of the Company.</li>
			</ul>

			<h3>8) Limitation Of Liability</h3>
			<p>To the fullest extent permitted by applicable law, the Company shall not be liable for any direct, indirect, incidental, special, punitive or consequential damages, or lost profits resulting from Your access to or use of the Product, whether based on breach of contract, breach of warranty, tort (including negligence), or any other legal theory. This includes Your inability to access or use (including due to modification, suspension, blocking, discontinuance, cancellation, or termination of the Product or any part thereof) the Product. These limitations apply to any matter related to the Product, third party internet sites, programs or conduct, viruses or other disabling features, incompatibility between the Product and other services, software, or hardware, and any delay or failure in initiating, conducting, or completing any transmission or transaction in connection with the Production an accurate or timely manner. These limitations also apply even if this remedy does not fully compensate You for any losses, or fails its essential purpose; or even if the Company knew or should have known about the possibility of the damages.</p>

			<p>Without limiting the foregoing, under no circumstances shall the Company be held liable for any delay or failure in performance resulting directly or indirectly from acts of nature, forces, or causes beyond its reasonable control, including, without limitation, Internet failures, computer equipment failures, telecommunication equipment failures, other equipment failures, electrical power failures, strikes, labor disputes, riots, insurrections, civil disturbances, shortages of labor or materials, fires, floods, storms, explosions, acts of God, war, governmental actions, orders of domestic or foreign courts or tribunals, non-performance of third parties, or loss of or fluctuations in heat, light, or air conditioning.</p>


			<h3>9) Termination</h3>

			<p>9.1.The Terms of Use will continue to apply until terminated by either You or the Company as set forth below.</p>
			<p>9.2.The Company may, at any time, with or without notice, terminate the Terms of Use with You if:</p>

			<ul class="list1">
				<li>You breach any of the provisions of the Terms of Use or any other terms, conditions, or policies that may be applicable to You from time to time (or have acted in a manner that clearly shows that You do not intend to, or are unable to, comply with the same);</li>
				<li>The Company is required to do so by law (for example, where the provision of the Products to You is, or becomes, unlawful);</li>
				<li>You use the Products in a manner that is unlawful or against the Terms of Use, Privacy Policy or any other policy or law applicable to You;</li>
				<li>Your payment is overdue by more than fifteen (15) days.</li>
			</ul>

			<p>9.3.You agree that the Company shall not be liable to You or any third party for any termination of Your Account (and accompanying deletion of Your Account Information), or Your access to the Website and Products.</p>

			<p>9.4.The Company may also terminate or suspend all or a portion of Your Account and/or access to the Product with or without reason. Except as may be set forth in the Terms of Use, termination of Your Account may include: (i) removal of access to the Product; (ii) return of all data owned by the Subscriber and trademark, logo and service mark available with the Company; and (iii) barring of further use of the Product.</p>


			<h3>10) Choice Of Law And Jurisdiction</h3>

			<p>This Agreement shall be construed in accordance with the applicable laws of India. The Courts at Coimbatore shall have exclusive jurisdiction in any proceedings arising out of this Terms of Use.</p>

			<h3>11) Severability</h3>

			<p>If any term, provision, covenant or restriction of these Terms of Use is held by a court of competent jurisdiction to be invalid, void or unenforceable, the remainder of the terms, provisions, covenants and restrictions of these Terms of Use shall remain in full force and effect and shall in no way be affected, impaired or invalidated.</p>

			<h3>12) No Waiver</h3>

			<p>The rights and remedies available under this Terms of Use may be exercised as often as necessary and are cumulative and not exclusive of rights or remedies provided by law. It may be waived only in writing. Delay in exercising or non-exercise of any such right or remedy does not constitute a waiver of that right or remedy, or any other right or remedy.</p>


			<h3>13) General</h3>

			<p>You cannot assign or otherwise transfer the Terms of Use, or any right granted hereunder to any third party. These Terms of Use comprise the full and complete agreement between You and the Company with respect to the use of the Product and supersedes and cancels all prior communications, understandings, and agreements between You and the Company, whether written or oral, expressed or implied with respect thereto.</p>	
            
            <p>Ontabee has the Rights and Liberty to showcase Ontabee's clients app's as portfolio's to other prospects or clients. In case if the Client is not willing in Ontabee showing their works done for the client with others, Then both The Client and Ontabee will agree mutually in this case and Ontabee will not showcase the work done for their client with others as agreed.</p>	
            
			<h3>14) Customer Data</h3>            

			<p>Customer data will be provided only to Ontabee's direct customers.</p>
			<p>Customer data will not be provided to the Resellers and their clients.</p>
			
            
			
		</div> <!--cms_content--> 
	</div> <!--container-->
</div> <!--cms_page-->

<?php include('inc/footer.php');?>