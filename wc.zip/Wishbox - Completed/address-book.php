<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- acc page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi pin3"></i>
            <h2>Address Book</h2>
            <p>Add  a new address and manage the delivery address</p>
          </div>
          <div class="white-30 address-book">
            <div class="saved-address opens">
              <!-- custom row -->
              <div class="cs-row">
                <ul class="reset">
                  <li>
                    <div class="box add-new-address">
                      <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="d-tables">
                      <span class="d-table-cell">
                      <i class="fi plus-circle2"></i>
                      Add New Address
                      </span>
                      </a>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Home</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli1" checked="">
                      <label class="check-deliver" for="deli1">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Apartment</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli2">
                      <label class="check-deliver" for="deli2">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Office</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli3">
                      <label class="check-deliver" for="deli3">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Apartment</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli4">
                      <label class="check-deliver" for="deli4">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Office</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli5">
                      <label class="check-deliver" for="deli5">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Apartment</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli6">
                      <label class="check-deliver" for="deli6">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div class="box">
                      <h5>Office</h5>
                      <address>
                        Opposite Prestige Laundry, <br>
                        Al Mattar Al Qadeem 2nd Street, <br>
                        Old Airport Area, Doha.
                      </address>
                      <input type="radio" class="check-deliver" name="deliver" id="deli7">
                      <label class="check-deliver" for="deli7">Default Address</label>
                      <div class="options">
                        <a href="#add_new_address" data-toggle="modal" data-target="#add_new_address" class="edit fi"></a>
                        <a href="#remove_modal" data-toggle="modal" data-target="#remove_modal" class="trash2 fi"></a>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <!-- custom row -->
            </div>
          </div>
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<!-- add new address modal-->
<div id="add_new_address" class="modal address_modal fade" role="dialog">
  <div class="modal-dialog md">
    <div class="modal-content">
      <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>
      <!-- map address -->
      <div class="map-address showns">
        <div class="map-address-box">
          <div class="form-group nked">
            <i class="fi pin3"></i>
            <input type="text" value="" class="form-control" placeholder="Enter your delivery location">
            <button class="gps"><i class="fi gps"></i></button>
          </div>
          <div id="map" class="custom-maps"></div>
        </div>
        <div class="map-box-footer">
          <input type="radio" class="radio-cirlce" id="house" name="home-type">
          <label class="radio-cirlce" for="house">House</label>
          <input type="radio" class="radio-cirlce" id="apartment" name="home-type">
          <label class="radio-cirlce" for="apartment">Apartment</label>
          <input type="radio" class="radio-cirlce" id="office" name="home-type">
          <label class="radio-cirlce" for="office">Office</label>
          <input type="radio" class="radio-cirlce" id="others" value="others" checked name="home-type">
          <label class="radio-cirlce" for="others">Others</label>
        </div>
        <!-- form fields -->
        <div class="form-fields mt25">
          <!-- row -->
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="types"><span>Ex: Friend Home, Daughter school, etc…</span></label>
                <input id="types" type="text" class="form-control">
              </div>
            </div>
          </div>
          <!-- row -->
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="streetnumber"><span>Street number</span></label>
                <input id="streetnumber" type="text" class="form-control">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="buildin"><span>Building number</span></label>
                <input id="buildin" type="text" class="form-control">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="flat"><span>Flat number</span></label>
                <input id="flat" type="text" class="form-control">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="zones"><span>Zone</span></label>
                <input id="zones" type="text" class="form-control">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="areaname"><span>Area Name</span></label>
                <input id="areaname" type="text" class="form-control">
              </div>
            </div>
            <div class="col-sm-6">
              <div class="form-group icon normal">
                <label for="landmark"><span>Land Mark</span></label>
                <input id="landmark" type="text" class="form-control">
              </div>
            </div>
          </div>
          <!-- row -->
        </div>
        <!-- form fields -->
        <div class="text-right mt-15">
          <button class="btn icon-left"><i class="fi plus-circle1"></i> Add Address</button>
        </div>
      </div>
      <!-- map address -->
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!-- add new address modal-->
<!-- alert modal -->
<div id="remove_modal" class="modal alert_modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <h3>Remove</h3>
      <p>Do you want remove this?</p>
      <div class="buttons-flex">
        <button class="btns" data-dismiss="modal">No</button> <button class="btns">Yes</button>
      </div>
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!-- alert modal -->
<?php include ('inc/footer.php'); ?>