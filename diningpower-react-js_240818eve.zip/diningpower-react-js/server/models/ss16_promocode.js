/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Promocode', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    promocode: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'promocode'
    },
    amount: {
      type: "DOUBLE",
      allowNull: false,
      field: 'amount'
    },
    maximumRedeemPrice: {
      type: "DOUBLE",
      allowNull: false,
      field: 'maximum_redeem_price'
    },
    expiryDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'expiry_date'
    },
    usageType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'usage_type'
    },
    discountType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'discount_type'
    },
    minOrderValue: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'min_order_value'
    },
    applyShop: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'apply_shop'
    },
    appType: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'app_type'
    },
    userType: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      field: 'user_type'
    },
    vendor: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'vendor'
    }
  }, {
    tableName: 'ss16_promocode'
  });
};
