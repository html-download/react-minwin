<?php
/**
 * The theme options serialized in the database, we retrive them all into an array
 */
 
global $designpixi_options;
$designpixi_options = get_option( DesignPixi_THEMEOPTIONS );

?>