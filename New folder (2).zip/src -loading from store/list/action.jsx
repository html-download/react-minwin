import Constants from './constants.jsx';
import Store from './store.jsx';


class Actions {
	static actiontostore(restaurants) {
		
		return Store.dispatch({
			type: Constants.REQUEST,
            restaurants: restaurants
		})
	    /*return {

		 apistore: (store) => store.dispatch({
		                type: Constants.REQUEST,
		                restaurants: restaurants

		            });

		}*/

	}

	static actiontostore2(restaurants) {
		
		return Store.dispatch({
			type: Constants.REQUEST,
            restaurants: restaurants
		})
	    /*return {

		 apistore: (store) => store.dispatch({
		                type: Constants.REQUEST,
		                restaurants: restaurants

		            });

		}*/

	}
}





export default Actions;