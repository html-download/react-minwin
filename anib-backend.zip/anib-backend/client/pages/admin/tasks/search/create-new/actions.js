/* global window */
'use strict';
const CActions = require('../actions');
const ApiActions = require('../../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Qs = require('qs');


class Actions {

    static hideCreateNew() {

        Store.dispatch({
            type : Constants.HIDE_CREATE_NEW
        });
    }

    static setEvent(eventArray) {

        Store.dispatch({
            type : Constants.SET_EVENTS,
            eventArray: eventArray
        });
    }

    static getResults(data) {
        
        ApiActions.get(
            '/task',
            data,
            Store,
            Constants.GET_RESULTS,
            Constants.GET_RESULTS_RESPONSE
        );
    }


    static datePicker(date,field) {

        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD,
            date: date,
            field:field
        });

    }

    static createNew(data, history, callBack,event) {
        
        ApiActions.post(
            '/task',
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {
                
                if(response.status === 200) {                    

                    if(callBack) {
                        callBack(event);
                    } else {
                        CActions.hideCreateNew();
                        const path = '/admin/tasks';                    
                        history.push(path);
                        window.scrollTo(0, 0);   
                    }
                }
            }
        );
    }

    static changeSearchQuery(data, history) {

        history.push({
            pathname: '/admin/tasks',
            search: `?${Qs.stringify(data)}`
        });

        window.scrollTo(0, 0);
    }

    static getDealResults() {
        
        ApiActions.get(
            '/deal',
            undefined,
            Store,
            Constants.GET_DEALS_RESULTS,
            Constants.GET_DEALS_RESULTS_RESPONSE
        );
    }

    static getCustomerResults() {
        
        ApiActions.get(
            '/user',
            undefined,
            Store,
            Constants.GET_CUTOMER_RESULTS,
            Constants.GET_CUTOMER_RESULTS_RESPONSE
        );
    }
   
}


module.exports = Actions;
