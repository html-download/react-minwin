'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    show: PropTypes.bool,
    show_zone_historical : PropTypes.bool
};


class ModalForm extends React.Component {

    render() {
        return (
            <Modal
                id="modal_history"
                header={'Historical Data'}
                footer={false}
                show={this.props.show_zone_historical}
                onClose={Actions.hideZoneHistoricalModal}
                modalDialogClasses={{'modal-lg' : true}}
                modalClasses={{'right' : true, 'fade' : true, 'in':true}}>
                <div className="modal-body full_row">
                    <div className="form-group">
                        <input type="text" className="form-control date-inline hide" placeholder="Choose Date"/>
                        <input type="hidden" className="datepicker" placeholder=""/>
                    </div>
                    <div className="row">
                      <div className="col-sm-8">
                        <div className="form-group">
                            <select className="selectpicker" title="Choose Days">
                                <option>1 day</option>
                                <option>2 days</option>
                                <option>3 days</option>
                                <option>4 days</option>
                                <option>5 days</option>
                                <option>6 days</option>
                                <option>7 days</option>
                            </select>
                            <label className="text-center">Download Data(CSV)</label>
                        </div>
                      </div>
                      <div className="col-sm-4">
                        <button className="btn blue">Download</button>
                      </div>
                    </div>
                </div>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
