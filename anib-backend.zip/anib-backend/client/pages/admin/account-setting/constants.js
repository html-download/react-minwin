'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'SEND_MESSAGE',
    'SEND_MESSAGE_RESPONSE',
    'TOGGLE_PASSWORD',
    'GET_USER_RESULT',
    'GET_USER_RESULT_RESPONSE',
    'USER_UPDATE',
    'USER_UPDATE_RESPONSE'
]);
