/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16DeliveryboyRequests', {
    requestId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'request_id'
    },
    orderKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'order_key'
    },
    deliveryboyKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'deliveryboy_key'
    },
    requestedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'requested_datetime'
    }
  }, {
    tableName: 'ss16_deliveryboy_requests'
  });
};
