/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Currency', {
    currencyId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'currency_id'
    },
    currencyTitle: {
      type: DataTypes.STRING(32),
      allowNull: false,
      field: 'currency_title'
    },
    currencyCode: {
      type: DataTypes.STRING(3),
      allowNull: false,
      field: 'currency_code'
    },
    currencySymbol: {
      type: DataTypes.STRING(5),
      allowNull: false,
      field: 'currency_symbol'
    },
    symbolSide: {
      type: DataTypes.ENUM('Left','Right'),
      allowNull: false,
      defaultValue: 'Left',
      field: 'symbol_side'
    },
    decimalPlace: {
      type: DataTypes.CHAR(1),
      allowNull: false,
      field: 'decimal_place'
    },
    currencyValue: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'currency_value'
    },
    currencyStatus: {
      type: DataTypes.ENUM('Active','Inactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'currency_status'
    },
    defaultCurrency: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'default_currency'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00',
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: '0000-00-00 00:00:00',
      field: 'modified_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    }
  }, {
    tableName: 'ss16_currency'
  });
};
