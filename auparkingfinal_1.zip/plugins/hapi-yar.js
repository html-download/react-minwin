'use strict'

const register = (server, options, next) => {
    server.register([{
        register: require('yar'),
        options: {
            storeBlank: false,
            cookieOptions: {
                password: 'the-password-must-be-at-least-32-characters-long',
                isSecure: true
            }
        }
    }])
    next();
}

register.attributes = {
    name: 'React View'
}

module.exports = register