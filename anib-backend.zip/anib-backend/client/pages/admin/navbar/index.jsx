"use strict";
const Actions = require('./actions');
const PropTypes = require("prop-types");
const React = require("react");
const ReactRouter = require("react-router-dom");
const ClassNames = require("classnames");
import { Dropdown, DropdownMenu, DropdownToggle } from "reactstrap";
const Store = require('./store');

const Link = ReactRouter.Link;
const propTypes = {
  location: PropTypes.object
};

class Navbar extends React.Component {
  constructor(props) {
    super(props);
    
    Actions.getUser();
    
    this.state = Store.getState();

    this.toggle = this.toggle.bind(this);
  }

  componentDidMount() {

    this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
}

  componentWillUnmount() {

      this.unsubscribeStore();
  }

  onStoreChange() {

      this.setState(Store.getState());       
  }

  classForPath(pathPattern) {

    return ClassNames({
      active: this.props.location.pathname.match(pathPattern)
    });
  }

  toggleMenu() {

      Actions.navToggle(!this.state.navBarOpen);
  }

  toggle() {

      Actions.toggleOpen(!this.state.dropdownOpen)
  }

  render() {
      
      const admindata = this.state.data;
      const admin_firstname = admindata.first_name ?  admindata.first_name : "Admin"
      const admin_lastname = admindata.last_name ? admindata.last_name: " "
      const admin_name = admin_firstname.concat(admin_lastname);

      const imgdata = admindata.profile_image_path ? admindata.profile_image_path : "/public/media/images/profile_av.jpg" 


    const navBarCollapse = ClassNames({
      "navbar-collapse": true,
      collapse: !this.state.navBarOpen
    });

    return (
      <header className="header">
        <div className="container-fluid">
          <div className="logo">
            <Link to="/admin/deals">
              <img src="/public/media/images/logo.png" align="logo" />{" "}
            </Link>
          </div>

          <div className="navigation">
            <ul className="reset">              
              <li>
                <Link
                  to="/admin/customers"
                  className={this.classForPath(/^\/admin\/customers/)}
                >
                  <i className="icon-people" /> Customers
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/deals"
                  className={this.classForPath(/^\/admin\/deals/)}
                >
                  <i className="icon-layers" /> Enquiry
                </Link>
              </li>              
              <li>
                <Link
                  to="/admin/policies"
                  className={this.classForPath(/^\/admin\/policies/)}
                >
                  <i className="icon-support" /> Policies
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/tasks"
                  className={this.classForPath(/^\/admin\/tasks/)}
                >
                  <i className="icon-target" /> Tasks
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/users"
                  className={this.classForPath(/^\/admin\/users/)}
                >
                  <i className="icon-user" /> Users
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/roles"
                  className={this.classForPath(/^\/admin\/roles/)}
                >
                  <i className="icon-pin" /> Roles
                </Link>
              </li>  
            </ul>
          </div>
          <div className="user-profile">
            <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
              <DropdownToggle
                caret
                className="dropdown-toggle-admin"
                tag="button"
              >
                <span style={ { backgroundImage:  `url(${imgdata})` } }>
                </span>
               {admin_name}
              </DropdownToggle>
              <DropdownMenu>
                <div className="user-header">
                  <div className="user-content">
                    <div className="img_large" style={ { backgroundImage:  `url(${imgdata})` } }></div>
                    <span className="name"> {admin_name}</span>{" "}
                    <span className="role">Super Admin</span>{" "}
                  </div>
                </div>
                <Link
                  className="dropdown-item"
                  onClick={this.toggle}
                  to="/admin/account-setting"
                >
                  <i className="icon-user" /> Account Settings
                </Link>
                <Link
                  className="dropdown-item"
                  onClick={this.toggle}
                  to="/admin/email-setting"
                >
                  <i className="icon-envelope-open" /> Email Settings
                </Link>
                <a
                  href="/login/logout"
                  onClick={this.toggle}
                  className={"dropdown-item"}
                >
                  <i className="icon-logout" />Logout{" "}
                </a>
              </DropdownMenu>
            </Dropdown>
          </div>
        </div>
      </header>
    );
  }
}

Navbar.propTypes = propTypes;

module.exports = Navbar;
