/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16SmsHistory', {
    id: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    customerMobile: {
      type: DataTypes.STRING(10),
      allowNull: false,
      field: 'customer_mobile'
    },
    messageId: {
      type: DataTypes.STRING(125),
      allowNull: false,
      field: 'message_id'
    },
    smsType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'sms_type'
    },
    smsTitle: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'sms_title'
    },
    message: {
      type: DataTypes.STRING(459),
      allowNull: false,
      field: 'message'
    },
    smsStatus: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'sms_status'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      field: 'created_datetime'
    }
  }, {
    tableName: 'ss16_sms_history'
  });
};
