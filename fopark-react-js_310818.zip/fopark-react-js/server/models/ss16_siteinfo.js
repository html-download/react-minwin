/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Siteinfo', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    appName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'app_name'
    },
    appDesc: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'app_desc'
    },
    metaKeyword: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'meta_keyword'
    },
    metaDesc: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'meta_desc'
    },
    emailId: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'email_id'
    },
    phoneNumber: {
      type: DataTypes.STRING(50),
      allowNull: false,
      defaultValue: '0',
      field: 'phone_number'
    },
    siteLocation: {
      type: DataTypes.STRING(150),
      allowNull: false,
      field: 'site_location'
    },
    currencySymbol: {
      type: DataTypes.STRING(5),
      allowNull: false,
      field: 'currency_symbol'
    },
    currencyCode: {
      type: DataTypes.STRING(3),
      allowNull: false,
      field: 'currency_code'
    },
    currencyPosition: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'currency_position'
    },
    siteCopyright: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'site_copyright'
    },
    siteLogo: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'site_logo'
    },
    siteFavicon: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'site_favicon'
    },
    playstore: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'playstore'
    },
    appstore: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'appstore'
    },
    siteNoimage: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'site_noimage'
    },
    commision: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'commision'
    },
    serviceTax: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'service_tax'
    },
    country: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'country'
    },
    city: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'city'
    },
    maximumOrderQuantity: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'maximum_order_quantity'
    },
    minFundRequest: {
      type: "DOUBLE",
      allowNull: false,
      field: 'min_fund_request'
    },
    maxFundRequest: {
      type: "DOUBLE",
      allowNull: false,
      field: 'max_fund_request'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    termsAndConditions: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'terms_and_conditions'
    },
    privacyPolicy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'privacy_policy'
    },
    orderAcceptTimelimit: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'order_accept_timelimit'
    },
    cancellationTime: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'cancellation_time'
    },
    assignOrder: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'assign_order'
    },
    deliveryboyRadious: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'deliveryboy_radious'
    }
  }, {
    tableName: 'ss16_siteinfo'
  });
};
