const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'GET_RESTAURANTS_DATA',
    'GET_RESTAURANTS_DATA_RESPONSE',
    'ADDRESS_SEARCH',
    'EMPTY_RESTAURANT_LIST'
]);
