'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const CommonFunctions = require('../../../../../helpers/common-functions');


const initialState = {
    hydrated: false,
    loading: false,
    showFetchFailure: false,
    showSaveSuccess: false,
    error: undefined,
    hasError: {},
    help: {},

    is_load_vehicle_brand: false,

    pipeline_id: 1,
    customer_id: undefined,
    deal_quote_key: undefined,
    id: undefined,
    enquiry_type: undefined,
    vehicle_type: undefined,
    vehicle_insured_value: undefined,
    minimum_retail_price: undefined,
    maximum_retail_price: undefined,
    emirate_id: undefined,
    emirate_name: undefined,
    current_cover: undefined,
    no_of_passenger: undefined,
    current_insurer: undefined,
    first_registraion_date: undefined,
    rta_certificate_start_date: undefined,
    policy_issue_date: undefined,
    years_without_claim: undefined,
    claim_certificate_available: undefined,
    is_private_car: undefined,
    is_unmodified: undefined,
    is_car_gcc_spec: undefined,
    editable_field: undefined,
    cc_emails:undefined,
    bcc_emails:undefined,
    user_id:undefined,
    user_name:undefined,
    vehicle_brand:undefined,
    number_of_passengers:undefined,
    enquiry_type:undefined,
    enquiry_type_text:undefined,
    is_car_modified:undefined,
    deal_payment_status:undefined,
    is_third_party: undefined,
    is_uninsured: undefined,
    is_mortgaged: undefined,
    place_of_registration_id: undefined,
    place_of_registration: undefined,
    registartion_number: undefined,
    vehicle_color: undefined,
    seats: undefined,
    cylinders: undefined,
    tcf_number: undefined,
    chassis_number: undefined,
    engine_number: undefined,
    plate_code: undefined,
    vehicle_type : undefined,
    vehicle_type_text : undefined,
    choose_policy_url: undefined,
    year: undefined,
    year_key: undefined,
    vehicle_brand_model_key:undefined,
    vehicle_brand_model_name:undefined,
    vehicle_brand_model_trim_key: undefined,
    vehicle_brand_model_trim_name: undefined
};
const reducer = function (state = initialState, action) {
    

    if (action.type === Constants.LOADING_VEHICLE_BRAND) {
        return ObjectAssign({}, state, {
            is_load_vehicle_brand: action.load
        });
    }

    if (action.type === Constants.GET_DEAL_DETAILS) {
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true
        });
    }

    if (action.type === Constants.GET_DEAL_DETAILS_RESPONSE) {        

        const validation = ParseValidation(action.response);
        const data = (action.response && action.response.data) ? action.response.data : {};

        const stateUpdates = {
            loading: false,
            hydrated: true,
            showSaveSuccess: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        };

        
        if (action.response && action.response.status === 200) {

            stateUpdates.deal_quote_key = data.deal_quote_key ? data.deal_quote_key : undefined;
            stateUpdates.choose_policy_url = data.url ? data.url : undefined;
            stateUpdates.pipeline_id = data.pipeline_id ? data.pipeline_id : undefined;
            stateUpdates.customer_id = data.customer_id ? data.customer_id : undefined;
            stateUpdates.customer_name = data.customer_name ? data.customer_name : undefined;
            stateUpdates.cc_emails = data.cc_emails ? data.cc_emails : undefined;
            stateUpdates.bcc_emails = data.bcc_emails ? data.bcc_emails : undefined;
            stateUpdates.id = data.driving_details_key ? data.driving_details_key : undefined;
            stateUpdates.first_license_country_id = data.first_license_country_id ? data.first_license_country_id : undefined;
            stateUpdates.first_license_age = data.first_license_age ? data.first_license_age : undefined;
            stateUpdates.first_license_issue_date = data.first_license_issue_date ? data.first_license_issue_date : undefined;
            stateUpdates.uae_license_age = data.uae_license_age ? data.uae_license_age : undefined;
            stateUpdates.uae_license_issue_date = data.uae_license_issue_date ? data.uae_license_issue_date : undefined;
            stateUpdates.vehicle_brand = data.vehicle_brand ? data.vehicle_brand : undefined;
            stateUpdates.user_id = data.uae_license_issue_date ? data.user_id : undefined;
            stateUpdates.user_name = data.user_name ? data.user_name : undefined;
            stateUpdates.enquiry_type = data.enquiry_type ? data.enquiry_type : undefined;
            stateUpdates.enquiry_type_text = data.enquiry_type_text ? data.enquiry_type_text : undefined;
            stateUpdates.sum_insured = data.sum_insured ? data.sum_insured : undefined;
            stateUpdates.vehicle_insured_value = data.vehicle_insured_value ? data.vehicle_insured_value : undefined;
            stateUpdates.minimum_retail_price = data.minimum_retail_price ? data.minimum_retail_price : undefined;
            stateUpdates.maximum_retail_price = data.maximum_retail_price ? data.maximum_retail_price : undefined;
            stateUpdates.years_without_claim = data.years_without_claim ? data.years_without_claim : undefined;
            stateUpdates.number_of_passengers = data.number_of_passengers ? data.number_of_passengers : undefined;
            stateUpdates.first_registraion_date = data.first_registraion_date ? data.first_registraion_date : undefined;
            stateUpdates.rta_certificate_start_date = data.rta_certificate_start_date ? data.rta_certificate_start_date : undefined;
            stateUpdates.policy_issue_date = data.policy_issue_date ? data.policy_issue_date : undefined;
            stateUpdates.is_car_modified = data.is_car_modified ? data.is_car_modified : undefined;
            stateUpdates.user_id = data.user_id ? data.user_id : undefined;
            stateUpdates.deal_payment_status = data.deal_payment_status ? data.deal_payment_status : undefined;

            stateUpdates.emirate_id = data.emirate_id ? data.emirate_id :  undefined,
            stateUpdates.emirate_name = data.emirate_name ? data.emirate_name :  undefined,
            stateUpdates.is_car_gcc_spec = data.is_car_gcc_spec ? data.is_car_gcc_spec : undefined;
            stateUpdates.is_third_party = data.is_third_party ? data.is_third_party : undefined;
            stateUpdates.is_uninsured = data.is_uninsured ? data.is_uninsured : undefined;
            stateUpdates.is_mortgaged = data.is_mortgaged ? data.is_mortgaged : undefined;
            stateUpdates.place_of_registration_id = data.place_of_registration_id ? data.place_of_registration_id : undefined;
            stateUpdates.place_of_registration = data.place_of_registration ? data.place_of_registration : undefined;
            stateUpdates.registration_number = data.registration_number ? data.registration_number : undefined;
            stateUpdates.vehicle_color = data.vehicle_color ? data.vehicle_color : undefined;
            stateUpdates.seats = data.seats ? data.seats : undefined;
            stateUpdates.cylinders = data.cylinders ? data.cylinders : undefined;
            stateUpdates.tcf_number = data.tcf_number ? data.tcf_number : undefined;
            stateUpdates.chassis_number = data.chassis_number ? data.chassis_number : undefined;
            stateUpdates.engine_number = data.engine_number ? data.engine_number : undefined;
            stateUpdates.plate_code = data.plate_code ? data.plate_code : undefined;
            stateUpdates.vehicle_type = data.vehicle_type ? data.vehicle_type : undefined;
            stateUpdates.vehicle_type_text = data.vehicle_type_text ? data.vehicle_type_text : undefined;
            stateUpdates.year = data.year ? data.year : undefined;
            stateUpdates.year_key = data.year_key ? data.year_key : undefined;
            stateUpdates.vehicle_brand_key = data.vehicle_brand_key ? data.vehicle_brand_key : undefined;
            stateUpdates.vehicle_brand_name = data.vehicle_brand_name ? data.vehicle_brand_name : undefined;
            stateUpdates.vehicle_brand_model_key = data.vehicle_brand_model_key ? data.vehicle_brand_model_key : undefined;
            stateUpdates.vehicle_brand_model_name = data.vehicle_brand_model_name ? data.vehicle_brand_model_name : undefined;
            stateUpdates.vehicle_brand_model_trim_key = data.vehicle_brand_model_trim_key ? data.vehicle_brand_model_trim_key : undefined;
            stateUpdates.vehicle_brand_model_trim_name = data.vehicle_brand_model_trim_name ? data.vehicle_brand_model_trim_name : undefined;
            stateUpdates.policy_prev_expiry_date = data.policy_prev_expiry_date ? data.policy_prev_expiry_date : undefined;
            stateUpdates.insurer_code = data.insurer_code ? data.insurer_code : undefined;
                        
        }
        return ObjectAssign({}, state, stateUpdates);
    }

    if (action.type === Constants.SAVE_DEAL_DETAILS) {

        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_DEAL_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);
        const data = (action.response && action.response.data) ? action.response.data : {};
        const stateUpdates = {
            loading: false,
            hydrated: true,
            showSaveSuccess: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        };
        if (action.response && action.response.status === 200) {

            stateUpdates.deal_quote_key = data.deal_quote_key ? data.deal_quote_key : undefined;
            stateUpdates.url = data.choose_policy_url ? data.url : undefined;
            stateUpdates.customer_id = data.customer_id ? data.customer_id : undefined;
            stateUpdates.cc_emails = data.cc_emails ? data.cc_emails : undefined;
            stateUpdates.bcc_emails = data.bcc_emails ? data.bcc_emails : undefined;
            stateUpdates.id = data.driving_details_key ? data.driving_details_key : undefined;
            stateUpdates.first_license_country_id = data.first_license_country_id ? data.first_license_country_id : undefined;
            stateUpdates.first_license_age = data.first_license_age ? data.first_license_age : undefined;
            stateUpdates.first_license_issue_date = data.first_license_issue_date ? data.first_license_issue_date : undefined;
            stateUpdates.uae_license_age = data.uae_license_age ? data.uae_license_age : undefined;
            stateUpdates.uae_license_issue_date = data.uae_license_issue_date ? data.uae_license_issue_date : undefined;
            stateUpdates.vehicle_brand = data.vehicle_brand ? data.vehicle_brand : undefined;
            stateUpdates.user_id = data.user_id ? data.user_id : undefined;
            stateUpdates.user_name = data.user_name ? data.user_name : undefined;
            stateUpdates.editable_field =  undefined;
            stateUpdates.enquiry_type = data.enquiry_type ? data.enquiry_type : undefined;
            stateUpdates.enquiry_type_text = data.enquiry_type_text ? data.enquiry_type_text : undefined;
            stateUpdates.vehicle_insured_value = data.vehicle_insured_value ? data.vehicle_insured_value : undefined;
            stateUpdates.minimum_retail_price = data.minimum_retail_price ? data.minimum_retail_price : undefined;
            stateUpdates.maximum_retail_price = data.maximum_retail_price ? data.maximum_retail_price : undefined;
            stateUpdates.years_without_claim = data.years_without_claim ? data.years_without_claim : undefined;
            stateUpdates.number_of_passengers = data.number_of_passengers ? data.number_of_passengers : undefined;
            stateUpdates.first_registraion_date = data.first_registraion_date ? data.first_registraion_date : undefined;
            stateUpdates.rta_certificate_start_date = data.rta_certificate_start_date ? data.rta_certificate_start_date : undefined;
            stateUpdates.policy_issue_date = data.policy_issue_date ? data.policy_issue_date : undefined;
            stateUpdates.is_car_modified = data.is_car_modified ? data.is_car_modified : undefined;
            stateUpdates.deal_payment_status = data.deal_payment_status ? data.deal_payment_status : undefined;

            stateUpdates.emirate_id = data.emirate_id ? data.emirate_id :  undefined,
            stateUpdates.emirate_name = data.emirate_name ? data.emirate_name :  undefined,
            stateUpdates.is_third_party = data.is_third_party ? data.is_third_party : undefined;
            stateUpdates.is_car_gcc_spec = data.is_car_gcc_spec ? data.is_car_gcc_spec : undefined;
            stateUpdates.is_uninsured = data.is_uninsured ? data.is_uninsured : undefined;
            stateUpdates.is_mortgaged = data.is_mortgaged ? data.is_mortgaged : undefined;
            stateUpdates.place_of_registration_id = data.place_of_registration_id ? data.place_of_registration_id : undefined;
            stateUpdates.place_of_registration = data.place_of_registration ? data.place_of_registration : undefined;
            stateUpdates.registration_number = data.registration_number ? data.registration_number : undefined;
            stateUpdates.vehicle_color = data.vehicle_color ? data.vehicle_color : undefined;
            stateUpdates.seats = data.seats ? data.seats : undefined;
            stateUpdates.cylinders = data.cylinders ? data.cylinders : undefined;
            stateUpdates.tcf_number = data.tcf_number ? data.tcf_number : undefined;
            stateUpdates.chassis_number = data.chassis_number ? data.chassis_number : undefined;
            stateUpdates.engine_number = data.engine_number ? data.engine_number : undefined;
            stateUpdates.plate_code = data.plate_code ? data.plate_code : undefined;
            stateUpdates.vehicle_type = data.vehicle_type ? data.vehicle_type : undefined;
            stateUpdates.vehicle_type_text = data.vehicle_type_text ? data.vehicle_type_text : undefined;
            stateUpdates.year = data.year ? data.year : undefined;
            stateUpdates.year_key = data.year_key ? data.year_key : undefined;
            stateUpdates.vehicle_brand_key = data.vehicle_brand_key ? data.vehicle_brand_key : undefined;
            stateUpdates.vehicle_brand_name = data.vehicle_brand_name ? data.vehicle_brand_name : undefined;
            stateUpdates.vehicle_brand_model_key = data.vehicle_brand_model_key ? data.vehicle_brand_model_key : undefined;
            stateUpdates.vehicle_brand_model_name = data.vehicle_brand_model_name ? data.vehicle_brand_model_name : undefined;
            stateUpdates.vehicle_brand_model_trim_key = data.vehicle_brand_model_trim_key ? data.vehicle_brand_model_trim_key : undefined;
            stateUpdates.vehicle_brand_model_trim_name = data.vehicle_brand_model_trim_name ? data.vehicle_brand_model_trim_name : undefined;
            stateUpdates.policy_prev_expiry_date = data.policy_prev_expiry_date ? data.policy_prev_expiry_date : undefined;
            stateUpdates.insurer_code = data.insurer_code ? data.insurer_code : undefined;
        }

        return ObjectAssign({}, state, stateUpdates);
    }

    if (action.type === Constants.UPDATE_DATE_FIELD_DEAL_INFO) {

        switch(action.field) {
            
            case 'first_registraion_date':
                return ObjectAssign({}, state, {
                    first_registraion_date : action.date
                });
                break;
            case 'policy_issue_date':
                return ObjectAssign({}, state, {
                    policy_issue_date : action.date
                });
                break;
            case 'rta_certificate_start_date':
                return ObjectAssign({}, state, {
                    rta_certificate_start_date : action.date
                });
                break;
            case 'policy_prev_expiry_date':
                return ObjectAssign({}, state, {
                    policy_prev_expiry_date : action.date
                });
                break;
            default:
                /** todo */
                break;            
        }
    }

    if (action.type === Constants.EDITABLE_SHOW) {
        return ObjectAssign({}, state, {
            editable_field: action.field
        });
    }

    if (action.type === Constants.EDITABLE_HIDE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }

    if (action.type === Constants.RESET_STORE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }
    return state;
};


module.exports = reducer;
