/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16ModifiersizeType', {
    ingredientsTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'ingredients_type_id'
    },
    ingredientsTypeName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'ingredients_type_name'
    },
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'menu_id'
    },
    minimum: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'minimum'
    },
    maximum: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'maximum'
    },
    ingredientsTypeStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'ingredients_type_status'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    sort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort'
    },
    choosenType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '1',
      field: 'choosen_type'
    },
    required: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'required'
    },
    defaultModifier: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '2',
      field: 'default_modifier'
    }
  }, {
    tableName: 'ss16_modifiersize_type'
  });
};
