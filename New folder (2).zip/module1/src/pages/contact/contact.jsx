import React, {Component} from 'react';
import Container from 'react-bootstrap/Container'

class ContactForm extends Component{

  render(){

    return(
            <div>
             <Container>
            <h4>Contact Form</h4>  
            
            </Container>
            </div>
      )
  }

}

export default ContactForm;