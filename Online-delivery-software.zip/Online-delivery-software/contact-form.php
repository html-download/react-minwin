<div class="formInner">
<form id="contact_foot_form" method="post" name="contact_foot_form" action="/mail/contact_form.php">
<div class="row">
<div class="col-md-6">
<div class="posrela">
<label class="smallText" for="contact_name">Name <span>*</span></label>
<input type="text" name="contact_name" id="contact_name" placeholder="Enter your name" required="required">
</div>
<div class="posrela">
<label class="smallText" for="contact_email">Email Id<span>*</span></label>
<input type="email" name="contact_email" id="contact_email" onKeyUP="this.value = this.value.toLowerCase();" placeholder="Enter your email Id" required="required">
</div>
<div class="posrela">
<label class="smallText" for="contact_phone_con">Phone Number<span>*</span></label>
<input type="tel" name="contact_phone_con" id="contact_phone_con" placeholder="Enter your phone number" required="required"> 
<input type="hidden" id="contact_country" name="contact_country" value="">
<input type="hidden" id="contact_country_dial" name="contact_country_dial" value="">
<input type="hidden" id="contact_pageurl" name="contact_pageurl" value="">
</div>
</div>

<div class="col-md-6">
<div class="posrela">
<label class="smallText" for="contact_message">Message <span>*</span></label>
<textarea name="contact_message" required="required" id="contact_message" placeholder="Enter your message / requirement"></textarea>
</div>
<input type="submit" value="Send message">

</div>

</div>


</form>
</div>