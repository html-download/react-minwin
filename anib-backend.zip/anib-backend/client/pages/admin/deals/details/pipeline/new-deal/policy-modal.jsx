'use strict';
const React = require('react');
const Actions = require('./actions');
import { Button, Modal, ModalHeader, ModalBody } from 'reactstrap';
import { timingSafeEqual } from 'crypto';


class PolicyModal extends React.Component {

    constructor(props) {

        super(props);
        this.state = {
            plans : this.props.selected_plans
        };    
        
    }

    addPlan(e,value) {
                 
        /* const plans = this.state.plans;
        if (e.target.checked) {
            if (!this.checkifExists(value)) {
                plans.push(value);
                this.setState({
                    plans : plans
                });
            }            
        } else {
            this.removeValue(value);
            this.setState({
                plans : plans
            });
        } */


        const plans = [];
        if (e.target.checked) {            
            plans.push(value);
        }

        this.setState({
            plans : plans
        });
        
    }        

    componentWillReceiveProps(nextProps) {
        this.setState({
            plans: nextProps.selected_plans
        });
    }

    removeValue(value) {

        let plans = this.state.plans;
        plans.map((data,index) => {
            if(data.planId === value.planId) {
                plans.splice(index, 1)
            }
        });
        return plans;
    }

    checkifExists(value) {
        
        let exists = false;
        this.state.plans.map((data,index) => {
            if(data.planId === value.planId) {
                exists = true;
            }            
        });
        return exists;
    }

    /* defaultChekedIfExists(planId) {
     

        let checked = false;
        if(this.props.selected_plans) {
            this.props.selected_plans.map( (value, index) => {
                checked = (planId === value.selected_plan.planId)
            });
        }
        return checked;

    } */


    selectPlans() {
                
        let data = {
            deal_quote_request_id:this.props.deal_quote_request_key,
            selected_plan: this.state.plans
        };
        Actions.changePlan(data);
    }

    removeDuplicates(arr){
        let unique_array = []
        for(let i = 0;i < arr.length; i++){
            if(unique_array.indexOf(arr[i]) == -1){
                unique_array.push(arr[i])
            }
        }
        return unique_array
    }

    render() {                
            
        return (
            <Modal 
                isOpen={this.props.is_policy_modal_active} 
                onClose={Actions.closePolicyModal}
                modalClassName="compare-detail">
            <ModalHeader toggle={Actions.closePolicyModal}>
                Choose Plans
                <button className="btn btn-success" onClick={ (e) => this.selectPlans() }> Proceed </button>
            </ModalHeader>
            <ModalBody>
                <div className="row">
                    { 
                        this.props.policy_plans.map((value, index) => {
                        
                        return (
                            <div className="col-sm-4" key={Math.random()}>
                                <div className="compare_desc">
                                    <div className="compare_check">
                                        <span className="comp_img">
                                        <img src={this.props.insurence_product_image} />
                                    </span>
                                    </div>
                                    <div className="compare_select text-center">
                                        <h5>{value.name}</h5>
                                        <span>AED {value.premium}</span>   
                                        
                                        <div className="check-group">
                                            <input id={value.planId} className="hidden" name="ins" type="checkbox" onChange={ (e) => {this.addPlan(e,value)} } defaultChecked={this.checkifExists(value)}/>
                                            <label className="radio-btn" htmlFor={value.planId}>Choose Plan</label>
                                        </div>

                                    </div>
                                    <ul className="comp_points">
                                        {/* <li className="grey heading">Vehicle Insured Value: AED {value.premium}</li> */}
                                        { 
                                            value.covers.map((cover, index_) => {
                                                return <li key={Math.random()}>{cover.coverName}</li>;
                                            })
                                        }
                                    </ul>
                                </div>
                            </div>   
                        );
                    })
                }
                {
                    (this.props.policy_plans.length <= 0) ? 'There is no policies available right now...' : ''
                }
                </div>
            </ModalBody>
        </Modal>
        );
    }
}
module.exports = PolicyModal;