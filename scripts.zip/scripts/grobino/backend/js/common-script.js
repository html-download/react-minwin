$(document).ready(function() {
    // Executing scripts that are registered during the boot call / load
    exeOnLoad.apply(arguments);

    //App.init();

    /*$(".datetimepicker").datetimepicker({
        autoclose: !0,
        componentIcon: ".mdi.mdi-calendar",
        navIcons: {
            rightIcon: "mdi mdi-chevron-right",
            leftIcon: "mdi mdi-chevron-left"
        },
        align: 'left'
    });

    var clipboard = new Clipboard('.clipboard-btn');
    clipboard.on('success', function(e) {
        $(e.trigger).tooltip({title: 'Copied', placement: 'right'});

        e.clearSelection();
        showTooltip(e.trigger, 'Copied');
    });

    var clipboardBtn = $('.clipboard-btn');
    for (var i = 0; i < clipboardBtn.length; i++) {
        clipboardBtn[i].addEventListener('mouseleave', clearTooltip);
        clipboardBtn[i].addEventListener('blur', clearTooltip);
    }


    $('select.select2').select2();

    var tab;
    $('form[data-validate="true"]').each(function () {
        $(this).on('afterValidate', function (event, messages, errorAttributes) {
            if (errorAttributes != undefined && errorAttributes.length > 0 && errorAttributes[0].container != undefined) {

                tab = $(errorAttributes[0].container).parents('.tab-pane');
                if ( tab[0] != undefined ) {
                    tab = $("[data-toggle='tab'][href='#"+ tab.attr("id") +"']");
                    tab.tab('show');   // Display the content
                }
                setTimeout(function () {
                    $(errorAttributes[0].input).focus();
                }, 200);

            }
        });
    });*/
});

/*function clearTooltip(e) {
    // e.currentTarget.setAttribute('class', 'btn');
    // e.currentTarget.removeAttribute('aria-label');
    $(e.currentTarget).tooltip('destroy');
}
function showTooltip(elem, msg) {
    $(elem).tooltip('show');
    // elem.setAttribute('class', 'tooltipped tooltipped-s');
    // elem.setAttribute('aria-label', msg);
}*/
