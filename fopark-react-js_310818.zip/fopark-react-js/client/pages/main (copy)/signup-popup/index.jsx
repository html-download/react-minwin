const Form = require('./form.jsx');
const React = require('react');

class SignupPage extends React.Component {
    constructor(props) {
        super(props);
        this.handleModalClick = this.handleModalClick.bind(this);
    }
    handleModalClick(event) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
    }
    render() {
        return (
            <div className="custom-modal" onClick={this.handleModalClick}>
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                            <h4 className="modal-title">Create an Account</h4>
                            <h4 className="sub-title">Have a Dining Power account? <a role="button" type="button" id="load-signup-button">Sign in</a></h4>

                            <div className="social_login">
                                Sign up with 
                                <a role="button"> Facebook</a> or 
                                <a role="button"> Google</a>
                                <span>or</span>
                            </div>
                        </div>
                        <div className="modal-body">
                            <Form />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


module.exports = SignupPage;
