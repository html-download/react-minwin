'use strict';
const Constant =  require('./constants');
const ObjectAssign = require('object-assign');
const Redux = require('redux');
const ParseValidation = require('../../../../../helpers/parse-validation');
const CommonHelper = require('../../../../../helpers/common-functions');
const UserHelper = require('../../../../../helpers/user-identity');
const Async = require('async');

const initialState = {    
    loading: true,
    product_hydrated: true,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    field: {
        dataSource: CommonHelper.getAccessTree(),
        id: 'id',
        parentID: 'pid',
        text: 'name',
        hasChildren: 'hasChild'
    },
    altered_field: {}
};

let validation;
let result;
const reducer = function (state = initialState, request) {
        
    switch (request.type) {   

        case Constant.UPDATE_ROLE:
            
            /* localStorage.setItem(`role-`+request.id, JSON.stringify(request.value));

            let value = request.value;
            let alteredField = state.field.dataSource;
            
            state.field.dataSource.map((fieldValue, index) => {
                
                value.map(record => {
                    
                    if (fieldValue.id === parseInt(record)) {
                        alteredField[index] = ObjectAssign({}, fieldValue, {
                            isChecked : true
                        })
                    } 
                    
                });
            });

            return ObjectAssign({}, state, {
                dataSource: alteredField,
                id: 'id',
                parentID: 'pid',
                text: 'name',
                hasChildren: 'hasChild'
            }); */
            
            break;

        case Constant.UPDATE_ROLE_RESPONSE:
            
            localStorage.setItem(`role-`+request.id, JSON.stringify(request.value));            

            let value = request.value;
            
            let alteredField = state.field.dataSource;
            
            state.field.dataSource.map((fieldValue, index) => {
                
                value.map(record => {
                    
                    if (fieldValue.id === parseInt(record)) {
                        alteredField[index] = ObjectAssign({}, fieldValue, {
                            isChecked : true
                        })
                    } 
                    
                });
            });

            return ObjectAssign({}, state, {
                dataSource: alteredField,
                id: 'id',
                parentID: 'pid',
                text: 'name',
                hasChildren: 'hasChild'
            });
            
            break;

        case Constant.GET_ROLE:
                        
            break;
        case Constant.GET_ROLE_RESPONSE:
            
            const role = JSON.parse(request.response.data.role_json);
            const alteredField2 = state.field.dataSource;

            Async.forEachOf(alteredField2, (value, index, callback) => {

                alteredField2[index] = ObjectAssign({}, value, {
                    isChecked : role.includes(value.id)
                });
            });

            return ObjectAssign({}, state, {
                dataSource: alteredField2,
                id: 'id',
                parentID: 'pid',
                text: 'name',
                hasChildren: 'hasChild',
                loading: false
            });

            break;
        default:
            return ObjectAssign({}, state);
            break;
    }           
};
module.exports = Redux.createStore(reducer);


