<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- acc page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi user"></i>
            <h2>My Account</h2>
            <p>Change your profile image and account settings</p>
          </div>
          <div class="white-30 my-profile">
            <!-- my photo -->
            <div class="my-photo">
              <span class="img" style="background-image: url(assets/img/circle-photo.png)"></span>
              <div class="checkbox-upload">
                <input type="file" id="upload" name="upload">
                <label for="upload">Change Photo</label>
              </div>
            </div>
            <!-- my photo -->
            <!-- form elements -->
            <div class="row">
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon has-value">
                  <label for="mname"><i class="fi user1"></i><span>Name</span></label>
                  <input id="mname" type="text" class="form-control" value="Khuzaimah Raghid">
                </div>
                <!-- formgroup -->
              </div>
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon has-value">
                  <label for="mtel"><i class="lni-mobile"></i><span>Mobile Number</span></label>
                  <input id="mtel" type="tel" class="form-control" value="+9876543210">
                </div>
                <!-- formgroup -->
              </div>
            </div>
            <!-- form elements -->
            <!-- form elements -->
            <div class="row">
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon has-value">
                  <label for="memails"><i class="fi mail"></i><span>Email Address</span></label>
                  <input id="memails" type="text" class="form-control" value="khuzaimahraghid@gmail.com">
                </div>
                <!-- formgroup -->
              </div>
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon has-value-top">
                  <label><i class="lni-world"></i><span>Nationality</span></label>
                  <select class="selectpicker ui_style3">
                    <option>Arabian</option>
                    <option>Tamilan</option>
                  </select>
                </div>
                <!-- formgroup -->
              </div>
            </div>
            <!-- form elements -->
            <!-- form elements -->
            <div class="row">
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon has-value">
                  <label for="mage"><i class="lni-seo-consulting"></i><span>Age</span></label>
                  <input id="mage" type="text" class="form-control" value="28">
                </div>
                <!-- formgroup -->
              </div>
              <div class="col-sm-6">
                <div class="form-group gender">
                  <span>Male</span> 
                  <label for="gender" class="switchup label">
                  <input id="gender" type="checkbox"> 
                  <span class="slider round"></span>
                  </label>
                  <span class="pleft">Female</span>                         
                </div>
              </div>
            </div>
            <!-- form elements -->
            <div class="text-right">
              <button class="btn">Update Info</button>
            </div>
            <!-- change password -->
            <div class="change-password">
              <!-- form elements -->
              <div class="row">
                <div class="col-sm-6">
                  <!-- formgroup -->
                  <div class="form-group icon">
                    <label for="mnepassword"><i class="fi lock2"></i><span>New Password</span></label>
                    <input id="mnepassword" type="password" class="form-control">
                  </div>
                  <!-- formgroup -->
                </div>
                <div class="col-sm-6">
                  <div class="form-group icon">
                    <label for="mcpassword"><i class="fi lock2"></i><span>Confirm New Password</span></label>
                    <input id="mcpassword" type="password" class="form-control">
                  </div>
                </div>
              </div>
              <!-- form elements -->
              <div class="text-right">
                <button class="btn">Update Password</button>
              </div>
            </div>
            <!-- change password -->
          </div>
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>