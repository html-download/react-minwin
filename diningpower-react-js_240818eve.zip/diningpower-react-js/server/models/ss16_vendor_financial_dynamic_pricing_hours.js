/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorFinancialDynamicPricingHours', {
    dynamicPriceHoursId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'dynamic_price_hours_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    days: {
      type: DataTypes.STRING(120),
      allowNull: false,
      field: 'days'
    },
    startHours: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'start_hours'
    },
    endHours: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'end_hours'
    },
    type: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'type'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      field: 'status'
    }
  }, {
    tableName: 'ss16_vendor_financial_dynamic_pricing_hours'
  });
};
