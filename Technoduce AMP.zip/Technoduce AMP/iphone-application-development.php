<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/angular-logo.png" alt="AngularJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Top Rated <br>iPhone App Development Company</h1>
      <p class="desc animated fadeInUp mb30">Developing iPhone applications that give a boost to your brand-name.</p>
      <a href="<?php echo $baseurl;?>contactus" class="btn line animated fadeInUp">Get a free quote</a>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="pt0">
  <div class="container md text-center">
    <h2 class="head style1">iPhone Application Development</h2>
    <p><i>" We develop user-friendly mobile applications with the most advanced technologies, after studying the requirements of the client. "</i></p>    
    <p class="mb0">Technoduce Info Solutions is an expert iPhone application development company, having developed iPhone apps for several global clients. We develop user-friendly mobile applications with the most advanced technologies, after studying the requirements of the client. Our customer-centric approach accompanied with the fresh-minds of our team deliver cost-effective results for your project. Moreover, Technoduce and its members lay special stress on maintaining the highest standards of quality in every project.</p>
  </div> <!--container-->
</section>

<section class="half greydark">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right white">
        <h2 class="head style1 line white">Extraordinary services of <br>iPhone Application Development</h2>
        <p>We can develop both native and hybrid iPhone apps for different mobile platforms to suit your business needs. Our mobile app and design services have served the needs of different clients and boosted their sales massively. In fact, we are the best mobile app development company in the region and a perfect partner for iPhone app development outsourcing.</p>
        <p>Do you know that why we go for iPhone app development? Today millions of iPhone app users are increasing in the world, If you want to reach your business globally, then you have to be aware of mobile app development for business. Obviously, you know N number of competitors are daily arising related to your business So if you are focusing only on the web platform, then surely you are going to miss the millions of customers who are using iPhone. We have to be updated in all technology development and be aware of what mobile devices our customers are using, So you can reach your business all over the world over iPhone app.Get your business reachable to your customer's iPhone through our iPhone apps developed by us.</p>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="dark">
	<div class="container white">
    <div class="row">
      <div class="col_6 pl30 pull_right diagram">
        <amp-img src="https://192.168.1.149:444/images/angular-development.png" alt="AngularJS Development" width="460" height="450" layout="responsive"></amp-img>
      </div>

      <div class="col_6 pr30">
        <h2 class="head style1 line">iPhone app developement tools & technologies</h2>
        <p class="head_desc mb20">Technoduce uses the best methods to deliver highly productive iPhone applications. Here are some of the technological tools that we use:</p>        
        <ul class="lists mb0">
          <li>Mac OS - OS X El Capitan</li>
          <li>SDK - iOS 9.2.1 SDK</li>
          <li>Language - Objective-C/Swift</li>
          <li>DataBase - Coredata</li>
          <li>Development tool - Xcode 7.0</li>
          <li>Library - Pod</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="grey">
	<div class="container">
    <h2 class="head style1 line">Our iPhone app services include</h2>
    <ul class="features style1 col4 reset">
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>iPhone web service integration</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>iPhone mobile website development</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>iPhone social networking</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>iPhone m-commerce solution</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Custom native apps development</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Educational apps</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Entertainment apps</span>
        </div>
      </li>
      <li>
        <div class="box">
          <i class="fa fa-gear"></i>
          <span>Traveling, navigation</span>
        </div>
      </li>
    </ul>
  </div> <!--container-->
</section>

<section class="half greydark">
  <div class="bg bg1 right"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_left white">
        <h2 class="head style1 line white">Benefits of iPhone app services</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet.</p>
        <ul class="lists mb0">
          <li>Well versed in latest technologies</li>
          <li>Technically sound developers</li>
          <li>Applications with intuitive designs</li>
          <li>World-wide customer-base</li>
          <li>Dedicated customer service</li>
          <li>Customized solutions</li>
          <li>Good turn around time</li>
          <li>Good field knowledge</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="dark">
  <div class="container text-center white">
    <h2 class="head style1">Our mobile app development process flow</h2>
    <p class="md mb40">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit vulputate urna sit amet, consectetur adipiscing elit.</p>
    <amp-img src="https://www.technoduce.com/images/site/inner_flow.png" alt="AngularJS Development" width="917" height="313" style="max-width:917px; margin:0 auto" layout="responsive"></amp-img>
  </div> <!--container-->
</section>

<section>
	<div class="container md text-center">
    <h2 class="head style1">Want dedicated iPhone app developers for your project?</h2> 
    <a href="<?php echo $baseurl;?>contactus" class="btn green">Hire our iPhone developer</a>
  </div> <!--container-->
</section>

<section class="section grey text-center portfolio">
	<div class="container">
		<h2 class="head style1">iPhone app development portfolios</h2>
		<p class="md mb40">Our past projects speak a lot about the Company's commitment to maintaining quality in developing innovative iPhone applications. <br>Check out a couple of them here:</p>
		<div class="row">
			<div class="col_3">
				<a href="https://192.168.1.149:444//portfolio/caterninja.html" target="_blank">
					<amp-img src="https://192.168.1.149:444/images/food-dashboard.png" alt="food dashboard" width="987" height="410" layout="responsive"></amp-img>
				</a>
			</div>
		</div>
	</div> <!--container-->
</section> <!--section-->

<?php include ('inc/footer.php'); ?>