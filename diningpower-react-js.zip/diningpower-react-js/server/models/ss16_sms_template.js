/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16SmsTemplate', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    title: {
      type: DataTypes.STRING(125),
      allowNull: false,
      field: 'title'
    },
    template: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'template'
    }
  }, {
    tableName: 'ss16_sms_template'
  });
};
