const React = require('react');
const PropTypes = require('prop-types');
const ReactRouter = require('react-router-dom');

const Link = ReactRouter.Link;

const propTypes = {
    location: PropTypes.object
};
class Sidebar extends React.Component {
    render() {
        return (
                <aside className="main-sidebar">
                  <section className="sidebar full_row">
                    <ul className="sidebar-menu" data-widget="tree">
                      <li><Link to="/dashboard"><i className="fa fa-dashboard"></i> <span>Dashboard</span></Link></li>
                      <li><Link to="/lots"><i className="fa fa-map"></i>Lots</Link></li>
                      {/*<li><Link to="/lots-details"><i className="fa fa-list"></i>List of Lots</Link></li>
                      <li className="treeview ">
                          <a><i className="fa fa-map"></i> <span>Lots Management</span> <span className="pull-right-container"> <i className="fa fa-angle-left pull-right"></i></span></a>
                          <ul className="treeview-menu">
                              <li><Link to="/lots"><i className="fa fa-circle-o"></i>Lots</Link></li>
                              <li><Link to="/lots-details"><i className="fa fa-circle-o"></i>List of Lots</Link></li>
                          </ul>
                      </li>
                      <li><a href="404.html"><i className="fa fa-gear"></i> <span>404 Page</span></a></li>
                      <li><a href="forbidden.html"><i className="fa fa-gear"></i> <span>Forbidden</span></a></li>
                      <li><a href="blank.html"><i className="fa fa-gear"></i> <span>Blank Page</span></a></li>
                      <li><a href="modal.html"><i className="fa fa-gear"></i> <span>Modal</span></a></li>
                      <li><a href="forms.html"><i className="fa fa-gear"></i> <span>Form Design</span></a></li>
                      <li><a href="table.html"><i className="fa fa-gear"></i> <span>Table View</span></a></li>*/}
                    </ul>
                  </section>
                </aside>
        );
    }
}

Sidebar.propTypes = propTypes;


module.exports = Sidebar;
