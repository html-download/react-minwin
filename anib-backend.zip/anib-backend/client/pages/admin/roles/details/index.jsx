"use strict";
const Actions = require("./actions");
const DeleteForm = require("../../../../../client/pages/admin/components/delete-form.jsx");
const DetailsForm = require("./details-form.jsx");
const AccessControl = require("./access-control/index.jsx");
const PasswordForm = require("./password-form.jsx");
const PropTypes = require("prop-types");
const React = require("react");
const ReactRouter = require("react-router-dom");
const RolesForm = require("./roles-form.jsx");
const Store = require("./store");

import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Card,
  Button,
  CardTitle,
  CardText,
  Row,
  Col
} from "reactstrap";
import classnames from "classnames";

const Link = ReactRouter.Link;
const propTypes = {
  history: PropTypes.object,
  match: PropTypes.object
};

class DetailsPage extends React.Component {
    constructor(props) {
        super(props);

        Actions.getDetails(this.props.match.params.id);

        this.state = Store.getState();
    }

    toggle(tab) {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }

  componentDidMount() {
    this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
  }

  componentWillUnmount() {
    this.unsubscribeStore();
  }

  onStoreChange() {
    this.setState(Store.getState());
  }

    render() {        
      
        return (
        <section className="page-container">
            <div className="container">
                <div className="breadcums">
                    <ul className="reset">
                        <li>
                            <a href="/admin">Dashboard</a>
                        </li>
                        <li>
                            <a href="/admin/roles">Roles</a>
                        </li>
                        <li>
                            <span className="capitalize" id="roleNameTag"> </span>
                        </li>
                    </ul>
                    <button
                    className="btns outline-danger"
                    data-toggle="modal"
                    data-target="#delete"
                    >
                    {/*<i className="fa fa-trash" /> Delete*/}
                    </button>
                </div>
                <div className="single-page-content">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="white-box">
                                <AccessControl 
                                id={this.props.match.params.id}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        );
    }
}

DetailsPage.propTypes = propTypes;

module.exports = DetailsPage;
