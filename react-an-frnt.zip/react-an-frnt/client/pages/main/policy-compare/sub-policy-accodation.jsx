"use strict";
const React = require("react");

class SubPolicyAccordion extends React.Component {
  constructor(props) {
    super(props);
    this.toggleChange = this.toggleChange.bind(this);
    this.state = { show: false };
  }

  toggleChange(event, index) {
    event.preventDefault();
    this.setState({ show: !this.state.show });
  }

  render() {
    return (
      <tr>
        <td
          colspan="4"
          className={`toggle-td ${this.state.show === true ? "open" : " "}`}>
          <button
            className="btn-open"
            onClick={event => {
              this.toggleChange(event);
            }}>
            Features
          </button>
          <div className="show_panel">
            <table className="compare_sub_table">
              <tbody>
                <tr>
                  <td>Guarantee Of Garage Repair</td>
                  <td>Upto policy period</td>
                  <td>Upto policy period</td>
                  <td>Upto policy period</td>
                </tr>
                <tr>
                  <td>Taxi Fare</td>
                  <td>Upto AED 100</td>
                  <td>Upto AED 100</td>
                  <td>Upto AED 100</td>
                </tr>
                <tr>
                  <td>Personal Injury</td>
                  <td>Upto AED 10,000</td>
                  <td>Upto AED 10,000</td>
                  <td>Upto AED 10,000</td>
                </tr>
                <tr>
                  <td>Emergency Medical Expenses</td>
                  <td>Upto AED 3,000</td>
                  <td>Upto AED 3,000</td>
                  <td>Upto AED 3,000</td>
                </tr>
                <tr>
                  <td>Involuntary Loss Of Employment Insurance</td>
                  <td>Included</td>
                  <td>Included</td>
                  <td>Included</td>
                </tr>
              </tbody>
            </table>
          </div>
        </td>
      </tr>
    );
  }
}

module.exports = SubPolicyAccordion;
