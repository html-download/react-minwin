/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16SocialInfo', {
    storeSocialId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'store_social_id'
    },
    storeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'store_id'
    },
    storeFacebookShare: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'store_facebook_share'
    },
    fbAppId: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'fb_app_id'
    },
    fbSecretKey: {
      type: DataTypes.STRING(125),
      allowNull: false,
      field: 'fb_secret_key'
    },
    storeTwitterShare: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'store_twitter_share'
    },
    storeGoogleShare: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'store_google_share'
    },
    storeLinkedinShare: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'store_linkedin_share'
    },
    storeInstagram: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'store_instagram'
    },
    storeVimeo: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'store_vimeo'
    },
    googleAnalytics: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'google_analytics'
    },
    liveScript: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'live_script'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_social_info'
  });
};
