<?php 
	require_once('../PHPMailer/PHPMailerAutoload.php');
	if(isset($_POST) && !empty($_POST))
	{

    $error = 0;
    $request_validation['popname'] = $request_validation['popemail'] = $request_validation['popphone'] = '';
    
    if(empty($_POST['popname']) && $_POST['popname'] == '') {
      $error = 1;
      $request_validation['popname'] = "Name cannot empty";
    } 
    
    if(empty($_POST['popemail']) && $_POST['popemail'] == '') {
      $error = 1;
      $request_validation['popemail'] = "Email cannot empty";
    } 
    else if($_POST['popemail'] != '' && !preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $_POST['popemail']))
    {
      $error = 1;
      $request_validation['request_email'] = "Email is invalid";
    }
    
    if(empty($_POST['popphone']) && $_POST['popphone'] == '') 
    {
      $error = 1;
      $request_validation['popphone'] = "Phone Number cannot empty";
    } else if($_POST['popphone'] != '' && !preg_match("/^[0-9 +-]{5,20}$/", $_POST['popphone'])){
      $error = 1;
      $request_validation['popphone'] = "Phone Number is invalid";
    } 
        
    if($error == 1){

      header("Location: / "); die;
        //**header("Location: " . $_SERVER['HTTP_REFERER']);   
    } else if($error == 0 ){

		$mailer = new PHPMailer();
		$mailer->isSMTP();
		$mailer->Host = 'smtp.gmail.com';
		$mailer->Port = 465;
		$mailer->SMTPSecure = 'ssl';
		$mailer->SMTPAuth = true;
		$mailer->Username = 'smtp@technoduce.com';
    $mailer->Password = '(#regemfactorem@18#)';
		$mailer->setFrom('sales@technoduce.com', 'Online Delivery Software');
    $mailer->addAddress('sales@technoduce.com');
    $mailer->AddCC('rajesh@technoduce.com');
    $mailer->CharSet = 'UTF-8';
		$mailer->Subject = 'Inquiry - Delivery Software - '. $_POST["popname"] ;		
		$mailer->Body = ' <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <title>[SUBJECT]</title>
      <style type="text/css">
      body {
       padding-top: 0 !important;
       padding-bottom: 0 !important;
       padding-top: 0 !important;
       padding-bottom: 0 !important;
       margin:0 !important;
       width: 100% !important;
       -webkit-text-size-adjust: 100% !important;
       -ms-text-size-adjust: 100% !important;
       -webkit-font-smoothing: antialiased !important;
     }
     .tableContent img {
       border: 0 !important;
       display: block !important;
       outline: none !important;
     }
     a{
      color:#382F2E;
    }

    p, h1{
      margin:0;
    }

    div,p,ul,h1{
      margin:0;
    }

    .bigger{
      font-size: 24px;
    }
    .bgBody{
      background: #333333;
    }
    .bgItem{
      background: #ffffff;
    }
    h2{
      color:#444444;
      font-size:16px;
      font-weight:normal;
      margin:0;
    }
    p{
      color:#AAAAAA;
      font-size:13px;
      line-height:19px;
      font-weight:normal;
    }
    a.link2{
      padding:10px 20px;
      border-radius:3px;
      -moz-border-radius:3px;
      -webkit-border-radius:3px;
      color:#ffffff;
      font-size:13px;
      background:#C3CAA9;
      text-decoration:none;
    }

    a.link1{
      font-weight:bold;
      color:#7E8564;
      font-size:13px;
    }
.details_desc tr { }



.details_desc th {font-size: 16px ; font-weight: 400}

    </style>

  </head>
  <body paddingwidth="0" paddingheight="0"  style="padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;" offset="0" toppadding="0" leftpadding="0">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tableContent bgBody" align="center" style="font-family:Helvetica, Arial,serif;">

      <tr>
        <td >
          <table class="bgBody" width="720" border="0" cellspacing="0" cellpadding="0" align="center" style="border:1px solid #ccc">

          <tr>
            <td valign="top" class="movableContentContainer">
              
            <div class="movableContent">
              <table width="720" border="0" cellspacing="0" cellpadding="0"  align="center">
                <tr>
            <td bgcolor="#fff" style="border-top:4px solid #aece4e; ">
              <table width="720" border="0" cellspacing="0" cellpadding="0"  align="center">
                <tr><td height="0" colspan="4"></td></tr>
                <tr>
                  <td width="10"></td>

                  <td align="left" valign="middle" >
                     <div class="contentEditableContainer contentTextEditable" style="display:inline-block;">
                      <div class="contentEditable" >
                        <img style="padding: 20px;" src="http://image.technoduce.com/email/td-logo.png" alt="Technoduce">
                      </div>
                    </div>
                  </td>
                  <td width="28"></td>
                </tr>
               
              </table>
            </td>
          </tr>
              </table>
            </div>

            <div class="movableContent" >
              <table width="720" border="0" cellspacing="0" cellpadding="0"  align="center" class="bgItem">
                <tr>
            <td >
              <table class="email_banner" width="720" height="200" border="0" cellspacing="0" cellpadding="0"  align="center" style="background: url(http://image.technoduce.com/email/email_banner.png);">
                <tr><td height="30" colspan="6"></td></tr>

                <tr><td height="30" colspan="6"></td></tr>
              </table>
            </td>
          </tr>
              </table>
            </div>
              <div class="movableContent">
                <table width="720" border="0" cellspacing="0" cellpadding="0"  align="center">
                  <tr>
                    <td valign="top" bgcolor="#fff">
                    <h1 style="margin: 20px 15px; font-size:24px ">Inquired message from Delivery Software</h1>
                      <table class="callout details_desc table" style="border:1px solid #ccc; text-align: left; width: 95%;margin: 0 15px;">
                          <tr  >
                            <th style="padding: 20px;border-right:1px solid #ccc; border-bottom:1px solid #ccc; width: 30%;">Name</th>
                            <th style="padding: 20px;border-bottom:1px solid #ccc;">'. $_POST["popname"] .'</th>
                          </tr>
                         <tr >
                            <th style="padding: 20px;border-right:1px solid #ccc;border-bottom:1px solid #ccc; width: 30%;">Email</th>
                            <th style="padding: 20px;border-bottom:1px solid #ccc;">' . $_POST["popemail"] .'</th>
                          </tr>

                        <tr >
                            <th style="padding: 20px;border-right:1px solid #ccc;border-bottom:1px solid #ccc; width: 30%;">Phone Number</th>
                            <th style="padding: 20px;border-bottom:1px solid #ccc;">' . $_POST["popcountrycode"] .' ' . $_POST["popphone"] .'</th>
                          </tr>
                                                  <tr >
                            <th style="padding: 20px;border-right:1px solid #ccc;border-bottom:1px solid #ccc; width: 30%;">Country</th>
                            <th style="padding: 20px;border-bottom:1px solid #ccc;">' . $_POST["popcountry"] .'</th>
                          </tr>                          
                           
                      </table>
                    </td>
                  </tr>
                </table>
              </div>

              <div class="movableContent">
                <table width="720" border="0" cellspacing="0" cellpadding="0"  align="center" >                  
                  <tr>
                    <td valign="top" class="bgItem">
                      <p style="text-align: center; padding: 20px 0">© ' . date('Y') . ' Technoduce Info Solutions Pvt. Ltd. All rights reserved. </p>
                    </td>
                  </tr>
                </table>
              </div>
        

            </td>
          </tr>

        

        </table>
      </td>
    </tr>

    <tr><td height="55"></td></tr>
    </table>
      </body>
      </html>
';
		$mailer->AltBody = 'This is a plain-text message body';
		if(!$mailer->Send())
		{
		echo "Mailer Error: " . $mailer->ErrorInfo;
		}
		else
		{
			header("Location: /thankyou ");
		}
		   }
  }
  