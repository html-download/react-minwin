'use strict';
const Action = require('./actions');
const Form = require('./form.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Store = require('./store');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class ContactPage extends React.Component {

    constructor(props) {
        
        Action.getConfig();
        super(props);
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());        
    }

    render() {

        return (
            <section className="page-container">
                <Helmet>
                    <title>Email Setting</title>
                </Helmet>
                <div className="container md">

                    <div className="row">
                        <div className="col-md-3 text-right">
                            <ul className="quickLinks reset">
                                <li><Link to="/admin/account-setting">Account Settings</Link></li>
                                <li><Link className="active" to="/admin/email-setting">Email Settings</Link></li>
                            </ul>
                        </div>
                        <div className="col-md-9">
                            <div className="white-box padd-30">
                                <div className="form-box-horizandal">
                                    <Form 
                                        history={this.props.history}
                                        { ...this.state } />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        );
    }
}


module.exports = ContactPage;
