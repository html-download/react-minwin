'use strict';
const Actions = require('../actions');
const Button = require('../../../../components/form/button.jsx');
const CheckboxControl = require('../../../../components/form/checkbox-control.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');


const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class LoginPage extends React.Component {
    constructor(props) {

        super(props);

        
        this.input = {};
        this.state = Store.getState();
    }

    componentDidMount() {
        //Actions.getUserCreds();

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.username) {
            this.input.username.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.login({
            username: this.input.username.value(),
            password: this.input.password.value()
        });
    }

    render() {
        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success" className="alert alert-success">
                Success. Redirecting...
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.username = c)}
                    name="username"
                    placeholder="Email Id"
                    hideLabel={true}
                    hasError={this.state.hasError.username}
                    help={this.state.help.username}
                    disabled={this.state.loading}
                />
                <TextControl
                    ref={(c) => (this.input.password = c)}
                    name="password"
                    placeholder="Password"
                    hideLabel={true}
                    type="password"
                    hasError={this.state.hasError.password}
                    help={this.state.help.password}
                    disabled={this.state.loading}
                    groupClasses={{'show_hide': true}}
                />
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'form-group': false, 'row': true, 'mb-3': true}}>
                    <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'form-group': false, 'col-md-6': true}}>
                        {/*<CheckboxControl
                            ref={(c) => (this.input.remember_me = c)}
                            name="remember_me"
                            id="remember_me"
                            onChange={(e) => {}}
                            hasError={this.state.hasError.remember_me}
                            help={this.state.help.remember_me}
                            disabled={this.state.loading}
                            inputClasses={{'custom-control-input': true, 'form-control': false}}
                            groupClasses={{'form-group': false, 'custom-control': true, 'custom-checkbox': true, 'mb-25': true}}
                            labelClasses={{'custom-control-label': true, 'font-14': true, 'control-label': false, 'left-side': false}}
                            labelFor="remember_me"
                            label= {['Keep me logged in']}
                            labelPositionBottom={true}
                        />*/}
                    </ControlGroup>
                    <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'form-group': false, 'col-md-6': true}}>
                        <Button
                            type="submit"
                            inputClasses={{ 'btn-primary': true, 'btn-block': true, 'loader': true }}
                            disabled={this.state.loading}>
                            <Spinner space="right" show={this.state.loading} />
                            Login
                        </Button>
                    </ControlGroup>
                </ControlGroup>
                <p className="text-center">
                    <Link to="/login/forgot" >Having trouble logging in?</Link>
                </p>
            </fieldset>;
        }

        return (
            <section className="login-container text-center">
                <Helmet>
                    <title>Login</title>
                </Helmet>
                <div className="container-box">
                    <div className="full_row">
                        <div className="left-side">

                            <h3>Sign In</h3>
                            <p>By Signing Up, you can avail full features of our services.</p>
                            <p>Get an Account !!!</p>
                        </div>
                        <div className="right-side">

                            <div className="logo">
                                <img src="/public/media/images/logo.png" alt="Logo" />
                            </div>

                            <form onSubmit={this.handleSubmit.bind(this)}>
                                {alerts}
                                {formElements}
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}


module.exports = LoginPage;
