<?php include ('inc/header.php'); ?>

<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Our Product Demo</h1>
		<h2 class="head small wow fadeInUp">How can we help you today?</h2>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey">
	<div class="container">
		<div class="row product_demo">
			<div class="col-sm-6">
				<h3 class="wow fadeInUp">Backend - Demo</h3>
				<p><img src="images/dashboard.png" alt="Ontabee backend demo" class="wow zoomIn"></p>
				<p><a href="https://godemo.ontabee.com/admin/login" target="_blank" class="btn wow fadeInUp">Go to Demo</a></p>
				<p class="info wow fadeInUp">
					<span>Username: <b>demo@ontabee.com</b></span>
					<span>Password: <b>tech@123</b></span>
				</p>
			</div> <!--col-sm-6-->

			<div class="col-sm-6">
				<h3 class="wow fadeInUp">Frontend - Demo</h3>
				<p><img src="images/frontend-demo.png" alt="Ontabee frontend demo" class="wow zoomIn"></p>
				<p><a href="https://godemo.ontabee.com" target="_blank" class="btn wow fadeInUp">Go to Demo</a></p>
				<p class="info wow fadeInUp">
					<span>Username: <b>ontabeedemo</b></span>
					<span>Password: <b>demo@123</b></span>
				</p>
			</div> <!--col-sm-6-->
		</div> <!--product_demo-->
	</div> <!--container-->
</section>

<?php include('inc/footer.php');?>