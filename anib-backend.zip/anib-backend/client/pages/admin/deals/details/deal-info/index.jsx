'use strict';
const Actions = require('../actions');
const DateHelper = require('../../../../../helpers/date-time');
const PropTypes = require('prop-types');
const React = require('react');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const CommonStore = require('../../../common-store/store');
const CommonAction = require('../../../common-store/action');
const TextControl = require('../../../../../components/form/text-control.jsx');
const Toaster = require('../../../../../helpers/toaster');

const propTypes = {
    _id: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    loading: PropTypes.bool
};

class DetailsForm extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        
        this.state = {
            id: props.id,
            vehicle_type: props.vehicle_type,
            vehicle_insured_value: props.vehicle_insured_value,
            minimum_retail_price: props.minimum_retail_price,
            maximum_retail_price: props.maximum_retail_price,
            emirates_of_registered: props.emirates_of_registered,
            current_cover: props.current_cover,
            no_of_passenger: props.no_of_passenger,
            current_insurer: props.current_insurer,
            first_registraion_date: props.first_registraion_date,
            rta_certificate_start_date: props.rta_certificate_start_date,
            policy_issue_date: props.policy_issue_date,
            years_without_claim: props.years_without_claim,
            claim_certificate_available: props.claim_certificate_available,
            is_private_car: props.is_private_car,
            is_car_modified: props.is_car_modified,
            is_car_gcc_spec: props.is_car_gcc_spec,
            editable_field: props.editable_field,
            enquiry_type:props.enquiry_type,
            enquiry_type_text:props.enquiry_type_text,
            number_of_passengers:props.number_of_passengers,

            emirate_id: props.emirate_id,
            emirate_name: props.emirate_name,
            is_third_party: props.is_third_party,
            is_uninsured: props.is_uninsured,
            is_mortgaged: props.is_mortgaged,
            place_of_registration_id: props.place_of_registration_id,
            place_of_registration: props.place_of_registration,
            registration_number: props.registration_number,
            vehicle_color: props.vehicle_color,
            seats: props.seats,
            cylinders: props.cylinders,
            tcf_number: props.tcf_number,
            chassis_number: props.chassis_number,
            engine_number: props.engine_number,
            plate_code: props.plate_code,
            vehicle_type: props.vehicle_type,
            vehicle_type_text: props.vehicle_type_text,
            year: props.year,
            year_key: props.year_key,
            vehicle_brand_key: props.vehicle_brand_key,
            vehicle_brand_name: props.vehicle_brand_name,
            vehicle_brand_model_key: props.vehicle_brand_model_key,
            vehicle_brand_model_name: props.vehicle_brand_model_name,
            vehicle_brand_model_trim_key: props.vehicle_brand_model_trim_key,
            vehicle_brand_model_trim_name: props.vehicle_brand_model_trim_name,
            policy_prev_expiry_date: props.policy_prev_expiry_date,
            insurer_code: props.insurer_code,
        };                
        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);
        this.getCountryOptions = this.getCountryOptions.bind(this);
        this.datePicker = this.datePicker.bind(this);
        this.getVehicleTypeOptions = this.getVehicleTypeOptions.bind(this);
        this.checkNumberic = this.checkNumberic.bind(this);
    }

    checkNumberic(e) {

        let inputValue = e.target.value;
        let numericValue  = inputValue.replace(/\D/g,'');
        e.target.value = numericValue.substring(0, 10);
    }

    componentWillReceiveProps(nextProps) {        

        this.props.year_key !== nextProps.year_key ? CommonAction.getVehicleBrand(nextProps.year_key) : null;
        this.props.vehicle_brand_key !== nextProps.vehicle_brand_key ? CommonAction.getVehicleBrandModel(nextProps.vehicle_brand_key) : null;
        this.props.vehicle_brand_model_key !== nextProps.vehicle_brand_model_key ? CommonAction.getCartTrim(nextProps.vehicle_brand_model_key) : null;
        this.setState({
            id: nextProps.id,
            enquiry_type: nextProps.enquiry_type,
            vehicle_type: nextProps.vehicle_type,
            vehicle_insured_value: nextProps.vehicle_insured_value,
            minimum_retail_price: nextProps.minimum_retail_price,
            maximum_retail_price: nextProps.maximum_retail_price,
            emirates_of_registered: nextProps.emirates_of_registered,
            current_cover: nextProps.current_cover,
            no_of_passenger: nextProps.no_of_passenger,
            current_insurer: nextProps.current_insurer,
            first_registraion_date: nextProps.first_registraion_date,
            rta_certificate_start_date: nextProps.rta_certificate_start_date,
            policy_issue_date: nextProps.policy_issue_date,
            years_without_claim: nextProps.years_without_claim,
            claim_certificate_available: nextProps.claim_certificate_available,
            is_private_car: nextProps.is_private_car,
            is_car_modified: nextProps.is_car_modified,
            is_car_gcc_spec: nextProps.is_car_gcc_spec,
            editable_field: nextProps.editable_field,            
            enquiry_type_text:nextProps.enquiry_type_text,
            number_of_passengers:nextProps.number_of_passengers,

            emirate_id: nextProps.emirate_id,
            emirate_name: nextProps.emirate_name,
            is_third_party: nextProps.is_third_party,
            is_uninsured: nextProps.is_uninsured,
            is_mortgaged: nextProps.is_mortgaged,
            place_of_registration_id: nextProps.place_of_registration_id,
            place_of_registration: nextProps.place_of_registration,
            registration_number: nextProps.registration_number,
            vehicle_color: nextProps.vehicle_color,
            seats: nextProps.seats,
            cylinders: nextProps.cylinders,
            tcf_number: nextProps.tcf_number,
            chassis_number: nextProps.chassis_number,
            engine_number: nextProps.engine_number,
            plate_code: nextProps.plate_code,
            vehicle_type: nextProps.vehicle_type,
            vehicle_type_text: nextProps.vehicle_type_text,            
            year: nextProps.year,
            year_key: nextProps.year_key,
            vehicle_brand_key: nextProps.vehicle_brand_key,
            vehicle_brand_name: nextProps.vehicle_brand_name,
            vehicle_brand_model_key: nextProps.vehicle_brand_model_key,
            vehicle_brand_model_name: nextProps.vehicle_brand_model_name,
            vehicle_brand_model_trim_key: nextProps.vehicle_brand_model_trim_key,
            vehicle_brand_model_trim_name: nextProps.vehicle_brand_model_trim_name,
            policy_prev_expiry_date: nextProps.policy_prev_expiry_date,
            insurer_code: nextProps.insurer_code,
        });        
    }

    submitCustomer(event, field_name) {
                
        event.preventDefault();
        event.stopPropagation();
        let value = (this.input[field_name]) ? this.input[field_name].value() : undefined;
        switch (field_name) {
            case 'tcf_number':                
                if(parseInt(value.length) !== 8 && parseInt(value.length) !== 10) {
                    Toaster.error('TCF Number should be 8 or 10 digit');
                    return ;    
                }
                break;
            case 'vehicle_brand_model_trim_key':
                field_name = 'vehicle_brand_model_trim_id';
                break;
            case 'vehicle_brand_model_key':
                field_name = 'vehicle_brand_model_id';
                break;
            case 'vehicle_brand_key':
                field_name = 'vehicle_brand_id';
                break;
            case 'year_key':
                field_name = 'year_id';
                break;
            case 'first_registraion_date':
                value = DateHelper._getDbFormat(this.state.first_registraion_date);
                break;
            case 'rta_certificate_start_date':
                value = DateHelper._getDbFormat(this.state.rta_certificate_start_date);
                break;
            case 'policy_issue_date':
                value = DateHelper._getDbFormat(this.state.policy_issue_date);
                break;
            case 'policy_prev_expiry_date':
                value = DateHelper._getDbFormat(this.state.policy_prev_expiry_date);
                break;
            case 'vehicle_insured_value':
                value = value.replace(/\D/g,'');
                break;
        }        
        const id = this.props.deal_id;
        const data = {
            'attribute_key': field_name,
            'attribute_value': value
        };
        value ? Actions.saveDealDetails(id, data) : null;
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

    }

    addEditable(field) {

        Actions.addEditable(field);
    }

    getUpdateButton(field){

        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field); } } className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) } } className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        );
    }

    datePicker(date,field) {
        
        if (DateHelper._getDateFormat(date)) {
            Actions.datePickerDealInfo(date,field);
        }
    }

    getLabelContent(name, field, value, type) {
                
        switch(field) {

            case "vehicle_insured_value":
                return (
                    <div>
                     <div class="form-gp">
                                <label class="side">The Car is Unmodified</label>
                                <div class="side-input">
                                    <a href="#" data-type="select" data-source='[{"value":1,"text":"Yes"}, {"value":2,"text":"No"}]' class="add-forms">Yes</a>
                                </div>
                            </div>
                    <div className="form-gp">
                        <label className="side req">{name}</label>
                        <div className="side-input">
                            {
                                (value && value !== '') ? (
                                    <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{value}</a>
                                ) : (
                                    <a className="add-forms editable editable-click editable-empty" data-type={type} onClick={ (e) => { this.addEditable(field) }} > +Add</a>
                                )
                            }                            
                        </div>                        
                    </div>
                    <p> The Sum Insured value can be 
                        <br/>
                        <b>{this.state.minimum_retail_price}</b> - <b>{this.state.maximum_retail_price}</b> 
                    </p>
                    </div>
                );
                break;
            default:
                return (
                    <div className="form-gp">
                        <label className="side req">{name}</label>
                        <div className="side-input">
                            {
                                (value && value !== '') ? (
                                    <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{value}</a>
                                ) : (
                                    <a className="add-forms editable editable-click editable-empty" data-type={type} onClick={ (e) => { this.addEditable(field) }} > +Add</a>
                                )
                            }
                        </div>
                    </div>
                );
                break;
        }        
    }   

    
    getEmirateOptions() {        

        const emirates = CommonStore.getState().emirate_data;
        if (emirates.length === 0) {
            return null;
        }
        
        const data = emirates.map((data, index) => {
        return (
            <option 
                key={`emirate-option-${index}`} 
                value={data.emirate_key}
                data-tokens={`${data.emirate_name}`}>
                {`${data.emirate_name}`}
            </option>
            );
        });
        return data;
    }

    getPlaceOfRegistraionOptions() {        

        const place_of_registration = CommonStore.getState().place_of_registration;
        if (place_of_registration.length === 0) {
            return null;
        }
        
        const data = place_of_registration.map((data, index) => {
        return (
            <option 
                key={`place_of_registration-option-${index}`} 
                value={data.place_of_registration_key}
                data-tokens={`${data.place_of_registration_name}`}>
                {`${data.place_of_registration_name}`}
            </option>
            );
        });
        return data;
    }

    getVehicleBrandOptions() {

        const brands = CommonStore.getState().vehicle_brand;
        if (brands.length === 0) {
            return null;
        }
        
        const data = brands.map((data, index) => {
        return (
            <option 
                key={`brand-option-${index}`} 
                value={data.vehicle_brand_key}
                data-tokens={`${data.vehicle_brand_name}`}>
                {`${data.vehicle_brand_name}`}
            </option>
            );
        });
        return data;
    }

    getVehicleBrandModelOptions() {        

        const models = CommonStore.getState().vehicle_models;
        if (models.length === 0) {
            return null;
        }
        
        const data = models.map((data, index) => {
        return (
            <option 
                key={`model-option-${index}`} 
                value={data.vehicle_brand_model_key}
                data-tokens={`${data.vehicle_brand_model_name}`}>
                {`${data.vehicle_brand_model_name}`}
            </option>
            );
        });
        return data;
    }


    getVehicleTypeOptions() {

        const vehicleTypes = CommonStore.getState().vehicle_type;
        if (vehicleTypes.length === 0) {
            return null;
        }
        
        const data = vehicleTypes.map((data, index) => {
        return (
            <option 
                key={`vehicle-type-option-${index}`} 
                value={data.value}
                data-tokens={`${data.type}`}>
                {`${data.type}`}
            </option>
            );
        });
        return data;
    }

    getCountryOptions() {
        
        const places = CommonStore.getState().place_of_registration;

        if (places.length === 0) {
            return null;
        }
        
        const data = places.map((data, index) => {

        return (
            <option 
                key={`places-option-${index}`} 
                value={data.place_of_registration_key}
                data-tokens={`${data.place_of_registration_key}`}>
                {`${data.place_of_registration_name}`}
            </option>
            );
        });
        return data;
    }

    getVehicleModelYear() {
        
        const model_year = CommonStore.getState().vehicle_model_year;

        if (model_year.length === 0) {
            return null;
        }
        
        const data = model_year.map((data, index) => {

        return (
            <option 
                key={`emirate-option-${index}`} 
                value={data.year_key}
                data-tokens={`${data.year}`}>
                {`${data.year}`}
            </option>
            );
        });
        return data;
    }

    getVehicleTrims() {
        
        const vehicle_trims = CommonStore.getState().vehicle_trims;

        if (vehicle_trims.length === 0) {
            return null;
        }
        
        const data = vehicle_trims.map((data, index) => {

        return (
            <option 
                key={`emirate-option-${index}`} 
                value={data.vehicle_brand_model_trim_key}
                data-tokens={`${data.vehicle_brand_model_trim_name}`}>
                {`${data.vehicle_brand_model_trim_name}`}
            </option>
            );
        });
        return data;
    }

    getEnquiryTypes(){
        
        const enquiry_types = CommonStore.getState().enquiry_types;        
        if (enquiry_types.length === 0) { 
            return null;
        }

        const data = enquiry_types.map((enquiry_types, index) => {
            
        return <option
                key={`enquiry-option-${index}`}
                value={enquiry_types.value}
                data-tokens={`${enquiry_types.type}`}>
                {`${enquiry_types.type}`}
            </option>;
        });
        return data;
    }

    render() {                             

        const formElements = <fieldset>            
            {
                this.state.editable_field === 'enquiry_type' ? (
                    <SelectControl
                        ref={(c) => (this.input.enquiry_type = c)}
                        name="enquiry_type"
                        label="Enquiry type"
                        defaultValue={this.state.enquiry_type}
                        hasError={this.props.hasError.enquiry_type}
                        help={this.props.help.enquiry_type}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={ { 'control-label': false, 'side': true } }
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('enquiry_type')}
                        appendElementNotString={true}
                    >
                        <option value="">Select Option</option>
                        { this.getEnquiryTypes() }
                    </SelectControl>
                ) : this.getLabelContent('Enquiry type', 'enquiry_type', this.state.enquiry_type_text, 'select')
            }
            {
                this.state.editable_field === 'year_key' ? (
                    <SelectControl
                        ref={(c) => (this.input.year_key = c)}
                        name="year_key"
                        label="Vehicle Modal Year"
                        disabled={this.props.loading}
                        defaultValue={this.state.year_key}
                        hasError={this.props.hasError.year_key}
                        help={this.props.help.year_key}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('year_key')}
                        appendElementNotString={true}
                        isKeyEnable={true}                        
                        onChange={(e) => {}}
                    >
                        <option value="">Select Option</option>
                        { this.getVehicleModelYear() }
                    </SelectControl>
                ) : this.getLabelContent('Vehicle Modal Year', 'year_key', this.state.year, 'select')
            }
            {
                this.state.editable_field === 'vehicle_brand_key' ? (
                    <SelectControl
                        ref={(c) => (this.input.vehicle_brand_key = c)}
                        name="vehicle_brand_key"
                        label="Vehicle Brand"
                        disabled={this.props.loading}
                        defaultValue={this.state.vehicle_brand_key}
                        hasError={this.props.hasError.vehicle_brand_key}
                        help={this.props.help.vehicle_brand_key}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('vehicle_brand_key')}
                        appendElementNotString={true}
                        isKeyEnable={true}                        
                        onChange={(e) => {}}
                    >
                        <option value="">Select Option</option>
                        { this.getVehicleBrandOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Vehicle Brand', 'vehicle_brand_key', this.state.vehicle_brand_name, 'select')
            }
            
            {
                /* this.state.editable_field === 'vehicle_brand_model_key' ? (
                    <SelectControl
                        ref={(c) => (this.input.vehicle_brand_model_key = c)}
                        name="vehicle_brand_model_key"
                        label="Vehicle Brand Model"
                        disabled={this.props.loading}
                        defaultValue={this.state.vehicle_brand_model_key}
                        hasError={this.props.hasError.vehicle_brand_model_key}
                        help={this.props.help.vehicle_brand_model_key}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('vehicle_brand_model_key')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        onChange={(e) => {}}
                    >
                        <option value="">Select Option</option>
                        { this.getVehicleBrandModelOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Vehicle Brand Model', 'vehicle_brand_model_key', this.state.vehicle_brand_model_name, 'select') */
            }

            {
                /* this.state.editable_field === 'vehicle_brand_model_trim_key' ? (
                    <SelectControl
                        ref={(c) => (this.input.vehicle_brand_model_trim_key = c)}
                        name="vehicle_brand_model_trim_key"
                        label="Vehicle Model Trim"
                        disabled={this.props.loading}
                        defaultValue={this.state.vehicle_brand_model_trim_key}
                        hasError={this.props.hasError.vehicle_brand_model_trim_key}
                        help={this.props.help.vehicle_brand_model_trim_key}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('vehicle_brand_model_trim_key')}
                        appendElementNotString={true}
                        isKeyEnable={true}                        
                        onChange={(e) => {}}
                    >
                        <option value="">Select Option</option>
                        { this.getVehicleTrims() }
                    </SelectControl>
                ) : this.getLabelContent('Vehicle Model Trim', 'vehicle_brand_model_trim_key', this.state.vehicle_brand_model_trim_name, 'select') */
            }
            
            {                
                this.state.editable_field === 'vehicle_insured_value' ? (
                    <TextControl
                        ref={(c) => (this.input.vehicle_insured_value = c)}
                        name="vehicle_insured_value"
                        label={ "Sum Insured (AED) "+this.state.minimum_retail_price }
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{ 'form-group': true, 'form-gp': true }}
                        labelClasses={{ 'control-label': false, 'side': true }}
                        inputClasses={{ 'form-control': true, 'add-forms': true }}
                        appendElement={this.getUpdateButton('vehicle_insured_value')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.vehicle_insured_value}
                        /* onChange={(e) => {}} */
                    />
                ) : this.getLabelContent('Sum Insured (AED)', 'vehicle_insured_value', this.state.vehicle_insured_value, 'text')
            }
            {
                /* this.state.editable_field === 'emirate_id' ? (
                    
                    <SelectControl
                        ref={(c) => (this.input.emirate_id = c)}
                        name="emirate_id"
                        label="Emirate of registration"
                        defaultValue={this.state.emirate_id}
                        hasError={this.props.hasError.emirate_id}
                        help={this.props.help.emirate_id}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('emirate_id')}
                        appendElementNotString={true}                        
                    >
                        <option value="">Select Option</option>
                        { this.getEmirateOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Emirate of registration', 'emirate_id', this.state.emirate_name, 'select') */
            }
        
            {
                this.state.editable_field === 'place_of_registration_id' ? (
                    
                    <SelectControl
                        ref={(c) => (this.input.place_of_registration_id = c)}
                        name="place_of_registration_id"
                        label="Place of registration"
                        defaultValue={this.state.place_of_registration_id}
                        hasError={this.props.hasError.place_of_registration_id}
                        help={this.props.help.place_of_registration_id}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('place_of_registration_id')}
                        appendElementNotString={true}                        
                    >
                        <option value="">Select Option</option>
                        { this.getPlaceOfRegistraionOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Place of registration', 'place_of_registration_id', this.state.place_of_registration, 'select')
            }
            
            {
                /* this.state.editable_field === 'number_of_passengers' ? (
                    <TextControl
                        ref={(c) => (this.input.number_of_passengers = c)}
                        name="number_of_passengers"
                        label="No.of Passengers"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('number_of_passengers')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.number_of_passengers}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('No.of Passengers', 'number_of_passengers', this.state.number_of_passengers, 'text') */
            }
            
            {
                this.state.editable_field === 'first_registraion_date' ? (
                    <TextControl
                        ref={(c) => (this.input.first_registraion_date = c)}
                        name="first_registraion_date"
                        label="First Registration Date"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('first_registraion_date')}                        
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={ this.state.first_registraion_date !== undefined ? DateHelper._getDefaultFormat(this.state.first_registraion_date) : ''}
                        onChange={ (e) => { this.datePicker(e,'first_registraion_date')} }
                        isDatePicker={true}
                        maxDate={ new Date() }
                        
                    />
                ) : this.getLabelContent('First Registration Date', 'first_registraion_date', this.state.first_registraion_date, 'text')
            }

            {
                this.state.editable_field === 'rta_certificate_start_date' ? (
                    <TextControl
                        ref={(c) => (this.input.rta_certificate_start_date = c)}
                        name="rta_certificate_start_date"
                        label="RTA Certificate Start Date"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('rta_certificate_start_date')}                        
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={ this.state.rta_certificate_start_date !== undefined ? DateHelper._getDefaultFormat(this.state.rta_certificate_start_date) : ''}
                        onChange={ (e) => { this.datePicker(e,'rta_certificate_start_date')} }
                        isDatePicker={true}
                        maxDate={ new Date() }
                        
                    />
                ) : this.getLabelContent('RTA Certificate Start Date', 'rta_certificate_start_date', this.state.rta_certificate_start_date, 'text')
            }

            {
                this.state.editable_field === 'policy_prev_expiry_date' ? (
                    <TextControl
                        ref={(c) => (this.input.policy_prev_expiry_date = c)}
                        name="policy_prev_expiry_date"
                        label="Policy Previous Expiry Date"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('policy_prev_expiry_date')}                        
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={ this.state.policy_prev_expiry_date !== undefined ? DateHelper._getDefaultFormat(this.state.policy_prev_expiry_date) : ''}
                        onChange={ (e) => { this.datePicker(e,'policy_prev_expiry_date')} }
                        isDatePicker={true}
                        maxDate={ new Date() }
                        
                    />
                ) : this.getLabelContent('Policy Previous Expiry Date', 'policy_prev_expiry_date', this.state.policy_prev_expiry_date, 'text')
            }

            {
                this.state.editable_field === 'insurer_code' ? (
                    <TextControl
                        ref={(c) => (this.input.insurer_code = c)}
                        name="insurer_code"
                        label="Insurer Code"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('insurer_code')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.insurer_code}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Insurer Code', 'insurer_code', this.state.insurer_code, 'text')
            }

            {
                /* this.state.editable_field === 'years_without_claim' ? (
                    <TextControl
                        ref={(c) => (this.input.years_without_claim = c)}
                        name="years_without_claim"
                        label="Years without Cliam"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('years_without_claim')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.years_without_claim}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Years without Cliam', 'years_without_claim', this.state.years_without_claim, 'text') */
            }
            
            {
                this.state.editable_field === 'is_car_modified' ? (
                    <SelectControl
                        ref={(c) => (this.input.is_car_modified = c)}
                        key={'test'}
                        name="is_car_modified"
                        label="The Car is Unmodified"
                        defaultValue={this.state.is_car_modified === 1 ? 1 : 0 }
                        hasError={this.props.hasError.is_car_modified}
                        help={this.props.help.is_car_modified}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('is_car_modified')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        <option value="0">No</option>
                        <option value="1">Yes</option>
                    </SelectControl>
                ) : this.getLabelContent('The Car is Modified?', 'is_car_modified', (this.state.is_car_modified === 1) ? 'Yes' : 'No' , 'select')
            }
            {
                this.state.editable_field === 'is_car_gcc_spec' ? (
                    <SelectControl
                        ref={(c) => (this.input.is_car_gcc_spec = c)}
                        name="is_car_gcc_spec"
                        label="The Car is GCC?"
                        defaultValue={this.state.is_car_gcc_spec === 1 ? 1 : 2 }
                        hasError={this.props.hasError.is_car_gcc_spec}
                        help={this.props.help.is_car_gcc_spec}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('is_car_gcc_spec')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        <option value="2">No</option>
                        <option value="1">Yes</option>
                    </SelectControl>
                ) : this.getLabelContent('The Car is GCC?', 'is_car_gcc_spec', (this.state.is_car_gcc_spec === 1) ? 'Yes' : 'No', 'select')
            }
            {
                this.state.editable_field === 'is_mortgaged' ? (
                    <SelectControl
                        ref={(c) => (this.input.is_mortgaged = c)}
                        name="is_mortgaged"
                        label="Is Morgaged?"
                        defaultValue={this.state.is_mortgaged}
                        hasError={this.props.hasError.is_mortgaged}
                        help={this.props.help.is_mortgaged}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('is_mortgaged')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        <option value="2">No</option>
                        <option value="1">Yes</option>
                    </SelectControl>
                ) : this.getLabelContent('Is Morgaged?', 'is_mortgaged', (this.state.is_mortgaged === 1) ? 'Yes' : 'No', 'select')
            }
            {
                this.state.editable_field === 'is_third_party' ? (
                    <SelectControl
                        ref={(c) => (this.input.is_third_party = c)}
                        name="is_third_party"
                        label="Is Third Party?"
                        defaultValue={this.state.is_third_party}
                        hasError={this.props.hasError.is_third_party}
                        help={this.props.help.is_third_party}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('is_third_party')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        <option value="2">No</option>
                        <option value="1">Yes</option>
                    </SelectControl>
                ) : this.getLabelContent('Is Third Party?', 'is_third_party', (this.state.is_third_party === 1) ? 'Yes' : 'No', 'select')
            }
            {
                this.state.editable_field === 'is_uninsured' ? (
                    <SelectControl
                        ref={(c) => (this.input.is_uninsured = c)}
                        name="is_uninsured"
                        label="Is Uninsured?"
                        defaultValue={this.state.is_uninsured}
                        hasError={this.props.hasError.is_uninsured}
                        help={this.props.help.is_uninsured}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('is_uninsured')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        <option value="2">No</option>
                        <option value="1">Yes</option>
                    </SelectControl>
                ) : this.getLabelContent('Is Uninsured?', 'is_uninsured', (this.state.is_uninsured === 1) ? 'Yes' : 'No', 'select')
            }
            {
                this.state.editable_field === 'registration_number' ? (
                    <TextControl
                        ref={(c) => (this.input.registration_number = c)}
                        name="registration_number"
                        label="Registration Number"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('registration_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.registration_number}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Registration Number', 'registration_number', this.state.registration_number, 'text')
            }
            {
                this.state.editable_field === 'vehicle_color' ? (
                    <TextControl
                        ref={(c) => (this.input.vehicle_color = c)}
                        name="vehicle_color"
                        label="Vehicle Color"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('vehicle_color')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.vehicle_color}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Vehicle Color', 'vehicle_color', this.state.vehicle_color, 'text')
            }
            {
                this.state.editable_field === 'seats' ? (
                    <TextControl
                        ref={(c) => (this.input.seats = c)}
                        name="seats"
                        label="No Of Seats"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('seats')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.seats}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('No Of Seats', 'seats', this.state.seats, 'text')
            }
            {
                this.state.editable_field === 'cylinders' ? (
                    <TextControl
                        ref={(c) => (this.input.cylinders = c)}
                        name="cylinders"
                        label="Cylinders"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('cylinders')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.cylinders}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Cylinders', 'cylinders', this.state.cylinders, 'text')
            }
            {
                this.state.editable_field === 'tcf_number' ? (
                    <TextControl
                        ref={(c) => (this.input.tcf_number = c)}
                        name="tcf_number"
                        label="TCF Number"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('tcf_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.tcf_number}
                        onChange={ (e) => this.checkNumberic(e) }
                    />
                ) : this.getLabelContent('TCF Number', 'tcf_number', this.state.tcf_number, 'text')
            }
            {
                this.state.editable_field === 'chassis_number' ? (
                    <TextControl
                        ref={(c) => (this.input.chassis_number = c)}
                        name="chassis_number"
                        label="Chassis Number"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('chassis_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.chassis_number}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Chassis Number', 'chassis_number', this.state.chassis_number, 'text')
            }
            {
                this.state.editable_field === 'engine_number' ? (
                    <TextControl
                        ref={(c) => (this.input.engine_number = c)}
                        name="engine_number"
                        label="Engine Number"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('engine_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.engine_number}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Engine Number', 'engine_number', this.state.engine_number, 'text')
            }
            {
                this.state.editable_field === 'plate_code' ? (
                    <TextControl
                        ref={(c) => (this.input.plate_code = c)}
                        name="plate_code"
                        label="Plate Code"
                        disabled={this.props.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('plate_code')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.plate_code}
                        onChange={(e) => {}}
                    />
                ) : this.getLabelContent('Plate Code', 'plate_code', this.state.plate_code, 'text')
            }
            {
                this.state.editable_field === 'vehicle_type' ? (
                    <SelectControl
                        ref={(c) => (this.input.vehicle_type = c)}
                        name="vehicle_type"
                        label="Vehicle Type"
                        defaultValue={this.state.vehicle_type}
                        hasError={this.props.hasError.vehicle_type}
                        help={this.props.help.vehicle_type}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('vehicle_type')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        { this.getVehicleTypeOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Vehicle Type', 'vehicle_type', this.state.vehicle_type_text, 'select')
            }            

        </fieldset>;

        let state = this.state;
        return (
            
            <div className={ `white-box mt-25 ${!this.props.hydrated ? 'loader-tab-content' : ''}` }>
                
                <h5 className="mb-3 f18">Enquiry Info</h5>

                <form onSubmit={this.handleSubmit.bind(this)}>                    
                    {formElements}
                </form>

            </div>
        );
    }
}

DetailsForm.propTypes = propTypes;

module.exports = DetailsForm;
