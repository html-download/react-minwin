/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AuthRule', {
    name: {
      type: DataTypes.STRING(64),
      allowNull: false,
      primaryKey: true,
      field: 'name'
    },
    data: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'data'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_auth_rule'
  });
};
