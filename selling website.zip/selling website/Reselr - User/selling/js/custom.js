$(document).ready(function(){


// modal shown
$('.modal').on('shown.bs.modal', function (e) {
  $('body').addClass('modal-open');
})
$('.modal').on('hidden.bs.modal', function (e) {
   $('body').removeClass('modal-open');
})


// portfolio owl carousel
$('.owl-carousel').owlCarousel({
  
items:1,
loop: true,
  nav: true,
  dots: false,
  margin: 10,
  autoplay: true, 
   navText : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})

//res menu res-menu
// menu responsive click
$(".res-menu").click(function() {
  $(".site-left").toggleClass('open');
    $("body").toggleClass('overflow');
});
$(".res-close").click(function() {
  $(".site-left").removeClass('open');
    $("body").removeClass('overflow');
});


});



