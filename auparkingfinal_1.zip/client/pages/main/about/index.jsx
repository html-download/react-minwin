const React = require('react');
const ReactHelmet = require('react-helmet');
const LocationSearchInput = require('../lots/auto-complete-form.jsx');

const Helmet = ReactHelmet.Helmet;


class AboutPage extends React.Component {
    render() {

        return (
            <div className="content-wrapper error_page cms">
                <Helmet>
                    <title>About us</title>
                </Helmet>
                <section className="content">
                    <h3>What Is AU Parking?</h3>
                    <p>Searching for a parking place is a burden that often takes up far too much of drivers’ valuable time and unnecessarily eats into their fuel costs. AU Parking strives to lift that burden using an innovative technology that shows drivers the availability of open spaces in a parking lot in real time on their smartphones, tablets, or computers.     Using cameras installed in a parking lot, AU Parking uses digital video parsing technology to process live video streams that accurately monitor open or filled parking spaces in a lot or deck. A user can access the technology via the AU Parking app on his or her smart phone or tablet to reveal the location of available spaces, the length of time cars have been parked and other useful information for both the customer and parking manager. AU Parking is powered by Fopark, a product of Focus Engineering LLC.</p>
                </section>

            </div>
        );
    }
}


module.exports = AboutPage;