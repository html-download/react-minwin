'use strict';
const React = require('react');
const ReactRouter = require('react-router-dom');


const Link = ReactRouter.Link;


class Footer extends React.Component {
    render() {

        const year = new Date().getFullYear();

        return (
            <footer className="footer text-center">
                <div className="container relative">
                    <button className="btn-top wow zoomIn btn" onClick={e => { window.scroll({top: 0, left: 0, behavior: 'smooth' }) }}><i className="fa fa-angle-up"></i></button>
                    <ul className="qk_links wow fadeInUp">
                        <li><Link to="/about">About us</Link></li>
                        <li><Link to="/terms-and-conditions">Terms and Conditions</Link></li>
                        <li><Link to="/privacy-policy">Privacy Policy</Link></li>
                        <li><Link to="/contact">Contact Us</Link></li>
                    </ul>
                    <div className="pay_icon wow fadeInUp">
                        <span> <img src="/public/media/images/pay1.png"/></span>
                        <span><img src="/public/media/images/pay2.png"/></span>
                        <span><img src="/public/media/images/pay3.png"/></span>
                        <span><img src="/public/media/images/pay4.png"/></span>
                    </div>
                    <div className="social-links wow fadeInUp">
                        <a href="" className="color1" target="_blank"><i className="fa fa-facebook"></i> <span className="res">Facebook</span></a>
                        <a href="" className="color2" target="_blank"><i className="fa fa-twitter"></i> <span className="res">Twitter</span></a>
                        <a href="" className="color3" target="_blank"><i className="fa fa-google-plus"></i><span className="res"> Google Plus</span></a>
                        <a href="" className="color4" target="_blank"><i className="fa fa-linkedin"></i> <span className="res">Linkedin</span></a>
                        <a href="" className="color5" target="_blank"><i className="fa fa-youtube"></i> <span className="res">Youtube</span></a>
                    </div>
                    <p className="wow fadeInUp">© Copyright ANIB 2019 | All Rights Reserved</p>

                </div>
            </footer>
        );
    }
}


module.exports = Footer;
