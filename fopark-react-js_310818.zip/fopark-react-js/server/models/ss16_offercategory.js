/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Offercategory', {
    offeritemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'offeritem_id'
    },
    offertypvalue: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'offertypvalue'
    },
    offerExpirydatetime: {
      type: DataTypes.STRING(25),
      allowNull: false,
      field: 'offer_expirydatetime'
    },
    vendorId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'vendor_id'
    },
    vendorItemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'vendor_item_id'
    },
    itemPricePerUnit: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'item_price_per_unit'
    },
    discountType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'Discount_type'
    },
    discountpercent: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'discountpercent'
    },
    discountamount: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'discountamount'
    },
    offeredamount: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'offeredamount'
    },
    categoryKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'category_key'
    },
    itemKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'item_key'
    }
  }, {
    tableName: 'ss16_offercategory'
  });
};
