/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Image', {
    imageId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'image_id'
    },
    imageKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'image_key'
    },
    itemId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'item_id'
    },
    imageUserId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'image_user_id'
    },
    imageUserType: {
      type: DataTypes.ENUM('admin','vendor','customer'),
      allowNull: false,
      defaultValue: 'vendor',
      field: 'image_user_type'
    },
    moduleType: {
      type: DataTypes.ENUM('admin','vendor','customer','sub category','banner','vendor_item','guides','home_ads'),
      allowNull: true,
      field: 'module_type'
    },
    imagePath: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'image_path'
    },
    imageFileSize: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'image_file_size'
    },
    imageWidth: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'image_width'
    },
    imageHeight: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'image_height'
    },
    imageDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'image_datetime'
    },
    imageIpAddress: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'image_ip_address'
    },
    vendorimageSortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'vendorimage_sort_order'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    imageStatus: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'image_status'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_image'
  });
};
