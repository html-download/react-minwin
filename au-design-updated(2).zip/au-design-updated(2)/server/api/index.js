
exports.register = function (server, options, next) {
	server.route({
        method: 'GET',
        path: '/',
        handler: function (request, reply) {

            reply({ message: 'Welcome to the plot device.' });
        }
    });

    server.route({
        method: 'GET',
        path: '/bike/count',
        handler: function (request, reply) {
            let URL = request.query.url;
            let Bearer = request.query.bearer;

            var request = require("request");

            var options = { 
              method: 'GET',
              url: URL,
              headers: { 
                'Cache-Control': 'no-cache',
                Authorization: 'Bearer '+Bearer 
              } 
            };

            request(options, function (error, response, body) {
              //if (error) throw new Error(error);
              if (!error && response.statusCode == 200) {
                return reply(body);
              } else {
                return reply({
                  available_bikes : 0
                })
              }

            });
            
        }
    });


    next();
};


exports.register.attributes = {
    name: 'index'
};
