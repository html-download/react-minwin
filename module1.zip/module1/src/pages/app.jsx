import React from 'react';
import {BrowserRouter} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

import AppUniversal from './appuniversal.jsx';

const app = (

	<BrowserRouter>
	<AppUniversal/>
	</BrowserRouter>
); 

export default app;
