/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AdvertCategory', {
    advertId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'advert_id'
    },
    categoryId: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'category_id'
    },
    advertPosition: {
      type: DataTypes.ENUM('top','bottom'),
      allowNull: false,
      defaultValue: 'top',
      field: 'advert_position'
    },
    advertCode: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'advert_code'
    },
    status: {
      type: DataTypes.ENUM('Active','Inactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    }
  }, {
    tableName: 'ss16_advert_category'
  });
};
