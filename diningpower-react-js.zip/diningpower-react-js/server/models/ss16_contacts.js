/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Contacts', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    contactName: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'contact_name'
    },
    contactEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'contact_email'
    },
    contactPhone: {
      type: DataTypes.STRING(25),
      allowNull: false,
      field: 'contact_phone'
    },
    subject: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'subject'
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'message'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      field: 'trash'
    }
  }, {
    tableName: 'ss16_contacts'
  });
};
