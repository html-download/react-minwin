/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AccessControl', {
    accessId: {
      type: DataTypes.INTEGER(12),
      allowNull: false,
      primaryKey: true,
      field: 'access_id'
    },
    roleId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'role_id'
    },
    adminId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'admin_id'
    },
    authItem: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'auth_item'
    },
    create: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'create'
    },
    update: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'update'
    },
    delete: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'delete'
    },
    manage: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'manage'
    },
    controller: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'controller'
    },
    default: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '0',
      field: 'default'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_access_control'
  });
};
