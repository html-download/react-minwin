document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.bundle.min.js" ></scr'+'ipt>');



