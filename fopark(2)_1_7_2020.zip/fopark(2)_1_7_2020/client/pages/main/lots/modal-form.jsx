'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    show: PropTypes.bool,
    selected : PropTypes.string,
    selectedLatLng : PropTypes.string,
    title : PropTypes.string,
    percentage : PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    color : PropTypes.string,
    lot_status : PropTypes.number
};


class ModalForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = { lat: '', lng: '' };
    }
    render() {
        let msg;
        if (this.props.lot_status) {                
            if (this.props.percentage >= 95) {
                msg = 'Lot is '+this.props.percentage+'% occupied, your probability of finding an open space is low, please go back and select another lot';
            }
            else if (this.props.percentage >= 85 && this.props.percentage < 95) {
                msg = 'Lot is '+this.props.percentage+'% occupied, you may find an open space, if you arrive to the lot soon';
            }
            else {
                msg = 'Lot is '+this.props.percentage+'% occupied, you have a high probability of finding an open space';
            }
        } else {
            msg = 'NO DATA AVAILABLE';
        }
        return (
            <Modal
                id="lot_extention"
                header={false}
                footer={false}
                show={this.props.show}
                onClose={Actions.hideCreateNew}>
                <h4>{this.props.title}</h4>
                <a className="lot_info" style={{ background : this.props.color}}>{msg}</a>
                
                <Link to={`/lots/${this.props.selected}`} className='btn' onClick={Actions.hideCreateNew}>View Lot Map</Link>
                {(UserIdentity._checkCurrentAddress() !== null) ? (
                    <a target="_blank" href={`https://www.google.com/maps/dir/${this.props.selectedLatLng}/${UserIdentity._checkCurrentAddress().lat},${UserIdentity._checkCurrentAddress().lng}`} className='btn'>Get Driving Direction</a>
                ) : (
                    <a target="_blank" href={`https://www.google.com/maps/dir/${this.props.selectedLatLng}//`} className='btn'>Get Driving Direction</a>
                )}
                <a className="btn" onClick={Actions.hideCreateNew}>Go Back</a>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
