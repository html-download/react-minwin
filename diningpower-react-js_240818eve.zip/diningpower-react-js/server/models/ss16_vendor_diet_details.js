/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorDietDetails', {
    dietDetailId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'diet_detail_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    dietId: {
      type: DataTypes.STRING(64),
      allowNull: false,
      defaultValue: '',
      field: 'diet_id'
    },
    type: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'type'
    },
    days: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'days'
    },
    startTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'start_time'
    },
    endTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'end_time'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_vendor_diet_details'
  });
};
