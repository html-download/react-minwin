'use strict';
const Actions = require('./actions');
const Store = require('./store');
const Alert = require('../../../../components/alert.jsx');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const CommonHelper = require('../../../../helpers/common-functions');
const LinkState = require('../../../../helpers/link-state.js');
const Modal = require('../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../components/form/spinner.jsx');
const ReactSelectControl = require('../../../../components/form/react-select-control.jsx');
const TextControl = require('../../../../components/form/text-control.jsx');
import { Form, FormGroup, Label, Input, FormText } from 'reactstrap';

const propTypes = {
    email: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    mobile_no: PropTypes.string,
    show: PropTypes.bool,
    name: PropTypes.string,
    nationality: PropTypes.string
};


class CreateNewForm extends React.Component {
    constructor(props) {

        super(props);
        
        /** Initial Request */
        this.props.from_customer ? Actions.getCustomerDetails(this.props.customer_id) : undefined
        Actions.getEnquiryType();
        Actions.getYear();

        this.els = {};
        
        this.state = Store.getState();  

        this.getCustomers = this.getCustomers.bind(this);
        this.getMake = this.getMake.bind(this);
        this.getMakeModel = this.getMakeModel.bind(this);
        this.getTrim = this.getTrim.bind(this);
    }    

    componentDidMount() {
        
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    componentDidUpdate() {

        if (this.props.show && this.state.customer && this.state.name.length === 0) {
            this.els.customer.focus();
        }
    }

    getCustomers(customer_type) {
        Actions.getCutomerResults(customer_type);
    }

    getMake(value) {

        Actions.getMake({
            year_id: value
        });
    }

    getMakeModel(value) {

        Actions.getMakeModel({
            vehicle_brand_id: value,
            /* model_year: this.els.model_year.value() */
        });

    }

    getTrim(value) {

        Actions.getTrim({
            vehicle_brand_model_id: value
        });

    }

    onSubmit(event) {

        event.preventDefault();
        event.stopPropagation();
        
        let formData = {
            year_id: this.els.model_year.value(),
            brand_id: this.els.make.value(),
           /*  brand_model_id: this.els.make_model.value(), */
            /* trim_id: this.els.trim.value(), */
            enquiry_type: this.els.enquiry_type.value(),
            is_car_gcc_spec: this.els.vehicle_specification.value(),
            /* number_of_passengers: this.els.no_of_passenger.value(),
            vehicle_insured_value: this.els.sub_insured.value(), */
        };
        if(this.props.from_customer) {
            formData['customer_type'] = this.props.customer_type;
            formData['customer_id'] = this.props.customer_id;
        } else {
            formData['customer_type'] = this.els.customer_type.value();
            formData['customer_id'] = this.els.customer.value();
        }

        Actions.createNew(formData, this.props.history, this.props.searchData, this.props.parentAction);        
    }

    render() {

        let alert;        
        if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }        
        const currentInsurenceStatusInitalValue = {
            label:(this.state.current_status === 1) ? 'Insured' : 'Uninsured', value: this.state.current_status
        };
        
        let customersList = [];
        if(!this.props.from_customer && this.els.customer_type) {
            customersList = this.els.customer_type.value() === 1 ? CommonHelper.getOptionData(this.state.customer_data, 'customer_key', 'name', 'New Customer') : CommonHelper.getOptionData(this.state.customer_data, 'customer_key', 'company_name', 'New Customer');
        }

        const formElements = <fieldset>
            {alert}

            <div className="form-box-horizandal">
            
                { (this.props.from_customer ? 
                    <div>
                        <input type="hidden" ref={(c) => (this.els.customer = c)} name="customer" defaultValue={this.state.customer_detail.customer_key}></input>
                        <input type="hidden" ref={(c) => (this.els.customer_type = c)} name="customer_type" defaultValue={this.state.customer_detail.customer_key}></input>
                    </div>:
                    <div>
                    <ReactSelectControl
                        ref={(c) => (this.els.customer_type = c)}
                        name="customer_type"
                        label="Customer Type"
                        onChange={ (e) => this.getCustomers(e) }
                        hasError={this.state.hasError.customer_type}
                        help={this.state.help.customer_type}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        inputClasses={{'select-modal': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                        options={[ {label: 'Individual', value: 1}, {label: 'Corporate', value: 2}]}
                    />

                    <ReactSelectControl
                        ref={(c) => (this.els.customer = c)}
                        name="customer"
                        label="Customer"
                        value={this.state.customer}
                        onChange={(e) => {}}
                        hasError={this.state.hasError.customer}
                        help={this.state.help.customer}
                        disabled={this.state.loading || !this.state.customer_hydrated}
                        groupClasses={{'rq': true}}
                        inputClasses={{'select-modal': true}}
                        labelClasses={{'left-side': true, 'control-label': false}}
                        options={ customersList }
                    />
                    </div>
                )}
                <ReactSelectControl
                    ref={(c) => (this.els.model_year = c)}
                    name="model_year"
                    label="Model Year"
                    value={this.state.model_year}
                    onChange={ (e) => { this.getMake(e) }}
                    hasError={this.state.hasError.model_year}
                    help={this.state.help.model_year}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={CommonHelper.getOptionData(this.state.years,'year_key', 'year')}
                />
                <ReactSelectControl
                    ref={(c) => (this.els.make = c)}
                    name="make"
                    label="Make"
                    value={this.state.make}
                    onChange={ (e) => { this.getMakeModel(e) }}
                    hasError={this.state.hasError.make}
                    help={this.state.help.make}
                    disabled={this.state.loading || !this.state.make_hydrated}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={CommonHelper.getOptionData(this.state.make_data, 'vehicle_brand_key', 'vehicle_brand_name')}
                />
                {/* <ReactSelectControl
                    ref={(c) => (this.els.make_model = c)}
                    name="make_model"
                    label="Model"
                    value={this.state.make_model}
                    onChange={ (e) => { this.getTrim(e) }}
                    hasError={this.state.hasError.make_model}
                    help={this.state.help.make_model}
                    disabled={this.state.loading || !this.state.make_model_hydrated}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={CommonHelper.getOptionData(this.state.make_model_data, 'vehicle_brand_model_key', 'vehicle_brand_model_name')}
                /> */}
                {/* <ReactSelectControl
                    ref={(c) => (this.els.trim = c)}
                    name="trim"
                    label="Custom Car Trim"
                    value={this.state.trim}
                    onChange={ (e) => {  }}
                    hasError={this.state.hasError.trim}
                    help={this.state.help.trim}
                    disabled={this.state.loading || !this.state.trim_hydrated}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={CommonHelper.getOptionData(this.state.trim_data, 'vehicle_brand_model_trim_key', 'vehicle_brand_model_trim_name')}
                /> */}
                <ReactSelectControl
                    ref={(c) => (this.els.enquiry_type = c)}
                    name="enquiry_type"
                    label="Enquiry Type"
                    value={this.state.enquiry_type}
                    onChange={ (e) => { }}
                    hasError={this.state.hasError.enquiry_type}
                    help={this.state.help.enquiry_type}
                    disabled={this.state.loading || !this.state.enquiry_type_hydrated}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={CommonHelper.getOptionData(this.state.enquiry_type_data, 'value', 'type')}
                />
                <ReactSelectControl
                    ref={(c) => (this.els.vehicle_specification = c)}
                    name="vehicle_specification"
                    label="Vehicle Specification"
                    value={this.state.vehicle_specification}
                    onChange={ (e) => { }}
                    defaultValue={ 1 }
                    initialValue={ 1 }
                    hasError={this.state.hasError.vehicle_specification}
                    help={this.state.help.vehicle_specification}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={ [{label: 'GCC', value: 1},{label: 'Non GCC', value: 2}] }
                />
                <ReactSelectControl
                    ref={(c) => (this.els.current_status = c)}
                    name="current_status"
                    label="Current Insured Status"
                    value={this.state.current_status ? this.state.current_status : 1}
                    defaultValue={ this.state.current_status ? this.state.current_status : 1}
                    initialValue={this.state.current_status ? this.state.current_status : 1}
                    onChange={ (e) => { }}
                    hasError={this.state.hasError.current_status}
                    help={this.state.help.current_status}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                    options={ [{label: 'Insured', value: 1},{label: 'Uninsured', value: 2}] }
                />
                {/* <TextControl
                    ref={(c) => (this.els.sub_insured = c)}
                    name="sub_insured"
                    label="Sum Insured (AED)"                    
                    onChange={LinkState.bind(this)}
                    hasError={this.state.hasError.sub_insured}
                    help={this.state.help.sub_insured}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                />
                <TextControl
                    ref={(c) => (this.els.no_of_passenger = c)}
                    name="no_of_passenger"
                    label="No of Passengers"                    
                    onChange={LinkState.bind(this)}
                    hasError={this.state.hasError.no_of_passenger}
                    help={this.state.help.no_of_passenger}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    labelClasses={{'left-side': true, 'control-label': false, 'req': true}}
                /> */}
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'actions': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn': true, 'btn-white': true }}
                        disabled={this.state.loading}
                        onClick={this.props.parentAction.hideDealModal}
                        >
                        Close
                    </Button>
                    <Button
                        type="submit"
                        inputClasses={{ 'btn': true, 'btn-primary': true }}
                        disabled={this.state.loading}>
                        <Spinner space="right" show={this.state.loading} />
                        Create
                    </Button>
                </ControlGroup>
            </div>
        </fieldset>;

        return (
            <Modal
                header="New Enquiry"
                show={this.props.createDeal}
                onClose={this.props.parentAction.hideDealModal}
                groupClasses={{'model_design1': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>
                <form onSubmit={this.onSubmit.bind(this)}>
                    {formElements}
                </form>
            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;


module.exports = CreateNewForm;
