document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/chosen.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/wow.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/scrollbar.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/datetimepicker.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/rating.js" ></scr'+'ipt>');