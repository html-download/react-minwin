'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {
    loading: false,
    pipeline_loading: false,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    activeTab: 1,
    pipeline_data: [],
    order_id: '',
    view_url: ''
};
const reducer = function (state, action) {

    if (action.type === Constants.SEND_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SEND_MESSAGE_RESPONSE) {
        const validation = ParseValidation(action.response);

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        });
    }

    if (action.type === Constants.TOGGLE_PASSWORD) {
        return ObjectAssign({}, state, {
            show_change_password: action.checked
        });
    }

    if (action.type === Constants.TOGGLE_TAB) {
        return ObjectAssign({}, state, {
            activeTab: action.tab,
            view_url: action.url ? action.url : state.url,
            order_id: action.id ? action.id : state.order_id,
        });
    }

    if (action.type === Constants.UPDATE_ORDER_ID) {
        return ObjectAssign({}, state, {
            order_id: action.id,
        });
    }

    if (action.type === Constants.GET_PIPELINE_DETAILS) {
        return ObjectAssign({}, state, {
            pipeline_loading: true
        });
    }

    if (action.type === Constants.GET_PIPELINE_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);

        const result = (action.response && action.response.data) ? action.response.data : [];
        return ObjectAssign({}, state, {
            pipeline_loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            pipeline_data: result,
        });
    }
    return state;
};


module.exports = Redux.createStore(reducer, initialState);
