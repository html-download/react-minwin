<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <section class="checkout-notification">
    <div class="container">
      <ul class="reset">
        <li class="active"><span><i>1</i> Account Info</span></li>
        <li class="active"><span><i>2</i> Delivery Type</span></li>
        <li class="active"><span><i>3</i> Payment Method</span></li>
        <li class="active"><span><i>4</i> Order Confirmation</span></li>
      </ul>
      <!-- ul end -->
    </div>
    <!-- container -->
  </section>
  <!-- order confirmation -->
  <section class="order-confirmation">
    <div class="container text-center">
      <div class="box">
        <div class="box-head">
          <i class="fi tick1"></i>
        <h3>Order placed successfully !!</h3>
        <p>We have sent the order notification SMS to <span class="black">+98765432101</span></p>
      </div>
        <div class="grey-box">
          <p>Order ID</p>
          <p class="or-id">#000280441</p>
          <button class="btn" onclick="location.href='/orders-history';">Track Order</button>
        </div>
        <div class="box-footer">
          <h5>Get the <span>Wishbox</span> App!</h5>
          <p>Get the features of <span>Wishbox</span> by installing the mobile app and order from 
your mobile & track on the go, with the app.</p>
<p class="mb0 app_download full_row">
                    <a href="" target="_blank" class="current_page"><img src="assets/img/app-store.png"></a>
                    <a href="" target="_blank" class="current_page"><img src="assets/img/play-store.png"></a>
                </p>
        </div>
      </div>
    </div>
  </section>
  <!-- order confirmation -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>