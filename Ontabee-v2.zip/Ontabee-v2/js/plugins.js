document.write('<scr'+'ipt type="text/javascript" src="js/popper.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/owl.carousel.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap-select.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.nav.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.sticky-sidebar.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/resize-sensor.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.row-grid.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.magnific-popup.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.rateyo.min.js" ></scr'+'ipt>');


