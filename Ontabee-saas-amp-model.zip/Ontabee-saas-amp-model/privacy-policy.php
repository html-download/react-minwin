<?php include ('inc/header.php'); ?>

<div class="cms_page full_row">
	<div class="page_banner">
		<div class="container">
			<h1 class="head wow fadeInUp">Privacy & Policy</h1>
		</div> <!--container-->
	</div> <!--page_banner-->
	
	<div class="container">
		<div class="cms_content">
			<p>We value the trust placed in use by You and therefore, we follow the highest standards of privacy guidelines to protect the information shared by You with us.</p>

			<p>This Privacy Policy (“Privacy Policy”) governs the use of Personal Information and other confidential information shared with or collected by Ontabee. from the subscribers of our Cloud Service.This Privacy Policy is subject to change from time to time without any written notice to You. Any significant changes to this policy will be sent out to the account owners registered an email address.Please review the Privacy Policy from time to time to be updated with the latest changes and modifications.</p>

			<p>By subscribing to the Cloud Services, You agree to be bound by the terms of this Privacy Policy.</p>

			<p>All capitalized terms that have not been specifically defined herein shall have the same meaning as provided under the Terms of Use.</p>

			<p>This Privacy Policy should be read in conjunction and together with the Terms of Use available on <a href="/terms-and-conditions">https://www.ontabee.com/terms-and-conditions</a></p>

			<h3>1. Collection and Use of Personal Information</h3>

			<p>‘Personal Information’, ‘Information’ and ‘Sensitive Personal Data or Information’ shall have the meaning ascribed to it under the IT Act, 2000 and Information Technology (Reasonable Security Practises and Procedures and Sensitive Personal Data or Information) Rules, 2011.</p>

			<h3>Generic Information/Financial Information</h3>

			<p>We collect Your Personal Information or Information on your registration and subscription for the Cloud Services. In the case of an individual, we collect information with respect to Your name, email, skype id, address, IP address etc. Based on Your purchase of a subscription, collect information with respect to Your credit/debit card details or other bank account details. This information is stored by using an encrypted form in a secure manner to expedite Your future transactions. This information is also made available to our payment gateway partners and is governed by the privacy policy of such payment gateway partners.</p>

			<p>We collect information in order to provide You with a safe, efficient, smooth and customized experience. This allows us to provide services and features that most likely meet Your needs, and to customize the Cloud Services by providing You a dashboard with Your branding and/ or logo.</p>

			<p>Except as provided herein, We do not solicit any Sensitive Information about You. However, if You share such information with Us voluntarily, We will not be liable for any actions, claims, costs, expenses or other liabilities that may arise as a consequence of such an unauthorized use or misuse of such information.</p>

			<p>If You choose to post messages in Our chat rooms or other message areas or leave feedback, We will collect that information You provide to Us. We retain this information as necessary to resolve disputes, provide customer support and troubleshoot problems as permitted by law.</p>

			<p>We identify and use Your IP address to help identify Your geographic location and to administer the Cloud Services.</p>

			<p>We will occasionally ask You to complete optional online surveys. These surveys may ask You for contact information and demographic information (like zipping code, age, or income level). We use this data to tailor Your experience with respect to Cloud Services.</p>

			<h3>Cookie</h3>

			<p>A "cookie" is a small piece of information stored by a web server on a web browser so it can be later read back from that browser. Cookies are useful for enabling the browser to remember information specific to a given user. We place both permanent and temporary cookies on Your computer's hard drive. The cookies do not contain any of Your personally identifiable information.</p>

			<p>You will always have an option not to provide certain information and can choose to opt-out of the provision of certain information.</p>

			<p>We use the internet protocol address, browser type, browser language, referring URL, files accessed, errors generated, time zone, operating system and other visitor details collected in our log files to analyze the trends, administer the website, track visitor's movements and to improve our website. We link this automatically-collected data to other information we collect about You.</p>

			<h3>2. Disclosure of Personal Information with Third Parties</h3>

			<p>We may disclose Personal Information to affiliates and group companies. We may also disclose Your Personal Information to third parties strictly on confidential terms. We may disclose such information to third parties in order to provide You access to Cloud Services, to comply with Our legal obligations, to enforce Our Terms of Use, to facilitate Our marketing and advertising activities, or to prevent, detect, mitigate, and investigate fraudulent or illegal activities using the Cloud Server.</p>

			<p>We will always take Your express consent at the time of sharing Your Personal Information with third parties for their marketing and advertising purposes.</p>

			<p>Notwithstanding the aforesaid, We retain Our right to share Your Personal Information with any of Our affiliates or group companies for the purpose of promoting other Ontabee products offered by Our other businesses or by Our affiliates and group companies.</p>

			<p>In the event of any requirement by court order, government or quasi-government agency to disclose Your Personal Information, We will disclose information as may be legally required. We may also disclose Your Personal Information if We, in the good faith belief that such disclosure is reasonably necessary to respond to subpoenas, court orders, or another legal process.</p>

			<p>In the event Ontabee is merged with or acquired by another company or in the case of re-organization or re-structuring of business, We and Our affiliates will share Your Personal Information, wholly or in part, with another business entity.</p>

			<h3>3. Promotional and Marketing Activities</h3>

			<p>We will use Your contact information shared with Us, including Your email id, address, and phone number, to communicate Our promotional schemes or promote any product offered by Us or by Our affiliates and group companies.</p>

			<h3>4. Security and Compliance with Laws</h3>

			<p>We strive to protect Your Personal Information against unauthorized disclosure, misuse, unlawful use, modification, loss or destruction. We take all reasonable measures and precautions, as per standard industry practices, to keep Your Personal Information confidential. We ensure compliance with all applicable laws including but not limited to Information Technology (Reasonable security practices and procedures and sensitive personal data or information) Rules, 2011.</p>

			<h3>5. Amendments</h3>

			<p>We reserve the right, at our sole discretion, to modify the terms of this Privacy Policy from time to time in order to ensure compliance with applicable laws (“Updated Terms”). The Updated Terms shall be effective immediately and shall supersede these the terms of this Privacy Policy. We will not be under an obligation to notify you of any changes to this Privacy Policy. You shall be solely responsible for reviewing the Privacy Policy from time to time for any modifications. By continuing to subscribe to the Cloud Services after the Updated Terms have been published, You affirm Your agreement to the Updated Terms.</p>

			<h3>6. Contact Us</h3>

			<p>If You require any information or clarification regarding the use of Your Personal Information or this Privacy Policy, You can contact us at <a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></p>

			<p>If You have a grievance with respect to use of Your Personal Information, please write to the Legal team.</p>

			<p>Ontabee is a company based in India. By subscribing to the Cloud Services, You hereby acknowledge that Ontabee is not responsible or liable in any manner to comply with any local laws of Your territory except India.</p>		

			<h3>7. General Data Protection Regulation (GDPR) Compliance</h3>
			<p>Here at Ontabee, We take your privacy seriously and will only use your personal information administer your account and to provide the products and services you have requested from us.</p>
			<p>However from time to time, we would like to contact you with details of other [specific products]/ [offers ]/ [services]/ [competitions] we provide. If you consent to us contacting you for this purpose how you like us to contact you:</p>
			<p>Text message, Email, Telephone.</p> 
		</div> <!--cms_content-->
	</div> <!--container-->
</div> <!--cms_page-->

<?php include('inc/footer.php');?>