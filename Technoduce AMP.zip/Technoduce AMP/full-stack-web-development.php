<?php include ('inc/header.php'); ?>

<section class="page_banner style1 web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/full-stack-web-development-logo.png" alt="Full Stack Development" width="300" height="300" layout="responsive"></amp-img>
      </div>

      <h1 class="animated fadeInDown">Turning great ideas into reality</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
  
  <div class="web_menu">
    <div class="container">
      <ul class="reset">
        <li><a on="tap:ux.scrollTo(duration=500)"><i class="fa fa-paint-brush"></i> UX/UI</a></li>
        <li><a on="tap:frontend.scrollTo(duration=500)"><i class="fa fa-desktop"></i> Front End</a></li>
        <li><a on="tap:api.scrollTo(duration=500)"><i class="fa fa-database"></i> API</a></li>
        <li><a on="tap:backend.scrollTo(duration=500)"><i class="fa fa-sliders"></i> Backend</a></li>
        <li><a on="tap:devops.scrollTo(duration=500)"><i class="fa fa-cogs"></i> Devops</a></li>
        <li><a on="tap:quality.scrollTo(duration=500)"><i class="fa fa-check"></i> Quality</a></li>
        <li><a on="tap:scalable.scrollTo(duration=500)"><i class="fa fa-server"></i> Scalable</a></li>
        <li><a on="tap:cloud.scrollTo(duration=500)"><i class="fa fa-cloud"></i> Cloud</a></li>
      </ul>
    </div> <!--container-->
  </div> <!--web_menu-->
</section> <!--page_banner-->

<section class="clients">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section id="ux" class="half grey">
  <div class="bg bg1 right"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_left">
        <h2 class="head line style1">Think digitally with <br>full stack web development</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style1 mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section id="frontend" class="blue pb20 overlay left">
  <div class="container">
    <div class="content">
      <h2 class="head style1 white">Interactive Front End</h2>

      <amp-img src="<?php echo $baseurl;?>images/front-end.png" alt="Interactive Front End" width="1165" height="690" layout="responsive"></amp-img>

      <ul class="boxes reset col2">
        <li>
          <div class="box angular">
            <i class="icon angular"></i>
            <h3>AngularJS</h3>
            <p>Creating a dynamic web applications using AngularJS framework for a better user experience.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box react">
            <i class="icon react"></i>
            <h3>ReactJS</h3>
            <p>Simplified user interface components in development and interactive web pages with better performance.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box bootstrap">
            <i class="icon bootstrap"></i>
            <h3>Bootstrap framework</h3>
            <p>Bootstrap libraries for a rapid designing of forms, buttons, & other interface components & extensions.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box jquery">
            <i class="icon jquery"></i>
            <h3>jQuery library</h3>
            <p>We uses jQuery for easier navigations, animations, & Ajax applications for responsive web apps.</p>
          </div> <!--box-->
        </li>
      </ul>
    </div> <!--content-->
  </div> <!--container-->
</section> <!--frontend-->

<section id="api" class="grey">
  <div class="container relative">    
    <div class="col_6 pr30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="API Development" width="460" height="450" layout="responsive"></amp-img>
    </div>

    <div class="col_6 pl30">
      <h2 class="head line style1">Multi-tier API Development</h2>
      <p class="mb20">Complete API development for the web applications for better performance.</p>

      <ul class="boxes style1 reset">
        <li>
          <div class="box laravel">
            <i class="icon laravel"></i>
            <h3>Laravel framework</h3>
            <p>Whatever the platform is we make it happen using Laravel framework. Dream your web application, we design and develop to an elegant working system.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box nodejs">
            <i class="icon nodejs"></i>
            <h3>NodeJS</h3>
            <p>Web applications like e-commerce sites, single page application or multi page application choose your platform we are ready already.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box yii">
            <i class="icon yii"></i>
            <h3>Yii framework</h3>
            <p>Web applications for you, developed with fast and secure framework Yii2 at the earliest.</p>
          </div> <!--box-->
        </li>
      </ul>
    </div>
  </div> <!--container-->
</section> <!--api-->

<section id="backend" class="dark overlay">
  <div class="container">
    <div class="content">
      <h2 class="head style1 white">Secure Backend Web Development</h2>
      <p class="mb20">Stabilizing the backend process and fetch the data from various modules and integrate them into one as a fine product.</p>
      <amp-img src="<?php echo $baseurl;?>images/front-end.png" alt="Interactive Front End" width="1165" height="690" layout="responsive"></amp-img>

      <ul class="boxes style1 reset">
        <li>
          <div class="box laravel">
            <i class="icon laravel"></i>
            <h3>Laravel framework</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur varius quam in augue euismod ipsum dolor sit amet.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box nodejs">
            <i class="icon nodejs"></i>
            <h3>NodeJS</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur varius quam in augue euismod ipsum dolor sit amet.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box yii">
            <i class="icon yii"></i>
            <h3>Yii framework</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit curabitur varius quam in augue euismod ipsum dolor sit amet.</p>
          </div> <!--box-->
        </li>
      </ul>
    </div> <!--content-->
  </div> <!--container-->
</section> <!--backend-->

<section id="quality">
  <div class="container">    
    <div class="col_6 pull_right pl30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="API Development" width="460" height="450" layout="responsive"></amp-img>
    </div>

    <div class="col_6 pr30 content">
      <h2 class="head line style1">Continuous QA testing</h2>
      <p class="mb20">Testing devised at each phase of development to ensure flawless functionalities and deliver error-free web applications.</p>

      <ul class="lists style1">
        <li>Functional testing</li>
        <li>Smoke testing</li>
        <li>API testing </li>
        <li>Compatibility testing</li>
        <li>Load and performance testing</li>
        <li>Security testing </li>
        <li>Usability testing</li>
        <li>Sanity testing</li>
      </ul>
    </div>
  </div> <!--container-->
</section> <!--api-->

<section id="scalable" class="dark">
  <div class="container relative">    
    <div class="col_6 pr30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="API Development" width="460" height="450" layout="responsive"></amp-img>
    </div>

    <div class="col_6 pl30">
      <h2 class="head line style1 white">Scalable & Performance</h2>
      <p class="mb20 white">Transmit your application to cloud server with assured security and for steady performance.</p>

      <ul class="boxes style1 reset">
        <li>
          <div class="box linux">
            <i class="icon linux"></i>
            <h3>Linux</h3>
            <p>The open source OS backs up any high end application protected over years.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box apache">
            <i class="icon apache"></i>
            <h3>Apache</h3>
            <p>Apache, an open source cross platform web server withholds your data and also provide server-side programming language.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box apache">
            <i class="icon apache"></i>
            <h3>Nginx</h3>
            <p>An open source web server mainly for reverse proxying, load balancing, media streaming and caching and maximize the performance with stability.</p>
          </div> <!--box-->
        </li>
      </ul>
    </div>
  </div> <!--container-->
</section> <!--scalable-->

<section id="cloud" class="blue">
  <div class="container relative">    
    <div class="col_6 pull_right pl30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="API Development" width="460" height="450" layout="responsive"></amp-img>
    </div>

    <div class="col_6 pr30">  
      <h2 class="head line style1 white">On Your Own Cloud</h2>
      <p class="mb20 white">Hosting on virtual servers from physical networks for refined operations.</p>

      <ul class="boxes style1 reset">
        <li>
          <div class="box linux">
            <i class="icon linux"></i>
            <h3>AWS</h3>
            <p>Amazon Web Services, an on-demand cloud computing platform to host maintain and manage the data with secure and high speed.</p>
          </div> <!--box-->
        </li>
        <li>
          <div class="box apache">
            <i class="icon apache"></i>
            <h3>Google cloud</h3>
            <p>A suite of cloud computing by Google for data storage and analytics with advanced security and scalability.</p>
          </div> <!--box-->
        </li>
      </ul>
    </div>
  </div> <!--container-->
</section> <!--cloud-->

<?php include ('inc/footer.php'); ?>