<?php 

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
  $ip = $_SERVER['HTTP_CLIENT_IP'];
  } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
  $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
  } else {
  $ip = $_SERVER['REMOTE_ADDR'];
  }
  $ip = '106.51.48.24';
  $record = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
  
  session_start();
  require_once('../PHPMailer/PHPMailerAutoload.php');
  if(isset($_POST) && !empty($_POST))
  {
    $error = 0;
    $request_validation['demo_name'] = $request_validation['demo_email'] = $request_validation['demo_tel_code'] = '';
    
    if(empty($_POST['demo_name']) && $_POST['demo_name'] == '') {
      $error = 1;
      $request_validation['demo_name'] = "Name cannot empty";
    } 
    //~ else if($_POST['request_name'] != '' && !preg_match("/^[a-zA-Z]*$/",$_POST['request_name'])){
      //~ $error = 1;
      //~ $request_validation['request_name'] = "Name is invalid";
    //~ }
    
    if(empty($_POST['demo_email']) && $_POST['demo_email'] == '') {
      $error = 1;
      $request_validation['demo_email'] = "Email cannot empty";
    } 
    else if($_POST['demo_email'] != '' && !preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $_POST['demo_email']))
    {
      $error = 1;
      $request_validation['demo_email'] = "Email is invalid";
    }
    
    if(empty($_POST['demo_tel']) && $_POST['demo_tel'] == '') 
    {
      $error = 1;
      $request_validation['demo_tel'] = "Phone Number cannot empty";
    } else if($_POST['demo_tel'] != '' && !preg_match("/^[0-9 +-]{5,20}$/", $_POST['demo_tel'])){
      $error = 1;
      $request_validation['demo_tel'] = "Phone Number is invalid";
    } 
        
    if($error == 1){
      echo json_encode([ 'httpcode' => 400,'error' => $request_validation]);die;
        //**header("Location: " . $_SERVER['HTTP_REFERER']);   
    }
    else if($error == 0 && $_POST['demo_email'] != '')
    {
		$mailer = new PHPMailer();
		$mailer->isSMTP();
		$mailer->Host = 'smtp.gmail.com';
		$mailer->Port = 465;
		$mailer->SMTPSecure = 'ssl';
		$mailer->SMTPAuth = true;
		$mailer->Username = 'sales@ontabee.com';
		$mailer->Password = 'BEEsales@33';
		$mailer->setFrom('sales@ontabee.com', 'Ontabee Demo');
    $mailer->addAddress('sales@ontabee.com');
    //$mailer->AddBCC('rajesh@technoduce.com');
    $mailer->CharSet = 'UTF-8';
		$mailer->Subject = 'Inquiry - Ontabee Demo - '. $_POST["demo_name"] ;		
    $mailer->Body = '
    <!DOCTYPE HTML>
    <html lang="en-US">
    <head> 
      <meta charset="UTF-8" />
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet" type="text/css"/>
      <style>
        @import url("https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700");
        body{font-family: "Roboto", sans-serif;}
      </style>
    </head>
    <body style="background:#e6e7ea">
    
    <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="font-family: "Roboto"; font-size:14px; color:#333; line-height:20px;">
    <tbody>
     <tr>
      <td width="100%" valign="top" style="padding:35px 15px;">
        <table cellpadding="0" cellspacing="0" border="0" align="center" style="max-width:600px; margin:0 auto; width: 100%;">
          <tbody>
            <td>
              <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center" style="box-shadow: 0px 0px 25px rgba(0, 0, 0, 0.15); border-top-left-radius:8px; border-top-right-radius:8px">
              <tbody>
              <tr>
                <td valign="middle" style="background-color:#fff; padding:15px 20px 10px 20px; border-top-left-radius:8px; border-top-right-radius:8px;">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0" align="center">
                    <tbody>
                      <tr>
                        <td><a href="https://www.ontabee.com"><img src="https://www.ontabee.com/images/logo.png" alt="Ontabee" height="50"></a></td>
                        <td style="text-align:right; padding-top:4px;">
                          <a href="https://www.facebook.com/Ontabee-149066152475073/"><img src="https://www.ontabee.com/images/facebook.png" style="margin:2px"></a>
                          <a href="https://twitter.com/ontabee"><img src="https://www.ontabee.com/images/twitter.png" style="margin:2px"></a>
                          <a href="https://www.linkedin.com/company/ontabee/"><img src="https://www.ontabee.com/images/linkedin.png" style="margin:2px"></a>
                        </td>
                      </tr>					   
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td style="padding:40px 20px 60px 20px; text-align:center; background: url(https://www.ontabee.com/images/banner_small.jpg) no-repeat bottom; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">
                    <h1 style="font-size: 26px; font-weight:300; line-height:normal; margin:0px;">Free Online <b style="color: #FC8019; font-weight: 400;">Food</b> Ordering System <span style="display: block; text-transform: none; margin-top: 10px;">For Restaurant Business</span></h1>
                </td>
              </tr>              
              <tr>
                <td style="background-color:#fff; padding:20px;">
                  <h3 style="font-weight: 500; font-size:18px; margin:0px">Inquired message from <span style="color: #FC8019;">Ontabee.com</span></h3>
                </td>
              </tr>
              <tr>
                <td style="background:#fff; padding:0px 20px 20px 20px;">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0" style="border-collapse: collapse; background-color:#fff">                    
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["demo_name"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Email</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["demo_email"] .'</td>
                    </tr>    
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Phone Number</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["demo_tel_code"] .' ' . $_POST["demo_tel"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Country</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["demo_country"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Page URL</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_POST["demo_url"] .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Referer From</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">'. $_SESSION["referer"]  .'</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">IP</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_request . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">City</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_city . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Region</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_region . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Region Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_regionName . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Country Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_countryName . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Continent Name</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_continentName . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Latitude</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_latitude . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Longitude</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_longitude . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Time Zone</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500">' . $record->geoplugin_timezone . '</td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Customer App Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=j1qWh_N5IxI" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Delivery App Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=favN6OgqGi4" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                    <tr>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px;">Back-end Video Demo</td>
                      <td style="border: 1px dashed #b7b9bd; padding: 10px 15px; font-weight:500"><a href="https://www.youtube.com/watch?v=mAqgAeku_10" style="display: inline-block; padding: 8px 15px; border-radius: 4px; text-decoration: none; color: #fff; background: #FC8019; margin-top:2px">Click here to watch demo</a></td>
                    </tr>
                  </table>
                </td>                    
              </tr>		     
              <tr>
                <td valign="middle" style="background-color:#FC8019; color:#fff; padding:15px 20px; border-bottom-left-radius:8px; border-bottom-right-radius:8px">
                  <table cellpadding="0" cellspacing="0" width="100%" border="0">
                    <tr>
                      <td><span style="font-weight:300; font-size:13px">Best Regards,</span><br>Rajesh Prabhu S <span style="font-weight:300; font-size:12px">(CEO, Ontabee)</span></td>
                      <td style="text-align:right; padding-left:15px;">
                        <span style="font-weight:300; font-size:13px">For more information</span><br>
                        <a style="color:#fff; text-decoration:none">sales@ontabee.com</a>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
            </tbody>
            </table>
            </td>
          </tr>	
            <tr>
              <td valign="middle" style="padding:20px 20px; text-align:center; color:#666; font-size:13px">
                <p style="margin:0px 0px 15px 0px">Questions? The Ontabee team is always here to help. <br>Contact sales@ontabee.com and we&apos;ll get back to you soon.</p>
                &copy; '. date('Y') .' Ontabee. All rights reserved.
              </td>
            </tr>
          </tbody>
        </table>
       </td>
      </tr>
    </tbody>
    </table>
    
    </body>
    </html>    
    ';
		$mailer->AltBody = 'This is a plain-text message body';
		if(!$mailer->Send())
		{
		echo json_encode([ 'httpcode' => 405 ,'error' => "Mailer Error: " . $mailer->ErrorInfo]); die;
		}
		else
		{
      $_SESSION['msg'] = 0;
      echo json_encode([ 'httpcode' => 200]); die;
			//header("Location: /demo");
		}
	}
	}
