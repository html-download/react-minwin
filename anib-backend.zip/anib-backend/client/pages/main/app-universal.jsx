'use strict';
const Login = require('./login/home/index.jsx');
const LoginForgot = require('./login/forgot/index.jsx');
const LoginLogout = require('./login/logout/index.jsx');
const LoginReset = require('./login/reset/index.jsx');
const NotFound = require('./not-found.jsx');
const React = require('react');
const ReactRouter = require('react-router-dom');
const RouteRedirect = require('../../components/route-redirect.jsx');

const Route = ReactRouter.Route;
const Switch = ReactRouter.Switch;


const AppUniversal = function () {

    return (
        <div className="route">
            <Switch>
                <Route path="(/|/login)" exact component={Login} />
                <Route path="/login/forgot" exact component={LoginForgot} />
                <Route path="/login/reset/:email/:key" component={LoginReset} />
                <Route path="/login/logout" exact component={LoginLogout} />

                <RouteRedirect from="/moved" to="/" code={301} />

                <Route component={NotFound} />
            </Switch>
        </div>
    );
};


module.exports = AppUniversal;
