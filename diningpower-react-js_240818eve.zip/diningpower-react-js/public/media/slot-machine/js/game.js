const Game = {
    Obj : null
};
Game.Paytable =
[
    [0, 2,  5, 10, 10, 14, 14, 18, 18, 100, 100, 100, 200],
    [0, 4, 10, 20, 20, 28, 28, 36, 36, 200, 200, 200, 400],
    [0, 6, 15, 30, 30, 42, 42, 54, 54, 300, 300, 300, 600]
];

Game.Reel =
[
    // REEL 1:
    {
        Height          : 1500,
        Weight          : 20,
        Symbol1         : [ 5,  2,  4,  6,  4,  5,  0,  3,  5,  6,  1,  4,  5,  4,  2,  4,  5,  4,  1,  4],
        Symbol2         : [-1, -1, -1, -1, -1, -1, -1,  1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
        StopWeight      : [ 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
        Offset          : ["0 -1425px", "0 0px", "0 -75px", "0 -150px", "0 -225px", "0 -300px", "0 -375px", "0 -450px", "0 -525px", "0 -600px", "0 -675px", "0 -750px", "0 -825px", "0 -900px", "0 -975px", "0 -1050px", "0 -1125px", "0 -1200px", "0 -1275px", "0 -1350px"],
        Position        : 0,
        VirtualStop     : 2,
        PhysicalStop    : 1,
        Timer           : 0
    },

    // REEL 2:
    {
        Height          : 1500,
        Weight          : 20,
        Symbol1         : [ 6,  4,  6,  0,  6,  3,  4,  3,  6,  5,  3,  2,  4,  3,  6,  1,  5,  6,  3,  2],
        Symbol2         : [-1, -1, -1,  5, -1, -1,  1, -1, -1, -1, -1,  5, -1, -1, -1, -1, -1, -1, -1,  5],
        StopWeight      : [ 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
        Offset          : ["-125px -1425px", "-125px 0px", "-125px -75px", "-125px -150px", "-125px -225px", "-125px -300px", "-125px -375px", "-125px -450px", "-125px -525px", "-125px -600px", "-125px -675px", "-125px -750px", "-125px -825px", "-125px -900px", "-125px -975px", "-125px -1050px", "-125px -1125px", "-125px -1200px", "-125px -1275px", "-125px -1350px"],
        Position        : 0,
        VirtualStop     : 2,
        PhysicalStop    : 1,
        Timer           : 0
    },

    // REEL 3:
    {
        Height          : 1500,
        Weight          : 20,
        Symbol1         : [ 3,  5,  4,  3,  5,  7,  3,  2,  3,  4,  7,  3,  4,  3,  0,  7,  3,  2,  3,  7],
        Symbol2         : [-1, -1, -1, -1, -1, -1, -1,  5, -1, -1, -1, -1, -1, -1,  1, -1, -1,  5, -1, -1],
        StopWeight      : [ 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
        Offset          : ["-250px -1425px", "-250px 0px", "-250px -75px", "-250px -150px", "-250px -225px", "-250px -300px", "-250px -375px", "-250px -450px", "-250px -525px", "-250px -600px", "-250px -675px", "-250px -750px", "-250px -825px", "-250px -900px", "-250px -975px", "-250px -1050px", "-250px -1125px", "-250px -1200px", "-250px -1275px", "-250px -1350px"],
        Position        : 0,
        VirtualStop     : 2,
        PhysicalStop    : 1,
        Timer           : 0
    }
];

Game.GetOutcome = function(s1, s2, s3)
{
    if ((s1 == 0) && (s2 == 0) && (s3 == 0)) { console.log("Outcome = 11"); return { Outcome : 12, Multiplier : 1 }; }   // 12 = SEVEN-SEVEN-SEVEN
    if ((s1 == 1) && (s2 == 1) && (s3 == 1)) { console.log("Outcome = 10"); return { Outcome : 11, Multiplier : 1 }; }   // 11 = BAR-BAR-BAR
    if ((s1 == 2) && (s2 == 2) && (s3 == 2)) { console.log("Outcome =  9"); return { Outcome : 10, Multiplier : 1 }; }   // 10 = MELON-MELON-MELON
    if ((s1 == 2) && (s2 == 2) && (s3 == 1)) { console.log("Outcome =  8"); return { Outcome :  9, Multiplier : 1 }; }   //  9 = MELON-MELON-BAR
    if ((s1 == 3) && (s2 == 3) && (s3 == 3)) { console.log("Outcome =  7"); return { Outcome :  8, Multiplier : 1 }; }   //  8 = BELL-BELL-BELL
    if ((s1 == 3) && (s2 == 3) && (s3 == 1)) { console.log("Outcome =  6"); return { Outcome :  7, Multiplier : 1 }; }   //  7 = BELL-BELL-BAR
    if ((s1 == 4) && (s2 == 4) && (s3 == 4)) { console.log("Outcome =  5"); return { Outcome :  6, Multiplier : 1 }; }   //  6 = PLUM-PLUM-PLUM
    if ((s1 == 4) && (s2 == 4) && (s3 == 1)) { console.log("Outcome =  4"); return { Outcome :  5, Multiplier : 1 }; }   //  5 = PLUM-PLUM-BAR
    if ((s1 == 5) && (s2 == 5) && (s3 == 5)) { console.log("Outcome =  3"); return { Outcome :  4, Multiplier : 1 }; }   //  4 = ORANGE-ORANGE-ORANGE
    if ((s1 == 5) && (s2 == 5) && (s3 == 1)) { console.log("Outcome =  2"); return { Outcome :  3, Multiplier : 1 }; }   //  3 = ORANGE-ORANGE-BAR
    if ((s1 == 6) && (s2 == 6))              { console.log("Outcome =  1"); return { Outcome :  2, Multiplier : 1 }; }   //  2 = CHERRY-CHERRY-ANY
    if  (s1 == 6)                            { console.log("Outcome =  0"); return { Outcome :  1, Multiplier : 1 }; }   //  1 = CHERRY-ANY-ANY

    return { Outcome : 0, Multiplier : 1 };                                                 //  0 = ALL OTHER
};
