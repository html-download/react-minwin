'use strict';
const Async = require('async');
const Bcrypt = require('bcrypt');
const Boom = require('boom');
const Config = require('../../config');
const NodeLocalStorage = require('../../client/helpers/nodelocal-storage-access');
const Joi = require('joi');
const Request = require('request');

const internals = {};


const loginCall = function(username, password, callback) {

    Request(`${Config.get('/apiUrl')}/user/login`,{
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        formData: { 
            username: username,//username, 
            password: password//password
        } 
    }, function(error, response, body) {
        console.log("response", response);

        if (!error) {
            response = JSON.parse(response.body);
            callback(response, false);
        } else {
            callback(null, error);
        }
    })

};

internals.applyRoutes = function (server, next) {
    
    server.route({
        method: 'POST',
        path: '/login',
        config: {
            validate: {
                payload: {
                    username: Joi.string().lowercase().required().label('Email Id'),
                    password: Joi.string().required().label('Password')
                }
            },
            pre: [{
                assign: 'user',
                method: function (request, reply) {

                    const username = request.payload.username;
                    const password = request.payload.password;

                    loginCall(username, password, function(response, err){
                        if (err) {
                            return reply(Boom.badRequest(err));
                        }
                        
                        return reply(response);
                    });
                }
            }, {
                assign: 'logAttempt',
                method: function (request, reply) {

                    if (request.pre.user.status !== 200) {
                        return reply(Boom.badRequest(request.pre.user.message));
                    }

                    if (request.pre.user) {
                        return reply();
                    }

                    //const ip = request.info.remoteAddress;
                }
            },{
                assign: 'session',
                method: function (request, reply) {
                    let user = request.pre.user.data;

                    NodeLocalStorage.setItem(`user${request.pre.user.time}`, JSON.stringify({
                        _id: request.pre.user.time,
                        username: user.email,
                        email: user.email,
                        access_token: user.access_token
                    }));

                    return reply(true);
                }
            }]
        },
        handler: function (request, reply) {
            let user = request.pre.user.data;

            const credentials = user.access_token;
            const authHeader = credentials;

            const result = {
                user: {
                    _id: request.pre.user.time,
                    username: user.email,
                    email: user.email,
                    roles: { 
                        'admin': {
                            _id: user.time,
                            username: user.email,
                            email: user.email,
                        }
                    }
                },
                session: request.pre.session,
                authHeader: authHeader
            };

            var token = !request.state.token ? authHeader : request.state.token;
            
            request.cookieAuth.set(result);
            reply(result);//.state('token', token);
        }
    });

    

    next();
};


exports.register = function (server, options, next) {

    server.dependency(['mailer'], internals.applyRoutes);

    next();
};


exports.register.attributes = {
    name: 'login'
};
