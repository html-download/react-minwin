/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Menu', {
    menuId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'menu_id'
    },
    menuKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'menu_key'
    },
    menuName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'menu_name'
    },
    menuNotes: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'menu_notes'
    },
    menuStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted','Inactive','Pending-Review','Active-Attached'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'menu_status'
    },
    isDeleted: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '0',
      field: 'is_deleted'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    deletedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'deleted_datetime'
    },
    restoredDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'restored_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    deletedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'deleted_by'
    },
    restoredBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'restored_by'
    },
    sort: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'sort'
    }
  }, {
    tableName: 'ss16_menu'
  });
};
