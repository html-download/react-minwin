/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorItemIngredientsList', {
    itemIngredientsListId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'item_ingredients_list_id'
    },
    itemKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'item_key'
    },
    itemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_id'
    },
    itemIngredientsId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      field: 'item_ingredients_id'
    },
    typeId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      field: 'type_id'
    },
    vendorIngredientTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'vendor_ingredient_type_id'
    },
    price: {
      type: "DOUBLE(8,2)",
      allowNull: true,
      field: 'price'
    },
    ingredientName: {
      type: DataTypes.STRING(120),
      allowNull: false,
      field: 'ingredient_name'
    },
    pickupPrice: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'pickup_price'
    },
    delivryDpPrice: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'delivry_dp_price'
    },
    delivryResPrice: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'delivry_res_price'
    },
    premiumPrice: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'premium_price'
    },
    costPrice: {
      type: "DOUBLE(8,2)",
      allowNull: false,
      field: 'cost_price'
    },
    sortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'sort_order'
    },
    autoSelect: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'auto_select'
    },
    makeItemPrice: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'make_item_price'
    }
  }, {
    tableName: 'ss16_vendor_item_ingredients_list'
  });
};
