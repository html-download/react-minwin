signUpWithFacebook = function() {
        FB.login(function(response){
            if (response.authResponse) 
                window.location.href = base_url+"/users/fb_signup.html";
        },{scope: 'public_profile,email'});
        return false;
    };

    $(document).ready(function(){
		loginWithFacebook = function() {
			FB.login(function(response){
				if (response.authResponse) 
					window.location.href = base_url+"/users/fb_login.html";
			},{scope: 'public_profile,email'});
			return false;
		};
	});

/*
    signUpWithFacebook = function() {
        FB.login(function(response){
            if (response.authResponse) 
                window.location.href = base_url+"/users/fb_signup.html";
        });
        return false;
    };

    loginWithFacebook = function() {
        FB.login(function(response){
            if (response.authResponse) 
                window.location.href = base_url+"/users/fb_login.html";
        });
        return false;
    };*/

    logoutWithFacebook = function() {
        //alert("hai");
        /*FB.logout(function(response){
            alert("hai");
        });*/
    };

    window.fbAsyncInit = function() {
        FB.init({
            appId:  app_id,
            cookie: true, // This is important, it's not enabled by default
            version: 'v2.5'
        });
    };
    
    (function(d, s, id){
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) {return;}
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    
    //Email Validation
    function validateEmail(email)
    {
        var emailReg = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        var valid = emailReg.test(email);
        if(!valid) 
            return false;
        else 
            return true;
    }

    function setupLabel() 
    {
        if ($('.label_check input').length) {
            $('.label_check').each(function(){

                $(this).removeClass('c_on');
            });
            $('.label_check input:checked').each(function(){ 
                $(this).parent('label').addClass('c_on');
            });                
        };
        if ($('.label_radio input').length) {
            $('.label_radio').each(function(){ 
                $(this).removeClass('r_on');
            });
            $('.label_radio input:checked').each(function(){ 
                $(this).parent('label').addClass('r_on');
            });
        };
    };


   //validation function
    function validation($element)
    {
        $error = 0;
        postal_code_expr = /^\d{4}$/;
        $($element).each(function(){
            //Validation work for input elements not for bootstarp element
            if($(this).is("input, select"))
            {
                //Empty Validation
                if($(this).hasClass("required") && ($(this).val() == ""))
                {
					if($(this).hasClass("custom_phone"))
						$('.customer_mobile').text($(this).attr("name") + " cannot be empty.");
					else
						$(this).siblings(".errors").text($(this).attr("placeholder") + " cannot be empty.");
                    $error = 1;
                }
                //Minimum Validation
                else if($(this).hasClass("minimum") && ($(this).val() != "") && ($(this).val().length < parseInt($(this).attr("min"))))
                {
                    $(this).siblings(".errors").text($(this).attr("name") + " have minimum " + $(this).attr("min") + " characters.");
                    $error = 1;
                }
                //Maximum Validation
                else if($(this).hasClass("maximum") && ($(this).val() != "") && ($(this).val().length > parseInt($(this).attr("min"))))
                {
                    $(this).siblings(".errors").text($(this).attr("name") + " have maximum " + $(this).attr("max") + " characters.");
                    $error = 1;
                }
                //Email Validation
                else if($(this).hasClass("email") && ($(this).val() != "") && (!validateEmail($(this).val())))
                {
                    $(this).siblings(".errors").text("Invalid Email Address");
                    $error = 1;
                }
                //Number Validation
                else if($(this).hasClass("numbersOnly") && ($(this).val() != "") && (!$.isNumeric($(this).val())))
                {
					if($(this).hasClass("custom_phone"))
						$('.customer_mobile').text($(this).attr("name") + " accept numbers only");
					else
						$(this).siblings(".errors").text($(this).attr("name") + " accept numbers only");
                    $error = 1;
                }
                //Mobile Number validation
                else if($(this).hasClass("phone"))
                {
					
                    if(!$.isNumeric($(this).val()))
                    {
                        $(this).siblings(".errors").text($(this).attr("name") + " accept numbers only");
                        $error = 1;
                    }
                    else if($(this).val().length > 10 || $(this).val().length < 10)
                    {
                        $(this).siblings(".errors").text($(this).attr("name") + " accept 10 digits");
                        $error = 1;
                    }
                }
                                //Mobile Number validation
                else if($(this).hasClass("custom_phone") && ($(this).val() != "") && (!(/^[0-9-+]{6,13}$/).test($(this).val())))
                {
					$('.customer_mobile').text($(this).attr("name") + " accept only numbers, and the length between 6 to 13");
					$error = 1;
                    
                }
                //Postal Code Validation
                 else if($(this).hasClass("postal_code") && ($(this).val() != '') && (!(/^[0-9-+]{4,7}$/).test($(this).val())))
                {
					/*$('.postal_code').text($(this).attr("name") + " Invalid postal code");
                    $error = 1;						 */
                   $(this).siblings(".errors").text("Invalid Postal Code");
                    $error = 1; 
                }
                //Checkbox Validation
                else if($(this).hasClass("must_check") && (!$(this).is(":checked")))
                {
                    $(this).siblings(".errors").text("Please accept " + $(this).attr("name"));
                    $error = 1;
                }
                //Clear Error Message
                else{
					if($(this).hasClass("custom_phone")){
						$('.customer_mobile').text("");
					}
					else{
						$(this).siblings(".errors").text("");
					}
				}
            }
        });

        return $error;
    }

    //Autocomplete Area Selection
    function showAutoComplete()
    {
        $.ajax({
            url: base_url + "/area.html",
            type: "get",
            data: {city_key: $("#selectbox-city-list2").val()},
            dataType: "json",
            beforeSend: function(){
                //$("body").parent().prepend("<div class='header_loading'><img src='" + theme_path + "loader.gif'/></div>");
//$("body").parent().prepend("<div class='header_loading'></div>");
            },
            complete: function(){
               // $(".header_loading").remove();
            },
            success: function(data){
                $options = [];
                $.each(data, function(i, field){
                    $option = {"label":field.location, "value": field.area_key};
                    $options.push($option);
                });
                
                $("#inputArea").autocomplete({
                    source: $options,
                    focus: function(event, ui){
                        $("#inputArea").val(ui.item.label);
                        $("#inputAreaCtrl").val(ui.item.value);
                        return false;
                    },
                    select: function(event, ui){
                        $("#inputArea").val(ui.item.label);
                        $("#inputAreaCtrl").val(ui.item.value);
                        return false;
                    },
                    minLength: 2,
                });/*.focus(function(){
                    $('#inputArea').autocomplete('search', '')
                }).focusout(function(){
                    $("#inputArea").autocomplete("close");
                });*/
            },
        });
    }
    
    $(document).ready(function(){
        
        if($(".select_loader").length) //Remove loader for bootstrap buttons
            $(".select_loader").remove();

        $('.label_check, .label_radio').click(function(){
          setupLabel();
        });
        setupLabel();

      //  $(".alert-success,.alert-danger").delay(3000).fadeOut('slow',function() { $(this).remove();});      

        //Getting area list on based city on select box change event
        $(document).on("change", "#selectbox-city-list2", function(){
            $("#inputArea").val('');
            $("#inputAreaCtrl").val('');
            if($(this).val() != "")
                showAutoComplete();
        });

        //Remove error message on switching modal boxes
        $(document).on("click", ".actionButtons", function(){
            $(".action_modal").find(".errors").html("");
            $(".action_modal").find("input,textarea").val(""); 
            $("#login_form").find("#email_id").val(customer_email); //Setting remember me 
            if(customer_email)
                $("#login_form").find("#checkbox-1-1").attr("checked", true);
        });

        $(document).on("keyup", "#inputArea", function(e){
            if(!((e.keyCode >= 33  && e.keyCode <= 40) || (e.keyCode >= 16  && e.keyCode <= 20) || (e.keyCode == 13) || (e.keyCode == 27) || (e.keyCode == 45) || (e.keyCode >= 144 && e.keyCode <= 145) || (e.keyCode >= 112 && e.keyCode <= 123) || (e.keyCode >= 91 && e.keyCode <= 92)))
                $("#inputAreaCtrl").val('');
        });


        //Find resturant validation
        $(document).on("submit", "#find_shop_form", function(){
            $errors = 0;
            if($(this).hasClass(".find_rest"))
                $("#typeRestaurant").val(1);
            if($(this).hasClass(".find_all_shop"))
                $("#typeRestaurant").val(0);
            
            if($("#selectbox-city-list2").val() == "")
            {
                $("#selectbox-city-list2").siblings(".errors").html("<span>Please select the state</span>");
                $errors = 1;
            }
            else
                $("#selectbox-city-list2").siblings(".errors").html("");
            if($("#cityloadingvalues").val() == "")
            {
                $("#cityloadingvalues").siblings(".errors").html("<span>Please select the city</span>");
                $errors = 1;
            }
            else
                $("#cityloadingvalues").siblings(".errors").html("");

            //~ if($("#inputArea").val() == "" && $("#inputAreaCtrl").val() == "")
            //~ {
                //~ $("#inputArea").siblings(".errors").html("Area cannot be empty");
                //~ $errors = 1;
            //~ }
            //~ else if($("#inputArea").val() != "" && $("#inputAreaCtrl").val() == "")
            //~ {
                //~ $("#inputArea").siblings(".errors").html("Area doesn't exists");
                //~ $errors = 1;
            //~ }
            //~ else if($("#inputArea").val() == "" && $("#inputAreaCtrl").val() != "")
            //~ {
                //~ $("#inputArea").siblings(".errors").html("Area cannot be empty");
                //~ $errors = 1;
            //~ }
            //~ else
                //~ $("#inputArea").siblings(".errors").html("");
            
            if($errors)
                return false;
        });
        
        //Partner with us
        $(document).on("click", "#send_button", function(){
            var url = window.location.href;
            if(!validation($("#partner_form").find(".validation")))
            {
				$param = {res_city: $("#res_city").val(), res_name:$("#res_name").val(), vendor_area: $("#vendor_area").val(), vendor_name: $("#vendor_name").val(), email: $("#email").val(), contact_no: $("#contact_no").val(), outlets: $("#outlets").val()};
				$.ajax({
					url: base_url + "/users/partner.html",
					type: "post",
					data: $param,
					beforeSend: function(){
						$("#send_button").parent().prepend("<div class='login_loading'><img src='" + theme_path + "loader.gif'/></div>");
					},
					complete: function(){
						$(".login_loading").remove();
					},
					dataType: "json",
					success: function(data){
						if(parseInt(data['httpcode']) != 200)
						{
							$.each(data['error'], function(key, value){
								$("#partner_form").find("." + key).html(value[0]);
							});
						}
						else
							window.location.href = url;
					}
				});
			}
			return false;
        });

        //Login Form Validation
        $(document).on("click", "#login_button", function(){
            var url = window.location.href;
            if(!validation($("#login_form").find(".validation")))
            {
				//var captcha_token =$("#g-recaptcha-response").val();
				var captcha_token = "dsdsdsddsdsdsd";
				
				if(captcha_token==''){
					    $("#login_form").find(".recaptcha").html("Captcha cannot be blank");
					    return false;
					} 
                if($("#checkbox-1-1").prop("checked")){
					if($.isNumeric($("#email_id").val())){
						$param = {customer_mobile: $("#email_id").val(),customer_email:"", customer_password: $("#password").val(),token:captcha_token, rememeber_me: 1};
					}else{
						$param = {customer_email: $("#email_id").val(),customer_mobile:"", customer_password: $("#password").val(),token:captcha_token, rememeber_me: 1};
					}
                }else{
					if($.isNumeric($("#email_id").val())){
						$param = {customer_mobile: $("#email_id").val(),customer_email:"", customer_password: $("#password").val(),token:captcha_token};
					}else{
						$param = {customer_email: $("#email_id").val(),customer_mobile:"", customer_password: $("#password").val(),token:captcha_token};
					}
				}
                
                $.ajax({
                    url: base_url + "/users/login.html",
                    type: "post",
                    data: $param,
                    beforeSend: function(){
                        $("body").parent().prepend("<div class='login_loading'></div>");
                    },
                    complete: function(){
                      $(".login_loading").remove();
                    },
                    dataType: "json",
                    success: function(data){
                        $("#login_form").find(".errors").html("");
                        if(parseInt(data['httpcode']) != 200)
                        {
                            $.each(data['error'], function(key, value){
                                $("#login_form").find("." + key).html(value[0]);
                            });
                        }
                        else
                            window.location.href = url;
                    }
                });
				//grecaptcha.reset();
            }
            return false;
        });

        //Signup Form Validation
        $(document).on("click", "#verfication_button", function(){

					$("#success_msg").html("");
					$("#verfication_form").find(".errors").html("");
            var otp_verfication =$("#otp_verfication").val();
            var mobile_number =$("#verfication_customer_mobile").val();
				if(otp_verfication==''){
					    $("#verfication_form").find(".errors").html("OTP cannot be blank");
					    return false;
					}else{
					$.ajax({
                    url: base_url + "/users/otp_verfication.html",
                    type: "POST",
                    data: {otp_verfication: otp_verfication,customer_mobile: mobile_number},
                    beforeSend: function(){
                        $("#verfication_button").parent().prepend("<div class='login_loading'><img src='" + theme_path + "loader.gif'/></div>");
                    },
                    complete: function(){
                        $(".login_loading").remove();
                    },
                    dataType: "json",
                    success: function(data){
						
                      if(parseInt(data['httpcode']) == 200){
						       window.location.href = base_url;

							}
                        else
                            {
								$("#success_msg").html("Invalid OTP.");
								return false;
							}
                          

                    }       
                     
                });
						return false;	
						}
				 return false;		
		});

 
        $(document).on("click", "#signup_button", function(){
           var url = window.location.href;
            if(!validation($("#signup_form").find(".validation")))
            //if(1)
            {
				//var captcha_token =$("#g-recaptcha-response-1").val();
				var captcha_token ="sdsdsddsd";
				if(captcha_token==''){
					    $("#signup_form").find(".recaptcha").html("Captcha cannot be blank");
					    return false;
					}
				 
				var country_code  = $(".selected-dial-code").text();
				var mobile_number = country_code+$("#signup_phone").val();
               $.ajax({
                    url: base_url + "/users/signup.html",
                    type: "POST",
                    data: {customer_name: $("#signup_name").val(), customer_last_name: $("#signup_last_name").val(), customer_password: $("#signup_password").val(), customer_gender: $("#customer_gender").val(), customer_email: $("#signup_email").val(), customer_mobile: mobile_number, mobile_verification: 2, token: captcha_token},
                    beforeSend: function(){
                        $("#signup_button").parent().prepend("<div class='login_loading'><img src='" + theme_path + "loader.gif'/></div>");
                    },
                    complete: function(){
                        $(".login_loading").remove();
                    },
                    dataType: "json",
                    success: function(data){
                        if(parseInt(data['httpcode']) != 200)
                        {
                            $.each(data['error'], function(key, value){
                                $("#signup_form").find("." + key).html(value);
                            });
                        } else  if(parseInt(data['httpcode']) == 200){
								$("#verfication_customer_mobile").val(mobile_number);
								$('#signupModal').modal('hide');
								window.location.href = url;
							}
                        else
                            window.location.href = url;
                    }
                });
				//grecaptcha.reset();
				//grecaptcha.render('RecaptchaField1', {'sitekey' : '6LeMNyEUAAAAAHw10eSS-HhPddCm7jsDWm125fAf'});
            }
            
            return false;
        });

        //Forgot Password Validation
        $(document).on("click", "#forgot_pwd_button", function(){
            if(!validation($("#forgot_pwd_form").find(".validation")))
            {
                $.ajax({
                    url: base_url + "/users/forgot_password.html",
                    type: "POST",
                    data: { customer_email: $("#forgot_pwd_email").val()},
                    dataType: "json",
                    beforeSend: function(){
                        $("#forgot_pwd_button").parent().prepend("<div class='login_loading'><img src='" + theme_path + "loader.gif'/></div>");
                    },
                    complete: function(){
                        $(".login_loading").remove();
                    },
                    success: function(data){
                        if(parseInt(data['httpcode']) != 200)
                        {
                            $.each(data['error'], function(key, value){
                                $("#forgot_pwd_form").find("." + key).html(value);
                            });
                        }
                        else
                            window.location.href = base_url;
                    }
                });
            }
            return false;
        });

        //Subscription Validation
        $(document).on("click", ".sign_up", function(){
            $error = 0;
            if($("#selectbox-city-list1").val() == "")
            {
                $("#city_list_errors").html("Please select the city");
                $error = 1;
            }
            else
                $("#city_list_errors").html("");

            if($("#inputEmail").val() == "")
            {
                $("#inputEmail").siblings(".errors").html("Please fill the e-mail");
                $error = 1;
            }
            else if(!validateEmail($("#inputEmail").val()))
            {
                $("#inputEmail").siblings(".errors").html("Invalid email address");
                $error = 1;
            }
            else
                $("#inputEmail").siblings(".errors").html("");

            if($("#checkbox-3-3:checked").length == 0)
            {
                $("#checkbox_3_3_errors").html("Please agree the terms and conditions");
                $error = 1;
            }
            else
                $("#checkbox_3_3_errors").html("");
            
            if(!$error)
            {
                $loader = theme_path;
                $params = {"city": $("#selectbox-city-list1").val(), "email": $("#inputEmail").val()}
                $.ajax({
                    url: base_url + "/subscribe.html",
                    type: "post",
                    data: $params,
                    dataType: "json",
                    beforeSend: function(){
                        $("#subscribe").addClass("subscribe_loading");
                        $("#subscribe").append('<div class="subscribe_loader"><img src='+ $loader + 'loader.gif></div>');
                    },
                    complete: function(){
                        $("#subscribe").removeClass("subscribe_loading");
                        $(".subscribe_loader").remove();
                    },
                    success: function(data){
                        if(data.error)
                        {
                            if(data.error.email)
                                $("#inputEmail").siblings(".errors").html(data.error.email);
                            else
                                $("#checkbox_3_3_errors").html("Please try again later");
                        }
                        else
                            $(".subscription").html("<p class='after-signup'>Thank you for your subscription. From now on you will receive updates about exclusive offers in your city.</p>");
                    },
                });
				//grecaptcha.render('RecaptchaField1', {'sitekey' : '6LeMNyEUAAAAAHw10eSS-HhPddCm7jsDWm125fAf'});
            }
            return false;
        })


        var $fieldGrp;
        $(document).on('click', '.password-field-group .pwd-viewer-toggle', function () {
            $this = $(this);
            $fieldGrp = $this.closest('.password-field-group');

            if ( $fieldGrp.hasClass('pwd-visible') ) {
                $fieldGrp.removeClass('pwd-visible');

                $fieldGrp.find('input').attr('type', 'password');
                $this.removeClass('fa-eye-slash').addClass('fa-eye');
            } else {
                $fieldGrp.addClass('pwd-visible');

                $fieldGrp.find('input').attr('type', 'text');
                $this.removeClass('fa-eye').addClass('fa-eye-slash');
            }

        });
    });

	
