'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');

const initialState = {
    user_data: [],
    enquiry_types:[],
    driving_experience_data: [],
    experience_data: [],
    country_data:[],
    emirate_data: [],
    vehicle_type: [],
    product_data: [],
    vehicle_model_year: [],
    vehicle_brand: [],
    vehicle_models: [],
    vehicle_trims: [],
    place_of_registration: [],
    customer_info: {}
};

const reducer = function (state = initialState, action) {
    

    switch (action.type) {
        case Constants.GET_USER_DETAILS:
            return ObjectAssign({}, state, {
                user_data: []
            }); 
            break;
        case Constants.GET_USER_DETAILS_RESPONSE:
            const data = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {                
                user_data: data
            });
            break;
        case Constants.GET_ENQUIRY_RESULTS:
            return ObjectAssign({}, state, {
                enquiry_types: []
            }); 
            break;
        case Constants.GET_ENQUIRY_RESULTS_RESPONSE:
            const enquirydata = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {                
                enquiry_types: enquirydata ? enquirydata : []
            });
            break;

        case Constants.GET_DRIVING_EXPERIENCE_RESULTS:
            return ObjectAssign({}, state, {
                driving_experience_data: true
            }); 
            break;
        case Constants.GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE:

            const experiencedata = (action.response && action.response.data) ? action.response.data : [];            
            return ObjectAssign({}, state, {
                driving_experience_data: state.driving_experience_data.length > 0 ? state.driving_experience_data : experiencedata ? experiencedata : [],
                experience_data: experiencedata ? experiencedata : [],
            });
            break;

        case Constants.GET_COUNTRY_RESULTS:
            return ObjectAssign({}, state, {
                country_data: []
            });
            break;

        case Constants.GET_COUNTRY_RESULTS_RESPONSE:

            return ObjectAssign({}, state, {
                country_data: action.response.data
            });
            break;
        case Constants.GET_VEHICLE_TYPE:
            return ObjectAssign({}, state, {
                vehicle_type: []
            });
            break;

        case Constants.GET_VEHICLE_TYPE_RESPONSE:

            return ObjectAssign({}, state, {
                vehicle_type: action.response.data
            });
            break;
        case Constants.GET_NATIONALITY_RESULTS:
            return ObjectAssign({}, state, {
                nationality_data: []
            });
            break;
        case Constants.GET_NATIONALITY_RESULTS_RESPONSE:                    
            const stateUpdates = {
                nationality_data: action.response ? action.response.data : []
            };
            return ObjectAssign({}, state, stateUpdates);
            break;
        case Constants.GET_EMIRATES:
            return ObjectAssign({}, state, {
                emirate_data: []
            });            
            break;
        case Constants.GET_EMIRATES_RESPONSE:
            return ObjectAssign({}, state, {
                emirate_data:action.response.data
            });
            break;
        case Constants.GET_PRODUCT_DETAILS:
            return ObjectAssign({}, state, {
                product_data : []
            });
            break;

        case Constants.GET_PRODUCT_DETAILS_RESPONSE:
                        
            return ObjectAssign({}, state, {                
                product_data: (action.response && action.response.data) ? action.response.data : []
            });

            break;
        case Constants.GET_USER_DETAILS:
            return ObjectAssign({}, state, {
                user_data: []
            });
            break;
        case Constants.GET_USER_DETAILS_RESPONSE:            
            const user = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {                
                user_data: user
            });
            break;
        case Constants.GET_VEHICLE_MODEL_YEAR:
            return ObjectAssign({}, state, {
                vehicle_model_year: []
            });
            break;
        case Constants.GET_VEHICLE_MODEL_YEAR_RESPONSE:            
            const year = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {                
                vehicle_model_year: year
            });
            break;
        case Constants.GET_VEHICLE_BRAND:
            return ObjectAssign({}, state, {
                vehicle_brand: []
            });
            break;
        case Constants.GET_VEHICLE_BRAND_RESPONSE:
            const brands = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {
                vehicle_brand: brands
            });
            break;
        case Constants.GET_VEHICLE_BRAND_MODEL:
            return ObjectAssign({}, state, {
                vehicle_models: []
            });
            break;
        case Constants.GET_VEHICLE_BRAND_MODEL_RESPONSE:
            const models = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {
                vehicle_models: models
            });
            break;
        case Constants.GET_VEHICLE_TRIM:
            return ObjectAssign({}, state, {
                vehicle_trims: []
            });
            break;
        case Constants.GET_VEHICLE_TRIM_RESPONSE:
            const trims = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {
                vehicle_trims: trims
            });
            break;
        case Constants.GET_PLACE_OF_REGISTRATION:
            return ObjectAssign({}, state, {
                place_of_registration: []
            });
            break;
        case Constants.GET_PLACE_OF_REGISTRATION_RESPONSE:
            const places = (action.response && action.response.data) ? action.response.data : {};
            return ObjectAssign({}, state, {
                place_of_registration: places
            });
            break;
        case Constants.CUSTOMER_DETAILS_RESPONSE:
            
            return ObjectAssign({}, state, {
                customer_info: action.response
            });
            break;
        default:
            return state;
            break;
    }
};


module.exports = Redux.createStore(reducer);
