function documentReady(){
    $(".rateYo").rateYo({
       // rating: 1,
        halfStar: true,
        readOnly: true
       //starWidth: "40px"

    });
    $('.selectpicker').selectpicker('refresh');

}

function summernoteMedia(){
    $('.summernote-media').summernote({
        height: 150,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen', ]]
        ],
        /*callbacks: { 
            onBlur: function(e) { 
                $(this).summernote('formatPara'); 
            } 
        }*/
    });
}

function summernoteImage(){
    $('.summernote-image').summernote({
        height: 80,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['insert', ['link', 'picture',]],
        ], 
        /*callbacks: { 
            onBlur: function(e) { 
                $(this).summernote('formatPara'); 
            } 
        }*/
    });
}

function summernoteCommentImage() {
    $('.summernote-custom-image').summernote({
        // set editor height
        minHeight: null,             // set minimum height of editor
        maxHeight: null,             // set maximum height of editor
        focus: true,
        toolbar: [
            ['insert', ['picture']],
        ],                  // set focus to editable area after initializing summernote
        callbacks: {
             onBlur: function(event, $editable) {
                myHandler();
            }
        }
    });
}

function myHandler() {
    var $grid = $('.grid').masonry({
        itemSelector: '.grid-item',
        percentPosition: 'true',
        fitWidth: true,
        resize:true,
        gutter: 12,
       

    });
    $grid;
}
$(document).ready(function(){
new WOW().init();
//new

$(".rateYo").rateYo({
   // rating: 1,
    readOnly: true,
    halfStar: true,
   //starWidth: "40px"

  });

$(".rateYoRate").rateYo({
       // rating: 1,
        halfStar: true,
       //starWidth: "40px"

    });

//Fixed Header  
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".header.lead").addClass("fixed");
    } else {
        $(".header.lead").removeClass("fixed");
    }    
});

 //Carousel settings
$(document).ready(function() {
 var o1 = $('#c1'), o2 = $('#c2');

 //Sync o2 by o1
 o1.on('click', '.owl-next', function () {
   o2.trigger('next.owl.carousel')
 });
 o1.on('click', '.owl-prev', function () {
   o2.trigger('prev.owl.carousel')
 });


 //Carousel settings
 o1.owlCarousel({
   center : true,
   autoplay:true,
  loop : true,
  items : 1,
  margin:0,
  nav : true,
   navText: ["<i class='la la-angle-left'></i>", "<i class='la la-angle-right'></i>"],
 });
 o2.owlCarousel({
     autoplay:true,
   center : true,
  loop : true,
  items : 1,
  margin:0,
  
 
 });
});
  

// login

$(".login-signup-click, .register-popup").click(function() {
    let p=$('.login-signup-switch').prev('span.member');
    if ($(this).attr('data-key') === '1') {
        $('.login-signup-switch').html($('.login-signup-switch').attr('data-signin'));
        $('.login-signup-switch').attr('data-key',2);
        p.text(p.attr('data-signin'));
        $(".login-form-signin").addClass('remove-login');
        $(".login-form-signup").addClass('add-login');
    } else {
        $('.login-signup-switch').html($('.login-signup-switch').attr('data-signup'));
        $('.login-signup-switch').attr('data-key',1);
        p.text(p.attr('data-signup'));
        $(".login-form-signin").removeClass('remove-login');
        $(".login-form-signup").removeClass('add-login');
    }
});

//open another modal
$('.modal').on('shown.bs.modal', function () {
    $('body').addClass('modal-open');
});

//tooltip
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})

//search

  $(".red-tooltip").click(function() {
    $('.search-dropmenu').addClass('search-expand');
    //console.log('sadsafd', $('.bg-over'))
      $('.bg-over').addClass('in');
      setTimeout(function(){$('#search-product').focus()},100);
});

  // search close
  $(".search-close").click(function() {
    $('.search-dropmenu').removeClass('search-expand');
      $('.bg-over').removeClass('in');
});

  // shop expand
/*  $(".shop-category").click(function() {
    $('.shop-overlay-section').toggleClass('shop-expand');
    $('.bg-over').addClass('in');
});

  $(document).on("click", function(e) {

    if ($(e.target).is(".shop-category, .shop-overlay-section") === false) {
      $(".shop-overlay-section").removeClass("shop-expand");
      $('.bg-over').removeClass('in');
    }
  });
*/
// tab display
$(document).ready(function($) {
  $(".tab-titles li").hover(function() {
    $(".mob-subcategory .tab-content").hide();
    $(".tab-titles li").removeClass('active');          
    $(this).addClass("active");          
    var selected_tab = $(this).find("a").data("href");
    $(selected_tab).stop().fadeIn();
    return false;
  });
});

// dropdown mouse over toggle
$(".widget-title").click(function(e) {
    $(this).next(".widget-list").slideToggle('hide');
    $(this).toggleClass('arrow');
});

// div filter 


    $(".halfview").click(function () {
        $(this).text(function(i, v){
           return v === 'Hide Filters' ? 'Show Filters' : 'Hide Filters'
        })
    });

    // toggle to full width
    $(".halfview").click(function(e) {
        $(".fil-icon").toggleClass('close');
        $(".left-portion").toggleClass('none');
        $(".shop-right-portion").toggleClass('full-width');
        
    });



//menu tab
jQuery("a[id^='thumblink-']").click(function(){
    var num = this.id.split('-')[1];
    jQuery('#thumb-hover-' + num).toggle();
});


 $('.content-editor').richText({
    // text formatting
    bold: true,
    italic: true,
    underline: true,
    // text alignment
    leftAlign: false,
    centerAlign: false,
    rightAlign: false,
    justifyFull: false,
    // fonts
    fonts: false,
    fontList: false,
    // title
    heading: false,
    fileUpload: false,
    // lists
    ol: true,
    ul: true,
    // uploads
    imageUpload: true,
    // link
    urls: true,
    fontColor: false,
    fontSize: false,
    
    // media
    Embed: false,
    
    // tables
    table: false,
    
    // code
    removeStyles: false,
    code: false,
    
    // colors
    colors: false,
    
    // dropdowns
    fileHTML: false,
    imageHTML: false,
});


$('.content-editor-modal').richText({
    // text formatting
    bold: true,
    italic: true,
    underline: true,
    // text alignment
    leftAlign: false,
    centerAlign: false,
    rightAlign: false,
    justifyFull: false,
    // fonts
    fonts: false,
    fontList: false,
    // title
    heading: false,
    fileUpload: false,
    // lists
    ol: true,
    ul: true,
    // uploads
    imageUpload: false,
    // link
    urls: true,
    fontColor: false,
    fontSize: false,
        
    // media
    Embed: false,
    
    // tables
    table: false,
    
    // code
    removeStyles: false,
    code: false,
    
    // colors
    colors: false,
    
    // dropdowns
    fileHTML: false,
    imageHTML: false,
});

  // toggle to full width
    $(".remind-icon").click(function(e) {
        $(".remind-icon").toggleClass('strike');
    });

    $(".wishlist-btn").click(function(e) {
        $(".whislist").toggleClass('fill');
   

    });
    $('.starrr').starrr({
        readOnly: true
    })


// product slider with thumbnail

// join user on click
  $(".join-user, .follow-text").click(function () {
          $(this).toggleClass('user');
            $(this).text(function(i, v){
               return v === 'Follow' ? 'Following' : 'Follow'
            })
        });

//
//magnifi

$('.item-pop').magnificPopup({
   type: 'image',
      closeOnContentClick: true,
      closeBtnInside: false,
      gallery: { enabled:true }
});


//popmodal from  one modal

 $('.conti-nue').click(function() {
            $('.add-option-modal').one('hidden.bs.modal', function() {
                $('.edit-my-option').modal('show'); 
            }).modal('hide');
        });


 /*Equal Height*/

// equal height
// equl height

( function( $, window, document, undefined )
{
  'use strict';

  var $list = $( '.cus_address ul' ),
  $items = $list.find( '.box address' ),
  setHeights = function()
  {
    $items.css( 'height', 'auto' );

    var perRow = Math.floor( $list.width() / $items.width() );
    if( perRow == null || perRow < 2 ) return true;

    for( var i = 0, j = $items.length; i < j; i += perRow )
    {
      var maxHeight = 0,
      $row = $items.slice( i, i + perRow );

      $row.each( function()
      {
        var itemHeight = parseInt( $( this ).outerHeight() );
        if ( itemHeight > maxHeight ) maxHeight = itemHeight;
      });
      $row.css( 'height', maxHeight );
    }
};


setHeights();
$( window ).on( 'resize', setHeights );


})
( jQuery, window, document );


//expand textarea on click


// $('.commt-cancel').click(function() {
//  $(this).parent().$(".txt-btn").removeClass('view');
//  console.log(comment);
//  });

$(document).on('click', '.commt-cancel', function(e) {
    
   let parent = $(this).parents('div.small-textarea');
    parent.find('.note-editable').removeClass('heigt');
    parent.find('#showbutton').children('.txt-btn').removeClass('view');
});

/*$('body').on('click','.expand-text', function (el) {
         $(this).addClass('heigt');
         $(this).next( "div#showbutton" ).find('div').addClass('view')
     $(el).closest('.small-textarea').addClass('heigt');
     myHandler();

});*/

$(document).on('focus','.note-editable','.note-btn', function (e) {
         $(this).addClass('heigt');
        let parent = $(this).parents('div.small-textarea');
        parent.find('#showbutton').children('.txt-btn').addClass('view');
        myHandler();
        
});
/*
$('.expand-text').click(function (el) {
         $(this).addClass('heigt');
         console.log('element', $(this).next( "div#showbutton" ).find('div').addClass('view'))
     $(el).closest('.small-textarea').addClass('heigt');
     myHandler();

});*/

//masonry
$(document).on('click', '.commt-cancel', function(e) {
       myHandler();
     });
  function myHandler() {

        var $grid = $('.grid').masonry({
            itemSelector: '.grid-item',
            percentPosition: 'true',
            fitWidth: true,
            gutter: 12,
           
        });
        $grid;

    }
    if(typeof  window.myHandler == 'undefined'){
       setTimeout(function(){myHandler()},5000);
    }
    // $(window).on('load', function() {
    // })  

    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
        myHandler();
    });

   // TEXTAREA  
      $('#summernote-cmt').summernote(
    {
        height: 150,
        toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'underline', 'clear']],
        ['para', ['ul', 'ol', 'paragraph']],
        ['insert', ['link', 'picture']],

        ]
    });

    $('#summernote').summernote(
    {
        height: 150,
        toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'underline', 'clear']],
        ['para', ['ul', 'ol', 'paragraph']],
        ['insert', ['link', 'picture']],

        ]
    });
    
    $(function () {
        $('[data-toggle="popover"]').popover()
    })
    
    
    // footer closepanel
    
    $("footer .col-sm-3 h4").click(function() {
        $(this).parent().toggleClass('open');   
    });
    
    // mobile menu 
    $(".side-toggle").click(function() {
        $(".mob-submenu").toggleClass('open');
        $(".bg-over").addClass('in')
    });
    
    // mobile menu 
    
    $(".shop-category li a").click(function() {
        $(".mob-subcategory").addClass('open');

        $(".mob-featured, .mob-category").hide();
        $(".mob-featured").removeClass('view');
        $(".mob-category").removeClass('view');
    });
    
    $(".backfirst-arrow-category").click(function() {
        $(this).parents(".shop-overlay-section").toggleClass('open');

    });
    
    $(".back-arrow-category, .bg-over").click(function() {
        $(".mob-submenu").removeClass('open');
        $(".bg-over").removeClass('in')
    });
    
    $(".sub_menu").click(function() {
        $(".shop-overlay-section").removeClass('open');

    });
    
    $(".back-arrow-subcategory").click(function() {
        $(this).parents(".mob-subcategory").removeClass('open');
        $(".mob-featured").addClass('view');
        $(".mob-category").addClass('view');
    });

    
    $(".back-close-category").click(function() {
        $(".mob-submenu").removeClass('open');
        $(".bg-over").removeClass('in')

    });
    
    $(".noti-fication").click(function(e) {
        e.stopPropagation();

    });
    
    $(".noti-close").click(function(e) {
        $(".noti-fication").removeClass('show');
    });
    
    
    // mobile sub menu 
    $(".collapse-submenu").hide();
    $(".panel-heading").click(function (e) {
        e.stopPropagation();
        $(".collapse-submenu").show();

    });
    
    
    // mobile notification
    $(".click-noti").click(function(e) {
        $(".noti-fication").toggleClass('show');
    });
    
    // mobile filter
    $(".shop-filter").click(function(e) {
        $(".left-portion").toggleClass('show');
        $(".bg-over").toggleClass('in')
    });
    
    $(".filter-close, .bg-over").click(function(e) {
        $(".left-portion").removeClass('show');
        $(".bg-over").removeClass('in')
    });
    
    // block person
    $(".block-us").click(function () {
        $(this).next().text(function(i, v){
            return v === 'Block' ? 'Unblock' : 'Block'
        })
    });
    
    //back to top
    $('#goTop').goTop({
        src: "la la-angle-up",
    });
    $('.summernote-media').summernote({
        height: 150,
        toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'underline', 'clear']],
        ['color', ['color']],
        ['para', ['ul', 'ol', 'paragraph']],
        ['insert', ['link', 'picture', 'video']],
        ['view', ['fullscreen', ]]
        ]
    });
    
    $('.summernote-image').summernote({
        height: 80,
        toolbar: [
        ['style', ['style']],
        ['font', ['bold', 'underline', 'clear']],

        ['para', ['ul', 'ol', 'paragraph']],
        ['insert', ['link', 'picture',]],
        ]
    });


});



 