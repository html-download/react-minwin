/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorCommunicationMap', {
    communicationMapid: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'communication_mapid'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    mapInput: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'map_input'
    },
    mapNote: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'map_note'
    },
    mapType: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'map_type'
    },
    activationStatus: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'yes',
      field: 'activation_status'
    }
  }, {
    tableName: 'ss16_vendor_communication_map'
  });
};
