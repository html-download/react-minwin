'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');


const initialState = {
    show: false,
    loading: false,
    error: undefined,
    hasError: {},
    help: {},
    title: '',
    datetime: '',
    notes: '',
    deal_id: 0,
    customer_id: 0,
    is_done: 0,
    deal_data: [],
    customer_data: [],
    edit_task: {}
};

const reducer = function (state = initialState, action) {
    
    if (action.type === Constants.SHOW_CREATE_NEW) {                        

        return ObjectAssign({}, state, {
            show: true,
            edit_task: action.task_data
        });
    }

    if (action.type === Constants.HIDE_CREATE_NEW) {

        return ObjectAssign({}, state, {
            show: false,
            edit_task: {}
        });
    }

    if (action.type === Constants.GET_TASK_RESULTS) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.GET_TASK_RESULTS_RESPONSE) {

        const validation = ParseValidation(action.response);
        
        const stateUpdates = {            
            loading: false,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            nationality_data: action.response ? action.response.data : []   
        };

        return ObjectAssign({}, state, stateUpdates);
    }    

    return state;
};


module.exports = reducer;
