/* global window, document */
'use strict';
const Cookie = require('cookie');
const Qs = require('qs');
const Xhr = require('xhr');
const UserIdentity = require('./user-identity');
const ToasterContainer = require('../components/toaster.jsx');
const Toaster = new ToasterContainer();


const jsonFetch = function (options, callback) {

    const cookies = Cookie.parse(document.cookie);
    const config = {
        url: options.url,
        method: options.method,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    };

    if (UserIdentity._checkUserToken() !== null) {
        config.headers['X-api-key'] = UserIdentity._checkUserToken();
    }
    
    /*if (cookies.crumb) {
        config.headers['X-CSRF-Token'] = cookies.crumb;
    }*/

    if (options.query && options.method !== 'DELETE') {
        config.url += '?' + Qs.stringify(options.query);
    }

    if (options.data) {
        config.body = JSON.stringify(options.data);
    }

    if (options.method === 'DELETE') {
        config.body = JSON.stringify(options.query);
    }

    Xhr(config, (err, response, body) => {

        if (err) {
            return callback(err);
        }
        
        if (response.statusCode > 200) {
            body = JSON.parse(body);
            if ( body.message && (body.message === 'Not Authenticated' || body.message === 'User Not Authorized')) {
                localStorage.removeItem("user");
                Toaster.success('Your session has expired! login again');
                window.location.href = "/";
            }
        }
        if (response.statusCode >= 200 && response.statusCode < 300) {
            if (response.headers.hasOwnProperty('x-auth-required')) {
                if (window.location.pathname === '/login') {
                    return callback(Error('Auth required.'));
                }

                let returnUrl = window.location.pathname;

                if (window.location.search.length > 0) {
                    returnUrl += window.location.search;
                }

                returnUrl = encodeURIComponent(returnUrl);

                window.location.href = `/login?returnUrl=${returnUrl}`;
            }
            else {

                body = JSON.parse(body);
                body.statusCode = response.statusCode;
                callback(null, body);
                //callback(null, JSON.parse(body));
            }
        }
        else {
            const httpErr = new Error(response.rawRequest.statusText);
            if (response.statusCode === 500) {
                callback(httpErr, httpErr);
            } else {
                callback(httpErr, JSON.parse(body));
            }
        }
    });
};


if (global.window) {
    window.jsonFetch = jsonFetch;
}


module.exports = jsonFetch;
