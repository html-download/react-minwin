<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <section class="checkout-notification">
    <div class="container">
      <ul class="reset">
        <li class="active"><span><i>1</i> Account Info</span></li>
        <li class="focus"><span><i>2</i> Delivery Type</span></li>
        <li><span><i>3</i> Payment Method</span></li>
        <li><span><i>4</i> Order Confirmation</span></li>
      </ul>
      <!-- ul end -->
    </div>
    <!-- container -->
  </section>
  <!-- checkout notification -->
  <section class="checkout-page-content">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">
          <!-- full-row -->
          <div class="full_row">
            <!-- checkout box -->
            <div class="checkout-box">
              <i class="fi user1 icon-side"></i>
              <!-- boxed -->
              <div class="boxed">
                <!-- c title -->
                <div class="c-title">
                  <h3>Account Info</h3>
                  <p>You are logged in successfully</p>
                </div>
                <!-- c title -->
                <!-- after login -->
                <div class="after-login">
                  <ul class="user-info">
                    <li><p><i class="fi user1"></i> Khuzaimah Raghid</p></li>
                    <li><p><i class="fi mail"></i> khuzaimahraghid@gmail.com</p></li>
                    <li><p><i class="fi mobile1"></i> +98765432101</p></li>
                  </ul>
                </div>
                <!-- after login -->
              </div>
              <!-- boxed -->
            </div>
            <!-- checkout box -->
               <!-- checkout box -->
            <div class="checkout-box">
              <i class="fi pin3 icon-side"></i>
              <!-- boxed -->
              <div class="boxed">
                <!-- c title -->
                <div class="c-title">
                  <h3>Pickup and Delivery Address</h3>
                  <p>You can choose your pickup and delivery address here.</p>
                </div>
                <!-- c title -->

                 <!-- dine in section -->
                  <div class="dine-in-area opens">
                    <div class="row">
                      <div class="col-sm-4">
                        <div class="form-group icon-style-1">
                          <label>Pickup Date</label>
                          <i class="fi calendar3"></i>
                          <select class="selectpicker">
                            <option>7/17/2019</option>
                            <option>7/18/2019</option>
                            <option>7/19/2019</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group icon-style-1">
                          <label>Pickup Time</label>
                          <i class="fi clock2"></i>
                          <select class="selectpicker">
                            <option>10:30 AM</option>
                            <option>11:00 AM</option>
                            <option>11:30 AM</option>
                            <option>12:00 PM</option>
                            <option>12:30 PM</option>
                            <option>01:00 PM</option>
                            <option>01:30 PM</option>
                            <option>02:00 PM</option>
                            <option>02:30 PM</option>
                            <option>03:00 PM</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-4">
                      </div>
                    </div>
                         <div class="row">
                      <div class="col-sm-4">
                        <div class="form-group icon-style-1">
                          <label>Delivery Date</label>
                          <i class="fi calendar3"></i>
                          <select class="selectpicker">
                            <option>7/17/2019</option>
                            <option>7/18/2019</option>
                            <option>7/19/2019</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group icon-style-1">
                          <label>Delivery Time</label>
                          <i class="fi clock2"></i>
                          <select class="selectpicker">
                            <option>10:30 AM</option>
                            <option>11:00 AM</option>
                            <option>11:30 AM</option>
                            <option>12:00 PM</option>
                            <option>12:30 PM</option>
                            <option>01:00 PM</option>
                            <option>01:30 PM</option>
                            <option>02:00 PM</option>
                            <option>02:30 PM</option>
                            <option>03:00 PM</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-sm-4">
                      </div>
                    </div>
                  </div>
                  <!-- dine in section -->
              
                <!-- saved-->
                                      <!-- saved address -->
                    <div class="saved-address opens">
                      <!-- custom row -->
                      <div class="cs-row">
                      <ul class="reset">
                        <li>
                          <div class="box">
                            <h5>Home</h5>
                            <address>
                              Opposite Prestige Laundry, <br>
                              Al Mattar Al Qadeem 2nd Street, <br>
                            Old Airport Area, Doha.
                            </address>
                            <input type="radio" class="check-deliver" name="deliver" id="deli1" checked>
                            <label class="check-deliver" for="deli1">Delivery Here</label>
                            <div class="options">
                              <a href="#" class="edit fi"></a>
                              <a href="#" class="trash2 fi"></a>
                            </div>
                          </div>
                        </li>
                         <li>
                          <div class="box">
                            <h5>Apartment</h5>
                            <address>
                              Opposite Prestige Laundry, <br>
                              Al Mattar Al Qadeem 2nd Street, <br>
                            Old Airport Area, Doha.
                            </address>
                            <input type="radio" class="check-deliver" name="deliver" id="deli2">
                            <label class="check-deliver" for="deli2">Delivery Here</label>
                            <div class="options">
                              <a href="#" class="edit fi"></a>
                              <a href="#" class="trash2 fi"></a>
                            </div>
                          </div>
                        </li>
                          <li>
                          <div class="box">
                            <h5>Office</h5>
                            <address>
                              Opposite Prestige Laundry, <br>
                              Al Mattar Al Qadeem 2nd Street, <br>
                            Old Airport Area, Doha.
                            </address>
                            <input type="radio" class="check-deliver" name="deliver" id="deli3">
                            <label class="check-deliver" for="deli3">Delivery Here</label>
                            <div class="options">
                              <a href="#" class="edit fi"></a>
                              <a href="#" class="trash2 fi"></a>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div class="box add-new-address">
                            <a href="javascript:void(0);" class="d-tables">
                              <span class="d-table-cell">
                                <i class="fi plus-circle2"></i>
                                Add New Address
                              </span>
                            </a>
                          </div>
                        </li>
                      </ul>
                    </div>
                    <!-- custom row -->
                    </div>
                    <!-- saved address -->
                <!--saved end--->


              </div>
              <!-- boxed -->
            </div>
            <!-- checkout box -->
                 <!-- checkout box -->
            <div class="checkout-box deactive">
              <i class="fi wallet2 icon-side"></i>
              <!-- boxed -->
              <div class="boxed">
                <!-- c title -->
                <div class="c-title">
                  <h3>Payment Option</h3>
                  <p>You can choose your payment method to place order.</p>
                </div>
                <!-- c title -->
                  <!-- box radio -->
                <div class="box-radio">
                  <input type="radio" class="radios" id="online" name="type" checked value="online">
                  <label for="online" class="radios"><i class="fi credit-card1"></i> Online </label>
                  <input type="radio" class="radios" id="cod" name="type" value="cod">
                  <label for="cod" class="radios"><i class="fi cash"></i> Cod</label>
                  <input type="radio" class="radios" id="Wallet" name="type" value="wallet">
                  <label for="Wallet" class="radios"><i class="fi wallet2"></i> Wallet <span class="cash-amount">Balance <b>QR 250</b></span> </label>
                </div>
                <!-- box radio -->
              </div>
              <!-- boxed -->
            </div>
            <!-- checkout box -->

            <!-- place order button -->
            <div class="place-order text-right">
              <button class="btn" onclick="location.href='/confirmation';"><i class="fi tick1"></i> Place Order</button>
            </div>
            <!-- place order button -->

          </div>
          <!-- full-row -->

        </div>
        <!-- col-sm-8 -->
        <div class="col-sm-4">
          <div class="side_bar_cart">
            <ul class="mini_cart">
              <li class="vendor">
                <h5>Dirty Drawz Laundry Service</h5>
                <span>Abu Hamour</span>
              </li>
              <li class="item">
                <p>Dry Cleaning</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>		
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->			
                <a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
                <span class="price">QR 20</span>
              </li>
              <li class="item">
                
                <p>Blouse/Top</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>		
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->
                <span class="price">QR 20</span>
              </li>
              <li class="item">                
                <p>Ghee Rice + Pepper Chicken</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>		
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->			
                <a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
                <span class="price">QR 20</span>
              </li>
              <li class="item">
                <p><img src="assets/img/non-veg.svg">Mutton Biryani + Fried Leg + Pepsi 1/2</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>		
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->			
                <a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
                <span class="price">QR 20</span>
              </li>
            </ul>
            <!-- bill details -->
            <div class="bill-details">
              <div class="any-comments">
                <!-- any comments -->
                <div class="form-group">
                  <!-- formgroup -->
                  <textarea class="form-control" placeholder="Any comments? We will pass it to restaurant..."></textarea>
                </div>
              </div>
              <!-- any comments -->
              <!-- smile points -->
              <div class="smile-points">
                <p class="b">Smile Points</p>
                <span>Available Points - 150 <i class="info3 fi"></i> </span>
                <button class="redeem">REDEEM</button>
              </div>
              <!-- smile points -->
              <!-- Promocode -->
              <div class="promocode">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="PROMO CODE">
                  <div class="input-group-append">
                    <button class="btn btn-grey" type="button">APPLY</button>
                  </div>
                </div>
                <!-- Promocode -->
                <!-- text right -->
                <div class="text-right">
                  <a href="#apply-coupon" data-toggle="modal" data-target="#apply-coupon" class="primary-underline">Available Offers</a>
                </div>
                <!-- text right -->
              </div>
              <!-- Promocode -->
              <div class="bill-content">
                <p class="text-black">Bill Details</p>
                <p>Sub Total <span>QR 80</span></p>
                <p>Delivery Charge <span>QR 15</span></p>
                <p>Packaging Charge <span>QR 15</span></p>
                <p class="pink">Discount Value <span>- QR 10</span></p>
                <p class="pink">Smile Points <span>- QR 15</span></p>
                <p class="total">Total Amount <span>- QR 15</span></p>
              </div>
            </div>
            <!-- bill details -->
          </div>
          <!-- sidebar cart -->
        </div>
        <!-- col-sm-4 -->
      </div>
      <!-- row -->
    </div>
  </section>
</div>
<!--site_page-->


<!-- apply coupon -->
<div id="apply-coupon" class="modal available-Offers-modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>
      <div class="modal-body">
        <h2>Available Offers</h2>
        <ul class="offers-ul">
          <li>
            <div class="offer-box">
              <h3>Get 20% discount using YES Bank Cards</h3>
              <p>Use code YESBANK20 and get 20% discount up to Rs.75 on orders above Rs.300. Valid only on Wednesday & Thursday</p>
              <div class="flex">
                <div class="ticket">YESBANK20</div>
                <button class="btn line">APPLY COUPON</button>
              </div>
            </div>
          </li>
          <li>
            <div class="offer-box">
              <h3>Get 30% discount using Mastercard</h3>
              <p>Use code MASTERCARD100 & get 30% discount up to Rs.100 on your 2 orders above Rs.99</p>
              <div class="flex">
                <div class="ticket">MASTERCARD100</div>
                <button class="btn line">APPLY COUPON</button>
              </div>
            </div>
          </li>
          <li>
            <div class="offer-box">
              <h3>Get 20% discount using Lakshmi Vilas Bank Cards</h3>
              <p>Use code LVB20 & get 20% discount up to Rs.50 on your orders above Rs.200</p>
              <div class="flex">
                <div class="ticket">LVB20</div>
                <button class="btn line">APPLY COUPON</button>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <!--modal-body-->
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!-- apply coupon -->


<?php include ('inc/footer.php'); ?>
