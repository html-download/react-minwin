document.write('<scr'+'ipt type="text/javascript" src="/js/jquery-ui.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="/js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="/js/chosen.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="/js/intlTelInput.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="/js/jquery.validate.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="/js/wow.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="/js/carousel.min.js" ></scr'+'ipt>');