const ClassNames = require('classnames');
const ControlGroup = require('./control-group.jsx');
const ObjectAssign = require('object-assign');
const PropTypes = require('prop-types');
const React = require('react');

const propTypes = {
    autoCapitalize: PropTypes.string,
    disabled: PropTypes.bool,
    hasError: PropTypes.bool,
    help: PropTypes.string,
    inputClasses: PropTypes.object,
    label: PropTypes.array,
    labelPositionBottom: PropTypes.bool,
    hideLabel: PropTypes.bool,
    name: PropTypes.string,
    id: PropTypes.string,
    onChange: PropTypes.func,
    placeholder: PropTypes.string,
    type: PropTypes.string,
    value: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    groupClasses: PropTypes.object
};
const defaultProps = {
    type: 'text',
    autoCapitalize: 'off'
};


class TextControl extends React.Component {
    constructor(props){
        super(props);
        this.state = {
          type: this.props.type,
        }
        this.showHide = this.showHide.bind(this);
    }
    showHide(e){
        e.preventDefault();
        e.stopPropagation();
        this.setState(ObjectAssign(this.state, {
            type: this.state.type === 'input' ? 'password' : 'input'
        }));
    }
    focus() {

        return this.input.focus();
    }

    value() {

        return this.input.value;
    }

    render() {
        const groupClasses = ClassNames(ObjectAssign({
            'form-group': true,
            'has-error': this.props.hasError
        }, this.props.groupClasses));

        const passwordClass = ClassNames({
          'pass-show': true,
          'fa fa-fw': true,
          'field-icon': true,
          'toggle-password': true,
          'fa-eye': this.state.type === 'password',
          'fa-eye-slash': this.state.type === 'input'
        });

        const inputClasses = ClassNames(ObjectAssign({
            'form-control': true
        }, this.props.inputClasses));

        let passwordViewer;
        if (this.props.type === 'password') {
            passwordViewer = <p className={passwordClass} data-toggle={this.props.id} onClick={this.showHide}>
                
                {this.state.type === 'input' ? <span className="hide">&nbsp;Hide</span> : <span>&nbsp;Show</span>}
            </p>;
        }
        return (
            <ControlGroup
                hasError={this.props.hasError}
                label={this.props.label}
                hideLabel={this.props.hideLabel}
                labelPositionBottom={this.props.labelPositionBottom}
                help={this.props.help}
                groupClasses={this.props.groupClasses}>

                <input
                    ref={(c) => (this.input = c)}
                    type={this.state.type}
                    autoCapitalize={this.props.autoCapitalize}
                    className={inputClasses}
                    name={this.props.name}
                    id={this.props.id}
                    placeholder={this.props.placeholder}
                    value={this.props.value}
                    disabled={this.props.disabled ? 'disabled' : undefined}
                    onChange={this.props.onChange}
                />
                {passwordViewer}
            </ControlGroup>
        );
    }
}

TextControl.propTypes = propTypes;
TextControl.defaultProps = defaultProps;


module.exports = TextControl;
