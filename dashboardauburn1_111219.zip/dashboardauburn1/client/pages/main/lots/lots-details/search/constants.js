'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'CREATE_NEW',
    'CREATE_NEW_RESPONSE',
    'GET_CLIENT_LOT_RESULTS',
    'GET_CLIENT_LOT_RESULTS_RESPONSE',
    'GET_LOT_RESULTS',
    'GET_LOT_RESULTS_RESPONSE',
    'HIDE_CREATE_NEW',
    'SHOW_CREATE_NEW',
    'UPDATE_LOT_STATUS',
    'UPDATE_LOT_STATUS_RESPONSE'
]);
