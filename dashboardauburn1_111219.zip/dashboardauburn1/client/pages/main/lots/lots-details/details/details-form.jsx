'use strict';
const Actions = require('./actions');
const Alert = require('../../../../../components/alert.jsx');
const Button = require('../../../../../components/form/button.jsx');
const ControlGroup = require('../../../../../components/form/control-group.jsx');
const LinkState = require('../../../../../helpers/link-state');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../../components/form/spinner.jsx');
const TextControl = require('../../../../../components/form/text-control.jsx');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const ObjectAssign = require('object-assign');

const propTypes = {
    _id: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    loading: PropTypes.bool,
    name: PropTypes.object,
    showSaveSuccess: PropTypes.bool, 
    clients : PropTypes.string
};

class DetailsForm extends React.Component {
    constructor(props) {

        super(props);

        this.state = {
            name: props.name
        };

    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            name: nextProps.name
        });
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        const id = this.props._id;
        const data = {
            client_name: this.state.name.client_name,
            lot_name: this.state.name.lot_name
        };

        Actions.saveDetails(this.state.name.client_name, this.state.name.lot_name, data, this.props.history);
    }

    LinkState(e) {
        
        this.setState(ObjectAssign(this.state.name, {
            'client_name' : e.target.value 
        }));
    }
    render() {

        const data = this.props.clients === undefined ? (
            <option></option>
        ) : this.props.clients.map((record, index) => {
            return (
                <option selected={this.state.name.client_name === record.client_name} value={record.client_name}>{record.client_name}</option>
            )
        });
        
        const alerts = [];

        if (false && this.props.showSaveSuccess) {
            alerts.push(<Alert
                key="success"
                type="success"
                onClose={Actions.hideDetailsSaveSuccess}
                message="Success. Changes have been saved."
            />);
        }

        if (this.props.error) {
            alerts.push(<Alert
                key="danger"
                type="danger"
                message={this.props.error}
            />);
        }

        const formElements = <fieldset>
            <legend>Details</legend>
            {alerts}
            <TextControl
                name="name.lot_name"
                label="Lot Name (not editable)"
                value={this.state.name.lot_name}
                //onChange={this.LinkState.bind(this)}
                hasError={this.props.hasError['name.lot_name']}
                help={this.props.help['name.lot_name']}
                disabled={this.props.loading}
            />
            <SelectControl
                name="client_name"
                label="Client Name (not editable)" 
                //value={this.state.name.client_name}
                onChange={this.LinkState.bind(this)}
                hasError={this.props.hasError['name.client_name']}
                help={this.props.help['name.client_name']}
                disabled={this.props.loading}>

                <option>Please select client</option>
                {data}
            </SelectControl>
            <ControlGroup hideLabel={true} hideHelp={true}>
                <Button
                    type="submit"
                    inputClasses={{ 'btn': true, 'mb15': true }}
                    disabled={this.props.loading}>

                    Save changes
                    <Spinner space="left" show={this.props.loading} />
                </Button>
            </ControlGroup>
        </fieldset>;

        return (
            <form onSubmit={this.handleSubmit.bind(this)}>
                {formElements}
            </form>
        );
    }
}

DetailsForm.propTypes = propTypes;


module.exports = DetailsForm;
