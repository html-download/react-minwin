import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import Container from 'react-bootstrap/Container'
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';

import { connect} from 'react-redux';
class Home extends Component{
  constructor(props){
    super(props);
  /*  this.state={

      num_count_1: 50,
      num_count_2: 100,
      num_count_3: 300,
    }*/
  }


render(){
  return(
     <div>
     <Container>
        <Nav activeKey="/home">
            <Nav.Item>
            <Nav.Link href="/home"><Link to="/">Home</Link></Nav.Link>
            </Nav.Item>
            <Nav.Item>
             <Nav.Link eventKey="link-2"><Link to="/contact">Contact</Link></Nav.Link>
       </Nav.Item>
   </Nav>
        <div class="content-wrap">
          <ul>
            <li>
              <span>{this.props.num_1}</span>
               <h3>Feature</h3>
            </li>
             <li>
              <span>{this.props.num_2}</span>
               <h3>Feature</h3>
            </li>
             <li>
              <span>{this.props.num_3}</span>
               <h3>Feature</h3>
            </li>
           <li><a onClick={this.props.numFunc}>Click</a></li>
          </ul>
        </div>
        </Container>

     </div>
    )

   }

}

const mapStateToProps = (state) => {

  return{
    num_1:state.num_count_1,
    num_2:state.num_count_1,
    num_3:state.num_count_1,


  }
}
const mapDispatchToProps = (dispatch) =>{
  return{
      numFunc: () => dispatch({type: 'NUM_UPDATE'})
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(Home);