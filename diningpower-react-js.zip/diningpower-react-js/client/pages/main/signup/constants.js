const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'REGISTER',
    'REGISTER_RESPONSE'
]);
