'use strict';
const RequireDir = require('require-dir');
const EnvHelper = require('./client/helpers/environment.js');

let NODE_ENV = EnvHelper.toGetEnv();

global.inProduction = NODE_ENV === 'production';

RequireDir('./gulp');
