module.exports = function(){
// function Obj    (i)         { return document.getElementById(i); }
// function Hide   (i)         { document.getElementById(i).style.display = "none"; }
// function Show   (i)         { document.getElementById(i).style.display = "block"; }
// function ShowIf (i, c)      { document.getElementById(i).style.display = c ? "block" : "none"; }
// function MoveTo (i, x, y)   { var o = document.getElementById(i); o.style.left = x + "px"; o.style.top = y + "px"; }

FlipH: function (i, width, initial, final, duration, delay)
{
    var obj     = Obj(i);
    var frames  = width >> 1;
    var speed   = duration / width;

    setTimeout(function() { obj.className = initial; obj.style.width = width + "px"; }, delay);

    for (var x = 0; x < frames; x++)
    {
        setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

        delay += speed;
    }

    setTimeout(function() { obj.style.width = "0"; obj.style.marginLeft = "0"; obj.className = final; }, delay);

    for (var x = frames - 1; x >= 0; x--)
    {
        setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

        delay += speed;
    }

    setTimeout(function() { obj.style.width = width + "px"; obj.style.marginLeft = "0"; }, delay);

    return delay;
},

Slide: function (i, x1, y1, x2, y2, fps, duration, delay)
{

},

Obj: function (id)
{
    var o = document.getElementById(id);

    if (o == null)
    {
        alert("Object not found: " + id);
    }

    if (!o.IsExtended)
    {
        //////////////////////////////////////////////////////////////////////
        //
        // HIDE
        //
        //////////////////////////////////////////////////////////////////////

        o.Hide = function()
        {
            this.style.display = "none";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SHOW
        //
        //////////////////////////////////////////////////////////////////////

        o.Show = function()
        {
            this.style.display = "block";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SHOW IF
        //
        //////////////////////////////////////////////////////////////////////

        o.ShowIf = function(c)
        {
            this.style.display = c ? "block" : "none";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // FLIP HORIZONTALLY
        //
        //////////////////////////////////////////////////////////////////////

        o.FlipH = function(width, initial, final, duration, delay)
        {
            var obj     = this;
            var frames  = width >> 1;
            var speed   = duration / width;

            setTimeout(function() { obj.className = initial; obj.style.width = width + "px"; }, delay);

            for (var x = 0; x < frames; x++)
            {
                setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

                delay += speed;
            }

            setTimeout(function() { obj.style.width = "0"; obj.style.marginLeft = "0"; obj.className = final; }, delay);

            for (var x = frames - 1; x >= 0; x--)
            {
                setTimeout(function(nw, nm) { return function() { obj.style.width = nw + "px"; obj.style.marginLeft = nm + "px"; } }(width - (x << 1), x), delay);

                delay += speed;
            }

            setTimeout(function() { obj.style.width = width + "px"; obj.style.marginLeft = "0"; }, delay);

            return delay;
        };

        //////////////////////////////////////////////////////////////////////
        //
        // MOVE TO
        //
        //////////////////////////////////////////////////////////////////////

        o.MoveTo = function(x, y)
        {
            this.style.left = x + "px";
            this.style.top  = y + "px";
        };

        //////////////////////////////////////////////////////////////////////
        //
        // ROTATE
        //
        //////////////////////////////////////////////////////////////////////

        o.Rotate = function(a)
        {
            var s = "rotate(" + a + "deg)";

            this.style.transform        = s;
            this.style.mozTransform     = s;
            this.style.msTransform      = s;
            this.style.oTransform       = s;
            this.style.sandTransform    = s;
            this.style.webkitTransform  = s;
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SLIDE
        //
        //////////////////////////////////////////////////////////////////////

        o.Slide = function(x1, y1, x2, y2, fps, duration, delay)
        {
            var dx      = x2 - x1;
            var dy      = y2 - y1;
            var frames  = duration * fps / 1000;
            var speed   = duration / frames;
            var ox      = dx / frames;
            var oy      = dy / frames;
            var src     = this;

            setTimeout(function() { src.style.left = x1 + "px"; src.style.top = y1 + "px"; src.style.display = "block"; }, delay);

            for (var frame = 0; frame < frames; frame++) { delay += speed; setTimeout(function(x, y) { return function() { src.style.left = x + "px"; src.style.top  = y + "px"; }; }(x1 + (frame * ox), y1 + (frame * oy)), delay); }

            setTimeout(function() { src.style.left = x2 + "px"; src.style.top  = y2 + "px"; }, delay);

            return delay;
        };

        //////////////////////////////////////////////////////////////////////
        //
        // SLIDE AND RESIZE
        //
        //////////////////////////////////////////////////////////////////////

        o.SlideResize = function(x1, y1, w1, h1, x2, y2, w2, h2, fps, duration, delay)
        {
            var dx      = x2 - x1;
            var dy      = y2 - y1;
            var frames  = duration * fps / 1000;
            var speed   = duration / frames;
            var ox      = dx / frames;
            var oy      = dy / frames;
            var ow      = (w2 - w1) / frames;
            var oh      = (h2 - h1) / frames;
            var src     = this;

            setTimeout(function()
            {
                src.style.left      = x1 + "px";
                src.style.top       = y1 + "px";
                src.style.width     = w1 + "px";
                src.style.height    = h1 + "px";
                src.style.display   = "block";
            }, delay);

            for (var frame = 0; frame < frames; frame++) { delay += speed; setTimeout(function(x, y, w, h) { return function() { src.style.left = x + "px"; src.style.top = y + "px"; src.style.width = w + "px"; src.style.height = h + "px"; }; }(x1 + (frame * ox), y1 + (frame * oy), w1 + (frame * ow), h1 + (frame * oh)), delay); }

            setTimeout(function()
            {
                src.style.left   = x2 + "px";
                src.style.top    = y2 + "px";
                src.style.width  = w2 + "px";
                src.style.height = h2 + "px";
            }, delay);

            return delay;
        };

        o.IsExtended = true;
    }

    return o;
}

}
