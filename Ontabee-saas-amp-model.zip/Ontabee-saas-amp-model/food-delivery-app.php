<?php include ('inc/header.php'); ?>

<div class="page_banner bg3 style1">
	<div class="container pad0">
		<div class="col-sm-7 text-left mt30">
			<h1 class="head wow fadeInDown">FOOD DELIVERY APP</h1>
			<h2 class="head wow fadeInUp">Delivery app is to automate your delivery schedule</h2>
			<p class="apps">
				<a href="https://play.google.com/store/apps/details?id=com.tech.ontabee.deliveryboy" target="_blank"><img src="images/playstore.png" class="wow fadeInUp" alt="Playstore"></a>
				<a class="hide"><img src="images/appstore.png" class="wow fadeInUp" alt="Appstore"></a>
			</p>

			<span class="play wow fadeInUp" data-toggle="modal" data-target="#modal_video">
				<i class="fa fa-play"></i> Watch Video
			</span>
		</div>
		<div class="col-sm-5">
			<img src="images/delivery-app.png" class="wow fadeInUp" alt="Food Ordering System" data-wow-duration="1.5s">
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Give the most powerful delivery app to your delivery team</h2>
		<p class="mb0 wow fadeInUp">Our Online food delivery app is designed to serve customer of their taste, wherever they are, at their doorstep. Our online restaurant delivery app allows customers to choose their favourites from home or anywhere.</p>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="grey">
	<div class="container text-center">
		<h2 class="head wow fadeInUp">Delivery App Settings</h2>
		<ul class="reset timeline">
			<li>
				<i class="fi truck wow zoomIn"></i>
				<div class="content wow fadeInLeft">					
					<h2 class="head">Pickup & Delivery</h2>
					<p>Integrate your pickup & delivery with your restaurant online ordering system. Schedule and dispatch orders to your delivery man and track them in real-time.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi map-location wow zoomIn"></i>
				<div class="content wow fadeInRight">	
					<h2 class="head">Manage delivery</h2>
					<p>Assign and manage your deliveries near to your branch.</p>
				</div>
			</li>
			<li>
				<i class="fi fast-food wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Receive orders</h2>
					<p>Receive the orders via the app, You get the push notification which you either accept or decline the orders instantly.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi add-place wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Add location</h2>
					<p>Create multiple restaurants from your account and set up their menu items, product brands & delivery location.</p>
				</div>
			</li>
			<li>
				<i class="fi setting-location wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Manage Location</h2>
					<p>Each customer gets an account and they can view and track their orders, delivery staff can manage the delivery.</p>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="app_feature style1">	
	<div class="container pad0">		
		<h2 class="head mb40 wow fadeInUp">Features of online restaurant delivery system</h2>

		<ul class="reset text-right">
			<li class="wow fadeInLeft" data-wow-duration="1s">
				<i class="fa fa-map-marker"></i><span>Auto-delivery dispatching system</span>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="1.5s">
				<i class="fa fa-user-o"></i><span>Order allocation and also giving alerts & reminder for the delivery boy.</span>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="2s">
				<i class="fa fa-server"></i><span>Delivery staff dashboard - let the delivery staff can view all the assigned, declined, delivered order with the respective customer id.</span>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="2.3s">
				<i class="fa fa-credit-card"></i><span>Order status - it shows order status like whether it delivered or declined.</span>
			</li>
		</ul>
		
		<div class="img">
			<img src="images/delivery-app1.png" class="wow zoomIn" alt="mobile application" data-wow-duration="1.2s">
		</div>
		
		<ul class="reset last text-left">
			<li class="wow fadeInRight" data-wow-duration="1s">
				<i class="fa fa-smile-o"></i><span>Manage assigned order - The delivery staff can view the status of particular orders which is assigned to him with location & time.</span>
			</li>
			<li class="wow fadeInRight" data-wow-duration="1.5s">
				<i class="fa fa-gear"></i><span>Order history - Delivery staff can view the customer information including name, order item and location.</span>
			</li>
			<li class="wow fadeInRight" data-wow-duration="2s">
				<i class="fa fa-gear"></i><span>Manage profile - can create a profile listing which consists personal information of the customer.</span>
			</li>
			<li class="wow fadeInRight" data-wow-duration="2.3s">
				<i class="fa fa-gear"></i><span>Delivery Notification - Admin & outlet receive notification from delivery boy once the customer receives the order.</span>
			</li>
		</ul>	
	</div> <!--container-->	
</section> <!--page_banner-->

<section class="grey">
	<div class="container text-center">
		<h2 class="head wow fadeInUp">Mobile App Screens</h2>
		<div class="screens owl-carousel">
			<div><img src="images/da-screen1.jpg" alt="Splash"><span>1. Splash</span></div>
			<div><img src="images/da-screen2.jpg" alt="Login"><span>2. Login</span></div>
			<div><img src="images/da-screen3.jpg" alt="New Orders"><span>3. New Orders</span></div>
			<div><img src="images/da-screen4.jpg" alt="Assigned Orders"><span>4. Assigned Orders</span></div>
			<div><img src="images/da-screen5.jpg" alt="Order Details"><span>5. Order Details</span></div>
			<div><img src="images/da-screen6.jpg" alt="Track Location"><span>6. Track Location</span></div>
			<div><img src="images/da-screen7.jpg" alt="Delivered Orders"><span>7. Delivered Orders</span></div>
			<div><img src="images/da-screen8.jpg" alt="Profile"><span>8. Profile</span></div>
        </div>
	</div> <!--container-->
</section> <!--page_banner-->

<div id="modal_video" class="modal fade" role="dialog">
	<div class="modal-dialog modal-sm">
		<a class="close" data-dismiss="modal"><i class="fa fa-close"></i></a>
		<iframe id="video" width="100%" height="100%" src="https://www.youtube.com/embed/favN6OgqGi4?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div><!--modal-dialog-->
</div><!--modal_video-->

<?php include('inc/footer.php');?>