import React, {Component} from 'react';
import {BrowserRouter as Router, Route, Link, NavLink} from 'react-router-dom';
import {fitBounds} from 'google-map-react/utils';

import LotList from './LotList.js';
import ZoneList from './ZoneList';
import Lot from './Lot';
import LotEdit from './LotEdit';
import Map from './Map';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            'showSideNav': false,
            //'apiKey': {'key': 'AIzaSyA6SE4CuWBxuaRMh-02bIX-6sEWMGaIO00'},
            'apiKey': {'key': 'AIzaSyDNlIS2XVNFDl-FS3HfSaEWAIzm4-t66Lw'},
            'center': {
                'lat': 32.593357,
                'lng': -85.495163
            },
            'zoom': 17,
            'mapHeight': 0,
            'mapWidth': 0,
            'markers': [],
            'isOpen' : false
        };
        this.toggleNav = this.toggleNav.bind(this);
        this.updateMapBounds = this.updateMapBounds.bind(this);
        this.editMapBounds = this.editMapBounds.bind(this);
        this.updateMapCenter = this.updateMapCenter.bind(this);
        this.setMarkers = this.setMarkers.bind(this);
    }

    toggleNav() {
        this.setState({'showSideNav': !this.state.showSideNav})
    }

    updateMapCenter(center, zoom) {
        this.setState({center: null, zoom: null});
        this.setState({center: center, zoom: zoom});

    }

    updateMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    editMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    setMarkers(markers) {
        this.setState({'markers': markers});
    }

    componentDidMount() {
        this.setState({'mapHeight': window.innerHeight, 'mapWidth': window.innerWidth});
        if (this.state.center && this.state.zoom) {
            this.updateMapCenter(this.state.center, this.state.zoom);
        }
    }

    render() {
        return (
            <Router>
                <div>
                    <main role="main" className="container">
                        <nav className="navbar navbar-expand-md fixed-top navbar-dark">
                            <Link className="navbar-brand" to="/">AU Parking</Link>
                            <button className="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas"
                                    onClick={() => {
                                        this.setState({'showSideNav': !this.state.showSideNav})
                                    }}>
                                <span className="navbar-toggler-icon"/>
                            </button>

                            <div
                                className={`navbar-collapse offcanvas-collapse ${this.state.showSideNav ? "open" : ""}`}
                                id="navbarsExampleDefault">
                                <ul className="navbar-nav mr-auto">
                                    {
                                        [
                                            {'path': '/', 'title': 'Lots'},
                                            {'path': '/zones', 'title': 'Zones'},
                                            {'path': '/about', 'title': 'About'},
                                            {'path': '/terms', 'title': 'Terms & Privacy'}
                                        ].map((navItem, index) => (
                                            <li className="nav-item" key={index}>
                                                <NavLink exact={true} className="nav-link" activeClassName="active"
                                                         to={navItem.path} onClick={() => {
                                                    this.setState({'showSideNav': false})
                                                }}>{navItem.title}</NavLink>
                                            </li>
                                        ))
                                    }
                                    <li className="nav-item">
                                        <a href="https://au-parking.com/parking-info/" className="nav-link" target="_blank" rel="noopener noreferrer">Parking Info</a>
                                    </li>
                                    <li className="nav-item">
                                        <a href="http://fopark.io/#contact" className="nav-link" target="_blank"
                                           rel="noopener noreferrer">Contact</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </main>
                    <div className="container" style={{zIndex: 1001}}>
                        <Route exact path="/" component={LotList}/>
                        <Route path="/lots/:lotID" render={(routerProps) => (
                            <Lot {...routerProps} updateMapBounds={this.updateMapBounds} setMarkers={this.setMarkers}/>
                        )}/>
                        <Route path="/lots/:lotID/edit" render={(routerProps) => (
                            <LotEdit {...routerProps} updateMapBounds={this.updateMapBounds} setMarkers={this.setMarkers}/>
                        )}/>
                        <Route path="/zones" component={ZoneList}/>
                        <Route path="/about" component={About}/>
                        <Route path="/terms" component={Terms}/>
                    </div>
                    <Map
                        markers={this.state.markers}
                        center={this.state.center}
                        zoom={this.state.zoom}
                    />
                    <img src="/images/fopark.png" alt="Powered By FoPark" style={{
                        position: 'fixed',
                        bottom: 30,
                        right: 70,
                        zIndex: 0
                    }}/>
                </div>
            </Router>
        );
    }
}

class About extends Component {
    render() {
        return (
            <div className="my-3 p-3 bg-white rounded box-shadow">
                <h6 className="border-bottom border-gray pb-2 mb-0">
                    <div>About</div>
                </h6>
                <p>AU Parking is powered by FoPark technology. FoPark is engineered by Focus Engineering.</p>
                <p>Every day, drivers around the world waste their valuable time and fuel in their cars looking for an
                    open spot in crowded parking lots. FoPark is a next generation parking solution that tells your
                    customers exactly where the open spots are, with near real time parking occupancy information.</p>
                <p>The solution uses cameras and computing power to bring the latest parking information to a mobile
                    application in the palm of your hand. Its core engine is a digital video parsing technology (patent
                    pending) that processes live video streams from camera installations in the parking lot. The
                    solution can be installed independently to provide occupancy information on a website or a Mobile
                    app. It can also be integrated with existing parking reservation systems and payment systems.</p>
                <p>The installation process is no different than installing surveillance cameras in a parking lot or in
                    a building. No digging up of asphalt in the parking lot, No shut down of parking lot for
                    installation is required.Why do you need a separate video surveillance system for a parking lot,
                    when FoPark can give you the available spots for parking and its exact location, along with a
                    surveillance system.</p>
            </div>
        );
    }
}

class Terms extends Component {
    render() {
        return (
            <div className="my-3 p-3 bg-white rounded box-shadow">
                <h6 className="border-bottom border-gray pb-2 mb-0">
                    <div>Terms of Use</div>
                </h6>
                <p><strong>Introduction</strong></p>
                <p>The following Terms of Use (the “Terms”) are a legally binding agreement that shall govern the
                    relationship between Focus Engineering, LLC (“Focus Engineering”), our users and others which
                    may interact or interface with FoPark, and our subsidiaries, affiliates, partners, and parent
                    organizations in association with the use of the FoPark web and mobile app (“FoPark”), which
                    shall be defined below. By using FoPark, you agree to accept these Terms, including the Privacy
                    Policy contained on this page below. You must not use FoPark if you disagree with the Terms.</p>
                <p>FoPark is designed for users 13 years of age or older. Children under 13 may not utilize FoPark
                    for any purpose.</p>
                <p><strong>Intellectual Property Rights, Google Maps</strong></p>
                <p>You do hereby acknowledge and agree that FoPark and any essential software that may be used in
                    connection with FoPark (“Software”) contain proprietary and confidential material that is
                    protected by applicable intellectual property rights and other laws. Furthermore, you herein
                    acknowledge and agree that any Content which may be contained in any advertisements or
                    information presented by and through our Services or by advertisers is protected by copyrights,
                    trademarks, patents or other proprietary rights and laws. Therefore, except for that which is
                    expressly permitted by applicable law or as authorized by FoPark or such applicable licensor,
                    you agree not to alter, modify, lease, rent, loan, sell, distribute, transmit, and/or create any
                    plagiaristic works which are based on FoPark, in whole or part.</p>
                <p>FoPark is powered by open-source software. For more information on packages used, licensing,
                    compliance, or other issues, contact contact@fopark.io.</p>
                <p>FoPark incorporates the Google Maps API(s). By using FoPark, you explicitly agree to be bound
                    by <a href="https://www.google.com/intl/en/policies/terms">Google’s Terms of Service</a>.</p>
                <p><strong>Restrictions</strong></p>
                <p>You are specifically restricted from all of the following</p>
                <ul>
                    <li>publishing any FoPark material in any other media without the express consent of Focus
                        Engineering;
                    </li>
                    <li>selling, sublicensing and/or otherwise commercializing any FoPark material without the
                        express consent of Focus Engineering;
                    </li>
                    <li>using any part of FoPark in any way that is or may be damaging to its continued safe and
                        stable operation;
                    </li>
                    <li>using any part of FoPark in any way that impacts user access to FoPark;</li>
                    <li>engaging in any data mining, data harvesting, data extracting or any other similar activity
                        in relation to FoPark;
                    </li>
                </ul>
                <p><strong>No warranties</strong></p>
                <p>YOU HEREIN EXPRESSLY ACKNOWLEDGE AND AGREE THAT:</p>
                <p>THE USE OF FOPARK IS AT YOUR SOLE RISK. FOPARK SHALL BE PROVIDED ON AN “AS IS” AND/OR “AS
                    AVAILABLE” BASIS. FOCUS ENGINEERING AND OUR SUBSIDIARIES, AFFILIATES, OFFICERS, EMPLOYEES,
                    AGENTS, VENDORS, DEVELOPERS, PARTNERS AND LICENSORS EXPRESSLY DISCLAIM ANY AND ALL WARRANTIES OF
                    ANY KIND WHETHER EXPRESS, IMPLIED, OR STATUTORY INCLUDING, BUT NOT LIMITED TO ANY IMPLIED
                    WARRANTIES OF TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND/OR NON-INFRINGEMENT.
                    FOCUS ENGINEERING AND OUR SUBSIDIARIES, OFFICERS, EMPLOYEES, AGENTS, VENDORS, DEVELOPERS,
                    PARTNERS AND LICENSORS MAKE NO WARRANTIES THAT (i) FOPARK WILL MEET YOUR REQUIREMENTS; (ii)
                    FOPARK SHALL BE PROVIDED IN AN UNINTERRUPTED, TIMELY, SECURE OR ERROR-FREE MANNER; (iii) THAT
                    INFORMATION WHICH MAY BE OBTAINED FROM THE USE OF THE FOPARK WILL BE ACCURATE OR RELIABLE; AND
                    (v) THAT ANY SUCH ERRORS CONTAINED IN FOPARK SHALL BE CORRECTED.</p>
                <p><strong>Limitation of Liability</strong></p>
                <p>YOU EXPLICITLY ACKNOWLEDGE, UNDERSTAND AND AGREE THAT IN NO EVENT SHALL FOCUS ENGINEERING AND OUR
                    SUBSIDIARIES, PARENTS, AFFILIATES, OFFICERS, EMPLOYEES, AGENTS, VENDORS, DEVELOPERS, PARTNERS
                    AND LICENSORS BE LIABLE FOR LOST PROFITS OR ANY PUNITIVE, INDIRECT, INCIDENTAL, SPECIAL,
                    CONSEQUENTIAL OR EXEMPLARY DAMAGES (HOWEVER ARISING, INCLUDING NEGLIGENCE), INCLUDING, BUT NOT
                    LIMITED TO, DAMAGES WHICH MAY BE RELATED TO THE LOSS OF ANY BUSINESS, GOODWILL, USE OF THE
                    SERVICES, DATA AND/OR OTHER TANGIBLE OR INTANGIBLE LOSSES, UNLESS AND TO THE EXTENT PROHIBITED
                    BY LAW. OUR LIABILITY AND THAT OF OUR SUBSIDIARIES, PARENTS, AFFILIATES, OFFICERS, EMPLOYEES,
                    AGENTS, VENDORS, DEVELOPERS, PARTNERS AND/OR LICENSORS IS LIMITED TO THE LESSER OF THE ACTUAL
                    AMOUNT OF DIRECT DAMAGES, OR THE TOTAL AMOUNT PAID BY YOU THROUGH THE SERVICE. FOCUS ENGINEERING
                    AND OUR SUBSIDIARIES, PARENTS, AFFILIATES, OFFICERS, EMPLOYEES, AGENTS, VENDORS, DEVELOPERS,
                    PARTNERS AND LICENSORS ARE NOT LIABLE, AND YOU AGREE NOT TO HOLD THESE PARTIES RESPONSIBLE, FOR
                    ANY DAMAGES OR LOSSES INCLUDING THOSE NAMED ABOVE, RESULTING FROM THE FOLLOWING, EVEN IF WE HAVE
                    BEEN ADVISED OF THE POSSIBILITY OF THEIR OCCURRENCE:</p>
                <ul>
                    <li>THE USE OR INABILITY TO USE FOPARK;</li>
                    <li>GLITCHES, BUGS, ERRORS, OR INACCURACIES OF ANY KIND IN FOPARK OR IN THE INFORMATION OBTAINED
                        THEREIN;
                    </li>
                    <li>THE COST OF PROCURING SUBSTITUTE SERVICES;</li>
                    <li>YOUR NEED TO CHANGE PRACTICES, BEHAVIOR, OR OTHER PLANS, OR YOUR INABILITY TO CONDUCT
                        BUSINESS OR PAY ANY CHARGES, AS A RESULT OF CHANGES TO THIS AGREEMENT OR FOPARK POLICIES;
                    </li>
                    <li>STATEMENTS OR CONDUCT OF ANY SUCH THIRD PARTY ON OUR SERVICE;</li>
                    <li>FEES, CHARGES, DUES, OR OBLIGATIONS OWED TO THIRD PARTIES IN CONNECTION WITH YOUR USE OR
                        MISUSE OF FOPARK;
                    </li>
                    <li>AND ANY OTHER MATTER WHICH MAY BE RELATED TO FOPARK</li>
                </ul>
                <p><strong>Indemnification</strong></p>
                <p>You hereby indemnify to the fullest extent Focus Engineering and its subsidiaries, parents,
                    affiliates, officers, employees, agents, vendors, developers, partners and licensors from and
                    against any and/or all liabilities, costs, demands, causes of action, damages and expenses
                    arising in any way related to your breach of any of the provisions of these Terms.</p>
                <p><strong>Severability</strong></p>
                <p>In the event that any provision of these Terms is determined to be unlawful, void or
                    unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted
                    by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms
                    of Service. Such determinations shall not affect the validity and enforceability of any other
                    remaining provisions.</p>
                <p><strong>Entire Agreement</strong></p>
                <p>These Terms and any policies, including the Privacy Policy below, posted by us on this site or in
                    respect to FoPark constitute the entire agreement and understanding between you and us and
                    govern your use of FoPark, superseding any prior or contemporaneous agreements, communications
                    and proposals, whether oral or written, between you and us (including, but not limited to, any
                    prior versions of these Terms).</p>
                <p>Any ambiguities in the interpretation of these Terms of Service shall not be construed against
                    Focus Engineering or its agents, employees, contractors, vendors, partners, licensors, or other
                    related parties.</p>
                <p><strong>Governing Law &amp; Jurisdiction</strong></p>
                <p>These Terms will be governed by and interpreted in accordance with the laws of the State of
                    Alabama, and you submit to the non-exclusive jurisdiction of the state and federal courts
                    located in Alabama for the resolution of any disputes.</p>
                <p>&nbsp;</p>
                <h2>Privacy Policy</h2>
                <p>Focus Engineering, LLC (“Focus Engineering”, “we”, “us”) is located at:</p>
                <p>570 Devall Dr.<br/>
                    Suite 303<br/>
                    Auburn, AL 36832</p>
                <p>It is our policy to respect your privacy regarding any information we may collect while operating
                    our mobile and web apps. This Privacy Policy applies to the FoPark mobile and web app
                    (“FoPark”). We respect your privacy and are committed to protecting personally identifiable
                    information you may provide us through the app, if any. We have adopted this privacy policy
                    (“Privacy Policy”) to explain what information may be collected through the app, how we use this
                    information, and under what circumstances we may disclose the information to third parties. This
                    Privacy Policy applies only to information we collect through FoPark and does not apply to our
                    collection of information from other sources.</p>
                <p>This Privacy Policy, together with the Terms of Use posted above, set forth the general rules and
                    policies governing your use of our Website. Depending on your activities when using FoPark, you
                    may be required to agree to additional terms and conditions.</p>
                <p>Any data collected, as referenced by the below paragraphs, will never be rented, sold, or
                    otherwise given to third parties without the express consent of Focus Engineering.</p>
                <p><strong>App Store and Analytics Data</strong></p>
                <p>App stores, such as Google Play, the Apple App Store, the Amazon Appstore, and others, may
                    collect aggregated, non-personally-identifying information on FoPark’s users, including
                    statistics about installations and uninstallations. Focus Engineering does not control or direct
                    the collection of this information; please review your app store’s privacy policy for further
                    information.</p>
                <p>FoPark includes analytics tools provided by Google. We want to learn how you use FoPark so we can
                    improve it in future updates. Data collected includes statistics on page views. The data
                    collected is seen only by Focus Engineering and its agents, employees, and/or contractors, and
                    is stored within the Google Analytics system. Data is encrypted in transit and is anonymous.
                    Neither your name, email address, nor any other personal information will be linked to analytics
                    data.</p>
                <p><strong>Geolocation and Mapping</strong></p>
                <p>FoPark requests permission from your device to perform geolocation functions. Geolocation is only
                    performed if and when you request it by pressing the “my location” button located in the top
                    right corner of the app. Certain information, including your location and IP address, may be
                    passed to Google, the provider of our mapping and geolocation solution, via TLS-encrypted
                    transport. By using FoPark, you accept the terms in the <a
                        href="https://www.google.com/policies/privacy">Google Privacy Policy</a>, which is hereby
                    incorporated as part of this Privacy Policy.</p>
                <p><strong>Security</strong></p>
                <p>The security of your Personal Information is important to us, but remember that no method of
                    transmission over the Internet, or method of electronic storage is 100% secure. While we strive
                    to use commercially acceptable means to protect your Personal Information, we cannot guarantee
                    its absolute security.</p>
                <p><strong>Links To External Sites</strong></p>
                <p>FoPark may contain links to external sites that are not operated by us. If you click on a third
                    party link, you will be directed to that third party’s site. We strongly advise you to review
                    the Privacy Policy and terms and conditions of every site you visit.</p>
                <p>We have no control over, and assume no responsibility for the content, privacy policies or
                    practices of any third party sites, products or services.</p>
                <p><strong>Privacy Policy Changes</strong></p>
                <p>Although most changes are likely to be minor, Focus Engineering may change its Privacy Policy
                    from time to time, and in Focus Engineering’s sole discretion. Focus Engineering encourages
                    visitors to frequently check this page for any changes to its Privacy Policy. Your continued use
                    of FoPark after any change in this Privacy Policy will constitute your acceptance of such
                    change.</p>
            </div>
        );
    }
}

export default App;
