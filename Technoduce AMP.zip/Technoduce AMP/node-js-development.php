<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/node-js-logo.png" alt="NodeJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Top Rated NodeJS Development company</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="half_bg red">
  <div class="container relative">
    <div class="col_6 pr30 white">
      <h2 class="head line white style1">NodeJS web app development</h2>
      <p class="mb20">Node.js is a new open-source, cross-platform runtime environment for developing server-side web application. Although it's not JavaScript framework many of its basic modules are written in JavaScript. It has an event-driven architecture capable of asynchronous I/O. Node.js suitable to use in Chat based application because it is the most real-time with multi user application.</p>

      <h3 class="sub_head">Services in NodeJS</h3>
      <ul class="lists style1 mb0">
        <li>express.js -  Web development framework for Node.js</li>
        <li>Connect - Extensible HTTP server framework for Node.js</li>
        <li>Sockjs - Server-side component</li>
        <li>Mongojs - MongoDB wrappers to provide the API for MongoDB</li>
        <li>CoffeeScript - Developer write Node.js programs using Coffee</li>
      </ul>
    </div>
    
    <div class="col_6 pl30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="NodeJS Development" width="460" height="450" layout="responsive"></amp-img>
    </div>
  </div> <!--container-->
</section> <!--half_bg-->

<section>
  <div class="container">
    <h2 class="head text-center style1">Features of NodeJS</h2>
    <div class="web_features full_row">
      <div class="content">
        <ul class="reset">
          <li>
            <h3>One configuration </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Multiple nodes</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>REST interface</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
        </ul>
      </div>

      <div class="img">
        <amp-img src="<?php echo $baseurl;?>images/node-js-logo.png" alt="NodeJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Stream JSON over HTTP </h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Scalable performance</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Real time</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
        </ul>
      </div>
    </div> <!--web_features-->
  </div> <!--container-->
</section>

<section class="half dark">
	<div class="container">
    <div class="row white">
      <div class="col_6 pr30">
        <h2 class="head line white style1">Benefits of using Node.js</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style2 mb0">
          <li>Node.js allows to build a fast and scalable network application, which is capable of handling any number of connections with high throughput.</li>
          <li>npm is Node.js Package Manager, which comes default with every Node.js installation. It avoids version conflicts and keeps the package separate from other project. </li>
          <li>Node.js performs multiple concurrent connection with multiple user over real time application. </li>
          <li>HTTP and TCP protocol functions well with over all loading time and web performance.</li>
          <li> A perfect real time application with low level API and easy installation process.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg1 right"></div>
</section>

<section class="half red">
  <div class="bg bg2 left"></div>

	<div class="container">
    <div class="row white">
      <div class="col_6 pull_right">
        <h2 class="head line white style1">NodeJS Development Services</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style1 mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<?php include ('inc/footer.php'); ?>