'use strict';
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');


class Actions {
    static sendMessage(data) {

        ApiActions.post(
            '/profile',
            data,
            Store,
            Constants.SEND_MESSAGE,
            Constants.SEND_MESSAGE_RESPONSE
        );
    }

    static toggleChangePassword(checked) {

        Store.dispatch({
            type: Constants.TOGGLE_PASSWORD,
            checked: checked
        });
    }

    static getUser() {
        
        ApiActions.get(
            '/user/profile',
            undefined,
            Store,
            Constants.GET_USER_RESULT,
            Constants.GET_USER_RESULT_RESPONSE
        );
    }

    static updateUser(data) {

        ApiActions.post(
            '/user/update',
            data,
            Store,
            Constants.USER_UPDATE,
            Constants.USER_UPDATE_RESPONSE
        );
    }
}


module.exports = Actions;
