import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import CircularProgressbar from 'react-circular-progressbar';
import { Progress } from 'react-sweet-progress';
//import "react-sweet-progress/lib/style.css";
const ReactTooltip = require('react-tooltip');
const UserIdentity = require('../../../helpers/user-identity');
const Actions = require('./actions.js');
const ModalForm = require('./modal-form.jsx');
const LocationSearchInput = require('./auto-complete-form.jsx');
const Store = require('./store');
const ObjectAssign = require('object-assign');

class LotList extends Component {
    constructor(props) {
        super(props);
        
        this.state = Store.getState();
        
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        
        this.els = {};
        this.updateLotList = this.updateLotList.bind(this);
    }

    updateLotList() {
        let url;
        if (UserIdentity._checkUserAddress() !== null) {
            url = `${this.params.fopark_url}/client/lots?name=auburn&sort_by_location=${parseFloat(UserIdentity._checkUserAddress().lat)},${parseFloat(UserIdentity._checkUserAddress().lng)}`;
        } else {
            url = `${this.params.fopark_url}/client/lots?name=auburn`;
        }
        fetch(`${url}`, {
            'headers': new Headers({
                'X-api-key':  this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    
                    if('lots' in result){
                        this.setState({
                            isLoaded: true,
                            lots: result.lots,
                            error: false
                        });
                    } else {
                        this.setState({
                            isLoaded: true,
                            error: {
                                'message': 'No Lots Returned'
                            }
                        });
                    }
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            );
    };

    componentDidMount() {
        this.interval = setInterval(this.updateLotList, 15000);
        this.updateLotList();

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
        if (UserIdentity._checkUserAddress() !== null) {
            this.state = this.setState({ selectedAddress : UserIdentity._checkUserAddress()});
        }
        
    };

    onStoreChange() {

        this.setState(Store.getState());
    }

    componentWillUnmount() {
        this.unsubscribeStore();
        clearInterval(this.interval);
    };
    onNewClick(event, lot_name, LatLng, title, percentage, color, lot_status) {
        let address = {};
        
        Actions.showCreateNew(lot_name, address, LatLng, title, percentage, color, lot_status);
    }
    render() {
        const {error, isLoaded, lots} = this.state;
        const checkArray  = [];
        if (!isLoaded) {
            return <div className="loader"></div>
        } else if (error) {
            return <div className="msg_box text-center">
                <h6 className="msg"><i className="fa fa-exclamation-triangle" aria-hidden="true"></i> 
                    Uh Oh! Looks like there is a connection issue. Please try refreshing the app.
               </h6>
                <a onClick={this.updateLotList}><i className="fa fa-refresh" data-tip="Click to refresh lots"></i></a>
               
                <ReactTooltip />
                {/*<p style={{ 'display' : 'none'}}>Error: {error.message}</p>*/}
            </div>;
        } else {
            return (
                <div className="content-scroll">
                <div className="lot_box" data-scrollbar>
                    <h4 className="lot-title">Choose a Lot</h4>
                    { (UserIdentity._checkUserAddress() !== null) ? (
                        <span className="my_location"> <strong>Lots near </strong> {UserIdentity._checkUserAddress().address} </span>
                    ) : '' }
                    <div id="lotlink"> 
                    {Object.keys(lots).map((lot) => {
                        let occupied = 0;
                        let total = 0;
                        let percentage = 0;
                        let color = '';
                        let isZoneSelected = false;

                        //if (lots[lot].status) {
                            Object.keys(lots[lot].occupancy).map((zone) => {

                                let isZoneSelectedTemp = false;
                                if (zone !== 'undefined' && zone !== 'all') {
                                    isZoneSelectedTemp = localStorage.getItem(`${zone}_selected`);
                                
                                    if (typeof isZoneSelectedTemp === 'string' && !isZoneSelected) {
                                        if (isZoneSelectedTemp === 'false') {
                                            isZoneSelected = false;
                                        } else {
                                            isZoneSelected = true;
                                        }
                                    }
                                    if (isZoneSelectedTemp === null && !isZoneSelected) {
                                        isZoneSelected = true;
                                    }
                                    
                                    /*if ((isZoneSelectedTemp === null) || isZoneSelectedTemp === 'true') {
                                        occupied += lots[lot].occupancy[zone][1];
                                        total += lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][1] - lots[lot].occupancy[zone][3]+ occupied;
                                        percentage = Math.ceil((occupied / total) * 100);
                                    }*/

                                    //console.log(lots[lot]['title'] + " - " + lots[lot].occupancy[zone][0] + " - " + lots[lot].occupancy[zone][1] + " - " + lots[lot].occupancy[zone][2] + " - " + lots[lot].occupancy[zone][3]);
                                    if ((isZoneSelectedTemp === null) || isZoneSelectedTemp === 'true') {
                                        occupied += lots[lot].occupancy[zone][1];
                                        total += lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3];
                                        percentage = Math.ceil((occupied / total) * 100);
                                    }
                                    
                                    /*if (isZoneSelected) {
                                        occupied += lots[lot].occupancy[zone][1];
                                        total += lots[lot].occupancy[zone][2];
                                        percentage = Math.floor((occupied / total) * 100);
                                        
                                    }*/
                                }
                            })
                        /*} else {
                            isZoneSelected = false
                        }*/



                        if (percentage >= 95) {
                            color = 'rgb(237, 35, 40)';
                        }
                        else if (percentage >= 85 && percentage < 95) {
                            color = 'rgb(255, 165, 0)';
                        }
                        else {
                            color = 'rgb(0, 128, 0)';
                        }

                        
                        if (!lots[lot].status) {
                            color = '#f77f28';
                        }

                        if (isZoneSelected) {
                            checkArray.push(lots[lot]['lot_name']);
                            let distance_from_location = lots[lot]['distance_from_location'] !== undefined ? parseFloat(lots[lot]['distance_from_location']).toFixed(2) : 0;
                            return (
                                
                                <a className='lotLink' id={lots[lot]['lot_name']} key={lots[lot]['lot_name']} role="botton" >
                                    <ReactTooltip />
                                    <div className="media text-muted pt-3">
                                        <div className="media-body pb-3 mb-0 small lh-125">
                                            <div className="w100 each_lot">
                                                <div className="w100">
                                                    <h5 className="blue" onClick={((e) => this.onNewClick(e, lots[lot]['lot_name'], lots[lot]['entrance_coords'], lots[lot]['title'], percentage, color, lots[lot].status))}>
                                                        {lots[lot]['title']}
                                                    </h5>
                                                    { (!lots[lot].status) ? (
                                                        <div className="d-flex">
                                                            <p className="lot-sub">Open Spaces By Zone</p>
                                                            {
                                                                (distance_from_location !==0 && UserIdentity._checkUserAddress() !== null) ? (
                                                                    <span className="miles"><i className="fa fa-map-marker bounce"></i> {distance_from_location} miles</span>
                                                                ) : ''
                                                            }
                                                            <div className="clearfix"></div>
                                                            <p className="p-2" style={{ color : '#f77f28', 'textTransform' : 'uppercase'}}>No data available</p>

                                                        </div>
                                                    ) : (
                                                        <div className="d-flex">
                                                            <p className="lot-sub">Open Spaces By Zone</p>
                                                            {
                                                                (distance_from_location !==0 && UserIdentity._checkUserAddress() !== null) ? (
                                                                    <span className="miles"><i className="fa fa-map-marker bounce"></i> {distance_from_location} miles</span>
                                                                ) : ''
                                                            }
                                                            <div className="clearfix"></div>
                                                                {Object.keys(lots[lot].occupancy).sort().map((zone) => {
                                                                    
                                                                    if (zone !== 'undefined' && zone !== 'all') {
                                                                        let isZoneSelected = localStorage.getItem(`${zone}_selected`);

                                                                        let zoneColor = 'rgb(211, 170, 23)';
                                                                        switch(zone){
                                                                            case 'a':
                                                                                zoneColor = 'rgb(232, 228, 2)';
                                                                                break;
                                                                            case 'b':
                                                                                zoneColor = 'rgb(69, 255, 25)';
                                                                                break;
                                                                            case 'c':
                                                                                zoneColor = 'rgb(1, 34, 112)';
                                                                                break;
                                                                            case 'ada':
                                                                                zoneColor = 'rgb(18, 90, 214)';
                                                                                break;
                                                                            default:
                                                                                zoneColor = 'rgb(211, 170, 23)';
                                                                                break;
                                                                        }

                                                                        if (typeof isZoneSelected === 'string') {
                                                                            if (isZoneSelected === 'false') {
                                                                                isZoneSelected = false;
                                                                            }
                                                                            if (isZoneSelected) {
                                                                                isZoneSelected = true;
                                                                            }
                                                                        }
                                                                        if (isZoneSelected == null) {
                                                                            isZoneSelected = true;
                                                                        }
                                                                        let val = 0;
                                                                        if (isZoneSelected) {
                                                                            //val = lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][1];
                                                                            val = lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][1] - lots[lot].occupancy[zone][3];
                                                                            return (
                                                                                <div className='p-2'
                                                                                     key={`${lots[lot]['api_id']}_${zone}`}>
                                                                                    <span className="color_zone" style={{
                                                                                        'color': zoneColor
                                                                                    }}>{zone.toUpperCase()}</span>: { val >= 3 ? val : 'Less than 3'}
                                                                                    <span style={{ 'display' : 'none'}}>
                                                                                        {val}
                                                                                    </span>
                                                                                </div>
                                                                            );
                                                                        }
                                                                    }
                                                                    return '';
                                                                })}
                                                        </div>
                                                        )}
                                                </div>
                                                <div className="lot_progress">
                                                    { (lots[lot].status) ? ( 
                                                    <Progress
                                                      type="circle"
                                                      width={40}
                                                      percent={percentage}
                                                      status="active"
                                                      theme={
                                                            {
                                                              active: {
                                                                symbol: percentage + '%',
                                                                trailColor: (percentage >= 96) ? 'white' : 'green',
                                                                color: 'red'
                                                              },
                                                              default: {
                                                                symbol: percentage + '%',
                                                                trailColor: color,
                                                                color: color
                                                              },
                                                            }
                                                          }
                                                    />
                                                    ) : '' }
                                                </div>
                                                <div className="vehicles" >
                                                    <i className="fa fa-bus" aria-hidden="true" data-tip="Bus hub availabe at the lot"></i>
                                                    <i className="fa fa-bicycle" aria-hidden="true" data-tip="Bike hub availabe at the lot"></i>
                                                    { color === 'rgb(0, 128, 0)' ? 
                                                    (
                                                        <i className="fa fa-thumbs-up" aria-hidden="true" style={{ color : color}}></i>
                                                    ) : (!lots[lot].status) ? ''
                                                        : 
                                                        color == 'rgb(237, 35, 40)' ? 
                                                        (
                                                            <i className="fa fa-thumbs-down" aria-hidden="true" style={{ color : color}}></i>
                                                        ) : ''
                                                    }
                                                    
                                                </div>
                                                
                                            </div>
                                        </div>
                                   
                                        <a className="close-level" data-toggle="collapse" href="#level-box" aria-expanded="false" aria-controls="level-box">Close Levels
                                        <span className="level-arrow"></span>
                                        </a>
                                    </div>


                                   <div className="level-wrap" class="collapse" id="level-box">
                                       <div className="level-content each_lot">
                                           <h6>Levels</h6>
                                           <div className="p-2">
                                               <span>A: 35</span>
                                           </div>
                                           <div className="p-2">
                                               <span>A: 35</span>
                                           </div>
                                            <div className="lot_progress">
                                                    { (lots[lot].status) ? ( 
                                                    <Progress
                                                      type="circle"
                                                      width={40}
                                                      percent={percentage}
                                                      status="active"
                                                      theme={
                                                            {
                                                              active: {
                                                                symbol: percentage + '%',
                                                                trailColor: (percentage >= 96) ? 'white' : 'green',
                                                                color: 'red'
                                                              },
                                                              default: {
                                                                symbol: percentage + '%',
                                                                trailColor: color,
                                                                color: color
                                                              },
                                                            }
                                                          }
                                                    />
                                                    ) : '' }
                                                </div>
                                       </div>
                                        <div className="level-content each_lot">
                                           <h6>Levels</h6>
                                           <div className="p-2">
                                               <span>A: 35</span>
                                           </div>
                                           <div className="p-2">
                                               <span>A: 35</span>
                                           </div>
                                            <div className="lot_progress">
                                                    { (lots[lot].status) ? ( 
                                                    <Progress
                                                      type="circle"
                                                      width={40}
                                                      percent={percentage}
                                                      status="active"
                                                      theme={
                                                            {
                                                              active: {
                                                                symbol: percentage + '%',
                                                                trailColor: (percentage >= 96) ? 'white' : 'green',
                                                                color: 'red'
                                                              },
                                                              default: {
                                                                symbol: percentage + '%',
                                                                trailColor: color,
                                                                color: color
                                                              },
                                                            }
                                                          }
                                                    />
                                                    ) : '' }
                                                </div>
                                       </div>
                                   </div>

                                </a>
                                
                            )
                        } 
                        
                        return '';
                    })}
                    </div>
                    {(checkArray.length > 0) ? 
                    (
                        <ModalForm 
                            selected={this.state.selected}
                            {...this.state.createNew}
                        />
                    ) : 
                    (
                        <p className='lotLink text-center' > No lots found!</p>
                    )}
                    
                </div>
                </div>
            );
        }
    };
}

export default LotList;