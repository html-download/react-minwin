/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');


class Actions {

    static getRoles() {

        ApiActions.get(
            '/role',
            {},
            Store,
            Constants.GET_ROLES,
            Constants.GET_ROLES_RESPONSE
        );
    }
}


module.exports = Actions;
