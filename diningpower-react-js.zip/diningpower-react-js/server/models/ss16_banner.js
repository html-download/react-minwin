/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Banner', {
    bannerId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'banner_id'
    },
    bannerTitle: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'banner_title'
    },
    bannerImage: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'banner_image'
    },
    bannerVideoUrl: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'banner_video_url'
    },
    bannerUrl: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'banner_url'
    },
    bannerStatus: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Deactive',
      field: 'banner_status'
    },
    sort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    bannerBackgroundcolor: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'banner_backgroundcolor'
    }
  }, {
    tableName: 'ss16_banner'
  });
};
