'use strict';
const FluxConstant = require('flux-constant');

module.exports = FluxConstant.set([    
    'DRIVING_DETAILS',
    'DRIVING_DETAILS_RESPONSE',
    'GET_COUNTRY_RESULTS',
    'GET_COUNTRY_RESULTS_RESPONSE',
    'GET_DRIVING_EXPERIENCE_RESULTS',
    'GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE',
    'EDITABLE_SHOW',
    'EDITABLE_HIDE',
    'UPDATE_DATE_FIELD',
    'DISABLE_LOADER'
]);
