import Constants from './constants.jsx';
import Store from './store.jsx';

class Action {

	static getAPI(restaurants){

	 store.dispatch({
	                type: Constants.REQUEST,
	                restaurants: findresponse.restaurants

	            });
}
	

}

export default Action;