/* global window */
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');


class Actions {
    static sendRequest(data) {

        ApiActions.post(
            '/api/signup',
            data,
            Store,
            Constants.REGISTER,
            Constants.REGISTER_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response && response.user) {
                        localStorage.removeItem("user");
                        sessionStorage.removeItem("user");
                        if (response.rememberMe !== '') {
                            localStorage.setItem('user', JSON.stringify(response.user));
                        } else {
                            sessionStorage.setItem('user', JSON.stringify(response.user));
                        }
                        window.location.reload();
                    }
                }
            }
        );
    }
    static googlelogin(data) {

        ApiActions.post(
            '/api/signup/google',
            data,
            Store,
            Constants.REGISTER,
            Constants.REGISTER_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response && response.user) {
                        localStorage.removeItem("user");
                        sessionStorage.removeItem("user");
                        if (response.rememberMe !== '') {
                            localStorage.setItem('user', JSON.stringify(response.user));
                        } else {
                            sessionStorage.setItem('user', JSON.stringify(response.user));
                        }
                        window.location.reload();
                    }
                }
            }
        );
    }
};


module.exports = Actions;
