<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <!-- cms banner -->
  <section class="cms-page-banner text-center">
    <div class="container">
      <h2>Contact Us</h2>
      <ul class="br_ul reset">
        <li><a href="/">Home</a></li>
        <li><span>Contact us</span></li>
      </ul>
    </div>
  </section>
  <!-- cms banner -->
  <section class="contact">
    <div class="container mx-1150">
      <div class="box-up">
       <div class="row">
         <div class="col-sm-8 ">
         <div class="contact-us"> 
            <h3>Get in Touch</h3>
            <p>We are always happy to make valuable enquires.</p>
             <div class="row">
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon">
                  <label for="mname"><i class="fi user1"></i><span>Name</span></label>
                  <input id="mname" type="text" class="form-control">
                </div>
                <!-- formgroup -->
              </div>
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon">
                  <label for="mtel"><i class="fi mail"></i><span>Mobile Number</span></label>
                  <input id="mtel" type="tel" class="form-control">
                </div>
                <!-- formgroup -->
              </div>
            </div>
              <div class="row">
              <div class="col-sm-6">
                <!-- formgroup -->
                <div class="form-group icon">
                  <label for="memails"><i class="fi email"></i><span>Email Address</span></label>
                  <input id="memails" type="text" class="form-control">
                </div>
                <!-- formgroup -->
              </div>
            <div class="col-sm-6">
                <!-- form group -->
                <div class="form-group icon has-value-top">
                  <label><i class="fi mail"></i><span>Enquiry Type</span></label>
                  <select class="selectpicker ui_style3">
                    <option>Partner Registration</option>
                    <option>Join Us</option>
                  </select>
                </div>
                <!-- form group -->
              </div>
            </div>
            <div class="form-group">
              <textarea class="form-control" placeholder="Your Message..."></textarea>
            </div>
            <div class="text-right">
              <button class="btn">Send Message</button>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
            <div class="contact-right">
              <ul class="contact-icons">
                <li>
                  <i class="lni-map-marker"></i>
                    <h5>Reach Us</h5>
                    <p class="normal">108, Bin Dirham Plaza, Fereej Bin Dirham, P.O.Box 30217, Doha, Qatar.</p>
                </li>
                <li>
                  <i class="lni-envelope"></i>
                    <h5>Mail Us</h5>
                    <p class="normal">info@wishboxonline.com</p>
                </li>
                 <li>
                 <i class="lni-phone-handset"></i>
                    <h5>Call Us</h5>
                    <p class="normal">+974 444 75 725</p>
                </li>
                 <li>
                  <i class="lni-world"></i>
                    <h5>Social Media</h5>
                 <ul class="social_links">
          <li><a href="" target="_blank" class="current_page"><i class="lni-facebook-filled"></i></a></li>
          <li><a href="" target="_blank" class="current_page"><i class="lni-twitter-filled"></i></a></li>
          <li><a href="" target="_blank" class="current_page"><i class="lni-instagram-filled"></i></a></li>
          <li><a href="" target="_blank" class="current_page"><i class="lni-youtube"></i></a></li>
        </ul>
                </li>
            </ul>
          </div>
        </div>
      </div>
      </div>
    </div>
  </section>
  <!-- myaccount -->
</div>
<!-- site -->
<?php include ('inc/footer.php'); ?>