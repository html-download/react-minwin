const initialState = {

	 num_count_1: 50,
     num_count_2: 100,
     num_count_3: 300,
};


const reducer = (state = initialState, action) => {

	if(action.type === 'NUM_UPDATE'){
		return{...state,  num_count_1: 80,};
	}
	return state; 

}

export default reducer;