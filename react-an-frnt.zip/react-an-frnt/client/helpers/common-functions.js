'use strict';
const Config = require('../../config');

module.exports = {

    isEmpty: function (obj) {

        return !obj || Object.keys(obj).length === 0;
    },

    toTitleCase: function (str) {

    	try {
    		return str.split(/\s+/).map( s => s.charAt( 0 ).toUpperCase() + s.substring(1).toLowerCase() ).join( " " );
    	} catch (e) {
            //console.log(e.message);
            return null;
        }
    	
	},

 	toGetLetters: function (str, count) {

 		try {
	 		if (str.length === 0) {
	    		return '';
	    	}
	   		return str.substring(0, count);
	   	} catch (e) {
            //console.log(e.message);
            return null;
        }
	},

    wordTruncate(string, count) {
        
       if (string.length > count)
          return string.substring(0, count)+'...';
       else
          return string;
    },

    getOptionData(data, field_value, field_name, promt_value, is_promt = true ){
        
        if (!data) { 
            return [];
        }

        if (data.length === 0) { 
            return [];
        }
        
        let response = [];
        
        if (is_promt) {
            response.push({
                label: promt_value ? promt_value : 'Please Select',
                value: ''
            });
        }

        data.map((value, index) => {

            return response.push({
                label: value[field_name] !== ' ' ? value[field_name] :  '--noname',
                value: value[field_value]
            });
        });

        return response;
    },

    getModelYear(){

        const model_year = Config.get('/modelYear');

        let response = [];

        model_year.map((value, index) => {

            return response.push({
                label: value,
                value: value
            });
        });

        return response;
    }

};
