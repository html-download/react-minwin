//Animation
new WOW().init();

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});


// Modal Popup Not to Close 
$(".custom-modal, .event").on('click', function(event) { event.stopPropagation(); });

// Password Show Hide
$(".toggle-password").click(function() {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
    input.attr("type", "text");
    } else {
    input.attr("type", "password");
    }
});

$("#forget").click(function(){
    $(".reset-part").addClass("show-in");
    $(".login-part").addClass("hide");
});

$("#signin").click(function(){
    $(".reset-part").removeClass("show-in");
    $(".login-part").removeClass("hide");
});


$(document).ready(function(){
	$(".site_footer h4").click(function(){
			$(this).next(".res_acc, .about_content").slideToggle();        
			$(this).toggleClass("res_arrow17");
	});
});

$(document).ready(function(){
	$(".sound a").click(function(){
        $(this).toggleClass("off");
    });
});


/*Equal Height*/
( function( $, window, document, undefined ){
	'use strict';
	var $list		= $( '.login-register, .address_ul' ),
		$items		= $list.find( '.equal , .heights'),
		setHeights	= function()
	    {
			$items.css( 'height', 'auto' );
			var perRow = Math.floor( $list.width() / $items.width() );
			if( perRow == null || perRow < 2 ) return true;
			for( var i = 0, j = $items.length; i < j; i += perRow )
			{
				var maxHeight	= 0,
					$row		= $items.slice( i, i + perRow );

				$row.each( function()
				{
					var itemHeight = parseInt( $( this ).outerHeight() );
					if ( itemHeight > maxHeight ) maxHeight = itemHeight;
				});
				$row.css( 'height', maxHeight );
			}
		};	
	setHeights();
	$( window ).on( 'resize', setHeights );	
})( jQuery, window, document );	


// Spin wheels
$("#spinner").click(function(){
	$(".each-reel").toggleClass("spin");
});

//Arrow up down sorting
$( "#arrow_sort" ).click(function() {
  $(".fa-long-arrow-up").toggleClass( "fa-long-arrow-down" );
});

//Edit link hover
$('.fav_detail_part .pencil_hover').click(function(){	
    $('.fav-detail1').addClass('favbor_hidden');    
},function(){
	$('.fav-detail1').addClass('favbor_mrgin');
    $('.fav-detail1').removeClass('favbor_hidden'); 
    $('.fav-detail1 h4').hide();
    $('.fav-detail1 .fav_edit').show();
});

//gift info
$('.fa-question-circle').hover(function(){	
    $('.purchase_redeem,.add_credit').addClass('gift_info_hover');   
    $('.gift_info_hover .giftcard_info').css("visibility", "visible");
},function(){
    $('.purchase_redeem,.add_credit').removeClass('gift_info_hover');
    $('.giftcard_info').css("visibility", "hidden");
});

//detail page
// $('.collapse').collapse()

//view edit hover
$(document).on('focus active', '.large-label .form-control',function(){
$('label[for='+$(this).attr('id')+']').addClass('focus');
});
$(document).on('blur', '.large-label .form-control',function(){
$('label[for='+$(this).attr('id')+']').removeClass('focus');
});

//myaccount page

$('.plus_min').click(function(){
    $(this).find('i').toggleClass('fa-plus-square fa-minus-square')
    $(this).parents('div').toggleClass("bg_accord");
});

// Billing

$('ul.bill li input:checkbox').click(function(){
    if($(this).is(":checked")) {
        $(this).siblings('.bill-action').addClass("open");
    } else {
        $(this).siblings('.bill-action').removeClass("open");
    }
});

$('.bill a.dot').click(function(){
    $(this).closest('.bill-action').addClass("open");
    event.preventDefault();
});



// List Grid Address book
$(document).ready(function() {
    $('#grid').click(function(event){
    	event.preventDefault();
    	$('.address_ul').removeClass('list_item');
        $(this).addClass('active');
    	$('#list').removeClass('active');
        $('.address_ul li').resize();  
    });
    $('#list').click(function(event){
        event.preventDefault();
        $('.address_ul').addClass('list_item');
        $(this).addClass('active');
        $('#grid').removeClass('active');
        $('.address_ul li').resize();  
    });
});


// Add Address book Email, SMS on / off
$(document).ready(function () {
    $('input#sms_notify, #email_notify').click(function () {
        $('input:not(:checked)').parent().parent().removeClass("on");
        $('input:checked').parent().parent().addClass("on");
    });
    $('input#sms_notify:checked, input#email_notify:checked').parent().parent().addClass("on");
});


// 18-3-2019

$('.address_body .sort-address').on('change', function()
{   
    if (this.value == 1){
        $('.address_ul').addClass('all_details');
        $('.address_ul').removeClass('nameAndAddress');
        $('.address_ul').removeClass('nameOnly');
        $('.address_ul li').resize();      
        
    } else if (this.value == 2)
    {
        $('.address_ul').removeClass('all_details');
        $('.address_ul').addClass('nameAndAddress');
        $('.address_ul').removeClass('nameOnly');
        $('.address_ul li').resize();      

    } else if (this.value == 3)
    {

        $('.address_ul').removeClass('all_details');
        $('.address_ul').removeClass('nameAndAddress');
        $('.address_ul').addClass('nameOnly');
        $('.address_ul li').resize();              

    } else {

         $('.address_ul').removeClass('all_details');
        $('.address_ul').removeClass('nameAndAddress');
        $('.address_ul').removeClass('nameOnly');
        $('.address_ul li').resize();      
    }

});



 $('.address_ul  a.dot').click(function(event){
   $(this).closest('.action').addClass("open");
   $(this).closest('.address_ul li').addClass("heading-padding-adjust");
 });


$('.bill-preset li input:checkbox').click(function(){
    if($(this).is(":checked")) {
        $(this).parent().siblings('.action').addClass("open open_overide");
    } else {
        $(this).parent().siblings('.action').removeClass("open open_overide");
    }
});



 $('.bill-preset a.dot').click(function(event){
   $(this).closest('.action').addClass("open");
 });
 

$(document).mouseup(function(e) 
 {
     var container = $(".bill-preset .action");
    if (!container.is(e.target) && container.has(e.target).length === 0) 
     {
         container.removeClass("open");
     }
    
 });



$(document).mouseup(function(e) 
{
    var container = $(".address_ul .action");
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
        container.removeClass("open");
        container.closest(".address_ul li").removeClass("heading-padding-adjust");
    }
    
});



// hover


$(".address .address_head h3 i").on({
    mouseenter: function () {
        $(".address p.info_txt").addClass("open");
    },
    mouseleave: function () {
        $(".address p.info_txt").removeClass("open");
    }
});


// address popup

$('.address_popup').on('change', function()
{   
    if (this.value == 1){
        $('.mk_address').addClass('hides');
        $('.df_address').addClass("shows");
        
    } else 
    {
     $('.mk_address').removeClass('hides');    
     $('.df_address').removeClass("shows");
    } 
   

});


// date time show

 $('.date_click, .cs-date-time-picker .close, .overlay_dt.dt').click(function(event){
   $(".gift_cards").toggleClass('pb-300');
   $(".cs-date-time-picker").toggleClass('show_dtpicker');
   $(".overlay_dt.dt").toggleClass('shows');
 });


 $('.time_click, .overlay_dt.tim, .cs-time-picker .close').click(function(event){
   $(".gift_cards").toggleClass('pb-300');
   $(".cs-time-picker").toggleClass('show_timpicker');
   $(".overlay_dt.tim").toggleClass('shows');
 });
