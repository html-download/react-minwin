'use strict';
const Gulp = require('gulp');
const Concat = require('gulp-concat');
const Less = require('gulp-less');


Gulp.task('less', () => {

    const bundleConfigs = [{
        entries: [
            //'./client/core/bootstrap.less',
            './client/core/font-awesome.less'
        ],
        dest: './public',
        outputName: 'core.min.css'
    }, {
        entries: [
            './node_modules/react-table/react-table.css',
            './node_modules/react-datepicker/dist/react-datepicker.css',
            './node_modules/react-toastify/dist/ReactToastify.css',
            './node_modules/react-big-calendar/lib/css/react-big-calendar.css',
            './client/media/css/react-table-override.css',
            './client/media/css/style.css',
            './client/media/css/responsive.css'
        ],
        dest: './public/pages',
        outputName: 'main.min.css'
    }];

    return bundleConfigs.map((bundleConfig) => {

        return Gulp.src(bundleConfig.entries)
            .pipe(Concat(bundleConfig.outputName))
            .pipe(Less({ compress: true }))
            .pipe(Gulp.dest(bundleConfig.dest));
    });
});
