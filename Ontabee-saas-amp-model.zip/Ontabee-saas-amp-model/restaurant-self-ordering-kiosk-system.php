<?php include ('inc/header.php'); ?>

<div class="page_banner bg6 style1">
	<div class="container pad0">
		<div class="col-sm-7 text-left mt30">
			<h1 class="head wow fadeInDown">Self-Ordering Restaurant Kiosk System</h1>
		</div>
		<div class="col-sm-5">
			<img src="images/kiosks-system.png" class="wow fadeInUp" alt="Self-Ordering Restaurant Kiosk System" data-wow-duration="1.5s">
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Simplify Guest Self Ordering With Kiosk Software</h2>
		<p class="mb0 wow fadeInUp">Restaurant workers couldn't handle more orders for takeaway in busiest times. Ontabee provides the next step of an online Kiosk ordering system to get an order for takeaway to reduce the manual works and confusion. The restaurant keeps the Kiosk device in the front of the restaurant. The customer can come and select the items as their wish then place the order and gets the order print. Admin receives the order and prepares the item immediately and deliver it.</p>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="half bg6">
	<div class="center">
		<div class="container">
			<div class="col-sm-6 pull-right">
				<h2 class="head wow fadeInUp">Benefits Of Using Kiosk System</h2>
				<ul class="reset list1 fadeInUp">
					<li>Increase in Sales</li>
					<li>Reduce labor cost</li>
					<li>Improve order accuracy</li>
					<li>Improve speed of service at your busiest times</li>
					<li>Attract customer</li>
					<li>No more queues</li>
				</ul>
			</div>
		</div>
	</div>
</section> <!--half-->

<section class="app_feature style2">	
	<div class="container pad0">		
		<h2 class="head wow fadeInUp">Features Of Restaurant self-ordering system</h2>

		<ul class="reset text-right">
			<li class="wow fadeInLeft" data-wow-duration="1s">
				<i class="fa fa-file-text-o"></i>
				<h4>Digital menu</h4>
				<p>Attract the customer by providing the digital menu in the touchscreen for ordering the menu easily.</p>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="1.5s">
				<i class="fa fa-gears"></i>
				<h4>Fully automated</h4>
				<p>Automate the menu ordering and receiving to the kitchen to reduce the labor cost, time and manual errors.</p>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="2s">
				<i class="fa fa-clock-o"></i>
				<h4>Zero waiting time</h4>
				<p>By providing Kiosk system, Customers do not wait for the waiter for taking orders and to know the know the status of the order.</p>
			</li>
		</ul>
		
		<div class="img">
			<img src="images/kiosks-system.png" class="wow zoomIn" alt="Features Of Restaurant Self-Ordering System" data-wow-duration="1.2s">
		</div>
		
		<ul class="reset last text-left">
			<li class="wow fadeInRight" data-wow-duration="1s">
				<i class="fa fa-cloud"></i>
				<h4>Cloud solution</h4>
				<p>Store and manage the orders in the cloud so we can manage it at any time, anywhere.</p>
			</li>
			<li class="wow fadeInRight" data-wow-duration="1.5s">
				<i class="fa fa-cutlery"></i>
				<h4>Track order</h4>
				<p>Customer no need to ask the waiter about order status. They can see the order status in the dashboard itself.</p>
			</li>
			<li class="wow fadeInRight" data-wow-duration="2s">
				<i class="fa fa-print"></i>
				<h4>Order printing</h4>
				<p>Once the customer checks out the item then they can print the order with the order details.</p>
			</li>
		</ul>	
	</div> <!--container-->	
</section> <!--page_banner-->

<section class="grey">
	<div class="container text-center">
		<h2 class="head wow fadeInUp">Kiosk App Screens</h2>
		<div class="screens1 owl-carousel">
			<div><img src="images/1_tab_splash.png" alt="Splash"><span>1. Splash</span></div>
			<div><img src="images/2_tab_set_passcode.png" alt="Set Passcode"><span>2. Set Passcode</span></div>
			<div><img src="images/3_tab_enter_passcode.png" alt="Enter Passcode"><span>3. Enter Passcode</span></div>
			<div><img src="images/4_tab_food.png" alt="Choose Food"><span>4. Choose Food</span></div>
			<div><img src="images/5_tab_ingredients.png" alt="Ingredients"><span>5. Ingredients</span></div>
			<div><img src="images/6_1_tab_cart.png" alt="Cart"><span>6. Cart</span></div>
			<div><img src="images/6_2_tab_payment.png" alt="Payment"><span>7. Payment</span></div>
			<div><img src="images/7_tab_confirmation.png" alt="Order Confirmation"><span>8. Order Confirmation</span></div>
			<div><img src="images/8_tab_orders.png" alt="Order History"><span>9. Order History</span></div>
			<div><img src="images/9_tab_orders_info.png" alt="Order Details"><span>10. Order Details</span></div>
        </div>
	</div> <!--container-->
</section> <!--page_banner-->

<div id="modal_video" class="modal fade" role="dialog">
	<div class="modal-dialog modal-sm">
		<a class="close" data-dismiss="modal"><i class="fa fa-close"></i></a>
		<iframe id="video" width="100%" height="100%" src="https://www.youtube.com/embed/j1qWh_N5IxI?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div><!--modal-dialog-->
</div><!--modal_video-->

<?php include('inc/footer.php');?>