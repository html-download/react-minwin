'use strict';
const Actions = require('./actions');
const CommonHelper = require('../../../../../../helpers/common-functions');
const ProductDetails = require('./product-details');
const React = require('react');
const Store = require('./store');
const CreateQuote = require('./send-quote-modal');

class Quote extends React.Component {   

    constructor(props) {

        super(props);
        this.state = Store.getState();
        Actions.getMortgage();

    }

    componentDidMount() {
        
        Actions.getDealQuote({
            deal_id:  this.props.id
        });
        
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    toggleQuote() {

        Actions.toggleQuote();
    }

    getListItem() {
                 
        return (this.state.quote_data && this.state.quote_data.length > 0) ? this.state.quote_data.map((value, index) => {
            
            return  <ProductDetails 
                    key={index}
                    data={value}
                    morgage={this.state.mortgage}
                    toggle={this.props.toggle}
                    quote_save_loading={this.state.quote_save_loading}
                />;
        }) : '';
    }

    
    render() {

        return (
            <div>
                <div className="wi-content mt-30 full_row">
                    <div className="text-right mb-2"> <a className="link-text collapse-txt" data-toggle="collapse" href="javascript:"  onClick={ this.toggleQuote.bind(this) }> { this.state.is_quote_collapsed ? 'Expand' : 'Collapse' } </a> </div>
                    <div className={'genrate-new-quote collapse ' + (this.state.is_quote_collapsed ? 'hide' : 'show') } id="genrate">
                        <div className="first-box">
                            <h4 className="f20">Quote Summary {/* <a href="">Edit Quote</a> */}</h4>
                            <p>{ 'Lt\'s Start by creating a new quote for the customer '}</p>
                            <div className={`product-box ${!this.state.product_hydrated ? 'loader-tab': ''}`} >
                                <ul className="product-listing reset">                            
                                    {this.getListItem()}
                                </ul>
                                <div className="mt-3 mb-3 quicklink-share">
                                    <div className="form-group">
                                        <input type="text" className="form-control" defaultValue={this.props.deal_data.choose_policy_url} id="quote_clone" />
                                        <div className="fly">
                                            <label className="link-copy" htmlFor="clone" onClick={() => {CommonHelper.copyToClipboard('quote_clone')}}><i className="fa fa-clone"></i></label>
                                            <a href={this.props.deal_data.choose_policy_url} className="link-targer" target="_blank"><i className="fa fa-external-link" aria-hidden="true"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-3 mb-3 text-right">
                                    <a href={this.props.deal_data.choose_policy_url} target="_blank" className="btn btn-outline-success no-shadow">Manually Prepare Order</a>
                                </div>  
                            </div>
                        </div>
                    </div>
                </div>
                <CreateQuote
                    info_data={this.state}
                    id={this.props.id}
                    toggle={this.props.toggle}
                />
            </div>
        );
    }
}
module.exports = Quote;
