'use strict';
const Actions = require('./actions');
const Alert = require('../../../components/alert.jsx');
const Button = require('../../../components/form/button.jsx');
const ControlGroup = require('../../../components/form/control-group.jsx');
const LinkState = require('../../../helpers/link-state.js');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../components/form/spinner.jsx');
const SelectControl = require('../../../components/form/select-control.jsx');
const TextControl = require('../../../components/form/text-control.jsx');
const ReactSelectControl = require('../../../components/form/react-select-control.jsx');
import { Form, FormGroup, Label, Input, FormText } from 'reactstrap';
const CommonHelper = require('../../../helpers/common-functions');

const propTypes = {
    email: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    mobile_no: PropTypes.string,
    show: PropTypes.bool,
    name: PropTypes.string,
    nationality: PropTypes.string
};


class CreateNewForm extends React.Component {
    constructor(props) {

        super(props);

        this.els = {};
        this.state = {
            name: '',
            email: '',
            mobile_no: '',
            nationality: ''
        };
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            name: nextProps.name,
            email: nextProps.email,
            mobile_no: nextProps.mobile_no,
            nationality: nextProps.nationality
        });
    }

    componentDidUpdate() {

        if (this.props.show && this.state.name && this.state.name.length === 0) {
            this.els.name.focus();
        }
    }

    onSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.createNew({
            first_name: this.els.name.value(),
            email: this.els.email.value(),
            mobile_number: this.els.mobile_no.value(),
            nationality_id: this.els.nationality.value(),
        }, this.props.history, this.props.searchData);
    }

    render() {

        return (
            <Modal
                id="get-quotes"
                header=" "
                show={this.props.show_quote_modal}
                onClose={Actions.hideQuoteModal}
                groupClasses={{'modal_design': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>

                <div>
                    <button type="button" className="close" onClick={ (e) => {Actions.hideQuoteModal()}}>
                        &times;
                    </button>

                    <div id="example-basic" className="steps-custom-wizard">
                            <h3>Car Year</h3>
                            <section>
                                <div className="car-detail-container">
                                    <div className="first-container">
                                        <ul className="four-box">
                                            <li>
                                                <input type="radio" name="car-year" id="car-1" />
                                                <label htmlFor="car-1">2020</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-2"/>
                                                <label htmlFor="car-2">2019</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-3"/>
                                                <label htmlFor="car-3">2018</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-4"/>
                                                <label htmlFor="car-4">2017</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-5"/>
                                                <label htmlFor="car-5">2016</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-6"/>
                                                <label htmlFor="car-6">2015</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-7"/>
                                                <label htmlFor="car-7">2014</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-8"/>
                                                <label htmlFor="car-8">2013</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-9"/>
                                                <label htmlFor="car-9">2012</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-10"/>
                                                <label htmlFor="car-10">2011</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-11"/>
                                                <label htmlFor="car-11">2010</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-12"/>
                                                <label htmlFor="car-12">2009</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-13"/>
                                                <label htmlFor="car-13">2008</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-14"/>
                                                <label htmlFor="car-14">2007</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-15"/>
                                                <label htmlFor="car-15">2006</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-16"/>
                                                <label htmlFor="car-16">2005</label>
                                            </li>
                                            <li>
                                                <input type="radio" name="car-year" id="car-17"/>
                                                <label htmlFor="car-17">2004</label>
                                            </li>
                                        </ul>
                                        <div className="action-btn text-center">
                                            <button className="btn btn-white">See All Years <i className="fa fa-angle-down"></i> </button>
                                        </div>
                                    </div>
                            </div>
                        </section>
                    </div>
                </div>

            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;


module.exports = CreateNewForm;
