/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Area', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    areaKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'area_key'
    },
    countryId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'country_id'
    },
    cityId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'city_id'
    },
    location: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'location'
    },
    latitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'latitude'
    },
    longitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'longitude'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_area'
  });
};
