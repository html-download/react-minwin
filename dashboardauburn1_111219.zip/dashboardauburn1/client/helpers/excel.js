const Config = require('../../config');
const moment = require('moment-timezone');


var uri = 'data:application/vnd.ms-excel;base64,'
, tmplWorkbookXML = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
    + '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Author>Technoduce</Author><Created>{created}</Created></DocumentProperties>'
    + '<Styles>'
    + '@page {'
    + 'margin:.25in .25in .25in .25in;' 
    + 'mso-header-margin:.15in;' 
    + 'mso-footer-margin:.15in;' 
    + 'mso-page-orientation:landscape;' 
    + '}' 
    + 'tr { mso-height-source:auto; }' 
    + 'col { mso-width-source:auto; }' 
    + 'br { mso-data-placement:same-cell; }' 
    + 'td {' 
    + 'mso-style-parent:style0;' 
    + 'padding-top:1px;' 
    + 'padding-right:1px;' 
    + 'padding-left:1px;' 
    + 'mso-ignore:padding;' 
    + 'color:windowtext;' 
    + 'font-size:11.0pt;' 
    + 'font-weight:300;' 
    + 'font-style:normal;' 
    + 'text-decoration:none;' 
    + 'font-family:Calibri;' 
    + 'mso-generic-font-family:auto;' 
    + 'mso-font-charset:0;' 
    + 'mso-number-format:General;' 
    + 'text-align:general;' 
    + 'vertical-align:bottom;' 
    + 'border:none;' 
    + 'mso-background-source:auto;' 
    + 'mso-pattern:auto;' 
    + 'mso-protection:locked visible;' 
    + 'white-space:wrap;' 
    + 'mso-rotate:0;' 
    + '}' 
    + '.header {' 
    + 'mso-style-parent:style0;' 
    + 'font-weight:700;' 
    + '}' 
    + '.text {mso-number-format:"@";}' 
    + '.number {mso-number-format:"0";}' 
    + '.date {mso-number-format:"dd-mm-yyyy";text-align:left;}' 
    + '<Style ss:ID="Currency"><NumberFormat ss:Format="Currency"></NumberFormat></Style>'
    + '<Style ss:ID="Date"><NumberFormat ss:Format="Medium Date"></NumberFormat></Style>'
    + '</Styles>' 
    + '{worksheets}</Workbook>'
, tmplWorksheetXML = '<Worksheet ss:Name="{nameWS}"><Table>{rows}</Table></Worksheet>'
, tmplCellXML = '<Cell{attributeStyleID}{attributeFormula}><Data ss:Type="{nameType}">{data}</Data></Cell>'
, base64 = function(s) { 
    while (s.indexOf('â') != -1) s = s.replace('â','a');
    while (s.indexOf('ş') != -1) s = s.replace('ş','s');
    while (s.indexOf('ă') != -1) s = s.replace('ă','a');
    while (s.indexOf('ţ') != -1) s = s.replace('ţ','t');
    return window.btoa(unescape(encodeURIComponent(s))) 
}
, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }

module.exports = {
    exportExcel : function (state) {
        console.log('state: ', state);

        try {
            
            let tables = ['export_data']; 
            let wsnames = ['Overall Occupancy %']; 
            
            state.download_array.length > 0 && state.download_array[0].zones.length > 0 ? state.download_array[0].zones.map((zone, zoneIndex) => {

                tables.push(`export_data_zone_${zone}`);
                wsnames.push(`${zone.replace('/', '-').toUpperCase()} zone occupancy %`);
                return true;
            }) : null;

            let appname = 'Excel';
            var ctx = "";
            var workbookXML = "";
            var worksheetsXML = "";
            var rowsXML = "";
        
            for (var i = 0; i < tables.length; i++) {
            if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
            for (var j = 0; j < tables[i].rows.length; j++) {
                rowsXML += '<Row>'
                for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
                var dataType = tables[i].rows[j].cells[k].getAttribute("data-type");
                var dataStyle = tables[i].rows[j].cells[k].getAttribute("data-style");
                var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
                dataValue = (dataValue)?dataValue:tables[i].rows[j].cells[k].innerHTML;
                var dataFormula = tables[i].rows[j].cells[k].getAttribute("data-formula");
                dataFormula = (dataFormula)?dataFormula:(appname=='Calc' && dataType=='DateTime')?dataValue:null;
                ctx = {  attributeStyleID: (dataStyle=='Currency' || dataStyle=='Date')?' ss:StyleID="'+dataStyle+'"':''
                        , nameType: (dataType=='Number' || dataType=='DateTime' || dataType=='Boolean' || dataType=='Error')?dataType:'String'
                        , data: (dataFormula)?'':dataValue
                        , attributeFormula: (dataFormula)?' ss:Formula="'+dataFormula+'"':''
                        };
                rowsXML += format(tmplCellXML, ctx);
                }
                rowsXML += '</Row>'
            }
            ctx = {rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i};
            worksheetsXML += format(tmplWorksheetXML, ctx);
            rowsXML = "";
            }
    
            ctx = {created: (new Date()).getTime(), worksheets: worksheetsXML};
            workbookXML = format(tmplWorkbookXML, ctx);
    
            //console.log(workbookXML);
    
            var link = document.createElement("A");
            link.href = uri + base64(workbookXML);
            link.download = this.getFileName(state) || 'Workbook.xls';
            link.target = '_blank';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            return true;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },

    getFileName : function (state) {

        let filename;
        
        filename = `${state.lot.title} report on ${moment().tz(Config.get('/timeZone')).format('MM/DD/YYYY hh:mm A').toString()} [${moment(state.historical_date, 'MM/DD/YYYY').subtract(state.historical_day - 1, "days").format('MM/DD/YYYY').toString()} - ${state.historical_date}]`
        
        filename = filename ? filename+'.xls' : 'excel_data.xls';
        
        return filename;
    }
};
