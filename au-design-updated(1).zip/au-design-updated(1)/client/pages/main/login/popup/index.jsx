const Actions = require('../actions');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');
const CheckboxControl = require('../../../../components/form/checkbox-control.jsx');

const Async = require('async');
const ObjectAssign = require('object-assign');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class LoginPage extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
        this.handleRemember = this.handleRemember.bind(this);
    }
    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.username) {
            this.input.username.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleRemember(event) {
        const target = event.target;
        const checked = target.type === "checkbox" 
                        ? target.checked 
                        : target.value;
        if (checked === true) {
            this.setState(ObjectAssign(this.state, {
                checkboxCondition: true
            }));
        } else {
            this.setState(ObjectAssign(this.state, {
                checkboxCondition: false
            }));
        }
    }
    handleSubmit(event) {
        var username = this.input.username.value();
        var password = this.input.password.value();
        var remember = this.input.remember.value();
        
        event.preventDefault();
        event.stopPropagation();
            
        Actions.slogin({
                    username: username,
                    password: password,
                    remember: remember
                });
        /*Async.auto({
            api: function (done) {
                let response = Actions.login({
                    username: username,
                    password: password
                });
                done(null, response);
            },
            afterCall: ['api', function (results, done) {
                let responses = results.user;
                console.log("response", responses);
            }]
        }, (err, results) => {

            return true;
        });*/

        
    }

    render() {

        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success" className="alert alert-success">
                Success. Redirecting...
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.username = c)}
                    name="username"
                    hideLabel={true}
                    placeholder="Email"
                    hasError={this.state.hasError.username}
                    help={this.state.help.username}
                    disabled={this.state.loading}
                />
                <TextControl
                    ref={(c) => (this.input.password = c)}
                    name="password"
                    hideLabel={true}
                    placeholder="Password"
                    type="password"
                    hasError={this.state.hasError.password}
                    help={this.state.help.password}
                    disabled={this.state.loading}
                    onChange={this.handlePasswordChange}
                />
                <div className="form-group mtb10 mb20 remember">
                    <CheckboxControl
                       ref={(c) => (this.input.remember = c)}
                       name="remember"
                       id="remember"
                       inputClasses={{ 'checkbox': true }}
                       groupClasses={{ 'auto_wid': true }}
                       hasError={this.state.hasError.remember}
                       help={this.state.help.remember}
                       disabled={this.state.loading}
                       onChange={this.handleRemember}
                       value={this.state.checkboxCondition ? "1" : ""}
                       labelClasses={{ 'checkbox': true }}
                       labelFor="remember"
                       label= {['Remember Me']}
                       labelPositionBottom={true}
                   />
                    <a role="button" className="lh20 pull-right link lh14" id="forget">Forgot password?</a>
                </div>
                    <Button
                        type="submit"
                        inputClasses={{ 'full': true }}
                        disabled={this.state.loading}>

                        Sign In
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
            </fieldset>;
        }

        return (
            <div className="modal-content login-part">
                <div className="modal-header">
                    <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                    <h4 className="modal-title">Sign in...welcome back!</h4>
                    <h4 className="sub-title">New to Dining Power?  <a role="button" type="button" id="load-signin-button">Sign up</a></h4>
                    <div className="social_login">
                        Sign in with 
                        <a role="button"> Facebook</a> or 
                        <a role="button"> Google</a>
                        <span>or</span>
                    </div>
                </div>
                <div className="modal-body">
                    <form onSubmit={this.handleSubmit.bind(this)} className="w100 m0" autoComplete="off">
                        {alerts}
                        {formElements}
                    </form>
                </div>
            </div>
        );
    }
}


module.exports = LoginPage;
