'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');

const initialState = {
    hydrated: false,
    name: 'Loading...',
    createDeal:false,
    customer_details: {}
};
const reducer = function (state = initialState, action) {

    if (action.type === Constants.CUSTOMER_DETAILS) {
        return ObjectAssign({}, state, {
            hydrated: true,
            name: action.customer
        });
    }

    if (action.type === Constants.RESET_STORE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }

    if (action.type === Constants.SHOW_DEAL_CREATE_MODEL) {
        
        return ObjectAssign({}, state, {
            createDeal: true            
        });
    }

    if (action.type === Constants.HIDE_DEAL_CREATE_MODEL) {
        return ObjectAssign({}, state, {
            createDeal: false            
        });
    }

    if(action.type  === Constants.VIEW_CUSTOMER_DETAILS) {

        return ObjectAssign({}, state, {
            customer_details: {}
        });
    }

    if(action.type  === Constants.VIEW_CUSTOMER_DETAILS_RESPONSE) {

        return ObjectAssign({}, state, {
            customer_details: action.response.data
        });
    }

    return state;
};


module.exports = reducer;
