<?php include ('inc/header.php'); ?>

<div class="cms_page full_row">
	<div class="page_banner">
		<div class="container">
			<h1 class="head wow fadeInDown">About Ontabee</h1>
			<h2 class="head small wow fadeInUp">All Food lovers should visit immediately</h2>
		</div> <!--container-->
	</div> <!--page_banner-->
	
	<div class="container">
		<div class="cms_content">
			<p>Ontabee was founded to privilege restaurants with a platform to build, establish, and grow their online restaurant business and also based on great insights and strong technical expertise in building SaaS solutions. Ontabee's multi-directional approach helps restaurants to build their own brand and create a loyal service for its customers.</p>
			<p>We promise this should be possible without any hidden charges for the restaurant by charging high commission payment for each and every order.</p>
			<p>Ontabee supports the most convenient of online food ordering and delivery. But, many restaurants have great spicy food but they will lose sales & also their potential customers because of only reason that they don't have online ordering system for their restaurant business.</p>
			<p>To overcome this scenario many of those who built their online ordering system which ends up with bug software then the result will be the bad experience for each and every customer.</p>
			<p>Then in the other case of restaurant owners, they don't have any idea to built software for their own business. Either they will go which one of the online ordering system who earn commission for each order or ask the web development company to built a custom module which turns expensive as well.</p>
			<p>Our main objective is to solve this scenario and provide a solution for restaurant owners and food lovers.</p>			
		</div> <!--cms_content-->
	</div> <!--container-->
</div> <!--cms_page-->

<section class="team">
	<div class="container text-center">
		<h3 class="head wow fadeInUp">Meet Our Team</h3>
		<ul class="reset team">
			<li>
				<div class="img mb15">
					<img src="/images/rajesh.png" alt="Rajesh Prabhu" class="wow zoomIn">
				</div>
				<div class="content wow fadeInUp">
					<h4>Rajesh Prabhu</h4>
					<p class="job">Co-Founder & CEO</p>
					<p>Rajesh Prabhu has over 10 years of experience in the field of software development, mobile app services & new technology updates. He is very much responsible for overall operations and strategic management of the company. He is passionate about introducing new solutions for a problematic industry which leads him to a win-win situation. He believes that the success of his concern lies in between the dedicated team of professionals who works together with their potential to acquire it.</p>
				</div>
			</li>
			<li class="right">
				<div class="img mb15">
					<img src="/images/ramesh.png" alt="Rameshkumar" class="wow zoomIn">
				</div>
				<div class="content wow fadeInUp">
					<h4>Rameshkumar</h4>
					<p class="job">Project Manager</p>
					<p>Rameshkumar has over 6 years of experience in the field of software development. When he starts his career as iOS developer after that based on excellent talent & skills he is promoted to Project Manager. He will maintain the friendly relationship with the team members as well as respective clients. The way of thinking for the critical situation is very much different when compared with other employees because of this he sustain this position with the very short time.</p>
				</div>
			</li>
			<li>
				<div class="img mb15">
					<img src="/images/nandhakumar.png" alt="Nandhakumar" class="wow zoomIn">
				</div>
				<div class="content wow fadeInUp">
					<h4>Nandhakumar</h4>
					<p class="job">Project Co-ordinator</p>
					<p>Nandhakumar led the team to achieve the client goals throughout his service period internally and externally with a small and large team. He has an added advantage of thinking out of box technique which helps him to handle the critical situations with the client support service and make the connections smoother in a business.</p>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section>

<?php include('inc/footer.php');?>