/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorPayment', {
    requestId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'request_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'vendor_id'
    },
    requestAmount: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'request_amount'
    },
    requestDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'request_datetime'
    },
    requestStatus: {
      type: DataTypes.ENUM('Pending','Paid','Rejected'),
      allowNull: false,
      field: 'request_status'
    },
    bankName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'bank_name'
    },
    accountNumber: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'account_number'
    },
    ifscCode: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'ifsc_code'
    },
    branchName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'branch_name'
    },
    receipt: {
      type: DataTypes.STRING(124),
      allowNull: false,
      field: 'receipt'
    },
    totalOrderAmount: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'total_order_amount'
    },
    vendorPayableAmount: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'vendor_payable_amount'
    },
    totalEarnedCommission: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'total_earned_commission'
    },
    shopName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'shop_name'
    },
    outletKey: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'outlet_key'
    },
    paidDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      field: 'paid_date'
    }
  }, {
    tableName: 'ss16_vendor_payment'
  });
};
