

$(".show_hide .btn").click(function() {
    $(this).toggleClass("open");
        var input = $(".passToggle");
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});



$(document).ready(function() {
    $(".btn-top").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});



$('.select-modal').select2({
    dropdownParent: $('#create'),
    width: '100%'
});



$('select').select2({
  width: '100%'
});



$('.collapse-txt').click(function() {
  $(this).toggleClass( "active" );
  if ($(this).hasClass("active")) {
    $(this).text("Expand");
  } else {
    $(this).text("Collapse");
  }
});




// loader
  $('.loader').on('click', function() {
    var $this = $(this);
    var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
    if ($(this).html() !== loadingText) {
      $this.data('original-text', $(this).html());
      $this.html(loadingText);
    }
    setTimeout(function() {
      $this.html($this.data('original-text'));
    }, 2000);
  });

  //tooltip
  $(function () {
  $('[data-toggle="tooltip"]').tooltip()
})




$(document).ready(function() {
    $('.dataTable').DataTable({
      "aaSorting": []
    });

$('.dropdown-toggle').dropdown();

// toast alert

  $(".toast-alert").click(function(event) {
     Snackbar.show({text: 'Record Created Succesfully !'}); 
    });



$(document).ready(function() {
    $('.add-forms').editable({
      mode: 'inline',
      emptytext: '+Add', 
    });
});


$('.password-toggle').change(function() {
        $(".change-password").toggleClass("open");
    });


// close hide

  $(".first-box .btn-warning").click(function(event) {
       $(".first-box").addClass("hide");
       $(".second-box").addClass("open");
    });


// date picker

$('.datePicker').datepicker({
    language: 'en',
    minDate: new Date(),
    autoClose:true,
    dateFormat:"d/MM/yyyy"
});

$('.dateTimePicker').datepicker({
      language: 'en',
    minDate: new Date(),
    autoClose:true,
    dateFormat:"d/MM/yyyy",
    timepicker: true
});





var adjustment;

 $(".pipe-content ul").sortable({

 group: '.pipe_container',

onDrop: function  ($item, container, _super) {
    var $clonedItem = $('<li/>').css({height: 0});
    $item.before($clonedItem);
    $clonedItem.animate({'height': $item.height()});

    $item.animate($clonedItem.position(), function  () {
      $clonedItem.detach();
      _super($item, container);
    });

    $($item).parent().parent().parent().removeClass("moving");

  },

  // set $item relative to cursor position
  onDragStart: function ($item, container, _super) {
    var offset = $item.offset(),
        pointer = container.rootGroup.pointer;

    adjustment = {
      left: pointer.left - offset.left,
      top: pointer.top - offset.top
    };

    _super($item, container);


$($item).parent().parent().parent().removeClass("moving");
    

  },

  onDrag: function ($item, position) {
    $item.css({
      left: position.left - adjustment.left,
      top: position.top - adjustment.top
    });
$($item).parent().parent().parent().addClass("moving");
  }

 });


} );


setTimeout(function(){  $('.loader-table').removeClass(); },1000);

setTimeout(function(){  $('.loading-pipe').removeClass("loading-pipe"); },5000);
setTimeout(function(){  $('.loader-tab').removeClass("loader-tab"); },2500);
setTimeout(function(){  $('.loader-tab-content').removeClass("loader-tab-content"); },2500);



