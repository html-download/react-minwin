<?php include ('inc/header.php'); ?> 
 
<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Portfolio</h1>
		<h2 class="head small wow fadeInUp">List of Our Valuable Clients</h2>
	</div> <!--container-->
</div> <!--page_banner--> 

<section class="grey portfolio text-center">
	<div class="container">
		<ul class="reset">
			
			<li class="wow zoomIn">
				<img src="images/clients/ghostfood.jpg">
				<h5>Ghost Food</h5>
				<span>Spain</span>
				<a href="https://www.ghostfood.es" target="_blank">See on Live</a>
			</li>
			
			<li class="wow zoomIn">
				<img src="images/clients/tastemybiryani.jpg">
				<h5>Taste My Biryani</h5>
				<span>India</span>
				<a href="https://www.tastemybiryani.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/dcart.jpg">
				<h5>Dcart</h5>
				<span>India</span>
				<a href="http://www.dcartstore.com/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/shahigrill.jpg">
				<h5>Shahi Grill</h5>
				<span>India</span>
				<a href="https://www.shahigrill.in" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/bhukkad.jpg">
				<h5>BHUKKKAD</h5>
				<span>Bangladesh</span>
				<a href="http://www.bhukkkad.in" target="_blank">See on Live</a>
			</li>
			
			<li class="wow zoomIn">
				<img src="images/clients/tabao.jpg">
				<h5>Tabao</h5>
				<span>Singapore</span>
				<a href="http://tabao.sg" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/chennight.jpg">
				<h5>Chennight</h5>
				<span>India</span>
				<a href="http://www.chennight.com/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/safsaf.jpg">
				<h5>SafSaf Restaurant</h5>
				<span>Saudi Arabia</span>
				<a href="http://www.safsafonline.com/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/amirta.jpg">
				<h5>Amirtafood</h5>
				<span>India</span>
				<a href="http://www.amirtafood.in/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/lordrestaurant.jpg">
				<h5>Lord Restaurant</h5>
				<span>Australia</span>
				<a href="http://order.lordrestaurant.com.au/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/andhara.jpg">
				<h5>OSR Hotels</h5>
				<span>India</span>
				<a href="http://v2.osrhotels.com/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/stargourmet.jpg">
				<h5>Star Gourmet</h5>
				<span>India</span>
				<a href="https://www.stargourmet.in" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/hyleso.jpg">
				<h5>Hyleso</h5>
				<span>India</span>
				<a href="https://www.hyleso.in" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/rhodesbbq.jpg">
				<h5>Rhodes BBQ Smoke House</h5>
				<span>Nigeria</span>
				<a href="http://www.rhodesbbq.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/sasibriyanihotel.jpg">
				<h5>Sasi Briyani Hotel</h5>
				<span>India</span>
				<a href="http://sasibriyanihotel.in" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/ahlanfastfood.jpg">
				<h5>Ahlan fast food</h5>
				<span>Somalia</span>
				<a href="http://ahlanfastfood.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/cadaanichips.jpg">
				<h5>Cadaani Chips and Chicken</h5>
				<span>Somalia</span>
				<a href="http://cadaanichicken.com/" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/ordersula.jpg">
				<h5>SULA Indian Restaurant</h5>
				<span>Canada</span>
				<a href="http://www.ordersula.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/srtkitchens.jpg">
				<h5>SRT Kitchens</h5>
				<span>India</span>
				<a href="http://www.srtkitchens.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/claypot.jpg">
				<h5>Claypot Tanzania</h5>
				<span>Tanzania</span>
				<a href="http://claypot.co.tz" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/fooddli.jpg">
				<h5>Fooddli</h5>
				<span>India</span>
				<a href="http://www.fooddli.in" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/tumbites.jpg">
				<h5>Tumbites</h5>
				<span>India</span>
				<a href="http://order.tumbites.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/fudluv.jpg">
				<h5>FudLuv</h5>
				<span>India</span>
				<a href="http://fudluv.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/punjabidhaba.jpg">
				<h5>007 Punjabi Dhaba</h5>
				<span>India</span>
				<a href="https://www.007punjabidhaba.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/bigbelly.jpg">
				<h5>Big Belly</h5>
				<span>Malaysia</span>
				<a href="https://www.bigbelly.my" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/nibbles.jpg">
				<h5>Nibbles</h5>
				<span>Brazil</span>
				<a href="https://www.nibbles.com.br" target="_blank">See on Live</a>
			</li>
			
			<li class="wow zoomIn">
				<img src="images/clients/tiffkart.jpg">
				<h5>TiffKart</h5>
				<span>India</span>
				<a href="https://www.tiffkart.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/tapao.jpg">
				<h5>Tapao</h5>
				<span>Italy</span>
				<a href="https://www.tapao.it" target="_blank">See on Live</a>
			</li>
			
			<li class="wow zoomIn">
				<img src="images/clients/farmcityltd.jpg">
				<h5>FarmCity</h5>
				<span>Nigeria</span>
				<a href="http://app.farmcityltd.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/doncan.jpg">
				<h5>DonCan</h5>
				<span>Uruguay</span>
				<a href="https://www.don-can.com" target="_blank">See on Live</a>
			</li>
			<li class="wow zoomIn">
				<img src="images/clients/woknchork.jpg">
				<h5>Wok N Chork</h5>
				<span>India</span>
				<a href="http://woknchork.com" target="_blank">See on Live</a>
			</li>
			
			
			<li class="wow zoomIn">
				<img src="images/clients/walkaboutph.jpg">
				<h5>THE WALKABOUT HOTEL</h5>
				<span>Australia</span>
				<a href="http://www.walkaboutph.com.au" target="_blank">See on Live</a>
			</li>
			
			
			
		</ul>
	</div> <!--container--> 
</section>

<?php include('inc/footer.php');?>