/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorZone', {
    zoneId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'zone_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'vendor_id'
    },
    zoneName: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'zone_name'
    },
    mileStart: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'mile_start'
    },
    mileEnd: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'mile_end'
    },
    minOrderValue: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'min_order_value'
    },
    deliveryFeeDollar: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'delivery_fee_dollar'
    },
    deliveryFeePercentage: {
      type: "DOUBLE(10,3)",
      allowNull: false,
      field: 'delivery_fee_percentage'
    },
    serviceFeeDollarDelivery: {
      type: "DOUBLE(10,2)",
      allowNull: false,
      field: 'service_fee_dollar_delivery'
    },
    serviceFeePercentageDelivery: {
      type: "DOUBLE(10,3)",
      allowNull: false,
      field: 'service_fee_percentage_delivery'
    },
    minimumTip: {
      type: "DOUBLE(10,3)",
      allowNull: false,
      field: 'minimum_tip'
    },
    minAvgMinsDelivery: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'min_avg_mins_delivery'
    },
    maxAvgMinsDelivery: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'max_avg_mins_delivery'
    },
    deliveryOption: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '2',
      field: 'delivery_option'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    }
  }, {
    tableName: 'ss16_vendor_zone'
  });
};
