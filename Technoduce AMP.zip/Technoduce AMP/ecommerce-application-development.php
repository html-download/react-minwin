<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/ecommerce-development.png" alt="Ecommerce Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Top Rated <br>Ecommerce Development Company</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="overlay dark">
  <div class="container">
    <div class="content white">
      <h2 class="head style1 line white">Features we provide</h2>
      <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>

      <amp-img src="<?php echo $baseurl;?>images/front-end.png" alt="Interactive Front End" width="1165" height="690" layout="responsive"></amp-img>

      <ul class="features col3 reset">
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
        <li>
          <div class="box">
            <i class="fa fa-gear"></i>
            <span>Reliable and secure</span>
          </div>
        </li>
      </ul>
    </div> <!--content-->
  </div> <!--container-->
</section> <!--overlay-->

<section class="grey pb20">
  <div class="container text-center">
    <h2 class="head style1">E-commerce Deliverable</h2>
    <p class="md mb40">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit, Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet.</p>

    <div class="row text-left">
      <div class="col_7">
        <ul class="boxes icons reset col2">
          <li>
            <div class="box">
              <i class="fi cart-browser"></i>
              <h3>Web Commerce</h3>
              <p>Lorem ipsum dolor sit amet, cons adipiscing elit. Fusce ac ultricies sapien at auctor Lorem ipsum dolor sit amet, cons adipiscing.</p>
            </div> <!--box-->
          </li>
          <li>
            <div class="box">
              <i class="fi mobile-cart"></i>
              <h3>Mobile Commerce</h3>
              <p>Lorem ipsum dolor sit amet, cons adipiscing elit. Fusce ac ultricies sapien at auctor Lorem ipsum dolor sit amet, cons adipiscing.</p>
            </div> <!--box-->
          </li>
          <li>
            <div class="box">
              <i class="fi globe"></i>
              <h3>Social Commerce</h3>
              <p>Lorem ipsum dolor sit amet, cons adipiscing elit. Fusce ac ultricies sapien at auctor Lorem ipsum dolor sit amet, cons adipiscing.</p>
            </div> <!--box-->
          </li>
          <li>
            <div class="box">
              <i class="fi map-location"></i>
              <h3>Delivery App</h3>
              <p>Lorem ipsum dolor sit amet, cons adipiscing elit. Fusce ac ultricies sapien at auctor Lorem ipsum dolor sit amet, cons adipiscing.</p>
            </div> <!--box-->
          </li>
        </ul>
      </div> <!--col_7-->

      <div class="col_5">
        <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="E-commerce Development" width="460" height="450" layout="responsive"></amp-img>
      </div> <!--col_5-->
    </div>
  </div> <!--container-->
</section>

<section class="half blue">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row white">
      <div class="col_6 pull_right">
        <h2 class="head line white style1">Services we cover</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists blue style1 mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="half dark">
  <div class="bg bg2 right"></div>

	<div class="container">
    <div class="row white">
      <div class="col_6 pull_left">
        <h2 class="head line white style1">Services we cover</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists dark style1 mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="grey">
  <div class="container">
    <div class="row">
      <div class="col_6">
        <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="E-commerce Development" style="max-width:460px; margin:0 auto" width="460" height="450" layout="responsive"></amp-img>
      </div> <!--col_6-->

      <div class="col_6">
        <h2 class="head style1">Reports & Analytics</h2>
        <p class="md mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit, Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet.</p>
        <ul class="lists mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
        </ul>
      </div> <!--col_6-->
    </div>
  </div> <!--container-->
</section>

<?php include ('inc/footer.php'); ?>