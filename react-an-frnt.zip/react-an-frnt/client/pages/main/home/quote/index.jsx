'use strict';
const Form = require('./form.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');


const Helmet = ReactHelmet.Helmet;


class ContactPage extends React.Component {
    render() {

        return (
            <section >
                <Helmet>
                    <title>Contact us</title>
                </Helmet>
                <section class="empty-banner">
                </section>

                <section class="light_bg upload_details">
                    <div class="container">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                 <li class="breadcrumb-item"><a href="#">Home</a></li>
                               <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                            </ol>
                        </nav>

                        <h2 class="blue-heading sub-heading">Contact Us</h2>
                        <div class="white-box-shadow text-center contact contents">
                            
                            <div class="box-container">
                                <div class="row">
                                    <div class="col-md-8 contact_form">
                                       <h5>Get in Touch</h5>
                                       <form>
                                        <div class="row">
                                           <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter your First Name</label>
                                                    <input type="text" class="form-control"/>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                 <div class="form-group">
                                                    <label>Enter Your Last Name</label>
                                                    <input type="text" class="form-control"/>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Enter your Email Id</label>
                                                    <input type="text" class="form-control"/>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                 <div class="form-group">
                                                    <label>Enter Your Phone Number</label>
                                                    <input type="text" class="form-control"/>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Enter Your Message</label>
                                                  <textarea class="form-control"></textarea>
                                                </div>
                                                 <button class="btn btn-primary">Submit</button>
                                            </div>

                                        </div>
                                       </form>
                                    </div>
                                    <div class="col-md-4 ">
                                        <div class="contact_info">
                                        <h5>Contact Info</h5>
                                       <ul class="reset">
                                        <li><i class="icon-location-pin"></i><b>Location</b>
                                            JV Building, 2/3 &amp; 2/4 Mullai Nagar, 
                                            <br/>Maruthamalai Main Road,
                                             <br/>Vadavalli, Coimbatore - 641041,
                                              <br/>Tamil Nadu, India.
                                          </li>
                                         <li><i class="icon-phone"></i>
                                            <b>Customer Care</b>
                                            <a href="tel:+91-9686869685">+91-9686869685</a>
                                          </li>
                                           <li><i class="icon-envelope"></i>
                                            <b>Self Support</b>
                                            <a href="mailto:support@support.com">support@support.com</a>
                                          </li>
                                           <li><i class="icon-clock"></i>
                                            <b>Opening Hours</b>
                                            <a href="mailto:support@support.com">support@support.com</a>
                                          </li>
                                       </ul>
                                   </div>
                                    </div>
                                  </div>

                            </div>
                        </div>

                    </div>
                </section>
            </section>
        );
    }
}


module.exports = ContactPage;
