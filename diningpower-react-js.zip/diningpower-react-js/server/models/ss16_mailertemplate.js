/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Mailertemplate', {
    templateId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'template_id'
    },
    templateText: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'template_text'
    },
    templateType: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'template_type'
    }
  }, {
    tableName: 'ss16_mailertemplate'
  });
};
