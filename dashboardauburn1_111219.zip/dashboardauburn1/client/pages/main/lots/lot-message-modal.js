'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');
const moment = require('moment-timezone');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const Config = require('../../../../config.js');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    show: PropTypes.bool,
    show_message_modal : PropTypes.bool
};


class ModalForm extends React.Component {
    constructor(props){
        super(props);
        
        this.createLotMessage = this.createLotMessage.bind(this);
        this.renderDeleteElement = this.renderDeleteElement.bind(this);
    }
    createLotMessage() {
        let lot_message = $('#lot_message').val();
        let lot_message_date = $('#lot_message_date').val();
        let lot_message_time = $('#lot_message_time').val();

        lot_message_date  = lot_message_date.replace(/\//g, '-');

        if (lot_message === "") {
            Toaster.error('Message text cannot be blank!');
        } else {

            if (this.props.lot_message_id !== 0) {
                Actions.updateLotMessage({
                    msg_id : this.props.lot_message_id,
                    message : lot_message,
                    expires_by : moment(`${lot_message_date} ${lot_message_time}`, 'MM-DD-YYYY h:mm A').format()
                }, {id: this.props.lot_id})
            } else {
                Actions.createLotMessage({
                    lot_name : this.props.lot_name,
                    client_name : this.props.client_name,
                    message : lot_message,
                    expires_by : moment(`${lot_message_date} ${lot_message_time}`, 'MM-DD-YYYY h:mm A').tz(Config.get('/timeZone')).format()
                }, { id: this.props.lot_id})
                
            }
            
        }
        
    }

    renderDeleteElement() {

        if (this.props.lot_message_id && this.props.lot_message_id !== 0) {
            return (
                    <button 
                        id="button" 
                        className="btn red" 
                        onClick={(e) => { Actions.deleteLotMessage({
                                msg_id: this.props.lot_message_id
                            }, {
                                id: this.props.lot_id
                            })
                        } }>

                        Delete
                    </button>
            );
        }
        return null;
    }
    render() {
        return (
            <Modal
                id="modal_lot_msg"
                header={'Lot Message'}
                footer={false}
                show={this.props.show_message_modal}
                onClose={Actions.hideLotMessageModal}
                modalDialogClasses={{'modal-sm' : true}}>
                <div className="modal-body full_row">
                    <div className="form-group">
                      <label><i className="fa fa-comment-o" aria-hidden="true"></i> Message Text</label>
                      <textarea key={`${Math.floor((Math.random() * 1000))}-min`} id="lot_message" className="form-control" defaultValue={this.props.lot_message}></textarea>
                    </div>
                    <div className="form-group icon">
                      <label>Expires Date</label>
                      <input type="text" className="form-control datepicker" id="lot_message_date"  placeholder="Choose Date" defaultValue={this.props.lot_message_date} value={this.props.lot_message_date} readOnly/>
                      <i className="fa fa-calendar" aria-hidden="true"></i>
                    </div>
                    <div className="form-group time_picker icon">
                      <label>Expires Time</label>
                      <input type="text" className="form-control timepicker" id="lot_message_time"  placeholder="Choose Time" defaultValue={this.props.lot_message_time} value={this.props.lot_message_time}/>
                      <i className="fa fa-clock-o"></i>
                    </div>

                    <div className="form-group action">
                      <button id="button" className="btn grey pull-left" onClick={(e) => {Actions.hideLotMessageModal()}}>Cancel</button>
                      
                      {this.renderDeleteElement()}
                      
                      <button className="btn blue" onClick={(e) => {this.createLotMessage(e)}}>Save</button>
                    </div>
                </div>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
