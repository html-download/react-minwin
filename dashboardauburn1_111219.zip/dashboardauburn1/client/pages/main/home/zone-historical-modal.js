'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');
const moment = require('moment-timezone');
const Config = require('../../../../config.js');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    show: PropTypes.bool,
    show_zone_historical : PropTypes.bool,
    getHistoricalDownload : PropTypes.func
};


class ModalForm extends React.Component {

    render() {
        return (
            
            <Modal
                id="modal_history"
                header={'Historical Data'}
                footer={false}
                show={this.props.show_zone_historical}
                onClose={Actions.hideZoneHistoricalModal}
                modalDialogClasses={{'modal-lg' : true}}
                modalClasses={{'right' : true, 'fade' : true, 'in':true}}>

                
                <div className="modal-table">
                    <div className="modal-center">
                         <div className="htitle full_row" style={{'textTransform' : 'uppercase'}}>
                            {this.props.zone_selected} ZONE
                        </div>
                        <div className="col-sm-7">
                            <div id="historical_zone"></div>
                        </div>
                        <div className="col-sm-5">
                            <div className="form-group">
                            <div id="date-inline" data-date={this.props.historical_date}></div>
                            <input type="text" className="form-control date-inline hide" placeholder="Choose Date"/>
                            <input type="hidden" className="datepicker" placeholder=""/>
                            </div>
                            <div className="row">
                                <div className="col-sm-8">
                                    <div className="form-group">
                                        <select className="selectpicker" title="Choose Days" value={this.props.historical_day} onChange={ (event) => {Actions.setHistoricalDay(event.target.value)}}>
                                            <option value="1">1 day</option>
                                            <option value="2">2 days</option>
                                            <option value="3">3 days</option>
                                            <option value="4">4 days</option>
                                            <option value="5">5 days</option>
                                            <option value="6">6 days</option>
                                            <option value="7">7 days</option>
                                            <option value="15">15 days</option>
                                            <option value="30">30 days</option>
                                            <option value="45">45 days</option>
                                            <option value="60">2 months</option>
                                            <option value="90">3 months</option>
                                            <option value="180">6 months</option>
                                            <option value="365">1 year</option>
                                            <option value="730">2 years</option>
                                        </select>
                                        <label className="text-center" >Download Data (XLS)</label>
                                        <label className="text-center" style={{'fontSize' :  '10px'}}> (Note : Report generated 
                                            {this.props.historical_day !== 1 ? 
                                                ` from ${moment(this.props.historical_date, 'MM/DD/YYYY').subtract(this.props.historical_day - 1, "days").format('MM/DD/YYYY')} to ${this.props.historical_date})` : 
                                                ` for ${this.props.historical_date})`
                                            }

                                        </label>
                                    </div>
                                </div>
                                <div className="col-sm-4">
                                    <button className="btn blue" onClick={ this.props.getHistoricalDownload} >Download</button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
