'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'SEND_MESSAGE',
    'SEND_MESSAGE_RESPONSE',
    'SHOW_QUOTE_MODAL',
    'HIDE_QUOTE_MODAL',
]);
