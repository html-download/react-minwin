const Actions = require('../actions');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');
const UserIdentity = require('../../../../helpers/user-identity');

const ObjectAssign = require('object-assign');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;
const Redirect = ReactRouter.Redirect;

const propTypes = {
    match: PropTypes.object
};


class ActivationPage extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
    }

    componentDidMount() {
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.password) {
            this.input.password.focus();
        }
        Actions.activation({
            email: this.props.match.params.email,
            key: this.props.match.params.key
        });
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {
        event.preventDefault();
        event.stopPropagation();

        Actions.activation({
            email: this.props.match.params.email,
            key: this.props.match.params.key
        });
    }
    render() {
        if (UserIdentity._checkUserIdentity()) {
            return <Redirect to='/' push />;
        }
        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success">
                <div className="alert alert-success">
                    You have successfully activated the account.
                </div>
                <h4 className="sub-title">Have a Dining Power account? 
                    <Link to="/login"> Sign in</Link>
                </h4>
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    type="hidden"
                    hideLabel={true}
                    name="_key"
                    hasError={this.state.hasError.key}
                    value={this.props.match.params.key}
                    help={this.state.help.key}
                    disabled={true}
                />
                <TextControl
                    type="hidden"
                    hideLabel={true}
                    name="_email"
                    hasError={this.state.hasError.email}
                    value={this.props.match.params.email}
                    help={this.state.help.email}
                    disabled={true}
                />
                {/*<ControlGroup hideLabel={true} hideHelp={true}>
                    <Button
                        type="submit"
                        inputClasses={{ 'full': true, 'mtb16' : true }}
                        disabled={this.state.loading}>

                        Activating
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
                </ControlGroup>*/}
            </fieldset>;
        }

        return (
            <section className="login-register">
                <Helmet>
                    <title>User Activation</title>
                </Helmet>
                <div className="container">
                    <div className="login-left equal">
                        <div className="login-img">
                        <img src="/public/media/images/login.png" alt="Reset Password"/>
                        </div>
                    </div>
                    <div className="login-right equal">
                        <div className="custom-modal">
                            <div className="modal-dialog">
                                <div className="modal-content reset-part">
                                    <div className="modal-header">
                                        <h4 className="modal-title">Activating the User</h4>
                                        <h4 className="sub-title normal">Please be a patient to check and activating account.</h4>
                                    </div>
                                    <div className="modal-body">
                                        <form onSubmit={this.handleSubmit.bind(this)}>
                                            {alerts}
                                            {formElements}
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}

ActivationPage.propTypes = propTypes;


module.exports = ActivationPage;
