<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/react-js-logo.png" alt="ReactJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">One stop solution for ReactJS web development</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="half_bg red">
  <div class="container relative">
    <div class="col_6 pr30 white">
      <h2 class="head line white style1">Create awesome UIs by using React Javascript library</h2>
      <p class="mb20">React.js is the fastest growing flexible JavaScript front-end technology framework. Technoduce Info Solutions offers you a broad range of React.js web & mobile application development services that suits for big and small enterprises. React.js having enormous capabilities, such as simple scalability and flaw tolerance, allows for building a web application with different complexity levels. React mobile apps have the speed, UI and feel as well as the functionality of native mobile applications. The connection of HTML & JavaScript allows React.js developers to write reusable code. React component can reuse the existing application code without code rewriting.</p>

      <h3 class="sub_head">Services in ReactJS</h3>
      <ul class="lists style1 mb0">
        <li>React.js UI/UX development.</li>
        <li>React.js front-end services for all sized enterprises and startups.</li>
      </ul>
    </div>
    
    <div class="col_6 pl30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="ReactJS Development" width="460" height="450" layout="responsive"></amp-img>
    </div>
  </div> <!--container-->
</section> <!--half_bg-->

<section>
  <div class="container">
    <h2 class="head text-center style1">Influence The Power of React.js Development Services</h2>
    <div class="web_features full_row">
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Zero Dependencies</h3>
            <p>It is very easy to try it out on small features in an existing technology.</p>
          </li>
          <li>
            <h3>One Way Data Flow</h3>
            <p>React executes a one-way reactive data flow, which reduces side effect and it's easier when compared with two-way data binding.</p>
          </li>
          <li>
            <h3>Virtual DOM</h3>
            <p>A virtual DOM object is a representation of DOM objects like a lightweight copy which provides you simple programming model and better performance.</p>
          </li>
        </ul>
      </div>

      <div class="img">
        <amp-img src="<?php echo $baseurl;?>images/react-js-logo.png" alt="ReactJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
        </ul>
      </div>
    </div> <!--web_features-->
  </div> <!--container-->
</section>

<section class="half dark">
	<div class="container">
    <div class="row white">
      <div class="col_6 pr30">
        <h2 class="head line white style1">React.js Enclosed With Following Remarkable Features</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style2">
          <li>One-way data binding.</li>
          <li>Lightweight code based COM.</li>
          <li>Excellent component support.</li>
          <li>Highly adaptable.</li>
          <li>Interactive interface design.</li>
          <li>It allows building high-performance website.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg1 right"></div>
</section>

<section class="half red">
  <div class="bg bg2 left"></div>

	<div class="container">
    <div class="row white">
      <div class="col_6 pull_right">
        <h2 class="head line white style1">Why React JS for your mobile application?</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style1 mb0">
          <li>React JS is a modernized JavaScript framework backed by Facebook.</li>
          <li>Isomorphic apps can be organized fast by React JS.</li>
          <li>In React.js, without much of stretch can split pages or element into a little segment that can be reused in a different parts of a site.</li>
          <li>It is easy to debug react components with the tools which exists in the market.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="section timeline">
	<div class="container md">
		<h2 class="head style1">ReactJS web app development process</h2>
		<ul class="reset">
			<li>
				<div class="content">
					<span class="step">1</span><i class="fi monitor1"></i>
					<h3>Business analyst</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque dolor.</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">2</span><i class="fi setting"></i>
					<h3>Project Management</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque dolor.</p>
				</div>
      </li>
      <li>
				<div class="content">
					<span class="step">3</span><i class="fi design"></i>
					<h3>Design UX / UI</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque dolor.</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">4</span><i class="fi browser"></i>
					<h3>Development</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque dolor.</p>
				</div>
      </li>
      <li>
				<div class="content">
					<span class="step">5</span><i class="fi cloud-server"></i>
					<h3>Testing</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque dolor.</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">6</span><i class="fi cloud-server"></i>
					<h3>Deployment</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit pellentesque dolor.</p>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section> <!--section-->

<section class="half red">
	<div class="container">
    <div class="row white">
      <div class="col_6 pr30">
        <h2 class="head line white style1">Why choose Technoduce as an ReactJS development?</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style1 mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit ut pellentesque.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg3 right"></div>
</section>

<?php include ('inc/footer.php'); ?>