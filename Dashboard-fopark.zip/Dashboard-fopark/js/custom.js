

// Draw a sparkline for the #sparkline chart element
var values = [1, 2, 3];

$("#sparkline").sparkline([3,2,3,1,2,2,3,2], {
    type: 'pie',
    width: '150px',
    height: '150px',
    sliceColors: ['#337119','#1e5631','#4c9a2a','#76ba1b','#68bb59','#acdf87','#a4de02',
    '#cfeeb9']});

