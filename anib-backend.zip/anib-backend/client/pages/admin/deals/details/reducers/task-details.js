'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');


const initialState = {
    loading: false,
    error: undefined,
    task_modal_show: false,
    note_modal_show:false,
    notes: [],
    notes_loading: true,
    deal_docu: [],
    deal_docu_loading: true,
    deal_task: [],
    deal_task_loading: true
};
const reducer = function (state = initialState, action) {

    if (action.type === Constants.ADD_TASK_MODAL_SHOW) {
        return ObjectAssign({}, state, {
            task_modal_show: true
        });
    }

    if (action.type === Constants.ADD_TASK_MODAL_HIDE) {
        return ObjectAssign({}, state, {
            task_modal_show: false
        });
    }

    if (action.type === Constants.ADD_NOTE_MODAL_SHOW) {
        return ObjectAssign({}, state, {
            note_modal_show: true
        });
    }

    if (action.type === Constants.ADD_NOTE_MODAL_HIDE) {
        return ObjectAssign({}, state, {
            note_modal_show: false
        });
    }

    if (action.type === Constants.GET_NOTE_RESULT) {

        return ObjectAssign({}, state,{
            notes : [],
            notes_loading: true
        });
    }

    if (action.type === Constants.GET_NOTE_RESULT_RESPONSE) {

        if (action.response.status === 200) {
            return ObjectAssign({}, state,{
                notes : action.response.data,
                notes_loading: false
            });
        }
    }

    if (action.type === Constants.GET_DEAL_DOCU_DETAILS) {

        return ObjectAssign({}, state,{
            deal_docu : [],
            deal_docu_loading: true
        });
    }

    if (action.type === Constants.GET_DEAL_DOCU_DETAILS_RESPONSE) {
                
        if (action.response.status === 200) {
            return ObjectAssign({}, state,{
                deal_docu : action.response.data,
                deal_docu_loading: false
            });
        }
    }

    if (action.type === Constants.GET_DEAL_TASK_RESULT) {

        return ObjectAssign({}, state,{
            deal_task : [],
            deal_task_loading: true
        });
    }

    if (action.type === Constants.GET_DEAL_TASK_RESULT_RESPONSE) {
                
        if (action.response.status === 200) {
            return ObjectAssign({}, state,{
                deal_task : action.response.data,
                deal_task_loading: false,
                task_modal_show: false
            });
        }
    }


    if (action.type === Constants.RESET_STORE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }
    
    return state;
};


module.exports = reducer;
