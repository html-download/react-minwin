const React = require('react');
const PropTypes = require('prop-types');
const ReactRouter = require('react-router-dom');
const Favicon = require('react-favicon');

const SignupForm = require('./signup-popup/index.jsx');
const LoginForm = require('./login/popup/index.jsx');
const ForgotForm = require('./login/forgot-popup/index.jsx');
const UserIdentity = require('../../helpers/user-identity');
const DateTimeHelper = require('../../helpers/date-time');

const Link = ReactRouter.Link;

const propTypes = {
    location: PropTypes.object
};
class Navbar extends React.Component {
    constructor(props) {
        super(props);
        this.handleModalClick = this.handleModalClick.bind(this);
    }
    handleModalClick(event) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
    }
    componentDidMount() {
        //console.log("UserIdentity._checkUserToken()", UserIdentity._checkUserToken());
        localStorage.setItem('setStorage', null);
    }
    render() {
        return (
                <header className="main-header">  
                    <Favicon url="/public/media/images/favicon.png"/>  
                    <Link to="/dashboard" className="logo"><img src="/public/media/images/logo-w.png" /></Link>    
                    <nav className="navbar navbar-static-top">      
                      <a className="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span className="sr-only">Toggle navigation</span>
                        <span className="icon-bar"></span> <span className="icon-bar"></span> <span className="icon-bar"></span>
                      </a>
                      <h1>AU Parking Dashboard</h1>
                      <div className="navbar-custom-menu">
                        <ul className="nav navbar-nav">
                          <li>
                              <span>{DateTimeHelper._emailDateTemplate()}</span>
                          </li>
                          {/*<li>
                              <select className="selectpicker">
                                  <option>EN</option>
                                  <option>Other</option>
                              </select>
                          </li>*/}
                          <li className="dropdown user user-menu">
                            <a className="dropdown-toggle" data-toggle="dropdown">
                              <img src="/public/media/images/user-small.png" className="user-image" />
                              <span className="hidden-xs">Hi Don</span>
                            </a>            
                            <ul className="dropdown-menu">              
                              <li className="user-header">
                                <img src="/public/media/images/user.png" className="img-circle" />
                                <p>Don</p>
                              </li>
                              <li className="user-footer">
                                <div className="pull-left">
                                  <a role="button" className="btn">Profile</a>
                                </div>
                                <div className="pull-right">
                                    <Link to="/login/logout" className="btn grey">Sign Out</Link>
                                </div>
                              </li>
                            </ul>
                          </li>
                        </ul>
                      </div>
                    </nav>
                  </header> 
        );
    }
}

Navbar.propTypes = propTypes;


module.exports = Navbar;