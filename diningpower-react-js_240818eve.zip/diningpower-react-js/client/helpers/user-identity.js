'use strict';

module.exports = {
    _userIdentity : function () {
        try {
            if (localStorage == undefined) {
                var localStorage = null;
            }
            const tokens = localStorage.getItem('user');
            if (tokens !== null) {
                return JSON.parse(tokens);
            }

            return null;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _checkUserIdentity : function(){
        try {
            if (localStorage == undefined) {
                return false;
            }
            const tokens = localStorage.getItem('user');
            if (tokens !== null) {
                return true;
            }

            return false;
        } catch (e) {
            console.log(e.message);
            return false;
        }
    }
};
