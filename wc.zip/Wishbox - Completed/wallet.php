<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
<!-- myaccount -->
<section class="myaccount-page">
  <!-- container -->
  <div class="container mx-1150">
    <div class="full_row">
      <!-- fullrow -->
      <div class="side-bar-acc">
        <!-- header -->
        <div class="side-bar-header">
          <div class="round">KR</div>
          <h4>Khuzaimah Raghid</h4>
          <p>khuzaimahraghid@gmail.com</p>
          <p class="mb-0">+98765432101</p>
        </div>
        <!-- header -->
        <ul class="reset nav-side">
          <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
          <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
          <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
          <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
          <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
          <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
          <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
          <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
          <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
          <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
        </ul>
      </div>
      <!-- sidebar -->
      <!-- Smile page content -->
      <div class="acc_page_content">
        <div class="acc_title">
          <i class="fi wallet2"></i>
          <h2>Wallet</h2>
          <p>Top-up your wallet amount</p>
        </div>
        <div class="white-30">
          <!-- wallet wrap -->
          <div class="wallet-wrap d-flex">
            <div class="wallet-total">
              <p>Your wallet Balance</p>
              <span><i class="fi wallet1"></i>QR 400</span>
            </div>
            <span class="top-wrap"> <a class="top-up" data-dismiss="modal" data-toggle="modal" data-target="#modal_wallet">
            <i class="la la-plus"></i> Top Up</a></span>
          </div>
          <!-- wallet transaction-->
          <div class="transaction-wrap">
            <h3>Transaction History</h3>
            <div class="trans-history">
              <!--trans-history--->
              <div class="or-details">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span>+ QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 440</span>
                </div>
              </div>
              <div class="or-details">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span>+ QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 380</span>
                </div>
              </div>
              <div class="or-details reduce">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span class="minus-point">- QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 360</span>
                </div>
              </div>
              <div class="or-details">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span>+ QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 380</span>
                </div>
              </div>
              <div class="or-details reduce">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span  class="minus-point">- QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 360</span>
                </div>
              </div>
              <div class="or-details reduce">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span class="minus-point">- QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 380</span>
                </div>
              </div>
              <div class="or-details">
                <div>
                  ID
                  <span class="pinks">#WAllet001</span>
                </div>
                <div>
                  Transaction By
                  <span>Top-up</span>
                </div>
                <div>
                  Date & Time
                  <span>07/20/2019 11:10 AM</span>
                </div>
                <div>
                  Amount
                  <span>+ QR 20</span>
                </div>
                <div>
                  Balance
                  <span>QR 440</span>
                </div>
              </div>
              <!--trans-history end--->
            </div>
          </div>
        </div>
        <!-- smile page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
</section>
<!-- myaccount -->
</div>
<!--site_page-->
<div id="modal_wallet" class="modal fade wallet" role="dialog">
  <div class="modal-dialog sm">
    <div class="modal-content">
      <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>            
      <div class="modal-body">
        <div class="wallet-modal-wrap text-center">
          <i class="fi wallet1"></i>
          <h3>How much would you like to top up?</h3>
          
          <div class="enter-amount">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Enter Amount">
            </div>
          </div>
          

          <span class="full">Quick Top-up</span>
          <div class="wallet-topup">
            <input type="radio" class="wallet-chk" name="w-check" id="w-c1">
            <label class="wallet-chk" for="w-c1">QR <span>10</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c2">
            <label class="wallet-chk" for="w-c2">QR <span>20</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c3">
            <label class="wallet-chk" for="w-c3">QR <span>30</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c4">
            <label class="wallet-chk" for="w-c4">QR <span>40</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c5">
            <label class="wallet-chk" for="w-c5">QR <span>50</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c6">
            <label class="wallet-chk" for="w-c6">QR <span>60</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c7">
            <label class="wallet-chk" for="w-c7">QR <span>70</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c8">
            <label class="wallet-chk" for="w-c8">QR <span>80</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c9">
            <label class="wallet-chk" for="w-c9">QR <span>90</span></label>
            <input type="radio" class="wallet-chk" name="w-check" id="w-c10">
            <label class="wallet-chk" for="w-c10">QR <span>100</span></label>
          </div>
          <div class="add-topup d-flex">
            <div class="add-balance">
              <p>Wallet Balance</p>
              <span>QR 400 + <span class="pink"> QR 70 </span></span>
            </div>
            <a class="btn" data-dismiss="modal" data-toggle="modal" data-target="#modal_wallet">
            Top Up</a>
          </div>
        </div>
      </div>
      <!--modal-body-->
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!--modal_ratings-->
<?php include ('inc/footer.php'); ?>