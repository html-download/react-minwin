'use strict';
const Actions = require('./actions');
const ProductDetails = require('./product-details');
const React = require('react');
const Store = require('./store');
const CommonHelper = require('../../../../../../helpers/common-functions');
const DateHelper = require('../../../../../../helpers/date-time');
const ViewPolicy = require('../../../../policies/search/view-form');

class Closed extends React.Component {   

    constructor(props) {

        super(props);
        this.state = Store.getState();
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentDidUpdate(prevProps, prevState) {
        
        if (this.props.order_id !== undefined && prevProps.order_id !== this.props.order_id && this.props.order_id !== '') {
            Actions.getDealQuote(this.props.order_id);
        }
    }

    componentWillReceiveProps(nextProps) {
            
        nextProps.id ? Actions.getDealQuote(nextProps.deal_data.deal_quote_key) : undefined;
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }
        
    toggleQuote() {
        
        Actions.toggleQuote();
    }

    openPolicyModal() {

        Actions.openPolicyModal();
    }

    render() {

        let value = this.state.quote_data;
        return (                    
            <div>
                <div className="wi-content mt-30 full_row">
                    <div className="text-right mb-2"> 
                        <a className="link-text collapse-txt" data-toggle="collapse" href="#genrate"> Collapse </a> 
                    </div>
                    <div className="genrate-new-quote collapse show" id="genrate">
                        { CommonHelper.isEmpty(this.state.quote_data) ? (
                            <div className="under-construction">
                                <h3>Sorry! You have not won any Policy</h3>
                                <p>Thank you for your patience.</p>
                            </div>
                        ): (
                            <div className="first-box">
                                <div className="deal-won text-center">
                                    <img src="/public/media/images/won.png" />
                                    <div className="full_row">
                                        <h2>Closed Success</h2>
                                    </div>
                                </div>
                                <div className="product-box">
                                    <ul className="product-listing reset">
                                        <li>
                                            <div className="box">
                                                <div className="img">
                                                    <img src={value.insurence_product_image} />
                                                </div>
                                                <h5>{value['insurence_product_name']}</h5>
                                                <p>Sum Insured: AED {value['vehicle_insured_value']}</p>
                                                {/* <p>Quote Reference: {value['quote_reference_number']}</p> */}
                                                <p>Quotation Number: {value['quotation_number']}</p>
                                                <p className="tags" style={{ 'display' : 'none'}}> <span>Pab Driver</span> <span>Pab Passenger</span> </p>
                                                <div className="right-cd text-cenetr">
                                                    <p className="bold text-center">Total Premium <br/> AED {value['premium_value']}</p>
                                                    <div className="text-center mt-2">
                                                        <a href="#" className="view-text">{this.props.deal_payment_status === 1 ? 'Paid': this.props.deal_payment_status === 2 ? 'Unpaid' : 'Go back and Select'}</a>
                                                    </div>
                                                </div>
                                            </div>                                        
                                            <div className="box-fields">
                                                <div className="row viewed-content">
                                                    <div className="col-sm-3">
                                                        <div className="form-group">
                                                            <label>Policy Start Date</label>
                                                            <label className="answer">{value['policy_start_date']}</label>
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-3">
                                                        <div className="form-group">
                                                            <label>Policy Expiry Date</label>
                                                            <label className="answer">{value['policy_expire_date']}</label>
                                                        </div>
                                                    </div>
                                                    <div className="col-sm-3">
                                                        <div className="form-group">
                                                            <label>Policy Number</label>
                                                            <label className="answer">{value['policy_number']}</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-right mt-1 mb-3">
                                                    <button onClick={ (e) => this.openPolicyModal() } className="btn btn-outline-success no-shadow mt-3"> <i className="fa fa-external-link"></i> View Policy</button>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        ) }
                    </div>
                </div>
                <ViewPolicy
                    Actions = {Actions}
                    is_view_policy={this.state.is_view_policy}
                    {...this.state.policy_details}
                />
            </div>
        );
    }
}
module.exports = Closed;
