<?php include ('inc/header.php'); ?>

<section class="banner" style="background-image: url(assets/img/grocery.jpg)">
    <div class="container">
        <h1>Order Online from the verified <span>Grocery Stores</span></h1>
        <p>Specify your address to suggest you the fast delivery</p>

        <form class="search_form" action="restaurant">
            <div class="form_group">
                <i class="fi pin3"></i>
                <input type="text" id="location" class="form-control" placeholder="Enter your location">
                <i class="fi gps" data-toggle="tooltip" data-placement="left" title="Current Location"></i>
            </div> <!--form_group-->

            <div class="form_group hide">                
                <select id="services" class="selectpicker hide">
					<option data-text="Grocery Stores" data-icon="fi grocery" data-img="assets/img/grocery.jpg">Grocery Stores</option>
                    <option data-text="Restaurants"data-icon="fi shop" data-img="assets/img/restaurants.jpg">Restaurants</option>
					<option data-text="Laundry Service"data-icon="fi laundry" data-img="assets/img/laundry.jpg">Laundry Service</option>
					<option data-text="Other Services"data-icon="fi tools" data-img="assets/img/services.jpg">Other Services</option>
				</select>
            </div> <!--form_group-->

            <button class="btn search">Search</button>
        </form> <!--search_form-->

        <div class="full_row">
            <ul class="count">
                <li><i class="fi grocery"></i> <h4>350</h4> <span>Grocery Stores</span></li>
                <li><i class="fi shop"></i> <h4>500</h4> <span>Restaurants</span></li>
                <li><i class="fi laundry"></i> <h4>150</h4> <span>Laundry Service</span></li>
                <li><i class="fi tools"></i> <h4>200</h4> <span>Other Services</span></li>
            </ul>
        </div> <!--full_row-->
    </div> <!--container-->
</section> <!--banner-->

<section class="offers home">
    <div class="container">        
        <div class="row">
            <div class="col-sm">
                <h2>Top Offers</h2>
                <p class="grey mb0">Explore our best deals and offers exclusively for you!</p>
            </div>

            <div class="col-sm">
                <ul class="nav nav-tabs">
                    <li><a data-toggle="tab" href="#grocery" class="active"><i class="fi grocery"></i></a></li>
                    <li><a data-toggle="tab" href="#restaurants"><i class="fi shop"></i></a></li>
                    <li><a data-toggle="tab" href="#laundry"><i class="fi laundry"></i></a></li>
                    <li><a data-toggle="tab" href="#other_services"><i class="fi tools"></i></a></li>
                </ul>                
            </div>
        </div> <!--row-->

        <div class="tab-content full_row mt25">
            <div id="grocery" class="tab-pane fade show active">
                <div class="offers_list owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/img/offers/1.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/2.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/3.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/4.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/5.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/6.jpg">
                    </div> <!--item-->
                </div> <!--offers_list-->
            </div> <!--grocery-->

            <div id="restaurants" class="tab-pane fade">
                <div class="offers_list owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/img/offers/1.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/2.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/3.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/4.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/5.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/6.jpg">
                    </div> <!--item-->
                </div> <!--offers_list-->
            </div> <!--restaurants-->

            <div id="laundry" class="tab-pane fade">
                <div class="offers_list owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/img/offers/1.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/2.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/3.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/4.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/5.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/6.jpg">
                    </div> <!--item-->
                </div> <!--offers_list-->
            </div> <!--laundry-->

            <div id="other_services" class="tab-pane fade">
                <div class="offers_list owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/img/offers/1.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/2.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/3.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/4.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/5.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/6.jpg">
                    </div> <!--item-->
                </div> <!--offers_list-->
            </div> <!--other_services-->
        </div> <!--tab-content-->
    </div> <!--container-->
</section> <!--offers-->

<section class="offers pt0 home">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <div class="offers_home owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/img/offers/7.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/7.jpg">
                    </div> <!--item-->
                </div> <!--offers_home-->                
            </div> <!--col-sm-8-->

            <div class="col-sm-4">
                <div class="offers_home owl-carousel owl-theme mb30">
                    <div class="item">
                        <img src="assets/img/offers/8.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/9.jpg">
                    </div> <!--item-->
                </div> <!--offers_home-->
                
                <div class="offers_home owl-carousel owl-theme">
                    <div class="item">
                        <img src="assets/img/offers/9.jpg">
                    </div> <!--item-->
                    <div class="item">
                        <img src="assets/img/offers/8.jpg">
                    </div> <!--item-->
                </div> <!--offers_home-->
            </div> <!--col-sm-4-->
        </div>
    </div> <!--container-->
</section> <!--offers-->

<section class="bussiness home">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <h2>Are you ready to add your <span class="block">Bussiness in Wishbox?</span></h2>
                <p class="grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla rhoncus, nisi portadapibus ultrices, tortor massa varius lorem, sit amet vestibulum felis antet elit vivamus sed imperdiet ipsum. Nam semper sapien sem.</p>

                <ul class="list regular">
                    <li>Omnis iste natus error sit voluptatem accusantium dolorem .</li>
                    <li>Consectetur adipiscing elit, sed do eiusmod tempor incididunt .</li>
                    <li>Quis nostrud exercitation ullamco laboris nisi ut aliquip.</li>
                    <li>Consectetur adipiscing elit, sed do eiusmod tempor incididunt .</li>
                    <li>Quis nostrud exercitation ullamco laboris nisi ut aliquip.</li>
                </ul> <!--list-->

                <a class="btn" data-toggle="modal" data-target="#modal_bussiness"><i class="la la-plus-circle"></i> Add your Business</a>
            </div> <!--col-sm-6-->
        </div>
    </div> <!--container-->
</section> <!--bussiness-->

<section class="mobile home">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 text-center">
                <img src="assets/img/mobile-app.png" class="mobile_app">
            </div> <!--col-sm-6-->

            <div class="col-sm-6">
                <h2>Download Wishbox App</h2>
                <p class="grey">Download the app for free, and order takeaway online, anytime.</p>

                <div class="form-group icon">
                    <label for="mobile_app"><i class="lni-mobile"></i></label>
                    <input id="mobile_app" type="text" class="form-control" placeholder="Mobile Number">
                    <button class="btn">Send sms</button>
                </div> <!--form-group-->

                <p class="grey full_row">You will receive the SMS with app download link.</p>
                <p class="mb0 app_download full_row">
                    <a href="" target="_blank"><img src="assets/img/app-store.png"></a>
                    <a href="" target="_blank"><img src="assets/img/play-store.png"></a>
                </p>
            </div> <!--col-sm-6-->
        </div>
    </div> <!--container-->
</section> <!--mobile-->

<script>    
    $('#services').on('change', function () {
        var backImg = $('option:selected', this).data("img");
        var bannerText = $('option:selected', this).data("text");
        $('.banner').css('background-image', 'url(' + backImg + ')');
        $('h1 span').text(bannerText);
    });

    $('#location').click(function(){
        $('.search_form').addClass('services');
    });
</script>

<?php include ('inc/footer.php'); ?>
