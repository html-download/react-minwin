const React = require('react');
const ReactHelmet = require('react-helmet');

const Helmet = ReactHelmet.Helmet;

class LotsPage extends React.Component {
    render() {

        return (
            <div className="content-wrapper" id="lots">
                <section className="content">
                    <Helmet>
                        <title>Welcome to Dashboard</title>
                    </Helmet>
                </section>
            </div>
        );
    }
}


module.exports = LotsPage;
