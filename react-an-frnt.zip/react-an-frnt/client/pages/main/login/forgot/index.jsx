'use strict';
const Actions = require('../actions');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');
const Toaster = require('../../../../helpers/toaster');


const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class ForgotPage extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.email) {
            this.input.email.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Toaster.warning('Page is under construction!')

        Actions.forgot({
            email: this.input.email.value()
        });
    }

    render() {

        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success">
                <div className="alert alert-success">
                    If an account matched that address, an email will be sent with instructions.
                </div>
                <Link to="/login" className="btn btn-link">Back to login</Link>
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.email = c)}
                    name="email"
                    placeholder="Email Id"
                    hideLabel={true}
                    hasError={this.state.hasError.email}
                    help={this.state.help.email}
                    disabled={this.state.loading}
                />
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'form-group': false, 'row': true, 'mb-3': true}}>
                    <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'form-group': false, 'col-md-6': true}}>
                        <Link to="/" className="btn btn-secondary btn-block">Cancel</Link>
                    </ControlGroup>
                    <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'form-group': false, 'col-md-6': true}}>
                        <Button
                            type="submit"
                            inputClasses={{ 'btn-primary': true, 'btn-block': true, 'loader': true }}
                            disabled={this.state.loading}>

                            <Spinner space="right" show={this.state.loading} />
                            Send reset
                        </Button>
                    </ControlGroup>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <section className="login-container text-center forgot">
                <Helmet>
                    <title>Forgot password</title>
                </Helmet>
                <div className="container-box">
                    <div className="full_row">
                        <div className="left-side">
                            <h3>Forgot Password</h3>
                            <p>By Signing Up, you can avail full features of our services.</p>
                            <p>Get an Account !!!</p>
                        </div>
                        <div className="right-side">

                            <div className="logo">
                                <img src="/public/media/images/logo.png" alt="Logo" />
                            </div>

                            <p>Nulla blandit viverra interdum. Etiam mi urna, porttitor at tincidunt et.</p>

                            <form onSubmit={this.handleSubmit.bind(this)}>
                                {alerts}
                                {formElements}
                            </form>

                        </div>
                    </div>
                </div>
            </section>
        );
    }
}


module.exports = ForgotPage;
