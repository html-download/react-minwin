const React = require('react');
const ReactHelmet = require('react-helmet');

const Helmet = ReactHelmet.Helmet;

class MyRewardsPage extends React.Component {
    componentDidMount() {
        window.scrollTo(0, 0);
    }
    render() {

        return (
            <div>
                <Helmet>
                    <title>Rewards</title>
                </Helmet>
                <section className="myreward">
                    <div className="container">
                        <div className="full_row text-center">
                            <div className="width-600">
                                <h2>My Power Rewards</h2>
                                <p className="first">Earn points with every order - points never expire!</p>
                                <img src="public/media/images/reward.png" alt="Power Rewards" className="mb20"/>
                                <div className="full_row level">
                                    <div className="w50 point">
                                        <p>Point Balance</p>
                                        <span>10,000</span>
                                    </div>
                                    <div className="w50 status">
                                        <p>Staus Level</p>
                                        <span>Classic</span>
                                    </div>
                                    <p className="redeem">Redeem points for Power Rewards here.</p>
                                    <div className="full_row powerspin">
                                        <div className="spinner">
                                            <div className="spin_head">
                                                <img src="public/media/images/cake-xs.png" alt="Cake"/>
                                                <h4><i className="fa fa-star" aria-hidden="true"></i>Power Spin<i className="fa fa-star" aria-hidden="true"></i></h4>
                                                <img src="public/media/images/burger.png" alt="Burger"/>
                                            </div>
                                            <div className="spin_body success">
                                                <div className="spin_reel reel"><div className="each-reel reel1"></div></div>
                                                <div className="spin_reel reel"><div className="each-reel reel2"></div></div>
                                                <div className="spin_reel reel"><div className="each-reel reel3"></div></div>
                                            </div>
                                            <div className="spin_points">
                                                <div className="form-group">
                                                    <label>Points Won</label>
                                                    <input type="text" readOnly />
                                                </div>
                                                <div className="form-group good-luck">
                                                    <input type="text" value="Good Luck!" readOnly />
                                                </div>
                                                
                                                <div className="sound">
                                                    <label>reset</label>
                                                    <a href="javascript:void(0);" className="volume on"></a>
                                                </div>
                                            </div>
                                            <div className="spin-footer">
                                                <button className="btn grey1 active">POINTS SPIN <br></br><span>(inactive)</span></button>
                                                <button className="btn white1 inactive">BET <br></br>ONE</button>
                                                <button className="btn white1 inactive">BET <br></br>MAX</button>
                                                <button className="btn white1 inactive">SPIN <br></br>REELS</button>
                                            </div>
                                        </div>
                                        <div className="spinner_list">
                                            <ul className="spin-points reset">
                                                <li className="spin-head">
                                                    <p>POINTS SPIN <br></br><span>GOOD LUCK!</span></p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/powerbucks-sm.png" alt="Powerbucks"/></span>
                                                    <p>10,000</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/pizza-sm.png" alt="pizza"/></span>
                                                    <p>2,500</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/sub-sm.png" alt="sub"/></span>
                                                    <p>1,750</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/burger-sm.png" alt="burger"/></span>
                                                    <p>1,250</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/sub-burger.png" alt="sub-burger"/></span>
                                                    <p>1,250</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/star-sm.png" alt="star"/></span>
                                                    <p>1000</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/star2-sm.png" alt="star"/></span>
                                                    <p>750</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/star1-sm.png" alt="star"/></span>
                                                    <p>500</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/star3-sm.png" alt="star"/></span>
                                                    <p>500</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/cake-sm.png" alt="cake"/></span>
                                                    <p>250</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/cake2.png" alt="cake"/></span>
                                                    <p>125</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/cake1.png" alt="cake"/></span>
                                                    <p>50</p>
                                                </li>
                                                <li>
                                                    <span><img src="public/media/images/sun-sm.png" alt="sun"/></span>
                                                    <p>BONUS</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="full_row powerspin mt20">
                                            <div className="spinner">
                                                <div className="spin_head">
                                                    <img src="public/media/images/cake-xs.png" alt="Cake"/>
                                                    <h4><i className="fa fa-star" aria-hidden="true"></i>Power Spin<i className="fa fa-star" aria-hidden="true"></i></h4>
                                                    <img src="public/media/images/burger.png" alt="Burger"/>
                                                </div>
                                                <div className="spin_body success">
                                                    <div className="spin_reel reel"><div className="each-reel reel1"></div></div>
                                                    <div className="spin_reel reel"><div className="each-reel reel2"></div></div>
                                                    <div className="spin_reel reel"><div className="each-reel reel3"></div></div>
                                                </div>
                                                <div className="spin_points">
                                                    <div className="form-group">
                                                        <label>Winner Paid</label>
                                                        <input type="text" readOnly />
                                                    </div>
                                                    <div className="form-group">
                                                        <label>Credits</label>
                                                        <input type="text" value="200" readOnly />
                                                    </div>
                                                    <div className="form-group coins">
                                                        <label>Coins Played</label>
                                                        <input type="text" value="3" readOnly />
                                                    </div>
                                                    <div className="sound">
                                                        <label>reset</label>
                                                        <a href="javascript:void(0);" className="volume on"></a>
                                                    </div>
                                                </div>
                                                <div className="spin-footer">
                                                    <button className="btn grey1">POINTS SPIN <br></br><span>(inactive)</span></button>
                                                    <button className="btn white1">BET <br></br>ONE</button>
                                                    <button className="btn white1">BET <br></br>MAX</button>
                                                    <button className="btn white1">SPIN <br></br>REELS</button>
                                                </div>
                                            </div>
                                            <div className="spinner_list">
                                                <ul className="spin-points reset hide">
                                                    <li className="spin-head">
                                                        <p>POINTS SPIN <br></br><span>GOOD LUCK!</span></p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/powerbucks-sm.png" alt="Powerbucks"/></span>
                                                        <p>10,000</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/pizza-sm.png" alt="pizza"/></span>
                                                        <p>2,500</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/sub-sm.png" alt="sub"/></span>
                                                        <p>1,750</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/burger-sm.png" alt="burger"/></span>
                                                        <p>1,250</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/sub-burger.png" alt="sub-burger"/></span>
                                                        <p>1,250</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star-sm.png" alt="star"/></span>
                                                        <p>1000</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star2-sm.png" alt="star"/></span>
                                                        <p>750</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star1-sm.png" alt="star"/></span>
                                                        <p>500</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star3-sm.png" alt="star"/></span>
                                                        <p>500</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/cake-sm.png" alt="cake"/></span>
                                                        <p>250</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/cake2.png" alt="cake"/></span>
                                                        <p>125</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/cake1.png" alt="cake"/></span>
                                                        <p>50</p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/sun-sm.png" alt="sun"/></span>
                                                        <p>BONUS</p>
                                                    </li>
                                                </ul>
                                                <ul className="credit-list reset">
                                                    <li className="credit-head">
                                                        <p className="cposition">
                                                            <span className="ful_row">CREDITS</span>
                                                            <span>1st</span>
                                                            <span>2nd</span>
                                                            <span>3rd</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/powerbucks-sm.png" alt="Powerbucks"/></span>
                                                        <p className="cposition">
                                                            <span>5k</span>
                                                            <span>10k</span>
                                                            <span>20k</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/pizza-sm.png" alt="pizza"/></span>
                                                        <p className="cposition">
                                                            <span>100</span>
                                                            <span>200</span>
                                                            <span>300</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/sub-sm.png" alt="sub"/></span>
                                                        <p className="cposition">
                                                            <span>75</span>
                                                            <span>150</span>
                                                            <span>225</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/burger-sm.png" alt="burger"/></span>
                                                        <p className="cposition">
                                                            <span>50</span>
                                                            <span>100</span>
                                                            <span>150</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/sub-burger.png" alt="sub-burger"/></span>
                                                        <p className="cposition">
                                                            <span>50</span>
                                                            <span>100</span>
                                                            <span>150</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star-sm.png" alt="star"/></span>
                                                        <p className="cposition">
                                                            <span>30</span>
                                                            <span>60</span>
                                                            <span>90</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star2-sm.png" alt="star"/></span>
                                                        <p className="cposition">
                                                            <span>30</span>
                                                            <span>60</span>
                                                            <span>90</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star1-sm.png" alt="star"/></span>
                                                        <p className="cposition">
                                                            <span>20</span>
                                                            <span>40</span>
                                                            <span>60</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/star3-sm.png" alt="star"/></span>
                                                        <p className="cposition">
                                                            <span>20</span>
                                                            <span>40</span>
                                                            <span>60</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/cake-sm.png" alt="cake"/></span>
                                                        <p className="cposition">
                                                            <span>10</span>
                                                            <span>20</span>
                                                            <span>30</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/cake2.png" alt="cake"/></span>
                                                        <p className="cposition">
                                                            <span>5</span>
                                                            <span>10</span>
                                                            <span>15</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/cake1.png" alt="cake"/></span>
                                                        <p className="cposition">
                                                            <span>2</span>
                                                            <span>4</span>
                                                            <span>6</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <span><img src="public/media/images/sun-sm.png" alt="sun"/></span>
                                                        <p className="cposition lh26">BONUS</p>
                                                    </li>
                                                </ul>
                                            </div>
                                    </div>
                                    <div className="full_row shared-points custom">
                                        <h5>Shared Points <i className="fa fa-question-circle-o" aria-hidden="true"></i> <span>share my points</span></h5>
                                        <div className="table-responsive">
                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        <th></th>
                                                        <th>Shared By</th>
                                                        <th>Date / Last Status</th>
                                                        <th>Action / Result</th>
                                                        <th>Points</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><div className="stat-icon failed"></div></td>
                                                        <td>great-friend@email.com</td>
                                                        <td>05-15-2018 pending</td>
                                                        <td>
                                                            <span className="accept">accept</span>
                                                            <span className="decline">decline</span>
                                                        </td>
                                                        <td>5000</td>
                                                    </tr>
                                                    <tr>
                                                        <td><div className="stat-icon failed"></div></td>
                                                        <td>me (to: lucky-friend-number-1@em..)</td>
                                                        <td>05-15-2018 pending</td>
                                                        <td><span className="decline">revoke</span></td>
                                                        <td>-5000</td>
                                                    </tr>
                                                    <tr>
                                                        <td><div className="stat-icon warning"></div></td>
                                                        <td>me (to: lucky-friend-number-1@em..)</td>
                                                        <td>05-14-2018 / 11:30 pm</td>
                                                        <td>points revoked</td>
                                                        <td>-5000</td>
                                                    </tr>
                                                    <tr>
                                                        <td><div className="stat-icon"></div></td>
                                                        <td>me (to: gcookman@email.com)</td>
                                                        <td>05-10-2018 / 11:59 am</td>
                                                        <td>points given</td>
                                                        <td>-750</td>
                                                    </tr>
                                                    <tr>
                                                        <td><div className="stat-icon warning"></div></td>
                                                        <td>rejected-friend-numero-uno@email...</td>
                                                        <td>05-10-2018 / 05:58 am</td>
                                                        <td>points declined</td>
                                                        <td>500</td>
                                                    </tr>
                                                    <tr>
                                                        <td><div className="stat-icon"></div></td>
                                                        <td>great-friend-number-2@email.com </td>
                                                        <td>05-07-2018 / 12:22 pm</td>
                                                        <td>points received</td>
                                                        <td>750</td>
                                                    </tr>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    <div className="full_row activity custom">
                                        <h5>Rewards Program Activity</h5>
                                        <div className="table-responsive">
                                            <table className="table">
                                                <thead>
                                                    <tr>
                                                        <th>Description</th>
                                                        <th>Status <i className="fa fa-question-circle-o" aria-hidden="true"></i></th>
                                                        <th>Date/Time</th>
                                                        <th>Points</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>Order 3672392-DEL-DP: Firehouse Subs</td>
                                                        <td>C</td>
                                                        <td>05-15-2018 / 08:55 am</td>
                                                        <td>450</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Order 3123742-DEL-R: Tony’s Pizza & Pasta</td>
                                                        <td>C</td>
                                                        <td>05-11-2018 / 02:45 pm</td>
                                                        <td>1,450</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Power Spin: Flying Cake Winner (2/3)</td>
                                                        <td>C</td>
                                                        <td>05-11-2018 / 02:45 pm</td>
                                                        <td>250</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1st Review Bonus</td>
                                                        <td>C</td>
                                                        <td>05-06-2018 / 12:10 am</td>
                                                        <td>1,000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Review 4365234-PU: Abuelo’s Mexican</td>
                                                        <td>C</td>
                                                        <td>05-06-2018 / 12:10 am</td>
                                                        <td>200</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Order 4365234-PU: Abuelo’s Mexican</td>
                                                        <td>C</td>
                                                        <td>05-05-2018 / 11:00 am</td>
                                                        <td>2,000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Friend Invite Success: Congrats!</td>
                                                        <td>C</td>
                                                        <td>05-03-2018 / 06:30 pm</td>
                                                        <td>2,000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Reward: Dining Power T-Shirt (L)</td>
                                                        <td>C</td>
                                                        <td>05-03-2018 / 07:30 pm</td>
                                                        <td>-500</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1st Order Bonus</td>
                                                        <td>C</td>
                                                        <td>05-01-2018 / 06:58 pm</td>
                                                        <td>500</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Order 2365342-DEL-DP: Siam Sushi</td>
                                                        <td>C</td>
                                                        <td>05-01-2018 / 06:58 pm</td>
                                                        <td>500</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Account Created: Welcome to Dining Power!</td>
                                                        <td>C</td>
                                                        <td>04-22-2018 / 02:11 pm</td>
                                                        <td>100</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <nav aria-label="Page navigation" className="pagination custom">
                                            <ul className="pagination">
                                                <li className="page-item"><a className="page-link hide" href="#">Previous</a></li>
                                                <li className="page-item"><a className="page-link active" href="#">1</a></li>
                                                <li className="page-item"><a className="page-link" href="#">2</a></li>
                                                <li className="page-item"><a className="page-link" href="#">Next</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            
        );
    }
}


module.exports = MyRewardsPage;
