/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../helpers/toaster');
const UploadHelper = require('../../../../helpers/aixos-ajax');


class Actions {
    static getDetails(id) {

        this.getCustomerDeals(id);
        this.getNotes(id);
        this.getCustomerPolicy(id);
        this.getCustomerDocu(id);        
        this.getCustomer(id);        
    }    

    static getCustomer(customer_key)
    {        
        ApiActions.get(
            `/customer/${customer_key}`,
            undefined,
            Store,
            Constants.VIEW_CUSTOMER_DETAILS,
            Constants.VIEW_CUSTOMER_DETAILS_RESPONSE,
        );
    }

    static showDealModal() {
        
        Store.dispatch({
            type: Constants.SHOW_DEAL_CREATE_MODEL
        });
    }

    static hideDealModal() {

        Store.dispatch({
            type: Constants.HIDE_DEAL_CREATE_MODEL
        });
    }

    static uploadFile(data) {

        UploadHelper.upload(
            '/deal-document',
            data,
            Store,
            Constants.SAVE_DEAL_DOCUMENT_RESULTS,
            Constants.SAVE_DEAL_DOCUMENT_RESULTS_RESPONSE
        );
    }    


    static getCustomerDeals(id) {
        
        ApiActions.get(
            `/deal?customer_id=${id}`,
            undefined,
            Store,
            Constants.GET_DEALS_RESULTS,
            Constants.GET_DEALS_RESULTS_RESPONSE
        );
    }

    static getCustomerPolicy(id) {
        
        ApiActions.get(
            `/policy?customer_id=${id}`,
            undefined,
            Store,
            Constants.GET_POLICY_RESULTS,
            Constants.GET_POLICY_RESULTS_RESPONSE
        );
    }

    
    

    static hideDetailsSaveSuccess() {

        Store.dispatch({
            type: Constants.HIDE_DETAILS_SAVE_SUCCESS
        });
    }

    static savePassword(id, data) {

        if (data.password !== data.passwordConfirm) {
            return Store.dispatch({
                type: Constants.SAVE_PASSWORD_RESPONSE,
                err: new Error('password mismatch'),
                response: {
                    message: 'Passwords do not match.'
                }
            });
        }

        delete data.passwordConfirm;

        ApiActions.put(
            `/api/users/${id}/password`,
            data,
            Store,
            Constants.SAVE_PASSWORD,
            Constants.SAVE_PASSWORD_RESPONSE
        );
    }

    static hidePasswordSaveSuccess() {

        Store.dispatch({
            type: Constants.HIDE_PASSWORD_SAVE_SUCCESS
        });
    }

    static delete(id, history) {

        ApiActions.delete(
            `/customer/delete/${id}`,
            undefined,
            Store,
            Constants.DELETE,
            Constants.DELETE_RESPONSE,
            (err, response) => {

                if (!err) {
                    
                    history.push('/admin/customers');

                    window.scrollTo(0, 0);
                }
            }
        );
    }

    static addEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });

    } 

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });

    } 

    static showDeleteModal() {

        Store.dispatch({
            type: Constants.DELETE_MODAL_SHOW
        });

    } 

    static hideDeleteModal() {

        Store.dispatch({
            type: Constants.DELETE_MODAL_HIDE
        });

    } 

    static addNoteModal() {
                
        Store.dispatch({
            type: Constants.ADD_NOTE_MODAL_SHOW
        });
    }

    static hideNoteModal() {

        Store.dispatch({
            type: Constants.ADD_NOTE_MODAL_HIDE
        });
    }

    static getNotes(id) {
        
        ApiActions.get(
            `/deal-note?customer_id=${id}`,
            undefined,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE
        );
    }

    static getCustomerDocu(id) {
        
        ApiActions.get(
            `/deal-document?customer_id=${id}`,
            undefined,
            Store,
            Constants.GET_DOCU_RESULT,
            Constants.GET_DOCU_RESULT_RESPONSE
        );
    } 

    static deleteDocument(id) {
        
        ApiActions.delete(
            `/deal-document/${id}`,
            undefined,
            Store,
            Constants.GET_DOCU_RESULT,
            Constants.GET_DOCU_RESULT_RESPONSE
        );
    }    

    static getPolicy(policy_key)
    {
        ApiActions.get(
            `/policy/${policy_key}`,
            undefined,
            Store,
            Constants.VIEW_POLICY,
            Constants.VIEW_POLICY_RESPONSE
        );
    }

    static hideViewModal() {

        Store.dispatch({
            type: Constants.HIDE_POLICY_MODAL
        });
    }

    static deleteNote(note_key, id) {

        ApiActions.delete(
            `/deal-note/${note_key}`,
            undefined,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.hideNoteModal();
                        this.getNotes(id);
                        Toaster.success('Note Has been deleted..');
                    }
                }
            }
        );
    }

    static createNoteNew(data,id) {

        ApiActions.post(
            '/deal-note',
            data,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.hideNoteModal();
                        this.getNotes(id);
                        Toaster.success('Note Has been created..');
                    }
                }
            }
        );
    }

    static addTaskModal() {

        Store.dispatch({
            type: Constants.ADD_TASK_MODAL_SHOW
        });

    } 

    static hideTaskModal() {

        Store.dispatch({
            type: Constants.ADD_TASK_MODAL_HIDE
        });
    }            

    static resetStore() {

        Store.dispatch({
            type: Constants.RESET_STORE
        });

    } 
}


module.exports = Actions;
