'use strict';
const PropTypes = require('prop-types');
const React = require('react');
const Actions = require('./actions');
const PolicyModal = require('./policy-modal');
import { Button, Modal, ModalHeader, ModalBody } from 'reactstrap';
const Toaster = require('../../../../../../helpers/toaster');
const DateHelper = require('../../../../../../helpers/date-time');

const propTypes = {
    sendQuoteEvent: PropTypes.any    
};
class ProductInfoBox extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            modal: false
        };

        this.publishQoute = this.publishQoute.bind(this);
    }

    saveQuote() {

        Actions.saveQuote({deal_id: this.props.id}, this.props.toggle);
    }

    sendQuote() {
        
        Actions.sendQuote({deal_id: this.props.id}, this.props.toggle);
    }    


    sendQuoteMail(e) {
        e.preventDefault();        
        Actions.sendQuoteMail({
            deal_id: this.props.id,            
        },this.props.toggle);
    }


    publishQoute(deal_quote_key, checked) {                

        /* Toaster.warning('Please wait some time to update'); */
        Actions.updatePublish({
            "deal_quote_id": deal_quote_key,
            "is_publish": checked ? 1 : 0
        });
    }

    getListItem() {        

        const data = this.props.quote_data ? this.props.quote_data : [];

        if (this.props.list_loading) {
            return <div key={`value-option-1`} className="loader-tab-content"></div>
        }
        
        if (data.length === 0) { 
            return null;
        }
        const response = data.map((value, index) => {

            return <li key={`value-option-${index}`}>
                <div className="box">
                    <div className="img"><img src={value.insurence_product_image}/></div>
                    <h5>{value['insurence_product_name']}</h5>
                    <p>Sum Insured: AED {value['vehicle_insured_value']}</p>
                    {/* <p>Quote Reference: {value['quote_reference_number']}</p> */}
                    <p>Quotation Number: {value['quotation_number']}</p>
                    <p className="req">
                        {/* <span> <i className={`fa ${value['is_agency_repair'] ? 'fa-check' : 'fa-times'}`}></i> Agency</span> 
                        <span> <i className={`fa ${value['is_ncd_required'] ? 'fa-check' : 'fa-times'}`}></i> NCD Required</span> */}
                        <span className="choose_plan" onClick={ () => {Actions.openPolicyModal(value.deal_quote_key)} }> Update Plan <i className="fa fa-angle-down"></i> </span>
                    </p>
                    <p className="tags" style={{'display': 'none'}}> <span>Pab Driver</span> <span>Pab Passenger</span> </p>
                    <div className="right-cd">
                        <div className="status">
                            <label className="switch">
                                <input type="checkbox" id="checks" defaultChecked={value.is_publish} onChange={(e) => {this.publishQoute(value.deal_quote_key, e.target.checked)}} /><span className="slider round"></span></label>
                            <label htmlFor="checks">Publish</label>
                        </div>
                        <p>Deductible AED {value['deduction']}</p>
                        <p>Ded.Extra</p>
                        <p>Base Premium</p>
                        <p className="bold">AED {value['premium_value']}</p>
                    </div>
                </div>
            </li>;
        });

        return response;
    }

    render() {        

        return (
            <div className="product-box">
                <ul className="product-listing reset">
                    {this.getListItem()}
                </ul>                
                <div className="text-right mt-3 mb-3">
                    <button className="btn btn-outline-primary loader no-shadow" onClick={ (e) => {this.saveQuote()} }>Save</button>
                    <button data-toggle="modal" onClick={(e) => this.sendQuoteMail(e)} className="btn btn-primary ml-3 loader no-shadow">Save & Send</button>
                </div>  
                <div className="text-center mt-4">
                    <button className="btn btn-outline-success loader no-shadow" onClick={() => {Actions.toggleCreate()}}>Add New Product</button>
                </div>
                <br/><br/>
                <PolicyModal
                    {...this.props}
                />
            </div>
        );
    }
}
module.exports = ProductInfoBox;