<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/react-js-logo.png" alt="ReactJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">One stop solution for React Native App development</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="half_bg red">
  <div class="container relative">
    <div class="col_6 pr30 white">
      <h2 class="head line white style1">Efficient React native dev for Android & iOS</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque tempus ipsum vel sem euismod dapibus. Integer quis sem pellentesque, vestibulum nunc vel, fringilla felis. Curabitur eget enim nec augue molestie pharetra. Nam at risus quis ex interdum ultrices in vel nisl. Pellentesque ex nisl, vulputate at elit ac, sollicitudin feugiat magna. Nulla sed varius tellus. Morbi sit amet mi euismod, condimentum purus ut, pellentesque diam. Aliquam viverra ornare elit, lacinia euismod velit tincidunt in. Etiam consectetur velit non dolor mattis vestibulum.</p>
      <p>Donec eget maximus sem, in vehicula ante. Ut a lacinia tellus. Vivamus faucibus dolor eu felis rutrum, ut suscipit quam euismod. Nullam mollis placerat sem nec fringilla. Ut nisl tortor, venenatis sed mi nec, pretium fermentum risus.</p>
    </div>
    
    <div class="col_6 pl30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="ReactJS Development" width="460" height="450" layout="responsive"></amp-img>
    </div>
  </div> <!--container-->
</section> <!--half_bg-->

<section>
  <div class="container">
    <h2 class="head text-center style1">Benefits of using react native</h2>
    <div class="web_features full_row">
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
        </ul>
      </div>

      <div class="img">
        <amp-img src="<?php echo $baseurl;?>images/react-js-logo.png" alt="ReactJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Lorem ipsum dolor sit</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
        </ul>
      </div>
    </div> <!--web_features-->
  </div> <!--container-->
</section>

<section class="half dark">
	<div class="container">
    <div class="row white">
      <div class="col_6 pr30">
        <h2 class="head line white style1">React Native Services</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style2 mb0">
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
          <li>Lorem ipsum dolor sit amet, consectetur adipiscing</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg1 right"></div>
</section>

<?php include ('inc/footer.php'); ?>