import {fitBounds} from 'google-map-react/utils';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');
const UserIdentity = require('../../../helpers/user-identity');
const DateTimeHelper = require('../../../helpers/date-time');
const moment = require('moment-timezone');
const Config = require('../../../../config.js');

const initialState = {
    loading: false,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    'showSideNav': false,
    'apiKey': {'key': UserIdentity.googleApiKey},
    'center': {
        'lat': 32.593357,
        'lng': -85.495163
    },
    'zoom': 17,
    'mapHeight': 0,
    'mapWidth': 0,
    'markers': [],
    'isOpen' : false,
    isLoaded: false,
    lot: {},
    available: 0,
    occupied: 0,
    noData: 0,
    reserved: 0,
    hybrid_flag : 1,
    lot_name : '',
    lot_id: 0,
    client_name : '',
    unavailable : 1,
    show_message_modal : false,
    show_zone_historical : false,
    show_lot_historical : false,
    zone_percentage_array : [],
    time_limit : null,
    total_duration_mins : 0,
    total_duration_count : 0,
    avg_duration_count : 0,
    lot_message : "",
    lot_message_date : moment().tz(Config.get('/timeZone')).format("MM/DD/YYYY").toString(),
    lot_message_time : moment().tz(Config.get('/timeZone')).format("h:mmA").toString(),
    historical_day : 1,
    historical_date : moment().tz(Config.get('/timeZone')).format("MM/DD/YYYY").toString(),
    overlay_url : "/public/media/images/lots/au-mcwhorter.png",
    overlay_coords_ne : "",
    overlay_coords_sw : "",
    isOverlayLoaded: false,
    show_info_window : false,
    stallMarkerArray : {},
    popupEnabled : true,
    recentInfoWindowClose : false,
    percentage_array : [ 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00 ],
    time_array : [
        '0:30 am',
        '1:00 am',
        '1:30 am',
        '2:00 am',
        '2:30 am',
        '3:00 am',
        '3:30 am',
        '4:00 am',
        '4:30 am',
        '5:00 am',
        '5:30 am',
        '6:00 am',
        '6:30 am',
        '7:00 am',
        '7:30 am',
        '8:00 am',
        '8:30 am',
        '9:00 am',
        '9:30 am',
        '10:00 am',
        '10:30 am',
        '11:00 am',
        '11:30 am',
        '12:00 pm',
        '12:30 pm',
        '1:00 pm',
        '1:30 pm',
        '2:00 pm',
        '2:30 pm',
        '3:00 pm',
        '3:30 pm',
        '4:00 pm',
        '4:30 pm',
        '5:00 pm',
        '5:30 pm',
        '6:00 pm',
        '6:30 pm',
        '7:00 pm',
        '7:30 pm',
        '8:00 pm',
        '8:30 pm',
        '9:00 pm',
        '9:30 pm',
        '10:00 pm',
        '10:30 pm',
        '11:00 pm',
        '11:30 pm',
        '12:00 am'
    ],
    time_permanent_array : [
        '0:30 am',
        '1:00 am',
        '1:30 am',
        '2:00 am',
        '2:30 am',
        '3:00 am',
        '3:30 am',
        '4:00 am',
        '4:30 am',
        '5:00 am',
        '5:30 am',
        '6:00 am',
        '6:30 am',
        '7:00 am',
        '7:30 am',
        '8:00 am',
        '8:30 am',
        '9:00 am',
        '9:30 am',
        '10:00 am',
        '10:30 am',
        '11:00 am',
        '11:30 am',
        '12:00 pm',
        '12:30 pm',
        '1:00 pm',
        '1:30 pm',
        '2:00 pm',
        '2:30 pm',
        '3:00 pm',
        '3:30 pm',
        '4:00 pm',
        '4:30 pm',
        '5:00 pm',
        '5:30 pm',
        '6:00 pm',
        '6:30 pm',
        '7:00 pm',
        '7:30 pm',
        '8:00 pm',
        '8:30 pm',
        '9:00 pm',
        '9:30 pm',
        '10:00 pm',
        '10:30 pm',
        '11:00 pm',
        '11:30 pm',
        '12:00 am'
    ],
    rail_time_array : [
        '00:00',
        '00:30',
        '01:00',
        '01:30',
        '02:00',
        '02:30',
        '03:00',
        '03:30',
        '04:00',
        '04:30',
        '05:00',
        '05:30',
        '06:00',
        '06:30',
        '07:00',
        '07:30',
        '08:00',
        '08:30',
        '09:00',
        '09:30',
        '10:00',
        '10:30',
        '11:00',
        '11:30',
        '12:00',
        '12:30',
        '13:00',
        '13:30',
        '14:00',
        '14:30',
        '15:00',
        '15:30',
        '16:00',
        '16:30',
        '17:00',
        '17:30',
        '18:00',
        '18:30',
        '19:00',
        '19:30',
        '20:00',
        '20:30',
        '21:00',
        '21:30',
        '22:00',
        '22:30',
        '23:00',
        '23:30'
    ],
    download_array : []
};
const reducer = function (state, action) {

    if (action.type === Constants.SAVE_STATUS_HYBRID) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_STATUS_HYBRID_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            unavailable : result.status,
            hybrid_flag : result.hybrid_flag
        });
    }

    if (action.type === Constants.SAVE_STALL) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_STALL_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;
        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        });
    }

    if (action.type === Constants.GET_SUMMARY) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.GET_SUMMARY_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        let lot_name = result.lot_name;
        let hybrid_flag = result.occupancies.hybrid_flag;
        let client_name = result.occupancies.client_name;
        let lot_id = result.occupancies.id;
        let status = result.occupancies.status;
        
        let lots = result.occupancies;
        
        let zone_array = UserIdentity.defaultZones;
        //let zone_array = [ 'a', 'b', 'c', 'pc-1', 'pc-2', 'pc-3', 'pc-4', 'ada', 'temp'];
        let zone_percentage_array = [];
        

        Object.keys(lots.occupancy).map((zone) => {
            zone_array.forEach((selected) => {
                if (selected === zone) {
                    if (zone_percentage_array[zone]) {
                        zone_percentage_array[zone] = {
                            'total' : zone_percentage_array[zone].total + (lots.occupancy[zone][2] - lots.occupancy[zone][3]),
                            'occupied' : zone_percentage_array[zone].occupied + lots.occupancy[zone][1],
                            'remaining' : (zone_percentage_array[zone].total + (lots.occupancy[zone][2] - lots.occupancy[zone][3])) - zone_percentage_array[zone].occupied + lots.occupancy[zone][1],
                        }
                    } else {
                        zone_percentage_array[zone] = {
                            'total' : lots.occupancy[zone][2] - lots.occupancy[zone][3],
                            'occupied' : lots.occupancy[zone][1],
                            'remaining' : (lots.occupancy[zone][2] - lots.occupancy[zone][3]) - (lots.occupancy[zone][1])
                        }
                        
                    }
                    
                }
            });
        });

        if (result.occupancies.entrance_coords !== null) {
            const [neLat, neLng] = result.occupancies.overlay_coords_ne === null ?  result.occupancies.entrance_coords.split(',') : result.occupancies.overlay_coords_ne.split(',');
            const [swLat, swLng] = result.occupancies.overlay_coords_sw === null ?  result.occupancies.entrance_coords.split(',').split(',') : result.occupancies.overlay_coords_sw.split(',');
            const bound = {
                'ne': {
                    'lat': neLat,
                    'lng': neLng
                },
                'sw': {
                    'lat': swLat,
                    'lng': swLng
                }
            };

            const size = {'width': window.innerWidth, 'height': window.innerHeight};
            const {center, zoom} = fitBounds(bound, size);
            return ObjectAssign({}, state, {
                loading: false,
                success: !action.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                mapHeight : window.innerHeight, 
                mapWidth: window.innerWidth,
                hybrid_flag : hybrid_flag,
                lot_name: lot_name,
                client_name: client_name,
                unavailable: status,
                lot: result.occupancies,
                center: (result.occupancies.overlay_coords_ne !== null) ? center : {lat: Number(neLat), lng: Number(neLng)}, 
                zoom: (result.occupancies.overlay_coords_ne !== null) ? zoom : 18,
                zone_percentage_array : zone_percentage_array,
                overlay_coords_ne : result.occupancies.overlay_coords_ne,
                overlay_coords_sw : result.occupancies.overlay_coords_sw,
                overlay_url : result.occupancies.overlay_url,
                lot_id: lot_id
            });
        }  else {
            return ObjectAssign({}, state, {
                loading: false,
                success: !action.err,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help,
                mapHeight : window.innerHeight, 
                mapWidth: window.innerWidth,
                hybrid_flag : hybrid_flag,
                lot_name: lot_name,
                client_name: client_name,
                unavailable: status,
                lot: result.occupancies,
                zone_percentage_array : zone_percentage_array,
                overlay_coords_ne : result.occupancies.overlay_coords_ne,
                overlay_coords_sw : result.occupancies.overlay_coords_sw,
                overlay_url : result.occupancies.overlay_url,
                lot_id: lot_id
            });

        }
        
    }

    if (action.type === Constants.UPDATE_OCCUPANCY) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.UPDATE_OCCUPANCY_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        //let lot_name = result.Lot Name;
        let lot_name;
                    
        const markers = [];
        const disabledZones = [];
        
        var available_state = 0, occupied_state = 0, noData_state = 0, reserved_state = 0;
        for(let zone in localStorage){
            if(localStorage.hasOwnProperty(zone)){
                const zoneValue = localStorage.getItem(zone);
                if(zoneValue === 'false'){
                    disabledZones.push(zone);
                }
            }
        }
        let duration;
        let total_duration_mins = 0;
        let total_duration_count = 0;

        result.lot_status.forEach((stall) => {

            if (stall.occupancy_duration && stall.occupancy_duration !== null && stall.status !== 2) {
                duration = parseInt(Math.ceil(stall.occupancy_duration / 60))
                total_duration_mins += duration;
                total_duration_count++;
            } else {
                duration = '-';
            }

            const [lat, lng] = stall.coords !== null ? stall.coords.split(',') : ["", ""];
            const reserved = stall.reserve_flag;
            let icon;
            icon = 'green.png';

            if (state.unavailable === 1) {
                /*switch(stall.status){
                    case 0:
                        icon = 'green.png';
                        break;
                    case 1:
                        icon = 'red.png';
                        break;
                    default:
                        icon = 'orange.png';
                        break;
                }
                if(stall.zone === 'ada'){
                    icon = 'green-blue.png';
                }

                if(reserved){
                    icon = 'purple.png';
                }
                
                if(stall.display_only === 1 && stall.live_flag !== 1){
                    icon = 'orange.png';
                }
                if (stall.maintenance_flag === 1){
                    icon = 'red.png';
                }*/
                if (reserved){
                    icon = 'purple.png';
                } else if(stall.status === 0 && stall.zone === 'ada'){
                    icon = 'green-blue.png';
                } else if(stall.status === 1 && stall.zone === 'ada'){
                     icon = 'red-blue.png';
                } else if(stall.status === 2 && stall.zone === 'ada'){
                     icon = 'orange-blue.png';
                } else if (stall.status === 1){
                    icon = 'red.png';
                } else if (stall.status === 2){
                    icon = 'orange.png';
                } else if (reserved){
                    icon = 'purple.png';
                } else if(stall.status === 0 && !reserved){
                    icon = 'green.png';
                }
            } else {
                icon = 'orange.png';
            }
            
            if(!disabledZones.includes(`${stall.zone}_selected`)){
                markers.push({
                    stallId: stall.stall_id,
                    eventId: stall.event_id,
                    stallNumber: stall.stall_num,
                    lat: parseFloat(lat),
                    lng: parseFloat(lng),
                    reserved: reserved,
                    status: stall.status,
                    icon: icon,
                    isOpen: false,
                    lot_name : state.lot_name,
                    zone: stall.zone,
                    reserve_flag: stall.reserve_flag,
                    live_flag: stall.live_flag,
                    duration : duration,
                     is_blink : (state.time_limit === '' || state.time_limit === null) ? false : (Number(duration) >= Number(state.time_limit)) ? true : false
                });
                if (reserved){
                    reserved_state += 1;
                } else if(stall.status === 0 && !reserved){
                    available_state += 1;
                } else if (stall.status === 1){
                    occupied_state += 1;
                } else if (stall.status === 2){
                    noData_state += 1;
                } /*else if (reserved){
                    reserved_state += 1;
                }*/
            }
        });
        
        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            markers : markers,
            available: available_state,
            occupied: occupied_state,
            noData: noData_state,
            reserved: reserved_state,
            total_duration_mins : total_duration_mins,
            total_duration_count : total_duration_count,
            avg_duration_count : total_duration_count > 0 ? Math.ceil(parseInt(total_duration_mins / total_duration_count)) : 0
        });
    }

    if (action.type === Constants.SHOW_LOT_MESSAGE) {
        return ObjectAssign({}, state, {
            show_message_modal: true
        });
    }

    if (action.type === Constants.HIDE_LOT_MESSAGE) {
        return ObjectAssign({}, state, {
            show_message_modal: false
        });
    }

    if (action.type === Constants.SHOW_ZONE_HISTORICAL) {
        return ObjectAssign({}, state, {
            show_zone_historical: true
        });
    }

    if (action.type === Constants.HIDE_ZONE_HISTORICAL) {
        return ObjectAssign({}, state, {
            show_zone_historical: false
        });
    }

    if (action.type === Constants.SHOW_LOT_HISTORICAL) {
        return ObjectAssign({}, state, {
            show_lot_historical: true
        });
    }

    if (action.type === Constants.HIDE_LOT_HISTORICAL) {
        return ObjectAssign({}, state, {
            show_lot_historical: false
        });
    }

    if (action.type === Constants.SET_TIME_LIMIT) {
        let markers = []; 

        state.markers.forEach((stall) => {
            markers.push({
                stallId: stall.stallId,
                eventId: stall.eventId,
                stallNumber: stall.stallNumber,
                lat: stall.lat,
                lng: stall.lng,
                reserved: stall.reserved,
                status: stall.status,
                icon: stall.icon,
                isOpen: stall.isOpen,
                lot_name : stall.lot_name,
                zone: stall.zone,
                reserve_flag: stall.reserve_flag,
                live_flag: stall.live_flag,
                duration : stall.duration,
                is_blink : (action.time_limit === null || action.time_limit === '') ? false : (Number(stall.duration) >= Number(action.time_limit)) ? true : false
            });
        });

        return ObjectAssign({}, state, {
            time_limit: action.time_limit,
            markers : markers
        });
    }

    if (action.type === Constants.INIT_TIME_LIMIT) {
        return ObjectAssign({}, state, {
            time_limit: null
        });
    }
    
    if (action.type === Constants.SAVE_MAP_ARRAY) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;


        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            percentage_array : result.percentage ? result.percentage:  state.percentage_array,
            time_array : result.time ? result.time:  state.time_array,
        });
    }

    if (action.type === Constants.SET_HISTORICAL_DATE) {
        return ObjectAssign({}, state, {
            historical_date: moment(action.date, 'DD-MM-YYYY').format('MM/DD/YYYY').toString()
        });
    }

    if (action.type === Constants.SET_HISTORICAL_DAY) {
        return ObjectAssign({}, state, {
            historical_day: parseInt(action.day)
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY_DOWNLOAD) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY_DOWNLOAD_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response.data;

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            download_array : result
        });
    }

    if (action.type === Constants.CREATE_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.CREATE_MESSAGE_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        if (validation) {
        }
        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            show_message_modal: false
        });
    }

    if (action.type === Constants.UPDATE_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.UPDATE_MESSAGE_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            show_message_modal: false
        });
    }

    if (action.type === Constants.GET_LOT_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.GET_LOT_MESSAGE_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        let message = '';
        let expires_by_date = moment().tz(Config.get('/timeZone')).format("MM/DD/YYYY").toString();
        let expires_by_time = moment().tz(Config.get('/timeZone')).format("h:mmA").toString();
        let lot_message_id = 0;

        if (result.lot_messages && result.lot_messages.length > 0) {
            message = result.lot_messages[0].message;
            expires_by_date = DateTimeHelper._getLotMessageDate(result.lot_messages[0].expires_by);
            expires_by_time = DateTimeHelper._getLotMessageTime(result.lot_messages[0].expires_by);
            lot_message_id = result.lot_messages[0].id;
        }

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            lot_message : message,
            lot_message_date : expires_by_date,
            lot_message_time : expires_by_time,
            lot_message_id : lot_message_id
        });
    }

    if (action.type === Constants.GET_OVERLAY_IMAGE) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.GET_OVERLAY_IMAGE_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;
        
        return ObjectAssign({}, state, {
            loading: false,
            overlay_url: result.overlay_url ? result.overlay_url : null,
            isOverlayLoaded : true
        });
    }

    if (action.type === Constants.UPDATE_OVERLAY_LOAD) {
        return ObjectAssign({}, state, {
            isOverlayLoaded : false
        });
    }

    if (action.type === Constants.SHOW_INFO_WINDOW_MODAL) {
        return ObjectAssign({}, state, {
            show_info_window: state.popupEnabled ? true : false,
            stallMarkerArray : action.stallMarkerArray,
            recentInfoWindowClose : false
        });
    }

    if (action.type === Constants.HIDE_INFO_WINDOW_MODAL) {
        return ObjectAssign({}, state, {
            show_info_window: false,
            recentInfoWindowClose : true,
            stallMarkerArray : {}
        });
    }

    if (action.type === Constants.TOGGLE_INFO_WINDOW_MODAL) {
        return ObjectAssign({}, state, {
            show_info_window: !state.show_info_window,
            recentInfoWindowClose : true,
            stallMarkerArray : state.show_info_window ? state.stallMarkerArray : {}
        });
    }

    if (action.type === Constants.TOGGLE_POPUP_ENABLED) {
        return ObjectAssign({}, state, {
            popupEnabled: !state.popupEnabled,
            show_info_window: false
        });
    }

    if (action.type === Constants.RECENT_CLOSE_UPDATE) {
        return ObjectAssign({}, state, {
            recentInfoWindowClose: false
        });
    }

    return state;
};


module.exports = Redux.createStore(reducer, initialState);
