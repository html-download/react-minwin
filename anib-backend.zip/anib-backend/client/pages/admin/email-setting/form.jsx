'use strict';
const Actions = require('./actions');
const Alert = require('../../../components/alert.jsx');
const Button = require('../../../components/form/button.jsx');
const CheckboxControl = require('../../../components/form/checkbox-control.jsx');
const ControlGroup = require('../../../components/form/control-group.jsx');
const React = require('react');
const Spinner = require('../../../components/form/spinner.jsx');
const Store = require('./store');
const SelectControl = require('../../../components/form/select-control.jsx');
const TextControl = require('../../../components/form/text-control.jsx');


class Form extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();       
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.name) {
            this.input.name.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());        
    }    

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();
        
        Actions.saveSMTP({
            smtp_host: this.input.smtp_host.value(),
            smtp_encryption: this.input.smtp_encryption.value(),
            smtp_port: this.input.smtp_port.value(),
            smtp_username: this.input.smtp_username.value(),
            smtp_password: this.input.smtp_password.value()
        });
    }

    render() {

        let alert = [];

        if (this.state.success) {
            alert = <Alert
                type="success"
                message="Success. We have received your message."
            />;
        }
        else if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }

        let formElements;

        if (!this.state.success) {
            
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.smtp_host = c)}
                    isKeyEnable="true"
                    name="smtp_host"
                    label="Smtp Host"
                    hasError={this.state.hasError.smtp_host}
                    help={this.state.help.smtp_host}
                    disabled={this.state.loading}                    
                    defaultValue={this.props.smtp_host}
                />
                <SelectControl
                    ref={(c) => (this.input.smtp_encryption = c)}
                    isKeyEnable="true"
                    name="smtp_encryption"
                    label="Smtp Encryption"
                    defaultValue={this.state.smtp_encryption}
                    hasError={this.state.hasError.smtp_encryption}
                    help={this.state.help.smtp_encryption}
                    disabled={this.state.loading}
                    groupClasses={{'form-group': true, 'form-gp': true}}
                    labelClasses={{'control-label': false, 'side': true}}
                    inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                >   
                    <option value={''}>None</option>
                    <option value={'SSL'}>SSL</option>
                    <option value={'TLS'}>TLS</option>
                </SelectControl>
                <TextControl
                    ref={(c) => (this.input.smtp_port = c)}
                    isKeyEnable="true"
                    name="smtp_port"
                    label="Smtp Port"
                    hasError={this.state.hasError.smtp_port}
                    help={this.state.help.smtp_port}
                    disabled={this.state.loading}
                    defaultValue={this.props.smtp_port}
                />
                <TextControl
                    ref={(c) => (this.input.smtp_username = c)}
                    isKeyEnable="true"
                    name="smtp_username"
                    label="Email Id"
                    hasError={this.state.hasError.smtp_username}
                    help={this.state.help.smtp_username}
                    disabled={this.state.loading}
                    defaultValue={this.props.smtp_username}
                />
                <TextControl
                    ref={(c) => (this.input.smtp_password = c)}
                    isKeyEnable="true"
                    name="smtp_password"
                    label="Phone Number"
                    hasError={this.state.hasError.smtp_password}
                    help={this.state.help.smtp_password}
                    disabled={this.state.loading}
                    defaultValue={this.props.smtp_password}
                />
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'full_row': true, 'text-right': true, 'action-bar': true, 'form-group': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn-outline-primary': true, 'no-shadow': true }}
                        disabled={this.state.loading}
                        onClick={(e) => {this.props.history.push('/admin')}}
                        >
                        Cancel
                    </Button>

                    <Button
                        type="submit"
                        inputClasses={{ 'btn-primary': true, 'no-shadow': true }}
                        disabled={this.state.loading}>

                        <Spinner space="right" show={this.state.loading} />
                        Update
                    </Button>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <form onSubmit={this.handleSubmit.bind(this)}>
                {alert}
                {formElements}
            </form>
        );
    }
}


module.exports = Form;
