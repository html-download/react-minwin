var Shape =
{
    Rect        : 0,
    Rectangle   : 0,
    Square      : 0,

    Circ        : 1,
    Circle      : 1,
    Ellipse     : 1,
    Oval        : 1,

    Poly        : 2,
    Polygon     : 2
};

function HotSpot(shape, coords)
{
    this.Coord          = coords;
    this.Enabled        = false;
    this.IsCapturing    = false;
    this.IsHovering     = false;
    this.Shape          = shape;

    this.Click          = function(a, c, s) { };
    this.DoubleClick    = function(a, c, s) { };
    this.Down           = function(a, c, s) { };
    this.Hover          = function(a, c, s) { };
    this.Leave          = function(a, c, s) { };
    this.Up             = function(a, c, s) { };

    this.Disable        = function( ) { this.Enabled = false; };
    this.Enable         = function( ) { this.Enabled = true;  };
    this.EnableIf       = function(c) { this.Enabled = c;     };

    switch (this.Shape)
    {
        case Shape.Rectangle:
        {
            this.Contains = function(x, y)
            {
                return (x >= this.Coord[0]) && (x <= this.Coord[2]) && (y >= this.Coord[1]) && (y <= this.Coord[3]);
            };

            break;
        }

        case Shape.Ellipse:
        {
            this.cx = (this.Coord[0] + this.Coord[2]) >> 1;
            this.cy = (this.Coord[1] + this.Coord[3]) >> 1;
            this.rx = (this.Coord[2] - this.Coord[0]) >> 1;
            this.ry = (this.Coord[3] - this.Coord[1]) >> 1;

            this.Contains = function(x, y)
            {
                var dx = x - this.cx;
                var dy = y - this.cy;

                return ((((dx * dx) / (this.rx * this.rx)) + ((dy * dy) / (this.ry * this.ry))) <= 1);
            };

            break;
        }

        case Shape.Polygon:
        {
            this.Points = this.Coord.length >> 1;

            if (this.Points < 3)
            {
                this.Contains = function(x, y)
                {
                    return false;
                };
            }
            else
            {
                this.Contains = function(x, y)
                {
                    var inside = false;
                    var newX, oldX, x1, x2;
                    var newY, oldY, y1, y2;

                    oldX = this.Coord[this.Coord.length - 2];
                    oldY = this.Coord[this.Coord.length - 1];

                    for (var p = 0; p < this.Points; p++)
                    {
                        newX = this.Coord[(p << 1) + 0];
                        newY = this.Coord[(p << 1) + 1];

                        if (newX > oldX)
                        {
                            x1 = oldX; x2 = newX; y1 = oldY; y2 = newY;
                        }
                        else
                        {
                            x1 = newX; x2 = oldX; y1 = newY; y2 = oldY;
                        }

                        if (((newX < x) == (x <= oldX)) && (((y - y1) * (x2 - x1)) < ((y2 - y1) * (x - x1))))
                        {
                            inside = !inside;
                        }

                        oldX = newX;
                        oldY = newY;
                    }

                    return inside;
                };
            }

            break;
        }
    }
}
