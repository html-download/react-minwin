/**
 *
 */
function bindFileInputField() {
    $('.files-name').change(function () {

        var file = $(this).get(0).files[0];

        if (file !== undefined) {
            file = file.name;
        } else {
            file = '<i class="fa fa-upload" aria-hidden="true"></i> Choose File';
        }

        $(this).prev('label').html(file);
    });
}

/**
 *
 */
function bindSelectField() {
    $('.selectpicker').selectpicker();
}

runOnLoad(function () {
    $('.date-picker').datepicker({
        autoclose: true,
        format: 'd/m/yyyy'
    });

});


