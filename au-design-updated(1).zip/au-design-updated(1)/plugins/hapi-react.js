'use strict'

const register = (server, options, next) => {
    server.register([{
        register: require('visionary'),
        options: {
            engines: { jsx: 'hapi-react-views' },
            compileOptions: {
                removeCacheRegExp: '.jsx'
            },
            relativeTo: __dirname,
            path: '../server/web'
        }
    }])
    next();
}

register.attributes = {
    name: 'React View'
}

module.exports = register