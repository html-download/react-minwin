'use strict';
const Alert = require('../../../../../../components/alert');
const Button = require('../../../../../../components/form/button.jsx');
const CommonStore = require('../../../../common-store/store');
const Spinner = require('../../../../../../components/form/spinner.jsx');
const Actions = require('./actions');
const React = require('react');
const ReactSelectControl = require('../../../../../../components/form/react-select-control.jsx');
const CommonHelper = require('../../../../../../helpers/common-functions');
const PropTypes = require('prop-types');
const Store = require('./store');

const propTypes = {
    info_data: PropTypes.any,
    id: PropTypes.any
};


class ProductInfoForm extends React.Component {
    
    constructor(props) {

        super(props);
        this.input = {};

        this.handleSubmit = this.handleSubmit.bind(this);
        this.checkApiStatus = this.checkApiStatus.bind(this);
        this.unCheckProductElement = this.unCheckProductElement.bind(this);
        this.changeBrandModel = this.changeBrandModel.bind(this);
        this.state = {
            insurence_product_ids: ''
        };
        this.productref = [];
        this.vehicle_brand_model = [];
        this.vehicle_brand_trim = [];

        Actions.getProduct({deal_key:this.props.id});
    }
    
    componentDidMount() {

        
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    checkApiStatus(insurence_product_ids, element) {
        
        this.setState({
            insurence_product_ids: insurence_product_ids
        });

        Actions.checkApiStatus(this.props.id, insurence_product_ids, this.unCheckProductElement, element.target);
    }

    handleSubmit(event) {
        
        const products = [];
        this.productref.map((element, index) => {
            
            if (element.checked) {
                let productModel = this.vehicle_brand_model[index] ? this.vehicle_brand_model[index].value : '';
                let productTrim = this.vehicle_brand_trim[index] ? this.vehicle_brand_trim[index].value : '';
                products.push({
                    underwriter_key: element.value,
                    trim_key: productTrim,
                    model_key: productModel
                });
            }
        });
        const id = this.props.id;
        const data = {
            deal_id : id,
            insurence_product: products
            /*
            quote_reference_number : this.input.quote_reference_number.value,
            vehicle_insured_value : this.input.vehicle_insured_value.value,
            premium_value : this.input.premium_value.value,
            deduction : this.input.deduction.value,
            extra_deduction : this.input.extra_deduction.value,
            is_agency_repair : this.input.is_agency_repair.checked ? 1 : 0,
            is_ncd_required : this.input.is_ncd_required.checked ? 1 : 0
            */
        };
        
        Actions.saveQuoteDetails(data, this.props.loadDeal);
    }

    unCheckProductElement(element) {

        element.checked = false;
    }

    checkProduct(ths) {

        /* if (ths.target.checked) {
            this.checkApiStatus(ths.target.value, ths);
        } */
    }

    changeBrandModel(underwriter_key, refElement) {

        /* console.log(refElement);
        console.log(refElement.selectedIndex);
        console.log(refElement.options[refElement.selectedIndex].getAttribute('remote_id'));
        console.log(refElement.getAttribute('class')); */
        let remote_id = refElement.options[refElement.selectedIndex].getAttribute('remote_id');        
        let data = {
            vehicle_brand_model_id: refElement.value,
            brand_model_remote_id: remote_id,
            //deal_key: this.props.id,
            underwriter_key: underwriter_key,
        };
       
        Actions.getModelTrim(data);
    }

    render() {

        const alerts = [];        
        if (this.props.info_data.error) {
            alerts.push(<Alert
                key="danger"
                type="danger"
                message={this.props.info_data.error}
            />);
        }        
        const insurence_product_id2 = (this.state.product_data && this.state.product_data.length > 0) ? this.state.product_data : [];

        return (
            <div>
                <div className="row">
                    <div className="col-md-12">
                        {alerts}
                    </div>
                                         
                    <div className="col-md-12">
                        <div className="first-box">                            
                            <ul className="quote-check split-view">
                                {
                                    
                                    (this.state.product_data_loading === false) ?
                                    insurence_product_id2.map((value, index) => {

                                        return (
                                            <li key={value.underwriter_key}>
                                               
                                                    <div className="form-group">
                                                        <input className="checkbox" id={value.underwriter_key} name="dat" value={value.underwriter_key} type="checkbox" onChange={this.checkProduct.bind(this)} ref={(input) => {this.productref[index] = input; }}/>
                                                        <label className="checkbox" htmlFor={value.underwriter_key}>{value.underwriter_name}</label>
                                                    </div>
                                                
                                                <div>
                                                    {                                                    
                                                        (value.vehicle_brand_model.length > 0) ? 
                                                        <div className="form-group">
                                                            <select className="form-control" ref={(input) => {this.vehicle_brand_model[index] = input; }} onChange={ (e) => {this.changeBrandModel(value.underwriter_key, this.vehicle_brand_model[index])} }>
                                                                {
                                                                    value.vehicle_brand_model.map((model, i) => {
                                                                        return (<option value={model.vehicle_brand_model_key} remote_id={model.remote_id}>{model.vehicle_brand_model_name}</option>);
                                                                    })
                                                                }
                                                            </select>
                                                        </div> : ''
                                                    }
                                                </div>
                                                <div class="col-md-12">
                                                    {
                                                        (value.vehicle_brand_trim.length > 0) ?
                                                        <div className="form-group">
                                                            <select className="form-control" ref={(input) => {this.vehicle_brand_trim[index] = input; }}>
                                                                {
                                                                    value.vehicle_brand_trim.map((trim, i) => {
                                                                        return (<option value={trim.vehicle_brand_model_trim_key}>{trim.vehicle_brand_model_trim_name}</option>);
                                                                    })
                                                                }
                                                            </select>
                                                        </div> : ''  
                                                    }
                                                </div>
                                            </li>
                                        );
                                    }) : (
                                        <li>
                                            <div className="form-group">
                                                Loading...
                                            </div>
                                        </li>
                                    )
                                    
                                }

                            </ul>
                        </div>
                        {/* <ReactSelectControl
                            ref={(c) => (this.input.insurence_product_id2 = c)}
                            name="product"
                            label="Product"
                            value={""}
                            onChange={(e) => {this.checkApiStatus(e)}}
                            disabled={this.props.loading}
                            groupClasses={{'rq': true}}
                            inputClasses={{'select-modal': true}}
                            labelClasses={{'left-side': true, 'control-label': false}}
                            options={CommonHelper.getOptionData(insurence_product_id2, 'underwriter_key', 'underwriter_name', 'Please Select Product')}
                            isMulti={true}
                        />
                        <div className="form-group">
                            <label>Product</label>
                            <select className="form-control" onChange={ this.checkApiStatus }  ref={(c) => (this.input.insurence_product_id = c)} disabled={this.props.loading}>
                                <option value="">Please select</option>
                                {this.getProductOptions()}
                            </select>
                        </div>
                        */}
                    </div>
                    {/* <div className="col-md-4">
                        <div className="form-group">
                            <label>Quote Reference</label>
                            <input type="text" className="form-control" ref={(c) => (this.input.quote_reference_number = c)} disabled={this.props.loading} value={`ANIB${Math.floor(100000 + Math.random() * 900000)}`}/>
                        </div>
                    </div>

                    <div className="col-md-4">
                        <div className="form-group">
                            <label>Sum Insured</label>
                            <input type="text" className="form-control" readOnly={(this.props.deal_data) ? true : false } defaultValue={ (this.props.deal_data) ? this.props.deal_data.vehicle_insured_value : '' } ref={(c) => (this.input.vehicle_insured_value = c)} disabled={this.props.loading}  />
                        </div>
                    </div> */}
                    
                </div>

                {/* <div className="row">
                    <div className="col-md-4">
                        <div className="form-group">
                            <label>Base Premium incl 5% VAT</label>
                            <input type="text" className="form-control" ref={(c) => (this.input.premium_value = c)} disabled={this.props.loading}/>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="form-group">
                            <label>Deductible</label>
                            <input type="text" className="form-control" ref={(c) => (this.input.deduction = c)} disabled={this.props.loading}/>
                        </div>
                    </div>

                    <div className="col-md-4">
                        <div className="form-group">
                            <label>Ded.Extra</label>
                            <input type="text" className="form-control" ref={(c) => (this.input.extra_deduction = c)} disabled={this.props.loading} />
                        </div>
                    </div>
                </div>
                <div className="row mt-2 mb-2">
                    <div className="col-md-4">
                        <div className="form-group">
                            <input className="checkbox" id="agency" name="agency" type="checkbox" ref={(c) => (this.input.is_agency_repair = c)} disabled={this.props.loading}/>
                            <label className="checkbox" htmlFor="agency">Agency Repair</label>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="form-group">
                            <input className="checkbox" id="ncd" name="ncd" type="checkbox" ref={(c) => (this.input.is_ncd_required = c)} disabled={this.props.loading}/>
                            <label className="checkbox" htmlFor="ncd">NCD Required</label>
                        </div>
                    </div>
                    <div className="col-md-4">
                    </div>
                </div> */}

                <div className="text-right mt-3 form-group">
                    <Button
                        type="submit"
                        inputClasses={{ 'btn': true, 'btn-success': true, 'no-shadow': true }}
                        disabled={this.props.loading}
                        onClick={(e) => {this.handleSubmit()}}>

                        <Spinner space="right" show={this.props.loading} />
                        Submit 
                    </Button>
                </div>
            </div>
        );
    }
}

module.exports = ProductInfoForm;