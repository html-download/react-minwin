<?php
	$logo = 'images/logo.png';

	$email = 'sales@ontabee.com';
	$partner_mail = 'partner@ontabee.com';
	$mobile = '+91 73958 06006';
	$whatsapp = '+917395806006';
	$skype = 'live:sales_75654';
	$address = 'JV Building, Maruthamalai Main Road,<br>Mullai Nagar, Vadavalli, <br>Coimbatore - 641041,  <br>Tamil Nadu, India.';

	$facebook = 'https://www.facebook.com/Ontabee-149066152475073/';
	$twitter = 'https://twitter.com/ontabee';
	$linkedin = 'https://www.linkedin.com/company/ontabee/';
	
	$price = '69';
	$setupprice = '299';
?>

<?php
	/*SEO*/ 

	$url = explode('/',$_SERVER['REDIRECT_URL']);
	if($url[1] == ''){
		$title = 'Free online food ordering & delivery system, software for restaurant';
		$description = 'Get free online food ordering & delivery system with software for your restaurant business. We deliver both the web & mobile for customer and delivery boy. Try Ontabee for free.';
		$keywords = 'restaurant ordering system, food ordering system, restaurant ordering software, food ordering software, restaurant delivery system, food delivery system, restaurant delivery software, food delivery software, online ordering system';
		$style =[];
		$style[]= 'style.css';
		$style[]= 'home.min.css';
		$img =[];
		$img[]= 'images/food-ordering-system.png';

	}
	if($url[1] == 'about-us'){		
		$title = 'About Ontabee -  Restaurant online food ordering system';
		$description = "Read information about Ontabee's the benefits & value of the product and services provided by the company. Learn about why we're committed to helping restaurant business owners with our online food ordering system.";
		$keywords = 'Restaurant ordering system, Restaurant delivery system, Restaurant ordering software, Restaurant delivery software, Online food ordering software, Online food ordering system';
		$img =[];
		$img[]= 'images/rajesh.png';
		$img[]= 'images/ramesh.png';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'about.min.css';
	}
	if($url[1] == 'chownow-alternative'){
		$title = 'ChowNow Alternative, Clone | Similar to ChowNow ';
		$description = 'Looking for ChowNow alternative? Ontabee provides free online restaurant ordering system for your restaurant. Get online ordering system similar to ChowNow.';
		$keywords = 'ChowNow alternative, ChowNow clone, similar to ChowNow';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'contact'){
		$title = 'Contact us for online ordering system for your restaurant';
		$description = 'Get in touch with us for perfect online ordering system for your single or multiple restaurants. Our Ontabee suits well for your any online ordering and delivery business. For instant support WhatsApp at +91 90039 60003';
		$keywords = 'online ordering system for restaurants, ordering online system, online food ordering system, online restaurant ordering system ';
		$style[]= 'style.min.css';
		$style[]= 'contact.min.css';
		$style[]= 'product-pages.min.css';
	}
	if($url[1] == 'facebook-ordering'){
		$title = 'Online Facebook ordering app for restaurant | Ontabee';
		$description = 'Ontabee lets you integrate Facebook ordering app for online restaurants ordering business. Creating a direct path through Facebook to online ordering website. ';
		$keywords = 'facebook ordering system for restaurant, facebook ordering app for restaurant';
		$img =[];
		$img[] = 'images/facebook-ordering.png';
		$img[] = 'images/forbes-logo.png';
		$img[] = 'images/facebook-menu.png';
		$img[] = 'images/facebook-order.png';
		$img[] = 'images/facebook-notification.png';
		$img[] = 'images/facebook-promote.png';
	}
	if($url[1] == 'faq'){
		$title = 'Frequently asked questions about Our product, service & support - Ontabee';
		$description = 'Want to know the customer frequently asked questions about our product features, pricing, and other clarifications?.';
		$keywords = 'FAQ about Food ordering system, FAQ online ordering system.';
	}
	if($url[1] == 'features'){
		$title = 'Features of Free restaurant order management system - Ontabee';
		$description = 'Ontabee provides full featured online restaurant order management system. Get modernize your online ordering system with your own mobile app. Get all the features for just $'.$price.' now!';
		$keywords = 'restaurant order management system, free restaurant order management, free order management system';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
	}
	if($url[1] == 'food-delivery-app'){
		$title = 'Food delivery tracking app demo Android, iOS for delivery boy';
		$description = 'Food delivery app demo Android, iOS for delivery boy to receive an order instantly. Delivery tracking app in real time so that customer track the delivery boy live location';
		$keywords = 'food delivery app, food delivery tracking app, food delivery android app, food delivery iPhone app';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/delivery-app.png';
		$img[] = 'images/delivery-app1.png';
		$img[] = 'images/da-screen1.jpg';
		$img[] = 'images/da-screen2.jpg';
		$img[] = 'images/da-screen3.jpg';
		$img[] = 'images/da-screen4.jpg';
		$img[] = 'images/da-screen5.jpg';
		$img[] = 'images/da-screen6.jpg';
		$img[] = 'images/da-screen7.jpg';
		$img[] = 'images/da-screen8.jpg';
	}
	if($url[1] == 'food-ordering-app-for-restaurants'){
		$title = 'Food ordering app demo Android, iOS for customer';
		$description = 'Food ordering app demo Android, iOS for customer front end to place an order and attract your customer. Get the live demo app on corresponding app store';
		$keywords = 'food ordering app, food ordering android app, food ordering iPhone app';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/mobile-app-ordering.png';
		$img[] = 'images/mobile-app.png';
		$img[] = 'images/mobile-app1.png';
		$img[] = 'images/screen1.jpg';
		$img[] = 'images/screen2.jpg';
		$img[] = 'images/screen3.jpg';
		$img[] = 'images/screen4.jpg';
		$img[] = 'images/screen5.jpg';
		$img[] = 'images/screen6.jpg';
		$img[] = 'images/screen7.jpg';
		$img[] = 'images/screen8.jpg';
		$img[] = 'images/screen9.jpg';
		$img[] = 'images/screen10.jpg';
		$img[] = 'images/screen11.jpg';
		$img[] = 'images/screen12.jpg';
		$img[] = 'images/screen13.jpg';
		$img[] = 'images/screen14.jpg';
		$img[] = 'images/screen15.jpg';
		$img[] = 'images/screen16.jpg';
		$img[] = 'images/screen17.jpg';
		$img[] = 'images/screen18.jpg';
		$img[] = 'images/screen19.jpg';
	}
	if($url[1] == 'food-ordering-software-admin-dashboard'){
		$title = 'Online Food ordering software admin dashboard for restaurant business';
		$description = 'We provide Admin dashboard to manage everything in one place at anytime anywhere.';
		$keywords = 'food ordering software, online food ordering software';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/admin-dashboard.png';
		$img[] = 'images/setting.png';
		$img[] = 'images/access-control.png';
		$img[] = 'images/master.png';
		$img[] = 'images/items.png';
		$img[] = 'images/customer.png';		
		$img[] = 'images/orders.png';		
		$img[] = 'images/delivery-boy.png';
	}
	if($url[1] == 'food-order-receiving-app'){
		$title = 'Food order receiving  demo Android app for restaurant';
		$description = 'Food order receiving Android demo app for the restaurant to get an instant order notification so that you accept or decline the order immediately.';
		$keywords = 'food order receiving app, restaurant order receiving app';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/order-receiving-app.png';
		$img[] = 'images/food-order-receiving-app.png';
		$img[] = 'images/screen1.jpg';
		$img[] = 'images/da-screen2.jpg';
		$img[] = 'images/va_screen1.jpg';
		$img[] = 'images/va_screen2.jpg';
		$img[] = 'images/va_screen3.jpg';
		$img[] = 'images/va_screen4.jpg';
		$img[] = 'images/va_screen5.jpg';
		$img[] = 'images/va_screen6.jpg';
	}
	if($url[1] == 'gloriafood-alternative'){
		$title = 'GloriaFood Alternative, Clone | Similar to GloriaFood';
		$description = 'Looking for GloriaFood alternative? Ontabee provides free online restaurant ordering system for your restaurant. Get online ordering system similar to GloriaFood. ';
		$keywords = 'GloriaFood alternative, GloriaFood clone, similar to GloriaFood ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'menudrive-alternative'){
		$title = 'MenuDrive Alternative, Clone | Similar to MenuDrive';
		$description = 'Looking for MenuDrive alternative? Ontabee provides free online restaurant ordering system for your restaurant. Get online ordering system similar to MenuDrive.';
		$keywords = 'MenuDrive alternative, MenuDrive clone, similar to MenuDrive  ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'imenu360-alternative'){
		$title = 'iMenu360 Alternative, Clone | Similar to iMenu360';
		$description = 'Looking for iMenu360 alternative? Ontabee provides free online food ordering system for your restaurant. Get online ordering system similar to iMenu360. ';
		$keywords = 'iMenu360 alternative, iMenu360 clone, similar to iMenu360 ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'menu-ca-alternative'){
		$title = 'Menu.ca Alternative, Clone | Similar to Menu.ca';
		$description = 'Looking for Menu.ca alternative? Get online ordering system similar to Menu.ca. ';
		$keywords = 'Menu.ca alternative, Menu.ca clone, similar to Menu.ca ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'oddle-alternative'){
		$title = 'Oddle Alternative, Clone | Similar to Menu.ca';
		$description = 'Looking for Oddle alternative? Get online ordering system similar to Oddle. ';
		$keywords = 'Oddle alternative, Oddle clone, similar to Oddle ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'mobi2go-alternative'){
		$title = 'Mobi2go Alternative, Clone | Similar to Mobi2go';
		$description = 'Looking for Mobi2go alternative? Get online ordering system similar to Mobi2go ';
		$keywords = 'Mobi2go alternative, Mobi2go clone, similar to Mobi2go ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}
	if($url[1] == 'olo-alternative'){
		$title = 'Olo Alternative, Clone | Similar to Olo';
		$description = 'Looking for Olo alternative? Get online ordering system similar to Olo ';
		$keywords = 'Olo alternative, Olo clone, similar to Olo ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}	
	if($url[1] == 'limetray-alternative'){
		$title = 'Limetray Alternative, Clone | Similar to Limetray';
		$description = 'Looking for Limetray alternative? Get online ordering system similar to Limetray ';
		$keywords = 'Limetray alternative, Limetray clone, similar to Limetray ';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/dashboard.png';
		$img[] = 'images/graph.png';
	}		
	if($url[1] == 'online-ordering-system-for-restaurants'){
		$title = 'Online ordering system for restaurants - Ontabee';
		$description = 'Online ordering system for restaurants on the website to enhance your business in your own brand name and logo';
		$keywords = 'Online ordering system for restaurants, Online ordering system, Online website ordering for food';
		$img =[];
		$img[] = 'images/website-ordering.png';
		$img[] = 'images/online-ordering.png';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
	}
	if($url[1] == 'table-reservation-system'){
		$title = 'Online table reservation, booking system for small and large restaurants';
		$description = 'Online table reservation and booking software system for restaurants. It is simple to use, save your time and used to earn more money.';
		$keywords = 'Online table reservation system for restaurants, Online table booking system';
		$img =[];
		$img[] = 'images/website-ordering.png';
		
	}
	if($url[1] == 'pricing'){
		$title = 'Online ordering & delivery system pricing for restaurant - Ontabee';
		$description = 'Check out our Ontabee, an online restaurant ordering system pricing plan. Now you can start your online ordering business even for free. Try our premium version to use unlimited features.';
		$keywords = 'online ordering system, online ordering system for restaurant, online food ordering system';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'pricing.min.css';
		$style[]= 'product-pages.min.css';
	}
	if($url[1] == 'privacy-policy'){
		$title = 'Ontabee - Privacy &amp; Policy';
		$description = 'Ontabee privacy policy explains our policy regarding all general information, security &amp; compliance with laws, and amendments. Check out our privacy policy to know more.';
		$keywords = 'Privacy  Policy';
	}
	if($url[1] == 'restaurant-ordering-software-dashboard'){
		$title = 'Online restaurant ordering software dashboard for each restaurant';
		$description = 'Get the Restaurant dashboard to manage all your orders and deliveries only.';
		$keywords = 'restaurant ordering software, online restaurant ordering software';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
		$img =[];
		$img[] = 'images/restaurant-dashboard.png';
		$img[] = 'images/restaurant-orders.png';
		$img[] = 'images/restaurant-delivery-boy.png';
		$img[] = 'images/restaurant-reports.png';
	}
	if($url[1] == 'signup'){
		$title = 'Try Ontabee - Free online restaurant ordering system ';
		$description = 'Try Ontabee for free a perfect online restaurant ordering system for your restaurant business. You can upgrade to premium version to get access to unlimited features.';
		$keywords = 'Ontabee for free, free online ordering system, free restaurant ordering system, free ordering system for restaurant';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'signup.min.css';
	}
	if($url[1] == 'terms-and-conditions'){
		$title = 'Ontabee - Terms &amp; conditions';
		$description = 'Read the complete terms and conditions of Ontabee before you subscribe for the monthly plan. For more details, you can contact us.';
		$keywords = 'terms and conditions';
	}
	if($url[1] == 'tools-and-technology'){
		$title = 'Check our latest tools & technology used for our product';
		$description = 'Have a look at our latest technologies which we used for our development than our competitors. Also, we do the auto-deployment for server deployment.';
		$keywords = 'food ordering development technology, food ordering open source';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'tools-technology.min.css';
	}
	if($url[1] == 'restaurant-management-system-for-chef'){
		$title = 'Restaurant Management System & Software for Professional Chef - Ontabee';
		$description = "Ontabee provides a complete solution for online ordering software of your restaurant's, fast and reliable platform that system does it all from taking order to delivery updates.";
		$keywords = 'Restaurant Management System for Professional Chef, Restaurant Management System';
		$img =[];
		$img[] = 'images/mobile-app1.png';
	}
	if($url[1] == 'knowledge-base'){
		$title = 'Knowledge base for backend setting over view - Ontabee';
		$description = "Get to know the Ontabee's backend work flow and modification for frontend from backend.";
		$keywords = 'knowledge-base';
	}
	if($url[1] == 'demo'){
		$title = 'Ontabee demo for frontend and backend';
		$description = "Get the demo details of frontend and backend with login details.";
		$keywords = 'Ontabee demo';
	}
	if($url[1] == 'ordering-co-alternative'){
		$title = 'Ordering.Co alternative, clone | Ordering.Co Vs Ontabee';
		$description = "Looking for Ordering.Co alternative? Compare the features and pricing between Ontabee and Ordering.Co, And choose to buy the software.";
		$keywords = 'Ordering.Co alternative';
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
	}
	if($url[1] == 'portfolio'){
		$title = 'Food ordering system project portfolios - Ontabee&#39;s Customers';
		$description = "Find our customers those who are using Ontabee and running the restaurant business successfully.";
		$keywords = 'portfolio';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'portfolio.min.css';
	}
	if($url[1] == 'integration'){
		$title = 'Integrated third-party service providers in Ontabee';
		$description = "We have integrated many third-party service providers in Ontabee. Admin can manage it from their backend itself to use those services.";
		$keywords = 'Ontabee integrations, SMS gateway Integration, Payment gateway Integration';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'portfolio.min.css';
	}
	if($url[1] == 'restaurant-self-ordering-kiosk-system'){
		$title = 'Restaurant self-ordering kiosk system, software';
		$description = "Get restaurant self-ordering kiosk system for ordering the menu in front of the restaurant using the touch screen to manage the crowd. Free Sign up for the live demo today.";
		$keywords = 'Restaurant self-ordering kiosk system';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'product-pages.min.css';
	}
	if($url[1] == 'case-studies'){
		$title = 'Case Study | Online Food Ordering System - Ontabee';
		$description = 'Find out the problem which occur in theri existing restaurant bsiness and providing solution to overcome those problem and to know how effective Ontabee is satisfying cilent requirements.';
		$keywords = 'Food Delivery System Case Study, Online Ordering Software Case Study, Ontabee Case Studies.';
		$style =[];
		$style[]= 'style.min.css';
		$style[]= 'case-study.min.css';
	}
	if($url[1] == 'case-study' && isset($url[2]) && $url[2]=='shuneezfsc'){
		$title = 'Case Study | Shuneezfsc Online food ordering & Delivery Software - Ontabee';
		$description = 'Shuneezfsc app is the food delivery application, where the customer can easily keep track of the delivery boy and achieves their targeted buisness level in an enhanced manner.';
		$keywords = 'Online Food Ordering Software, Online Food Delivery Software, Food Ordering System, Food Delivery System.';
		$style[]= 'style.min.css';
		$style[]= 'case-study.min.css';
	}
	if($url[1] == 'case-study' && isset($url[2]) && $url[2]=='hungrybunny'){
		$title = 'Case Study | Hungry Bunny Online Restaurant Ordering System - Ontabee';
		$description = 'Hungry Bunny is the perfect online food ordering system for restaurant business with increasing sales and improve revenue level which supports both mobile & web platform.';
		$keywords = 'Online Restaurant Ordering System, Online Restaurant Ordering Software, Online Food Ordering Software, Online Food Delivery Software.';
		$style[]= 'style.min.css';
		$style[]= 'case-study.min.css';
	}
?>