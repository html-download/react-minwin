'use strict';
const Async = require('async');
const Bcrypt = require('bcrypt');
const Boom = require('boom');
const Config = require('../../config');
const Joi = require('joi');
const models = require('../models');
const Uuid = require('uuid');
const DateTimeHelper = require('../../client/helpers/date-time');

const internals = {};


internals.applyRoutes = function (server, next) {
    const User = models.models.ss16Customer;
    /*const AuthAttempt = server.plugins['hapi-mongo-models'].AuthAttempt;
    const Session = server.plugins['hapi-mongo-models'].Session;
    const User = server.plugins['hapi-mongo-models'].User;*/


    server.route({
        method: 'POST',
        path: '/login',
        config: {
            validate: {
                payload: {
                    username: Joi.string().lowercase().required().label('Email'),
                    password: Joi.string().required(),
                    remember: Joi.string().allow('').optional()
                }
            },
            pre: [/*{
                assign: 'abuseDetected',
                method: function (request, reply) {

                    const ip = request.info.remoteAddress;
                    const username = request.payload.username;

                    AuthAttempt.abuseDetected(ip, username, (err, detected) => {

                        if (err) {
                            return reply(err);
                        }

                        if (detected) {
                            return reply(Boom.badRequest('Maximum number of auth attempts reached. Please try again later.'));
                        }

                        reply();
                    });
                }
            }, */{
                assign: 'user',
                method: function (request, reply) {

                    const username = request.payload.username;
                    const password = request.payload.password;

                    Async.auto({
                        
                        user: function (done) {

                            const query = {
                                customerStatus: 'Active'
                            };

                            if (username.indexOf('@') > -1) {
                                query.customer_email = username.toLowerCase();
                            }
                            else {
                                query.customer_email = username.toLowerCase();
                            }
                            User.findOne({ where: query, raw: true }).then(function(user){
                                if (!user) {
                                    return reply(Boom.badRequest('Incorrect email'));
                                }
                                if (user == null) {
                                    done(null, true);
                                }
                                done(null, user);
                                //done(null,user.toJSON());
                            });
                            /*let user = User.findOne(query, done);
                            done(null,user.toJSON());*/
                            /*const conditions = {
                                customer_email: request.payload.email
                            };*/
                            /*let user = */
                            /*User.findOne(conditions).then(function(user){
                                done(null,user.toJSON());
                            });*/
                           /* User.findOne(conditions, (err, user) => {

                                    if (err) {
                                        return reply(err);
                                    }

                                    if (!user) {
                                        return reply(Boom.badRequest('Invalid email'));
                                    }
                                    done(null,user.toJSON());
                                    //reply(user);
                                });*/
                            //self.findOne(query, done);
                        },
                        activation: ['user', function (results, done) {

                            const query = {
                                customerActivationStatus: 1
                            };

                            if (username.indexOf('@') > -1) {
                                query.customer_email = username.toLowerCase();
                            }
                            else {
                                query.customer_email = username.toLowerCase();
                            }
                            User.findOne({ where: query, raw: true }).then(function(user){
                                if (!user) {
                                    return reply(Boom.badRequest('Account is not activated! please activate it.'));
                                }
                                if (user == null) {
                                    done(null, true);
                                }
                                done(null, user);
                                //done(null,user.toJSON());
                            });
                            /*let user = User.findOne(query, done);
                            done(null,user.toJSON());*/
                            /*const conditions = {
                                customer_email: request.payload.email
                            };*/
                            /*let user = */
                            /*User.findOne(conditions).then(function(user){
                                done(null,user.toJSON());
                            });*/
                           /* User.findOne(conditions, (err, user) => {

                                    if (err) {
                                        return reply(err);
                                    }

                                    if (!user) {
                                        return reply(Boom.badRequest('Invalid email'));
                                    }
                                    done(null,user.toJSON());
                                    //reply(user);
                                });*/
                            //self.findOne(query, done);
                        }],
                        salt: [ 'user', 'activation', function (results, done) {
                            Bcrypt.genSalt(10, done);
                        }],
                        hash: [ 'user', 'activation', 'salt', function (results, done) {
                            Bcrypt.compare(password, results.salt, done);
                        }],
                        passwordMatch: ['user', 'activation', 'salt', 'hash', function (results, done) {
                            if (!results.user) {
                                return done(null, false);
                            }
                            const query = {};

                            query.passwordHash = results.hash;
                            Bcrypt.compare(password, results.user.passwordHash, function(err, res) {
                              if(!res) {
                                return reply(Boom.badRequest('Incorrect password'));
                              } else {
                                done(null, true);
                              }
                            });
                            /*User.findOne({ where: query, raw: true }).then(function(passuser){
console.log("user", passuser);  
                                
                                
                                if (passuser == null) {
                                    done(null, true);
                                }
                                done(null, passuser);
                                //done(null,user.toJSON());
                            });*/

                            //const source = results.user.password;
                            //Bcrypt.compare(password, source, done);
                        }]
                    }, (err, results) => {

                        if (err) {
                            
                            //done(null, false);
                            return reply(err);
                            //return callback(err);
                        }

                        if (results.passwordMatch) {
                            return reply(null, results.user);
                            //return callback(null, results.user);
                            //done(null, results.user);
                        }
                        //done(null, true);
                        reply(null, results.user);
                    });
                    /*User.findByCredentials(username, password, (err, user) => {

                        if (err) {
                            return reply(err);
                        }

                        reply(user);
                    });*/
                }
            }/*, {
                assign: 'logAttempt',
                method: function (request, reply) {

                    if (request.pre.user) {
                        return reply();
                    }

                    const ip = request.info.remoteAddress;
                    const username = request.payload.username;

                    AuthAttempt.create(ip, username, (err, authAttempt) => {

                        if (err) {
                            return reply(err);
                        }

                        return reply(Boom.badRequest('Username and password combination not found or account is inactive.'));
                    });
                }
            }, {
                assign: 'session',
                method: function (request, reply) {

                    Session.create(request.pre.user._id.toString(), (err, session) => {

                        if (err) {
                            return reply(err);
                        }

                        return reply(session);
                    });
                }
            }*/]
        },
        handler: async function (request, reply) {
            const username = request.payload.username;
            const password = request.payload.password;
            const rememberMe = request.payload.remember;

            Async.auto({
                salt: function (done) {
                    Bcrypt.genSalt(10, done);
                },
                hash: ['salt', function (results, done) {
                    Bcrypt.compare(password, results.salt, done);
                }],
                user: ['salt', 'hash', function (results, done) {

                    const query = {
                        customerStatus: 'Active'
                    };

                    if (username.indexOf('@') > -1) {
                        query.customer_email = username.toLowerCase();
                    }
                    else {
                        query.customer_email = username.toLowerCase();
                    }
                    User.findOne({ where: query, raw: true }).then(function(user){
                        if (!user) {
                            return reply(Boom.badRequest('Incorrect email'));
                        }
                        if (user == null) {
                            done(null, true);
                        }
                        done(null, user);
                    });
                }],
                passwordMatch: ['salt', 'hash', 'user', function (results, done) {
                    console.log("passwordMatch");
                    if (!results.user) {
                        return done(null, false);
                    }
                    const query = {};

                    query.passwordHash = results.hash;

                    User.findOne({ where: query, raw: true }).then(function(user){
                        if (!user) {
                            return reply(Boom.badRequest('Incorrect password'));
                        }
                        if (user == null) {
                            done(null, true);
                        }
                        done(null, user);
                    });
                }]
            }, (err, results) => {
                if (err) {
                    
                    return reply(err);
                }

                if (results.passwordMatch) {
                    
                    const credentials = results.user.customerEmail + ':'/* + results.session.key*/;
                    const authHeader = 'Basic ' + new Buffer(credentials).toString('base64');
                    const result = {
                        user: {
                            _id: results.user.customerKey,
                            email: results.user.customerEmail
                        },
                        authHeader,
                        rememberMe : rememberMe
                    };

                    request.cookieAuth.set(result);
                    return reply(result);
                }
                //done(null, true);
                reply(null, results.user);
            });
    
        }
    });


    server.route({
        method: 'POST',
        path: '/login/forgot',
        config: {
            validate: {
                payload: {
                    email: Joi.string().email().lowercase().required()
                }
            },
            pre: [{
                assign: 'user',
                method: async function (request, reply) {
                    try {
                        const conditions = {
                            customer_email: request.payload.email
                        };

                        let user = await User.find({ where: conditions, raw: true });

                        if (!user) {
                            return reply(Boom.conflict('You have entered wrong email id!'));
                        }

                        reply(user);

                    } catch (e) {
                        if (err) {
                            console.log("err", err);
                            return reply(e);
                        }
                    }
                }
            }]
        },
        handler: function (request, reply) {
            const mailer = request.server.plugins.mailer;
            const key = Uuid.v4();

            Async.auto({
                salt: function (done) {
                    Bcrypt.genSalt(10, done);
                },
                hash: ['salt', function (results, done) {
                    Bcrypt.hash(key, results.salt, done);
                }],
                user: ['salt', 'hash', function (results, done) {

                    const id = request.pre.user.customerId.toString();
                    let customer_data = {
                        "resetToken": results.hash,
                        "resetExpires": Date.now() + 10000000
                    };
                    let conditions = {
                        "customerId": id
                    };
                    User.update(customer_data, { where : conditions, raw: true  }).then(function(user){
                        done(null, user);
                    });
                }],
                getUser: ['salt', 'hash', 'user', function (results, done) {

                    const id = request.pre.user.customerId.toString();
                    let conditions = {
                        "customerId": id
                    };
                    User.find({ where: conditions, raw: true }).then(function(user){
                        done(null, user);
                    });
                }],
                email: ['salt', 'hash', 'user', 'getUser', function (results, done) {
                    const emailOptions = {
                        subject: 'Reset your ' + Config.get('/projectName') + ' password',
                        to: request.payload.email
                    };
                    const template = 'forgot-password';
                    const context = {
                        baseHref: Config.get('/baseUrl') + '/login/reset',
                        email: results.getUser.customerEmail,
                        key: results.hash,
                        customerName: results.getUser.customerName,
                        baseUrl: Config.get('/baseUrl'),
                        date : DateTimeHelper._emailDateTemplate()
                    };

                    mailer.sendEmail(emailOptions, template, context, done);
                }]
            }, (err, results) => {

                if (err) {
                    return reply(err);
                }

                reply({ success: true });
            });
        }
    });


    server.route({
        method: 'POST',
        path: '/login/reset',
        config: {
            validate: {
                payload: {
                    key: Joi.string().required(),
                    email: Joi.string().email().lowercase().required(),
                    password: Joi.string().required()
                }
            },
            pre: [{
                assign: 'user',
                method: async function (request, reply) {
                    try {
                        const conditions = {
                            customer_email: request.payload.email,
                            reset_token: request.payload.key
                        };

                        let user = await User.find({ where: conditions, raw: true });

                        if (!user) {
                            return reply(Boom.conflict('Invalid email or key.'));
                        }

                        reply(user);

                    } catch (e) {
                        if (err) {
                            console.log("err", err);
                            return reply(e);
                        }
                    }
                }
            }]
        },
        handler: function (request, reply) {
            const mailer = request.server.plugins.mailer;
            let payload = request.payload;

            Async.auto({
                salt: function (done) {
                    Bcrypt.genSalt(10, done);
                },
                hash: ['salt', function (results, done) {
                    Bcrypt.hash(payload.password, results.salt, done);
                }],
                user: ['salt', 'hash', function(results, done) {
                    const id = request.pre.user.customerId.toString();
                    let customer_data = {
                        "passwordHash": results.hash,
                        "modifiedDatetime": new Date(),
                        "resetToken": null,
                        "resetExpires": null

                    };
                    let conditions = {
                        "customerId": id
                    };
                    User.update(customer_data, { where : conditions, raw: true  }).then(function(user){
                        done(null, user);
                    });
                }]
            }, (err, results) => {
                if (err) {
                    return reply(err);
                }

                reply({ success: true });
            });
        }
    });
    server.route({
        method: 'POST',
        path: '/login/activation',
        config: {
            validate: {
                payload: {
                    key: Joi.string().required(),
                    email: Joi.string().email().lowercase().required()
                }
            },
            pre: [{
                assign: 'user',
                method: async function (request, reply) {
                    try {
                        const conditions = {
                            customer_email: request.payload.email,
                            customer_activation_key: request.payload.key
                        };

                        let user = await User.find({ where: conditions, raw: true });

                        if (!user) {
                            return reply(Boom.conflict('Invalid email or key.'));
                        }

                        reply(user);

                    } catch (e) {
                        if (err) {
                            console.log("err", err);
                            return reply(e);
                        }
                    }
                }
            }]
        },
        handler: function (request, reply) {
            const mailer = request.server.plugins.mailer;
            let payload = request.payload;

            Async.auto({
                user: function(done) {
                    const id = request.pre.user.customerId.toString();
                    let customer_data = {
                        "customerActivationStatus": 1,
                        "modifiedDatetime": new Date(),
                        "customerActivationKey": null
                    };
                    let conditions = {
                        "customerId": id
                    };
                    User.update(customer_data, { where : conditions, raw: true  }).then(function(user){
                        done(null, user);
                    });
                }
            }, (err, results) => {
                if (err) {
                    return reply(err);
                }

                reply({ success: true });
            });
        }
    });


    next();
};


exports.register = function (server, options, next) {

    server.dependency(['mailer'], internals.applyRoutes);

    next();
};


exports.register.attributes = {
    name: 'login'
};
