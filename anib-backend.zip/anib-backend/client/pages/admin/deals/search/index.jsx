'use strict';
const Actions = require('./actions');
const CreateNewForm = require('../new-deal/create-new-deal');
const FilterForm = require('./filter-form.jsx');
const DataTable = require('./data-table.jsx');
const Paging = require('../../../../components/paging.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Results = require('./results.jsx');
const ReactHelmet = require('react-helmet');
const Store = require('./store');
const Qs = require('qs');


const propTypes = {
    history: PropTypes.object,
    location: PropTypes.object
};

const Helmet = ReactHelmet.Helmet;

class SearchPage extends React.Component {

    constructor(props) {

        super(props);

        const query = Qs.parse(this.props.location.search.substring(1));
        
        Actions.getResults(query);

        this.els = {};
        
        this.state = Store.getState();        
    }

    componentWillReceiveProps(nextProps) {

        const query = Qs.parse(nextProps.location.search.substring(1));

        Actions.getResults(query);
    }

    componentDidMount() {
        
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    
    }

    componentWillUnmount() {

        Actions.resetStore();
        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    onFiltersChange(event) {

        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }

        Actions.changeSearchQuery(this.els.filters.state, this.props.history);
    }

    onPageChange(page) {
        
        this.els.filters.changePage(page);
    }

    onNewClick() {
        
        Actions.showDealModal();
    }

    render() {    
        
        const {
            is_pipeline
        } = this.state.results;
        
        return (

            <section className="page-container">
            <Helmet>
                <title>Enquiry</title>
            </Helmet>
            <div className="container">
                <div className="heading-title">
                    <div className="fly-right">{/*r_100*/}
                        <button
                            ref={(c) => (this.els.createNew = c)}
                            className="btn btn-primary pull-right"
                            onClick={this.onNewClick.bind(this)}>

                            Create new
                        </button>
                    </div>
                    <div className="view-change" style={{ 'display': 'none'}}>
                        <a className={ `${is_pipeline ? 'active' : ''}` } id="pipeLine" onClick={(e) => { Actions.togglePipeline(false)}}><i className="fa fa-th"></i></a>
                        <a className={ `${!is_pipeline ? 'active' : ''}` }  title="" onClick={(e) => { Actions.togglePipeline(true)}}><i className="fa fa-th-list"></i></a>
                    </div>
                    <h2>Enquiry</h2>
                </div>
                { /*<DataTable data={this.state.results.data} />*/ }
                { !is_pipeline ? (
                        <div>
                            <FilterForm
                                ref={(c) => (this.els.filters = c)}
                                loading={this.state.results.loading}
                                query={Qs.parse(this.props.location.search.substring(1))}
                                onChange={this.onFiltersChange.bind(this)}
                            />
                            <Results 
                                data={this.state.results.data} 
                                editable_field={this.state.results.editable_field} 
                                user_id={this.state.results.user_id} 
                                user_name={this.state.results.user_name} 
                                user_data={this.state.results.user_data} 
                                id={this.state.results.user_data} 
                                list_loading={this.state.results.list_loading} 
                                location={this.props.location}
                                searchData={this.els.filters ? this.els.filters.state : undefined}
                                history={this.props.history}/>
                                
                            <Paging
                                ref={(c) => (this.els.paging = c)}
                                pages={this.state.results.pages}
                                loading={this.state.results.loading}
                                onChange={this.onPageChange.bind(this)}
                            />
                        </div>
                    ): (
                        <div>
                           

                         <div className="content">
                <div className="pipe_container">
                    <div className="pipe-columns first">
                        <div className="pipe-heading blue">
                            <h4>New Deal</h4>
                            <div className="pipe_info">
                                $25,000 - 1 Deal
                            </div>
                        </div>
                        <div className="pipe-content">
                            <ul className="reset">
                                <li>
                                    <div className="white-box-drag" onclick="location.href='single-deals.html';">
                                        <h4>2019 Audi A6</h4>
                                        <p>Company Name</p>
                                        <p>$25,000</p>
                                        <i className="fa fa-user-circle ac_circle"></i>
                                        <i className="fa fa-check-circle bt_status green"></i>
                                    </div>
                                </li>
                                <li>
                                    <div className="white-box-drag" onclick="location.href='single-deals.html';">
                                        <h4>2019 Audi QR</h4>
                                        <p>Company Name</p>
                                        <p>$45,000</p>
                                        <i className="fa fa-user-circle ac_circle"></i>
                                        <i className="fa fa-exclamation-triangle bt_status"></i>
                                    </div>
                                </li>
                                <li>
                                    <div className="white-box-drag" onclick="location.href='single-deals.html';">
                                        <h4>Skoda Rapid</h4>
                                        <p>Company Name</p>
                                        <p>$45,000</p>
                                        <i className="fa fa-user-circle ac_circle"></i>
                                        <i className="fa fa-exclamation-triangle bt_status"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="pipe-footer">
                            <a href="#" data-toggle="modal" data-target="#create" className="full_btn">
                                <i className="material-icons">add</i>
                            </a>
                        </div>
                    </div>

                    <div className="pipe-columns">
                        <div className="pipe-heading violet">
                            <h4>Quote</h4>
                            <div className="pipe_info">
                                $0.00
                            </div>
                        </div>
                        <div className="pipe-content">
                            <ul className="reset">

                            </ul>
                        </div>
                        <div className="pipe-footer">
                            <a href="#" data-toggle="modal" data-target="#create" className="full_btn">
                                <i className="material-icons">add</i>
                            </a>
                        </div>
                    </div>

                    <div className="pipe-columns">
                        <div className="pipe-heading orange">
                            <h4>Order</h4>
                            <div className="pipe_info">
                                $0.00
                            </div>
                        </div>
                        <div className="pipe-content">
                            <ul className="reset">
                            </ul>

                        </div>
                        <div className="pipe-footer">
                            <a href="#" data-toggle="modal" data-target="#create" className="full_btn">
                                <i className="material-icons">add</i>
                            </a>
                        </div>
                    </div>

                    <div className="pipe-columns">
                        <div className="pipe-heading green">
                            <h4>House Keeping</h4>
                            <div className="pipe_info">
                                $0.00
                            </div>
                        </div>
                        <div className="pipe-content">
                            <ul className="reset">

                                <li>
                                    <div className="white-box-drag" onclick="location.href='single-deals.html';">
                                        <h4>2019 Audi QR</h4>
                                        <p>Company Name</p>
                                        <p>$45,000</p>
                                        <i className="fa fa-user-circle ac_circle"></i>
                                        <i className="fa fa-exclamation-triangle bt_status"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="pipe-footer">
                            <a href="#" data-toggle="modal" data-target="#create" className="full_btn">
                                <i className="material-icons">add</i>
                            </a>
                        </div>
                    </div>

                    <div className="pipe-columns">
                        <div className="pipe-heading red">
                            <h4>Closed</h4>
                            <div className="pipe_info">
                                $0.00
                            </div>
                        </div>
                        <div className="pipe-content">
                            <ul className="reset">

                                <li>
                                    <div className="white-box-drag" onclick="location.href='single-deals.html';">
                                        <h4>2019 Audi QR</h4>
                                        <p>Company Name</p>
                                        <p>$45,000</p>
                                        <i className="fa fa-user-circle ac_circle"></i>
                                        <i className="fa fa-exclamation-triangle bt_status"></i>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="pipe-footer">
                            <a href="#" data-toggle="modal" data-target="#create" className="full_btn">
                                <i className="material-icons">add</i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
                        </div>
                    )
                }
                
                </div>
                <CreateNewForm
                    history={this.props.history}
                    location={this.props.location}
                    createDeal={this.state.results.createDeal}
                    parentAction={Actions}
                    searchData={this.els.filters ? this.els.filters.state : undefined}                    
                />
            </section>
        );
    }
}

SearchPage.propTypes = propTypes;


module.exports = SearchPage;
