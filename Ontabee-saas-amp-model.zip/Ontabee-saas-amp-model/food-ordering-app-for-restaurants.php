<?php include ('inc/header.php'); ?>

<div class="page_banner bg2 style1">
	<div class="container pad0">
		<div class="col-sm-7 text-left mt30">
			<h1 class="head wow fadeInDown">Food Ordering App</h1>
			<h2 class="head wow fadeInUp">Mobile application for foodies</h2>
			<p class="apps">
				<a href="https://play.google.com/store/apps/details?id=com.ontabee&hl=en" target="_blank"><img src="images/playstore.png" class="wow fadeInUp" alt="Playstore"></a>
				<a href="https://itunes.apple.com/us/app/ontabee/id1351280947?ls=1&mt=8" target="_blank"><img src="images/appstore.png" class="wow fadeInUp" alt="Appstore"></a>
			</p>

			<span class="play wow fadeInUp" data-toggle="modal" data-target="#modal_video">
				<i class="fa fa-play"></i> Watch Video
			</span>
		</div>
		<div class="col-sm-5">
			<img src="images/mobile-app-ordering.png" class="wow fadeInUp" alt="food ordering app" data-wow-duration="1.5s">
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Our online ordering system comes with a responsive mobile app for customer</h2>
		<p class="mb0 wow fadeInUp">Get mobile application with custom built for iOS & Android platforms in shorter time. Create aesthetic and professional mobile ordering app for your restaurant on your own brand name and logo, with affordable price and customizable structure.</p>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="grey text-center">
	<div class="container">
		<h2 class="head wow fadeInUp">The Fastest way to order food online</h2>
		<ul class="box_type equal reset col_3">
			<li class="wow fadeInUp" data-wow-duration="1s">
				<div class="content height">
					<i class="fi promotion"></i>
					<h3>App-only offers</h3>
					<p>Encourage your website & mobile site visitor to use your online food ordering software by running exclusive application with effective offers.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.3s">
				<div class="content height">
					<i class="fi dinner"></i>
					<h3>Image-based menus</h3>
					<p>Attract more customer with the amazing menu item images.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.6s">
				<div class="content height">
					<i class="fi app"></i>
					<h3>Offer your customers the ultimate brand experience</h3>
					<p>Release your brand's full potential with your own mobile app. Stand out with unique content to your brand and allow every customer to order food online through your very own app.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1s">
				<div class="content height">
					<i class="fi track"></i>
					<h3>Order Tracking</h3>
					<p>The customer can track their order and notify them the status of their order.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.3s">
				<div class="content height">
					<i class="fi credit-card"></i>
					<h3>Flexible Payment Option</h3>
					<p>Give your customer the facility to order their food by paying online or directly.</p>
				</div>
			</li>
			<li class="wow fadeInUp" data-wow-duration="1.3s">
				<div class="content height">
					<i class="fi user"></i>
					<h3>Feedback</h3>
					<p>Allow your customers to rate & review and also provide feedback about their order directly on the app.</p>
				</div>
			</li>
		</ul>
	</div>
</section>

<section>
	<div class="container pad0">		
		<div class="col-sm-6 text-center mb20">
			<img src="images/mobile-app.png" class="wow zoomIn" alt="mobile application" data-wow-duration="1.2s">
		</div>
		
		<div class="col-sm-6">
			<h2 class="head wow fadeInUp">Order by Mobile Application</h2>
			<ul class="reset list1 mb30 wow fadeInUp">
				<li>The user can order through the mobile app and also can track the delivery.</li>
				<li>Each time an order is placed, you get a real-time notification on your device. </li>
				<li>Real-time order confirmation, instant customer satisfaction.</li>
			</ul>
			
			<h2 class="head small wow fadeInUp">Why restaurant owner love our real-time mobile ordering application?</h2>
			<ul class="reset list1 wow fadeInUp">
				<li>Convenient - they can order food from wherever they are.</li>
				<li>No Busy lines - While taking orders directly through online customer never get a busy line.</li>
				<li>No misunderstanding - they can order through online so there is no chance for misplacing of orders.</li>
				<li>Order Confirmation - Admin can confirm their order instantly.</li>
			</ul>
		</div>
	</div> <!--container-->
</section> <!--page_banner-->

<section class="half bg4">
	<div class="center">
		<div class="container">
			<div class="col-sm-6 pull-right">
				<h2 class="head wow fadeInUp">Benefits of using online food ordering software for your customer</h2>
				<ul class="reset list1 fadeInUp">
					<li>No need to wait in long queues to place an order.</li>
					<li>Increased clarity in pricing</li>
					<li>The most convenient way of ordering food from any place at anytime</li>
					<li>Multiple ways to pay for the order</li>
					<li>Loyalty points which mean better savings for them, when they frequently placing an order.</li>
				</ul>
			</div>
		</div>
	</div>
</section> <!--half-->

<section class="half right bg5">
	<div class="center">
		<div class="container">
			<div class="col-sm-6 pull-left">
				<h2 class="head wow fadeInUp">Benefits of using food ordering system for restaurant</h2>
				<ul class="reset list1 fadeInUp">
					<li>Customers spend more when they order through an app as they have more time to make a decision.</li>
					<li>Restaurants can handle orders with more accuracy, increase their productivity and also improve their revenue level.</li>
					<li>The restaurant can reduce manual error while taking an order on phone call.</li>
					<li>Loyalty programs help the restaurant to maintain customers and do more repeat business.</li>
					<li>It is very easier to check the cash flow in the restaurant without having to open the ordering registers.</li>
				</ul>
			</div>
		</div>
	</div>
</section> <!--half-->

<section class="app_feature">	
	<div class="container pad0">		
		<h2 class="head wow fadeInUp">Features of Mobile App Ordering</h2>
		<p class="mb40 wow fadeInUp">Features of free online food ordering software for restaurant owners.</p>

		<ul class="reset text-right">
			<li class="wow fadeInLeft" data-wow-duration="1s">
				<i class="fa fa-map-marker"></i>Our application shows the available nearby branch on location-base.
			</li>
			<li class="wow fadeInLeft" data-wow-duration="1.5s">
				<i class="fa fa-user-o"></i>User-friendly with easy checkout
			</li>
			<li class="wow fadeInLeft" data-wow-duration="2s">
				<i class="fa fa-server"></i>Customer details are stored for their future service.
			</li>
		</ul>
		
		<div class="img">
			<img src="images/mobile-app1.png" class="wow zoomIn" alt="mobile application" data-wow-duration="1.2s">
		</div>
		
		<ul class="reset last text-left">
			<li class="wow fadeInRight" data-wow-duration="1s">
				<i class="fa fa-credit-card"></i>Possibility to pay for order through online using the software.
			</li>
			<li class="wow fadeInRight" data-wow-duration="1.5s">
				<i class="fa fa-smile-o"></i>Real-time order confirmation and instant satisfaction of customer.
			</li>
			<li class="wow fadeInRight" data-wow-duration="2s">
				<i class="fa fa-gear"></i>Real time delivery tracking and order status system.
			</li>
		</ul>	
	</div> <!--container-->	
</section> <!--page_banner-->

<section class="grey">
	<div class="container text-center">
		<h2 class="head wow fadeInUp">Mobile App Screens</h2>
		<div class="screens owl-carousel">
			<div><img src="images/screen1.jpg" alt="Splash"><span>1. Splash</span></div>
			<div><img src="images/screen2.jpg" alt="Your Location"><span>2. Your Location</span></div>
			<div><img src="images/screen3.jpg" alt="Restaurant Menu"><span>3. Restaurant Menu</span></div>
			<div><img src="images/screen4.jpg" alt="Menu"><span>4. Menu Details</span></div>
			<div><img src="images/screen5.jpg" alt="Cart"><span>5. My Cart</span></div>
			<div><img src="images/screen6.jpg" alt="Sign In"><span>6. Sign In</span></div>
			<div><img src="images/screen7.jpg" alt="Sign Up"><span>7. Sign Up</span></div>
			<div><img src="images/screen8.jpg" alt="OTP"><span>8. OTP Verification</span></div>
			<div><img src="images/screen9.jpg" alt="Checkout"><span>9. Checkout</span></div>
			<div><img src="images/screen10.jpg" alt="Confirmation"><span>10. Confirmation</span></div>
			<div><img src="images/screen11.jpg" alt="Profile"><span>11. Profile</span></div>
			<div><img src="images/screen12.jpg" alt="Orders"><span>12. Orders</span></div>
			<div><img src="images/screen13.jpg" alt="Order"><span>13. Order Details</span></div>
			<div><img src="images/screen14.jpg" alt="Order Status"><span>14. Order Status</span></div>
			<div><img src="images/screen15.jpg" alt="Track Order"><span>15. Track Order</span></div>
			<div><img src="images/screen16.jpg" alt="Address"><span>16. Address Book</span></div>
			<div><img src="images/screen17.jpg" alt="Location"><span>17. Choose Your Location</span></div>
			<div><img src="images/screen18.jpg" alt="Add Address"><span>18. Add Address</span></div>
			<div><img src="images/screen19.jpg" alt="Edit Address"><span>19. Edit Address</span></div>
        </div>
	</div> <!--container-->
</section> <!--page_banner-->

<div id="modal_video" class="modal fade" role="dialog">
	<div class="modal-dialog modal-sm">
		<a class="close" data-dismiss="modal"><i class="fa fa-close"></i></a>
		<iframe id="video" width="100%" height="100%" src="https://www.youtube.com/embed/j1qWh_N5IxI?rel=0&amp;showinfo=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div><!--modal-dialog-->
</div><!--modal_video-->

<?php include('inc/footer.php');?>