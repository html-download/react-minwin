'use strict';
var LocalStorage = require('node-localstorage').LocalStorage,
localStorage = new LocalStorage('./public/scratch');
const Config = require('../../config');

module.exports = {
    setItem: function (name, value) {
        try {
            localStorage.setItem(`${Config.get('/cookieSecret')}_${name}`, value)
            return true;
        } catch (e) {
            //console.log(e.message);
            return null;
        }
    },

    getItem: function(name){
        try {
            var storage = localStorage.getItem(`${Config.get('/cookieSecret')}_${name}`);

            return storage;
        } catch (e) {
            //console.log(e.message);
            return null;
        }
    },

    removeItem: function(name){
        try {
            
            var storage = localStorage.removeItem(`${Config.get('/cookieSecret')}_${name}`);

            return true;
        } catch (e) {
            //console.log(e.message);
            return null;
        }
    },

    getAuthToken: function(name){
        try {
            
            var storage = localStorage.removeItem(`${Config.get('/cookieSecret')}_${name}`);

            let storageData = storage ? JSON.parse(storageData) : null;

            return storageData.access_token ? storageData.access_token : null;
        } catch (e) {
            //console.log(e.message);
            return null;
        }
    }
};
