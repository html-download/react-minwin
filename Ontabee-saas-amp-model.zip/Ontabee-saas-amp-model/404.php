<?php $title = 'Page not found - Ontabee' ?>
<?php $description = '' ?>
<?php $keywords = '' ?>

<?php include ('inc/header.php'); ?>

<section class="page_banner thankyou not_found">
	<div class="container">
		<div class="content">			
			<i class="fi">404</i>
			<h2>Page not found</h2>
			<p>Don' t worry you will be back on track in no time!</p>
			<a href="<?php echo $baseurl;?>" class="btn">Back To Home</a>
		</div>
	</div> <!--container-->
</section>
  
<!-- main content end -->

<?php include('inc/footer.php');?>