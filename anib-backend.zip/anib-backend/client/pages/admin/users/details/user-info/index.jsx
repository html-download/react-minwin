'use strict';
const Actions = require('./actions');
const Store = require('./store');
const Alert = require('../../../../../components/alert.jsx');
const CommonFunctions = require('../../../../../../client/helpers/common-functions');
const PropTypes = require('prop-types');
const DateHelper = require('../../../../../helpers/date-time');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const SelectControl = require('../../../../../components/form/select-control.jsx');
const TextArea = require('../../../../../components/form/textarea-control');
const TextControl = require('../../../../../components/form/text-control.jsx');
const ReactSelectControl = require('../../../../../components/form/react-select-control');
const CommonHelper = require('../../../../../helpers/common-functions');
const CStore = require('../../common/store');

const propTypes = {
    customer_id: PropTypes.string,
    callback_fun: PropTypes.any,
    deal_id:PropTypes.string
};

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;

class CustomerDetailsForm extends React.Component {

    constructor(props) {

        super(props);
        Actions.getUserDetails(this.props.user_id, true);
        this.input = {};
        this.state = Store.getState();
        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);        
        this.updateDOB = this.updateDOB.bind(this);
        this.customerInfo = this.customerInfo.bind(this);
        this.checkMobileNumber = this.checkMobileNumber.bind(this);
        CStore.subscribe(this.onCommonStoreUpdate.bind(this));

        this.state = {
            roles: []
        };

        this.user_types = CommonHelper.getUserTypes();
    }

    onCommonStoreUpdate() {
        
        this.setState({
            roles: CStore.getState().roles
        });
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }
    
    onStoreChange() {

        this.setState(Store.getState());
    }

    submitCustomer(event, field_name) {
        
        event.preventDefault();
        event.stopPropagation();                
        
        const id = this.props.user_id;
        const value = (this.input[field_name]) ? this.input[field_name].value() : undefined;
        const data = {
            'attribute_key': field_name,
            'attribute_value': value
        };
        Actions.saveUserDetails(id, data);
    }

    addEditable(field) {

        Actions.addEditable(field);
    }

    getUpdateButton(field) {

        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field) }} className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) }} className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        );
    }

    getLabelContent(name, field, value, type) {

        return (
            <div className="form-gp">
                <label className="side req">{name}</label>
                <div className="side-input">
                    { 
                        (value && value !== '') ? (
                            <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{ value }</a>
                        ) : (
                            <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable(field) }} >+Add</a>
                        )
                    }
                </div>
            </div>
        );
    }

    getEmirateOptions() {

        const emirates = this.state.emirate_data ? this.state.emirate_data : [];
        
        if (emirates.length === 0) { 
            return null;
        }
        return emirates.map((emirate, index) => {

            return <option key={`emirate-option-${index}`} value={emirate.emirate_key} data-tokens={`${emirate.emirate_name}`}> {`${emirate.emirate_name}`} </option>;
        });
    }

    updateDOB(date) {

        Actions.updateDOB(date);
    }

    customerInfo() {
                        
        return {
            firstName: this.state.first_name,
            lastName: this.state.last_name,
            dateOfBirth: this.state.dob,
            nationality: this.state.nationality_id,
            emailAddress: this.state.email,
            mobileNo: this.state.mobile_number,
            gender: this.state.gender,
            poBox: this.state.po_box,
            emiratesID: this.state.emirate_id,
            adressLine1: this.state.address,
            adressLine2: this.state.address
        };
    }

    checkMobileNumber(e) {

        let inputValue = e.target.value;
        let mobileNumber  = inputValue.replace(/\D/g,'');
        e.target.value = mobileNumber.substring(0, 10);
    }

    render() {

        const alerts = [];
        if (this.state.error) {
            alerts.push(<Alert
                key="danger"
                type="danger"
                message={this.state.error}
            />);
        }

        const formElements = <fieldset>
            {alerts}
            {
                this.state.editable_field === 'first_name' ? (
                    <TextControl
                        ref={(c) => (this.input.first_name = c)}
                        name="first_name"
                        label="First Name"
                        hasError={this.state.hasError.first_name}
                        help={this.state.help.first_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('first_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.first_name}                        
                    />
                ) : this.getLabelContent('First Name', 'first_name', this.state.first_name, 'text')
            }
            {
                this.state.editable_field === 'last_name' ? (
                    <TextControl
                        ref={(c) => (this.input.last_name = c)}
                        name="last_name"
                        label="Last Name"
                        hasError={this.state.hasError.last_name}
                        help={this.state.help.last_name}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('last_name')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.last_name}                        
                    />
                ) : this.getLabelContent('Last Name', 'last_name', this.state.last_name, 'text')
            }

            {
                this.state.editable_field === 'mobile_number' ? (
                    <TextControl
                        ref={(c) => (this.input.mobile_number = c)}
                        name="mobile_number"
                        label="Phone"
                        hasError={this.state.hasError.mobile_number}
                        help={this.state.help.mobile_number}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('mobile_number')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.mobile_number}                        
                        onChange={ (e) => this.checkMobileNumber(e) }
                    />
                ) : this.getLabelContent('Phone', 'mobile_number', this.state.mobile_number, 'text')
            }
            
            {
                this.state.editable_field === 'email' ? (
                    <TextControl
                        ref={(c) => (this.input.email = c)}
                        name="email"
                        label="Email"
                        hasError={this.state.hasError.email}
                        help={this.state.help.email}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('email')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={this.state.email}
                    />
                ) : this.getLabelContent('Email', 'email', this.state.email, 'text')
            }
            {
                this.state.editable_field === 'role_id' ? (
                   
                    <ReactSelectControl
                        ref={(c) => (this.input.role_id = c)}
                        name="role_id"
                        label="Role"
                        hasError={this.state.hasError.role_id}
                        help={this.state.help.role_id}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('role_id')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={ {value:this.state.role_id, label: this.state.role_name} }
                        options={ CommonHelper.getOptionData(this.state.roles, 'role_id', 'role_name') }
                    />
                ) : this.getLabelContent('Role', 'role_id', this.state.role_name, 'select')
            }
            {
                this.state.editable_field === 'user_type' ? (
                   
                    <ReactSelectControl
                        ref={(c) => (this.input.user_type = c)}
                        name="user_type"
                        label="User Type"
                        hasError={this.state.hasError.user_type}
                        help={this.state.help.user_type}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}
                        appendElement={this.getUpdateButton('user_type')}
                        appendElementNotString={true}
                        isKeyEnable={true}
                        defaultValue={ this.state.user_type }
                        options={ this.user_types }
                    />
                ) : this.getLabelContent('User Type', 'user_type', this.state.user_type_label, 'select')
            }

        </fieldset>;

        return (
            
            <div className={ `white-box mt-25 ${this.state.hydrating ? 'loader-tab-content' : ''}` }>
                <Helmet>
                    <title>{ CommonFunctions.toTitleCase(name) }</title>
                </Helmet>
                <div className="customer-box">                    
                    {
                        (this.state.editable_field === 'username' && this.state.username !== ' ') ? (
                            <TextControl
                                ref={(c) => (this.input.username = c)}
                                name="username"
                                hideLabel={true}
                                hasError={this.state.hasError.username}
                                help={this.state.help.username}
                                disabled={this.state.loading}
                                validation={true}
                                groupClasses={{'form-group': true, 'form-gp': true}}
                                labelClasses={{'control-label': false, 'side': true}}
                                inputClasses={{'form-control': true, 'add-forms': true}}
                                appendElement={this.getUpdateButton('username')}
                                appendElementNotString={true}
                                isKeyEnable={true}
                                defaultValue={this.state.username}                                
                            />
                        ) : (
                            <h4 className="capitalize" onClick={(e) => { this.addEditable('username') }}> { this.state.username ? CommonFunctions.toTitleCase(this.state.username) : (
                                <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable('username') }} >+Add</a>
                            ) } </h4>
                        )
                    }
                    {
                        (this.props.viewCustomer && this.props.user_id) ? <Link to={`/admin/customers/${this.props.user_id}` } className="add-forms editable editable-click editable-empty"> View </Link> : ''
                    }
                    <span>User</span>
                </div>
                <form>
                    {formElements}
                </form>
            </div>
        );
    }
}

CustomerDetailsForm.propTypes = propTypes;


module.exports = CustomerDetailsForm;
