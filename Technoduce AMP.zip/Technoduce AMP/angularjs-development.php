<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/angular-logo.png" alt="AngularJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Top Rated AngularJS Development company</h1>
      <p class="desc animated fadeInUp mb0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="half_bg red">
  <div class="container relative">
    <div class="col_6 pr30 white">
      <h2 class="head line white style1">Customizable AngularJS Web App Development Services</h2>
      <p class="mb20">AngularJS is structural open source JavaScript framework which is maintained by Google. This MVW (Model-View-Whatever) based front-end framework is appropriated to develop dynamic web apps using JavaScript, CSS, and HTML to overcome the development challenges of single page applications.</p>

      <ul class="lists style1 mb0">
        <li>AngularJS enhance HTML with new attributes.</li>
        <li>AngularJS is ideal for Single Page Applications (SPAs).</li>
        <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
        <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
      </ul>
    </div>
    
    <div class="col_6 pl30 diagram">
      <amp-img src="<?php echo $baseurl;?>images/angular-development.png" alt="AngularJS Development" width="460" height="450" layout="responsive"></amp-img>
    </div>
  </div> <!--container-->
</section> <!--half_bg-->

<section>
  <div class="container">
    <h2 class="head text-center style1">Outstanding features involves AngularJS</h2>
    <div class="web_features full_row">
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Two-way data binding</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Easy to understand & use MVC architecture</h3>  
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Dynamic & Agile Solutions</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Inline Templates</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          </ul>
      </div>

      <div class="img">
        <amp-img src="<?php echo $baseurl;?>images/angular-logo.png" alt="AngularJS Development" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <div class="content">
        <ul class="reset">
          <li>
            <h3>Directives & Filters</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Clear synchronization between Model and DOM</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>REST friendly application framework</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          <li>
            <h3>Ease testing and e2e testing environment</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          </li>
          </ul>
      </div>
    </div> <!--web_features-->
  </div> <!--container-->
</section>

<section class="half dark">
	<div class="container">
    <div class="row white">
      <div class="col_6 pr30">
        <h2 class="head line white style1">Why choose AngularJS development services?</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style2 mb0">
          <li>Dynamic web application development.</li>
          <li>Application Migration Services.</li>
          <li>User interactive module development.</li>
          <li>Custom widgets developmen.</li>
          <li>AngularJS Design</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg1 right"></div>
</section>

<section class="half red">
  <div class="bg bg2 left"></div>

	<div class="container">
    <div class="row white">
      <div class="col_6 pull_right">
        <h2 class="head line white style1">Why most of the companies are using AngularJS?</h2>
        <h3>Flexibility</h3>
        <p class="mb20">AngularJS offers much more flexible than the basic HTML, concede anyone to create a single application and simple development & testing stages for a fast and secure website. </p>
        <h3>Stretchability</h3>
        <p class="mb20">AngularJS is extremely extendable and also works with a variety of libraries which means you can customize your workflow to meet your exact requirements.</p>
        <ul class="lists style1 mb0">
          <li>High-quality services with Transparency.</li>
          <li>Affordable & Secure Development.</li>
          <li>Write less code.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section class="section timeline">
	<div class="container md">
		<h2 class="head style1">AngularJS web app development process</h2>
		<ul class="reset">
			<li>
				<div class="content">
					<span class="step">1</span><i class="fi monitor1"></i>
					<h3>Business analyst</h3>
					<p>Build and manage a relationship between the clients & the organization and also developing a technical solution to the business problems.</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">2</span><i class="fi setting"></i>
					<h3>Project Management</h3>
					<p>The strategic roles & responsibilities which involves resources planning, analyzing and managing project risk.</p>
				</div>
      </li>
      <li>
				<div class="content">
					<span class="step">3</span><i class="fi design"></i>
					<h3>Design UX / UI</h3>
					<p>A creative designer works in an area of marketing and advertising to create brochures, product labels & also has always been to translate and communicate the value of business ideas into consumers.</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">4</span><i class="fi browser"></i>
					<h3>Development</h3>
					<p>Develop a full-fledged application which the main objective to satisfy the specific requirements of the business people.</p>
				</div>
      </li>
      <li>
				<div class="content">
					<span class="step">5</span><i class="fi cloud-server"></i>
					<h3>Testing</h3>
					<p>Testing in software quality through manual & automation testing and also responsible for detecting & reporting bugs.</p>
				</div>
			</li>
			<li class="right">
				<div class="content">
					<span class="step">6</span><i class="fi cloud-server"></i>
					<h3>Deployment</h3>
					<p>Its enable to deploy the project to the integration services server. Parameters are used to assign the values to project deployment file.</p>
				</div>
			</li>
      <li>
        <div class="content">
          <span class="step">5</span><i class="fi cloud-server"></i>
          <h3>Support</h3>
          <p>Provides you an extended client support.</p>
        </div>
      </li>
		</ul>
	</div> <!--container-->
</section> <!--section-->

<section class="half red">
	<div class="container">
    <div class="row white">
      <div class="col_6 pr30">
        <h2 class="head line white style1">Why choose Technoduce as an AngularJS development?</h2>
        <p class="mb20">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut pellentesque dolor vel diam consectetur ultricies. Nullam ornare tempor est a tempus.</p>
        <ul class="lists style1 mb0">
          <li>One stop solution for all AngularJS needs.</li>
          <li>We have an expertise team in AngularJS, familiar with all the frameworks.</li>
          <li>We are specialized in high-quality browser-based application development.</li>
          <li>Active support & maintenance.</li>
          <li>Predictability and consistency in our services.</li>
          <li>Our team of professionals assures that we broaden the scope of services we provide to our clients.</li>
          <li>End to End service.</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->

  <div class="bg bg3 right"></div>
</section>

<?php include ('inc/footer.php'); ?>