'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');


const initialState = {
    loading: false,
    error: undefined,
    delete_modal_show: false
};
const reducer = function (state = initialState, action) {

    if (action.type === Constants.GET_DETAILS_RESPONSE) {
        return ObjectAssign({}, state);
    }

    if (action.type === Constants.DELETE) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.DELETE_RESPONSE) {
        const validation = ParseValidation(action.response);

        return ObjectAssign({}, state, {
            loading: false,
            error: validation.error
        });
    }

    if (action.type === Constants.DELETE_MODAL_SHOW) {
        return ObjectAssign({}, state, {
            delete_modal_show: true
        });
    }

    if (action.type === Constants.DELETE_MODAL_HIDE) {
        return ObjectAssign({}, state, {
            delete_modal_show: false
        });
    }
    return state;
};


module.exports = reducer;
