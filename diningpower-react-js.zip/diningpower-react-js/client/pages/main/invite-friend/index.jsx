const React = require('react');
const ReactHelmet = require('react-helmet');

const Helmet = ReactHelmet.Helmet;

class InviteFriendPage extends React.Component {
    componentDidMount() {
        window.scrollTo(0, 0);
    }
    render() {

        return (
            <div>
                <Helmet>
                    <title>Invite Friend</title>
                </Helmet>
                <section className="invite">
                    <div className="container">
                        <div className="col-sm-12 text-center">
                            <div className="width-650">
                                <h2>Invite Friends - Give $10, Get $10</h2>
                                <p className="first">(after their first order of $15+)</p>
                                <img src="/public/media/images/invite.png" alt="Invite Friends" className="mb20" />
                                <div className="form-group send required">
                                    <input type="text" className="form-control" name="Email" placeholder="Add friends’ email addresses, separated by commas" />
                                    <button className="btn snd">Send</button>
                                </div>
                                <div className="or">
                                    <span>or</span>
                                </div>
                                <div className="form-group share required">
                                    <label>Share Link:</label>
                                    <div className="copy">
                                        <input type="text" className="form-control" name="Email" placeholder="Invited Link" value="http://dp-fsl/tyuL-csmr/A-321783942" />
                                        <button className="btn">Copy</button>
                                    </div>
                                    <span>
                                        <button className="btn fb"><i className="fa fa-facebook-official" aria-hidden="true"></i>Share</button>
                                        <button className="btn twit"><i className="fa fa-twitter" aria-hidden="true"></i>Tweet</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="full_row earnings">
                        <h4>You’ve earned <span>$20</span> from <span>2</span> completed referrals.</h4>
                        <ul className="reset">
                            <li>
                                <div className="referals failed">
                                    <div className="stat-icon"></div>
                                    <div className="mail">slow-response-friend@email.com</div>
                                    <div className="date">05-01-2018 invited</div>  
                                    <div className="earn">$10 pending</div>
                                    <div className="result"><a href="#">resend invite</a></div>
                                </div>
                            </li>
                            <li>                        
                                <div className="referals">
                                    <div className="stat-icon"></div>
                                    <div className="mail">great-friend@email.com</div>
                                    <div className="date">04-25-2018 ordered</div>  
                                    <div className="earn">$10 earned    </div>
                                    <div className="result">Congrats!</div>
                                </div>
                            </li>
                            <li>                        
                                <div className="referals">
                                    <div className="stat-icon"></div>
                                    <div className="mail">great-friend-number-2@email.com</div>
                                    <div className="date">04-21-2018 ordered</div>  
                                    <div className="earn">$10 earned    </div>
                                    <div className="result">Congrats!</div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </section>
            </div>
            
        );
    }
}


module.exports = InviteFriendPage;
