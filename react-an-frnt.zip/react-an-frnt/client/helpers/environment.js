'use strict';
/*const Dotenv = require('dotenv');

Dotenv.config({ silent: true });*/

module.exports = {

    toGetEnv: function () {

        return (process.env.NODE_ENV === 'undefined' || process.env.NODE_ENV === undefined) ? 'development' : process.env.NODE_ENV;
    },

    toGetPort: function () {

        return (process.env.PORT === 'undefined' || process.env.PORT === undefined) ? 8027 : process.env.PORT;
    },

    toGetCookieSecret: function () {

        return (process.env.COOKIE_SECRET === 'undefined' || process.env.COOKIE_SECRET === undefined) ? process.env.COOKIE_SECRET : '!k3yb04rdK4tz~4qu4~k3yb04rdd0gz!';
    },

    toGetSmtpPassword: function () {

        return (process.env.SMTP_PASSWORD === 'undefined' || process.env.SMTP_PASSWORD === undefined) ? process.env.SMTP_PASSWORD : 'test';
    }
};
