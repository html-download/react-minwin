var Game, Obj, HotSpot, Shape, Font, Rectangle = {};
Game =
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GAME-SPECIFIC FIELDS
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Bet                 : 3,
    Credits             : 1000,
    LastOutcome         : 0,
    LastWin             : 0,
    Paytable            : [],
    Reel                : [],
    BonusActivated      : false,
    BeginBonus          : function() { },
    BonusWin            : 0,

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // EVENT HANDLING
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Button              : false,
    CaptureStart        : [-1, -1],
    HotSpot             : [],
    IsCapturing         : false,
    IsHovering          : false,

    GetEventInfo        : function(e) { var o = Obj("capture"), x = 0, y = 0, a = e.altKey, c = e.ctrlKey, s = e.shiftKey; if (e.offsetX || e.offsetY) { x = e.offsetX; y = e.offsetY; } else { while (o) { x += o.offsetLeft; y += o.offsetTop; o = o.offsetParent; } x = e.pageX - x; y = e.pageY - y; } return { X : x, Y : y, Alt : a, Ctrl : c, Shift : s, Button : Game.Button }; },
    GlobalMouseDown     : function(e) { Game.Button = true; },
    GlobalMouseUp       : function(e) { Game.Button = false; Game.IsCapturing = false; for (var h in Game.HotSpot) { Game.HotSpot[h].IsCapturing = false; } },
    KeyReleased         : function(e) { /* if (Game.HotSpot["ButtonMsgBox"].Enabled == false) { return true; } if ((e.keyCode == 13) || (e.keyCode == 27) || (e.keyCode == 32)) { Game.HotSpot["ButtonMsgBox"].Click(); return false; } return true; */ },
    MouseClick          : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y) && Game.HotSpot[h].Contains(Game.CaptureStart[0], Game.CaptureStart[1])) { Game.IsCapturing = false; Game.IsHovering = true; Game.HotSpot[h].IsCapturing = false; Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].Click(evt.Alt, evt.Ctrl, evt.Shift); } } },
    MouseDoubleClick    : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y) && Game.HotSpot[h].Contains(Game.CaptureStart[0], Game.CaptureStart[1])) { Game.IsCapturing = false; Game.IsHovering = true; Game.HotSpot[h].IsCapturing = false; Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].DoubleClick(evt.Alt, evt.Ctrl, evt.Shift); } } },
    MouseDown           : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); Game.CaptureStart = [evt.X, evt.Y]; for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y)) { Game.IsCapturing = true; Game.HotSpot[h].IsCapturing = true; Game.HotSpot[h].Down(evt.Alt, evt.Ctrl, evt.Shift); } } },
    MouseMove           : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); var NewCap = false; var NewHov = false; for (var h in Game.HotSpot) { if (Game.HotSpot[h].Enabled) { if (Game.IsCapturing && Game.Button) { if (Game.HotSpot[h].Contains(evt.X, evt.Y)) { if (Game.HotSpot[h].IsCapturing) { if (!Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].Down(evt.Alt, evt.Ctrl, evt.Shift); } } else { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(evt.Alt, evt.Ctrl, evt.Shift); } } } else { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(evt.Alt, evt.Ctrl, evt.Shift); } } } else { if (Game.HotSpot[h].Contains(evt.X, evt.Y)) { if (!Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = true; Game.HotSpot[h].Hover(evt.Alt, evt.Ctrl, evt.Shift); } } else { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(evt.Alt, evt.Ctrl, evt.Shift); } } } } else { if (Game.HotSpot[h].IsCapturing || Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsCapturing = false; Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(); } } NewCap |= Game.HotSpot[h].IsCapturing; NewHov |= Game.HotSpot[h].IsHovering; } Game.IsCapturing = NewCap; Game.IsHovering = NewHov; },
    MouseOut            : function(e) { Game.IsHovering = false; for (var h in Game.HotSpot) { if (Game.HotSpot[h].IsHovering) { Game.HotSpot[h].IsHovering = false; Game.HotSpot[h].Leave(); } } },
    MouseUp             : function(e) { var evt = Game.GetEventInfo(e ? e : window.event); for (var h in Game.HotSpot) { Game.IsCapturing = false; Game.HotSpot[h].IsCapturing = false; if (Game.HotSpot[h].Enabled && Game.HotSpot[h].Contains(evt.X, evt.Y)) { Game.HotSpot[h].IsHovering = true; if (Game.HotSpot[h].IsCapturing) { Game.HotSpot[h].Up(evt.Alt, evt.Ctrl, evt.Shift); } else { Game.HotSpot[h].Hover(evt.Alt, evt.Ctrl, evt.Shift); } } else { Game.HotSpot[h].IsHovering = false; } } },

    BeforeInitialize    : function() { },
    AfterInitialize     : function() { },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // INITIALIZE
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Initialize : function()
    {
        Game.BeforeInitialize();

        Game.HotSpot.ButtonBetOne           = new HotSpot(Shape.Rectangle, [493,520, 560,575]);
        Game.HotSpot.ButtonBetMax           = new HotSpot(Shape.Rectangle, [571,520, 638,575]);
        Game.HotSpot.ButtonSpin             = new HotSpot(Shape.Circle,    [668,505, 753,589]);

        Game.HotSpot.ButtonBetOne.Leave     = function(a, c, s) { if (this.Enabled) { Obj("btn_betone").style.backgroundPosition = "0 0"; } };
        Game.HotSpot.ButtonBetOne.Down      = function(a, c, s) { Obj("btn_betone").style.backgroundPosition = "0 -55px"; };
        Game.HotSpot.ButtonBetOne.Up        = function(a, c, s) { Obj("btn_betone").style.backgroundPosition = "0 0"; };
        Game.HotSpot.ButtonBetOne.Click     = function(a, c, s) { Obj("btn_betone").style.backgroundPosition = "0 0"; Game.Clear(); Game.Bet = (Game.Bet % 3) + 1; Game.Update(true); };

        Game.HotSpot.ButtonBetMax.Leave     = function(a, c, s) { if (this.Enabled) { Obj("btn_betmax").style.backgroundPosition = "-67px 0"; } };
        Game.HotSpot.ButtonBetMax.Down      = function(a, c, s) { Obj("btn_betmax").style.backgroundPosition = "-67px -55px"; };
        Game.HotSpot.ButtonBetMax.Up        = function(a, c, s) { Obj("btn_betmax").style.backgroundPosition = "-67px 0"; };
        Game.HotSpot.ButtonBetMax.Click     = function(a, c, s) { Obj("btn_betmax").style.backgroundPosition = "-67px 0"; Game.Bet = 3; Game.Update(true); Game.Play(); };

        Game.HotSpot.ButtonSpin.Leave       = function(a, c, s) { if (this.Enabled) { Obj("btn_spin").style.backgroundPosition = "-134px 0"; } };
        Game.HotSpot.ButtonSpin.Down        = function(a, c, s) { Obj("btn_spin").style.backgroundPosition = "-134px -85px"; };
        Game.HotSpot.ButtonSpin.Up          = function(a, c, s) { Obj("btn_spin").style.backgroundPosition = "-134px 0"; };
        Game.HotSpot.ButtonSpin.Click       = function(a, c, s) { Obj("btn_spin").style.backgroundPosition = "-134px 0"; Game.Play(); };

        var gam = Obj("game");
        var cap = Obj("capture");

        document.onselectstart              = function() { return false; };
        document.ondragstart                = function() { return false; };
        cap.onselectstart                   = function() { return false; };
        cap.ondragstart                     = function() { return false; };
        cap.onmousemove                     = Game.MouseMove;
        cap.onmousedown                     = Game.MouseDown;
        cap.onmouseup                       = Game.MouseUp;
        cap.onclick                         = Game.MouseClick;
        cap.ondblclick                      = Game.MouseDoubleClick;
        cap.onmouseout                      = Game.MouseOut;
        document.body.onmousedown           = Game.GlobalMouseDown;
        document.body.onmouseup             = Game.GlobalMouseUp;
        document.onkeydown                  = function(e) { return Game.KeyReleased(e || window.event); }

        Obj("loading").Hide();
        Obj("game").Show();

        Game.AfterInitialize();

        Game.HotSpot.ButtonBetOne.Enable();
        Game.HotSpot.ButtonBetMax.Enable();
        Game.HotSpot.ButtonSpin.Enable();

        Game.Update(true);

        Obj("game").scrollIntoView();
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // CLEAR
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Clear : function()
    {
        Game.LastWin = 0;

        Obj("win").innerHTML = "";
        Obj("msg").innerHTML = "";
        Obj("payline").Hide();
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // UPDATE
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Update : function(btn)
    {
        Font.Write("credits", "lcd33", Game.Credits.toFixed(0));

        if (Game.LastWin > 0)
        {
            Font.Write("win", "lcd33", Game.LastWin.toFixed(0));
        }
        else
        {
            Obj("win").innerHTMl = "";
        }

        Font.Write("bet", "lcd33", Game.Bet.toFixed(0));

        if (btn)
        {
            Game.HotSpot.ButtonBetOne.Enable(); Obj("btn_betone").Show();
            Game.HotSpot.ButtonBetMax.Enable(); Obj("btn_betmax").Show();
            Game.HotSpot.ButtonSpin.Enable();   Obj("btn_spin").Show();
        }
        else
        {
            Game.HotSpot.ButtonBetOne.Disable(); Obj("btn_betone").Hide();
            Game.HotSpot.ButtonBetMax.Disable(); Obj("btn_betmax").Hide();
            Game.HotSpot.ButtonSpin.Disable();  Obj("btn_spin").Hide();
        }
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // PLAY
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    Play : function()
    {
        Game.Clear();

        Font.Write("msg", "lcd17", "GOOD LUCK!");

        Game.HotSpot.ButtonBetOne.Disable(); Obj("btn_betone").Hide();
        Game.HotSpot.ButtonBetMax.Disable(); Obj("btn_betmax").Hide();
        Game.HotSpot.ButtonSpin.Disable();   Obj("btn_spin").Hide();

        Game.Credits -= Game.Bet;
        Font.Write("credits", "lcd33", Game.Credits.toFixed(0));

        Game.Reel[0].VirtualStop = Math.floor(Math.random() * Game.Reel[0].Weight);
        Game.Reel[1].VirtualStop = Math.floor(Math.random() * Game.Reel[1].Weight);
        Game.Reel[2].VirtualStop = Math.floor(Math.random() * Game.Reel[2].Weight);

        var w, s;

        w = Game.Reel[0].VirtualStop; s = 0; while (w >= Game.Reel[0].StopWeight[s]) { w -= Game.Reel[0].StopWeight[s++]; } Game.Reel[0].PhysicalStop = s;
        w = Game.Reel[1].VirtualStop; s = 0; while (w >= Game.Reel[1].StopWeight[s]) { w -= Game.Reel[1].StopWeight[s++]; } Game.Reel[1].PhysicalStop = s;
        w = Game.Reel[2].VirtualStop; s = 0; while (w >= Game.Reel[2].StopWeight[s]) { w -= Game.Reel[2].StopWeight[s++]; } Game.Reel[2].PhysicalStop = s;

        Game.Reel[0].Position = Math.floor(Math.random() * Game.Reel[0].Height);
        Game.Reel[1].Position = Math.floor(Math.random() * Game.Reel[1].Height);
        Game.Reel[2].Position = Math.floor(Math.random() * Game.Reel[2].Height);

        Game.Reel[0].Timer = setInterval(function() { Game.SpinReel(0); }, 5);
        Game.Reel[1].Timer = setInterval(function() { Game.SpinReel(1); }, 5);
        Game.Reel[2].Timer = setInterval(function() { Game.SpinReel(2); }, 5);

        setTimeout(function() { Game.StopReel(0); },  500);
        setTimeout(function() { Game.StopReel(1); }, 1100);
        setTimeout(function() { Game.StopReel(2); }, 1800);

        setTimeout(Game.PlayFinish, 1801);
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // SPIN REEL
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    SpinReel : function(n)
    {
        Game.Reel[n].Position = (Game.Reel[n].Position + 17) % Game.Reel[n].Height;

        Obj("reel" + n).style.backgroundPosition = "0 -" + (Game.Reel[n].Height - Game.Reel[n].Position) + "px";
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // STOP REEL
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    StopReel : function(n)
    {
        clearInterval(Game.Reel[n].Timer);

        Obj("reel" + n).style.backgroundPosition = Game.Reel[n].Offset[Game.Reel[n].PhysicalStop];
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // PLAY FINISH
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    PlayFinish : function()
    {
        var s1a = Game.Reel[0].Symbol1[Game.Reel[0].PhysicalStop];
        var s2a = Game.Reel[1].Symbol1[Game.Reel[1].PhysicalStop];
        var s3a = Game.Reel[2].Symbol1[Game.Reel[2].PhysicalStop];

        var s1b = Game.Reel[0].Symbol2[Game.Reel[0].PhysicalStop];
        var s2b = Game.Reel[1].Symbol2[Game.Reel[1].PhysicalStop];
        var s3b = Game.Reel[2].Symbol2[Game.Reel[2].PhysicalStop];

        var best = { Outcome : 0, Multiplier : 1 };

        var outcome1 = Game.GetOutcome(s1a, s2a, s3a); if (outcome1.Outcome > best.Outcome) { best = outcome1; }
        var outcome2 = Game.GetOutcome(s1a, s2a, s3b); if (outcome2.Outcome > best.Outcome) { best = outcome2; }
        var outcome3 = Game.GetOutcome(s1a, s2b, s3a); if (outcome3.Outcome > best.Outcome) { best = outcome3; }
        var outcome4 = Game.GetOutcome(s1a, s2b, s3b); if (outcome4.Outcome > best.Outcome) { best = outcome4; }
        var outcome5 = Game.GetOutcome(s1b, s2a, s3a); if (outcome5.Outcome > best.Outcome) { best = outcome5; }
        var outcome6 = Game.GetOutcome(s1b, s2a, s3b); if (outcome6.Outcome > best.Outcome) { best = outcome6; }
        var outcome7 = Game.GetOutcome(s1b, s2b, s3a); if (outcome7.Outcome > best.Outcome) { best = outcome7; }
        var outcome8 = Game.GetOutcome(s1b, s2b, s3b); if (outcome8.Outcome > best.Outcome) { best = outcome8; }

        Game.LastOutcome = best.Outcome;
        Game.LastWin     = Game.Paytable[Game.Bet - 1][Game.LastOutcome] * best.Multiplier;

        if (Game.LastWin > 0)
        {
            Obj("payline").Show();
            Font.Write("msg", "lcd17", "GAME PAYS " + Game.LastWin);
        }
        else
        {
            Obj("msg").innerHTML = "";
        }

        Game.Credits += Game.LastWin;
        Game.Update(true);
    },

    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //
    // GET OUTCOME
    //
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    GetOutcome : function(s1, s2, s3)
    {
        return { Outcome : 0, Multiplier : 1 };
    }
};

var save = window.onload;

window.onload = function()
{
    if (save)
    {
        save();
    }

    Game.Initialize();
};
