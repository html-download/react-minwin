'use strict';
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require("react-router-dom");
const RouteStatus = require('../../components/route-status.jsx');


const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;


class NotFoundPage extends React.Component {
    render() {

        return (
            <RouteStatus code={404}>
                <section className="notFoundPage">
                <div className="container">
                <img src="/public/media/images/noImage.jpg" alt="noImage" />
                    <Helmet>
                        <title>Page not found</title>
                    </Helmet>
                    <h1 className="page-header">Page not found</h1>
                    <p>We couldn’t find the page you requested.</p>
                    
                    <Link to="/">
                    <button className="btn">
                    Back to Home
                    </button>
                    </Link>
                    
                    </div>
                </section>
            </RouteStatus>
        );
    }
}


module.exports = NotFoundPage;
