import React from 'react'; 
import PropTypes from 'prop-types'; 
import ClassName from 'classnames';
const Textarea = (props) =>{

let groupClasses = ClassName(Object.assign({
    'form-group' : true
  }, props.groupClasses));

let inputClasses = ClassName(Object.assign({
    'form-control' : true
  }), props.inputClasses)

return (


  <div className={groupClasses}>
   
    <textarea
      className={inputClasses}
       name={props.name}
       content={props.content}
      rows={props.rows}
      onChange={props.onChange}
      placeholder={props.placeholder} />
  </div>

)
}


Textarea.propTypes = {  
  title:PropTypes.string.isRequired,
  rows:PropTypes.string.isRequired,
  content:PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
  onChange: PropTypes.func
};



export default Textarea;