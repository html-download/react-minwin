const React = require('react');
const ReactRouter = require('react-router-dom');

const Link = ReactRouter.Link;

class Footer extends React.Component {
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick(event) {
        /*console.log($('#asda').val())
        console.log('Click happened');*/
    }
    render() {
        const year = new Date().getFullYear();

        return (
            <footer className="site_footer full_row wow fadeIn">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-4">
                            <h4 onClick={this.handleClick}>Order from your phone. <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <div  className="res_acc">
                            <form className="order_phone">
                                <div className="w65">
                                    <input id="asda" type="text" className="form-control" placeholder="(555) 555-1212" />
                                </div>
                                <input type="button" className="get " value="Get the App" />
                            </form>
                            <p className="order_phone_txt">Enter your mobile number and we will send you the app. Available for <a role="button">iOS</a> and <a role="button">Android</a>.</p>
                            </div>
                            <h4 className="signup_offer_head">Sign up for tasty offers. <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <div className="res_acc">
                            <form className="signup_offer">
                                <div className="form-group order_phone">
                                    <input type="text" className="form-control w100" id="inputEmail" placeholder="Enter your email" />
                                    <span className="errors"></span>
                                </div>
                                <div className="form-group sign_up_btn">
                                    <input type="button" className="get w100" value="Sign Me Up" />
                                </div>
                            </form>
                            </div>
                        </div>
                        <div className="col-sm-2">
                            <h4>Useful Links <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <ul className="about_content reset">
                                <li>
                                    <Link to="/rewards">Rewards</Link>
                                </li>
                                <li><a role="button">FAQ</a></li>
                                <li><a role="button">Contact Us</a></li>
                            </ul>
                            <h4>Get to Know Us <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <ul className="about_content reset">
                                <li><a role="button">About Dining Power</a></li>
                                <li><a role="button">Our Apps</a></li>
                                </ul>
                        </div>
                        <div className="col-sm-2">
                            <h4>Partner With Us <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <ul className="about_content reset">
                                <li><a role="button">For Restaurants</a></li>
                                <li><a role="button">For Drivers</a></li>
                                <li><a role="button">For Corporate Accounts</a></li>
                            </ul>
                            <h4>Let’s Get Social <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <ul className="about_content reset">
                                <li><a role="button">Facebook</a></li>
                                <li><a role="button">Twitter</a></li>
                                <li><a role="button">Instagram</a></li>
                                <li><a role="button">Pinterest</a></li>
                                <li><a role="button">Youtube</a></li>
                            </ul>
                        </div>
                        <div className="col-sm-2">
                            <h4>Browse by Cities <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <ul className="about_content reset">
                                <li><a role="button">Los Angeles</a></li>
                                <li><a role="button">Coimbatore</a></li>
                            </ul>
                        </div>
                        <div className="col-sm-2">
                            <h4>Browse by Cuisines <i className="fa fa-angle-up" aria-hidden="true"></i></h4>
                            <ul className="about_content reset">
                                <li><a role="button">South Indian</a></li>
                                <li><a role="button">Italian</a></li>
                            </ul>
                        </div>
                        <div className="col-sm-12 mt30">
                            <ul className="reset copyright wow fadeInUp">
                                <li><img src="/public/media/images/white_star.png" alt="FooterImage"/></li>
                                <li><a role="button">Terms of Service</a></li>
                                <li><a role="button">Privacy Policy</a></li>
                                <li>&#169; {year}. Dining Power</li>
                            </ul>
                        </div>
                        
                    </div>
                </div> 
            </footer>
            
        );
    }
}


module.exports = Footer;
