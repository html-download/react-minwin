'use strict';
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const Actions = require('./actions');
const UpdateForm = require('./update-form.jsx');


const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array
};


class Results extends React.Component {
    onDelete(client) {

        event.preventDefault();
        event.stopPropagation();

        Actions.delete({
            client_name: client
        }, this.props.history);
    }
    onNewClick() {
        Actions.showUpdate();
    }
    onStatusUpdate(id, status) {
        let msg = status ? `${id} has been activated successfully` : `${id} has been deactivated successfully`;
        Actions.statusUpdate({
            client_name : id,
            active_flag : status ? 1 : 0
        }, msg);
    }
    render() {

        const rows = this.props.data === undefined ? (
                <tr key="1">
                    <td colSpan={5} style={{'textAlign' : 'center'}}>
                        Something Wrong!
                    </td>
                </tr>
            ) : this.props.data.map((record, index) => {
                index++;
            return (
                <tr key={record.id}>
                    <td>
                        {index}
                    </td>
                    <td>{record.client_name}</td>
                    <td>{record.email}</td>
                    <td className="status">
                        <label className="switch" htmlFor={`id_${record.client_name}`}>
                            <input type="checkbox" name={`id_${record.client_name}`} id={`id_${record.client_name}`} defaultChecked={record.active_flag}  onChange={(event)=> { this.onStatusUpdate(record.client_name, event.target.checked)}} />
                            <span className="slider"></span>
                        </label>
                    </td>
                    <td className="action">
                        <Link
                            to={`/lots-details/${record.client_name}`}
                            title="View"
                            title="Lots">
                            <i className="fa fa-map"></i>
                        </Link>
                        <Link
                            to={`/clients/${record.client_name}`}>
                            <i className="fa fa-pencil"></i>
                        </Link>
                        <a role="button" data-id={record.id} onClick={(e) => { const r = window.confirm("Are you sure you wish to delete this item?"); if(r == true){ this.onDelete(record.client_name) } }}  className="trash" title="Delete"><i className="fa fa-trash"></i></a>
                        {/*<Link
                            className="trash"
                            to={`/main/clients/delete/${record.id}`}
                            title="Delete">
                            <i className="fa fa-trash"></i>
                        </Link>*/}
                    </td>
                </tr>
            );
        });

        return (
            <div className="table-responsive">
                    <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th width="20">#</th>
                            <th className="stretch">Name</th>
                            <th className="stretch">Email</th>
                            <th className="status">Status</th>
                            <th className="action">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows}
                    </tbody>
                </table>
                {/*<UpdateForm
                    history={this.props.history}
                    location={this.props.location}
                    {...this.state.update}
                />*/}
            </div>
        );
    }
}

Results.propTypes = propTypes;


module.exports = Results;
