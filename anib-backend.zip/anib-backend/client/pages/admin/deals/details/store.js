'use strict';
const Delete = require('./reducers/delete');
const Redux = require('redux'); 
const TaskDetails = require('./reducers/task-details');
const DealBasicDetails = require('./reducers/deal-basic-details');
const dealDetails = require('./reducers/deal-details');
const common = require('./reducers/common');


module.exports = Redux.createStore(
    Redux.combineReducers({
        delete: Delete,
        taskDetails: TaskDetails,
        basicDetails: DealBasicDetails,
        dealDetails : dealDetails,
        common : common
    })
);
