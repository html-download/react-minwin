'use strict';
const Config = require('../../config');
const Async = require('async');

module.exports = {

    isEmpty: function (obj) {

        return !obj || Object.keys(obj).length === 0;
    },

    toTitleCase: function (str) {

    	try {
    		return str.split(/\s+/).map( s => s.charAt( 0 ).toUpperCase() + s.substring(1).toLowerCase() ).join( " " );
    	} catch (e) {
            //console.log(e.message);
            return null;
        }
    	
	},

 	toGetLetters: function (str, count) {

 		try {
	 		if (str.length === 0) {
	    		return '';
	    	}
	   		return str.substring(0, count);
	   	} catch (e) {
            //console.log(e.message);
            return null;
        }
	},

    wordTruncate(string, count) {
        
       if (string.length > count)
          return string.substring(0, count)+'...';
       else
          return string;
    },

    getOptionData(data, field_value, field_name, promt_value, is_promt = true ){
        
        if (!data) { 
            return [];
        }

        if (data.length === 0) { 
            return [];
        }
        
        let response = [];
        
        if (is_promt) {
            response.push({
                label: promt_value ? promt_value : 'Please Select',
                value: ''
            });
        }

        Async.forEachOf(data, (value, index, callback) => {

            return response.push({
                label: value[field_name] !== ' ' ? value[field_name] :  '--noname',
                value: value[field_value]
            });
        });        

        return response;
    },

    getModelYear(years = []){

        const model_year = (years.length <= 0) ?  Config.get('/modelYear') : years;

        let response = [];

        model_year.map((value, index) => {

            return response.push({
                label: value,
                value: value
            });
        });

        return response;
    },

    windowScroll(top = 0, left = 0, type = 'smooth') {

        window.scroll({
            top: top,
            left: left,
            behavior: type
        });
    },

    copyToClipboard(id) {

        /* Get the text field */
        var copyText = document.getElementById(id);

        /* Select the text field */
        copyText.select();

        /* Copy the text inside the text field */
        document.execCommand("copy");

        /* Alert the copied text */        
        return true;
    },


    getAccessTree() {
        
        return [
            { id: 'customer', name: 'Customers', hasChild: true, expanded: true, isChecked: false },
            { id: '2982650f-058c-428c-951d-de6ec5f742cd', pid: 'customer', name: 'Create', isChecked: false  },
            { id: 'fbcd1ad4-6156-4821-a2b2-a49af25245a2', pid: 'customer', name: 'List', isChecked: false  },
            { id: 'be3cc6be-64d5-4365-b06f-89b38f21bac3', pid: 'customer', name: 'Update', isChecked: false  },
            { id: '950536aa-c380-4e92-bb24-e5ef44569b49', pid: 'customer', name: 'Delete', isChecked: false },
            { id: 'enquiry', name: 'Enquiries', hasChild: true, expanded: false, isChecked: false },
            { id: 'ba99fa19-8e5c-4c30-abf6-432de7aba214', pid: 'enquiry', name: 'Create', isChecked: false  },
            { id: 'bed103bd-ee17-4793-aa5e-d56f61c3f0f3', pid: 'enquiry', name: 'List', isChecked: false  },
            { id: '39fcece6-b84d-43f0-beca-7be282f4dd5b', pid: 'enquiry', name: 'Update', isChecked: false  },
            { id: '935a3209-92dd-4c2f-86e5-6a31d711042e', pid: 'enquiry', name: 'Delete', isChecked: false },
            { id: 'policy', name: 'Policies', hasChild: true, expanded: false, isChecked: false },
            { id: 'e9c5a433-b1c2-424e-98e4-30975fe90d38', pid: 'policy', name: 'Create', isChecked: false  },
            { id: '71198037-edf0-4445-81bf-536dae4b7671', pid: 'policy', name: 'List', isChecked: false  },
            { id: '7b4f2569-f580-4619-a89e-1299a2644f01', pid: 'policy', name: 'Update', isChecked: false  },
            { id: 'c3f572a4-2883-4fcb-a5a5-1d21ea014a0e', pid: 'policy', name: 'Delete', isChecked: false },
            { id: 'task', name: 'Tasks', hasChild: true, expanded: false, isChecked: false },
            { id: '7cc4c34d-3e3b-4803-b337-7e0dcf6ca060', pid: 'task', name: 'Create', isChecked: false  },
            { id: '150d9771-2b44-46be-bd2e-4d1b88ab63c6', pid: 'task', name: 'List', isChecked: false  },
            { id: 'cdc03b1a-b93e-4183-88e7-f36e856f607d', pid: 'task', name: 'Update', isChecked: false  },
            { id: '618f9fa0-ae24-4a5b-a95c-50ae7cdd3692', pid: 'task', name: 'Delete', isChecked: false }
        ];
    },

    getUserTypes() {

        return [
            { label:'Super Admin', value: 1 },
            { label:'Admin', value: 2 },
            { label:'Agent', value: 3 },
            { label:'Lead Generator', value: 4 },
            { label:'Account Executive', value: 5 },
            { label:'Bill Collector', value: 6 },
            { label:'Technical Executive', value: 7 },
            { label:'Technical Manager', value: 8 }
        ]
    }
};
