const React = require('react');
const ReactHelmet = require('react-helmet');
const UserIdentity = require('../../../helpers/user-identity');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();

const PropTypes = require('prop-types');
const Actions = require('./actions.js');
const Store = require('./store');

const ObjectAssign = require('object-assign');

import Map from './Map';
import LotMap from './LotMap';

import LotList from './LotList.js';
import SlideToggle from './SlideToggle.js';
const LocationSearchInput = require('./auto-complete-form.jsx');

const Helmet = ReactHelmet.Helmet;

class LotsPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            'showSideNav': false,
            'apiKey': {'key': UserIdentity.googleApiKey},
            'center': {
                'lat': 32.593357,
                'lng': -85.495163
            },
            'zoom': 17,
            'mapHeight': 0,
            'mapWidth': 0,
            'markers': [],
            'user_markers': {},
            'current_markers': {},
            'isOpen' : false,
            isLot : true,
            show: false,
            selected : '', 
            selectedAddress: {},
            selectedLatLng:'',
            lots : [],
            percentage : 0,
            title : '', 
            color: '',
            distance_from_location : 0,
            lot_status : 1,
            overlay_coords_ne : "",
            isOverlayLoaded : true,
            clientMessageArray : [1]
        };

        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.toggleNav = this.toggleNav.bind(this);
        this.updateMapBounds = this.updateMapBounds.bind(this);
        this.editMapBounds = this.editMapBounds.bind(this);
        this.updateMapCenter = this.updateMapCenter.bind(this);
        this.setMarkers = this.setMarkers.bind(this);
        this.onNewClick = this.onNewClick.bind(this);
        this.onHide = this.onHide.bind(this);
        this.updateIsLot = this.updateIsLot.bind(this);
        this.mapViewFunction = this.mapViewFunction.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.onSubmitTerms = this.onSubmitTerms.bind(this);
        this.currentAddressGet = this.currentAddressGet.bind(this);
    }
    toggleNav() {
        this.setState({'showSideNav': !this.state.showSideNav})
    }

    updateMapCenter(center, zoom) {
        this.setState({center: null, zoom: null});
        this.setState({center: center, zoom: zoom});

    }

    updateMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    editMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    setMarkers(markers) {
        this.setState({'markers': markers});
    }
    handleChange (event) {
        if (UserIdentity._checkUserAddress() !== null) {
            this.setState({ selectedAddress :  UserIdentity._checkUserAddress().address});
        } else {
            this.setState({ selectedAddress :  ''});
        }
    }
    onChangeMap(checked) {
        localStorage.setItem(`isLot${UserIdentity._checkUserToken()}`, JSON.stringify(checked));
        /*for map view*/
        if (!checked ) {
            if (UserIdentity._checkCurrentAddress() !== null) {
                this.setState({'current_markers': {
                    'lat': parseFloat(UserIdentity._checkCurrentAddress().lat),
                    'lng': parseFloat(UserIdentity._checkCurrentAddress().lng),
                    'is_user':2,
                    lot_id: -1,
                    status: 1,
                    icon: 'marker_customer.png',
                    isOpen: false,
                    lot_name : 'search',
                    entrance_coords : `${parseFloat(UserIdentity._checkCurrentAddress().lat)},${parseFloat(UserIdentity._checkCurrentAddress().lng)}`,
                    percentage: 0,
                    color : '',
                    distance_from_location : 0,
                    title : 'You'
                }});
            }
            if (UserIdentity._checkUserAddress() !== null) {
                this.updateMapCenter({
                    'lat': UserIdentity._checkUserAddress().lat,
                    'lng': UserIdentity._checkUserAddress().lng
                }, 15)

                this.setState({'user_markers': {
                    'lat': parseFloat(UserIdentity._checkUserAddress().lat),
                    'lng': parseFloat(UserIdentity._checkUserAddress().lng),
                    'is_user':1,
                    lot_id: 0,
                    status: 1,
                    icon: 'marker_customer_des.png',
                    isOpen: false,
                    lot_name : 'search',
                    entrance_coords : `${parseFloat(UserIdentity._checkUserAddress().lat)},${parseFloat(UserIdentity._checkUserAddress().lng)}`,
                    percentage: 0,
                    color : '',
                    distance_from_location : 0,
                    title : 'Searched Area'
                }});
            } else {
                this.updateMapCenter({
                    'lat': 32.6032085,
                    'lng': -85.4923102
                }, 15)
            }
        } else {
            this.updateMapCenter({
                    'lat': 32.593357,
                    'lng': -85.495163
                }, 17)
        }
        this.setState({'isLot': checked});
        this.mapViewFunction(checked);
    }
    mapViewFunction (checked) {
        /*if its checked true then shows*/
        if (checked === false) {
            let url;
            if (UserIdentity._checkUserAddress() !== null) {
                url = `${this.params.fopark_url}/client/lots?name=auburn&sort_by_location=${parseFloat(UserIdentity._checkUserAddress().lat)},${parseFloat(UserIdentity._checkUserAddress().lng)}`
            } else {
                url = `${this.params.fopark_url}/client/lots?name=auburn`
            }
            fetch(url, {
                'headers': new Headers({
                    'X-api-key':  this.params.fopark_key
                })
            })
                .then(response => response.json())
                .then(
                    (result) => {
                        const markers = [];
                        if (UserIdentity._checkUserAddress() !== null) {
                            markers.push(this.state.user_markers);
                        }
                        if (UserIdentity._checkCurrentAddress() !== null) {
                            markers.push(this.state.current_markers);
                        }

                        result.lots.forEach((lot) => {
                            
                            let occupied = 0;
                            let total = 0;
                            let percentage = 0;
                            let color = '';
                            
                            let isZoneSelected = false;
                            Object.keys(lot.occupancy).map((zone) => {
                                let isZoneSelectedTemp = false;
                                if (zone !== 'undefined' && zone !== 'all') {
                                    isZoneSelectedTemp = localStorage.getItem(`${zone}_selected`);

                                    let zoneColor = 'rgb(211, 170, 23)';
                                    switch(zone){
                                        case 'a':
                                            zoneColor = 'rgb(232, 228, 2)';
                                            break;
                                        case 'b':
                                            zoneColor = 'rgb(69, 255, 25)';
                                            break;
                                        case 'c':
                                            zoneColor = 'rgb(1, 34, 112)';
                                            break;
                                        case 'ada':
                                            zoneColor = 'rgb(18, 90, 214)';
                                            break;
                                        default:
                                            zoneColor = 'rgb(211, 170, 23)';
                                            break;
                                    }

                                    if (typeof isZoneSelectedTemp === 'string' && !isZoneSelected) {
                                        if (isZoneSelectedTemp === 'false') {
                                            isZoneSelected = false;
                                        } else {
                                            isZoneSelected = true;
                                        }
                                    }
                                    if (isZoneSelectedTemp === null && !isZoneSelected) {
                                        isZoneSelected = true;
                                    }
                                    
                                    /*if ((isZoneSelectedTemp === null) || isZoneSelectedTemp === 'true') {
                                        occupied += lot.occupancy[zone][1];
                                        total += lot.occupancy[zone][2] - lot.occupancy[zone][1] - lot.occupancy[zone][3] + occupied;
                                        percentage = Math.ceil((occupied / total) * 100);
                                    }*/
                                    /*if (isZoneSelected) {
                                        occupied += lot.occupancy[zone][1];
                                        total += lot.occupancy[zone][2];
                                        percentage = Math.floor((occupied / total) * 100);
                                    }*/
                                    if ((isZoneSelectedTemp === null) || isZoneSelectedTemp === 'true') {
                                        occupied += lot.occupancy[zone][1];
                                        total += lot.occupancy[zone][2] - lot.occupancy[zone][3];
                                        percentage = Math.ceil((occupied / total) * 100);
                                    }
                                }
                            })
                            
                            let icon;
                            if (percentage >= 95) {
                                icon = 'map_view_red.png';
                                color = 'rgb(237, 35, 40)';
                            }
                            else if (percentage >= 85 && percentage < 95) {
                                icon = 'map_view_orange.png';
                                color = 'rgb(255, 165, 0)';
                            }
                            else {
                                icon = 'map_view_green.png';
                                color = 'rgb(0, 128, 0)';
                            }

                            if (!lot.status) {
                                icon = 'map_view_orange.png';
                                color = '#f77f28';
                            }
                            
                            if (lot.entrance_coords !== null) {
                                var [lat, lng] = lot.entrance_coords.split(',');
                            } else {
                                let entrance_coords = `${this.state.center.lat},${this.state.center.lng}`;
                                var [lat, lng] = entrance_coords.split(',');
                            }
                            if(isZoneSelected) {
                                markers.push({
                                    lat: parseFloat(lat),
                                    lng: parseFloat(lng),
                                    is_user: false,
                                    lot_id: lot.id,
                                    status: lot.status,
                                    icon: icon,
                                    isOpen: false,
                                    lot_name : lot.lot_name,
                                    entrance_coords : lot.entrance_coords,
                                    percentage: percentage,
                                    title: lot.title,
                                    color : color,
                                    distance_from_location : lot.distance_from_location
                                });
                            }
                        });
                        this.setMarkers(markers);
                        this.setState({
                            lots: result.lots
                        });
                    },
                    (error) => {
                        /*this.setState({
                            error
                        });*/
                    }
                );
        } else {

        }
    }
    componentDidMount() {
        this.setState({'mapHeight': window.innerHeight, 'mapWidth': window.innerWidth});
        if (this.state.center && this.state.zoom) {
            this.updateMapCenter(this.state.center, this.state.zoom);
        }
        if (UserIdentity._checkAcceptTerms() === false) {
            $('#terms_condition').css('display', 'block');
        } 

        if (this.state.clientMessageArray.length >= 0) {
            //$('#client_message').css('display', 'block');
        } 
        
        
    }
    updateIsLot() {
        //$("#hybrid").prop('checked', UserIdentity._checkIsLot())
        //this.setState({'isLot': UserIdentity._checkIsLot()});
    }
    onNewClick(event, lot_name, LatLng, title, percentage, color, lot_status) {
        let address = {};

        this.setState({
            show: true,
            selected : lot_name,
            selectedAddress : address,
            selectedLatLng : LatLng,
            title : title,
            percentage : percentage,
            color : color, 
            lot_status : lot_status,
        });

        //Actions.showCreateNewMap(lot_name, address, LatLng);
    }
    onHide(event) {
        let address = {};

        this.setState({
            show: false,
            selected : '',
            selectedAddress : address,
            selectedLatLng : ''
        });

        //Actions.showCreateNewMap(lot_name, address, LatLng);
    }
    onSubmitTerms(event) {
        if ($('#agree').prop('checked')) {
            localStorage.setItem(`terms_${UserIdentity._checkUserToken()}`, JSON.stringify(true));
            $('#terms_condition').css('display', 'none');
        } else {
            Toaster.error('Please accept terms and conditions!')
        }
    }
    currentAddressGet () {
        $('.cur_loc span').click();
        if (UserIdentity._checkCurrentAddress() !== null) {
            this.updateMapCenter({
                'lat': UserIdentity._checkCurrentAddress().lat,
                'lng': UserIdentity._checkCurrentAddress().lng
            }, 15)
        }
    }
    render() {
        return (
            <div className="content-wrapper" id="lots">
                
                <Helmet>
                    <title>Welcome to AU Parking</title>
                </Helmet>
                {(this.state.isLot) ? (
                    <section className="content">
                        <LotList />
                        <Map
                            markers={this.state.markers}
                            center={this.state.center}
                            zoom={this.state.zoom}
                            {...this.state}
                        />
                    </section>
                ) : (
                    <section className="content">
                        <LotMap
                            onNewClick={this.onNewClick}
                            onHide={this.onHide}
                            markers={this.state.markers}
                            center={this.state.center}
                            show={this.state.show}
                            zoom={15}
                            selected={this.state.selected}
                            createNew={this.state.createNew}
                            title={this.state.title}
                            percentage={this.state.percentage}
                            color={this.state.color}
                            lot_status={this.state.lot_status}
                            distance_from_location={this.state.distance_from_location}
                            selectedLatLng = {this.state.selectedLatLng}
                            currentAddressGet = {this.currentAddressGet}
                        />
                    </section>
                )}
                
                
                <div className="lot_view">
                        <label className="switch1 custom">
                          <input type="checkbox" id='hybrid' name="hybrid" type="checkbox" className="hide" defaultChecked={true} onChange={(event) => {this.onChangeMap(event.target.checked) }} />
                          <span className="slider1 round" htmlFor='hybrid'></span>
                        </label>
                        <a onClick={this.handleChange} className="btn loc-btn" data-target="#location_modal" data-toggle="modal"><i className="fa fa-search" aria-hidden="true"></i> Lots near destination</a> 
                        
                        <a onClick={() => {window.open("https://s3.amazonaws.com/auburntigers.com/documents/2019/7/25/Football_Parking_Website_2019.pdf", "", "width=500,height=500")}} className="btn game-day-btn" role="button" target="_blank">
                            <img src="/public/media/images/game-day.png" alt="game-day" /> 
                            Game day parking rules
                        </a> 
                </div>

                <div className="modal right fade" id="location_modal" tabIndex="-1" role="dialog" aria-labelledby="myModalLabel2">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header">
                                <button type="button" className="close" data-dismiss="modal">&times;</button>
                                <h4 className="modal-title">Enter destination to find closest lots</h4>
                            </div>
                            <div className="modal-body">
                                <SlideToggle />
                            </div>

                        </div>
                    </div>
                </div>
                <div id="terms_condition" style={{'display': 'none' }} className="modal custom" tabIndex="-1" role="dialog">
                    <div className="modal-dialog modal-sm" >
                        <div className="modal-content" >
                            <div className="modal-body" >
                                <img src="/public/media/images/logo1.png" alt="" />
                                <div className="terms">
                                    <h3>AUPARKING</h3>
                                    <p>Just one thing before you continue.Using a smartphone and driving is not safe - please check AU Parking before you go. or right after you arrive</p>
                                    <div className="form-group">
                                    <input id="agree" name="checkbox" type="checkbox" className="hide" />
                                    <label htmlFor="agree" className="checkbox" >I agree not to use AU Parking while driving</label>
                                    </div>
                                    <a className="btn orange" onClick={() => {this.onSubmitTerms()}}>CONTINUE</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="client_message" style={{'display': 'none' }} className="modal custom" tabIndex="-1" role="dialog">
                    <div className="modal-dialog modal-sm" >
                        <div className="modal-content" >
                            <div className="modal-body" >
                                <img src="/public/media/images/logo1.png" alt="" />
                                <div className="terms">
                                    <h3>AUPARKING</h3>
                                    <p>Just one thing before you continue.Using a smartphone and driving is not safe - please check AU Parking before you go. or right after you arrive</p>
                                    <div className="form-group">
                                    <input id="agree" name="checkbox" type="checkbox" className="hide" />
                                    <label htmlFor="agree" className="checkbox" >I agree not to use AU Parking while driving</label>
                                    </div>
                                    <a className="btn orange" >CONTINUE</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}


module.exports = LotsPage;
