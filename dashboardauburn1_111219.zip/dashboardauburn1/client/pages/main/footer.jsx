const React = require('react');
const ReactRouter = require('react-router-dom');
const ToasterContainer = require('../../components/toaster.jsx');
const Toaster = new ToasterContainer();

const Link = ReactRouter.Link;

class Footer extends React.Component {
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick(event) {
        Toaster.error('check!');
        /*console.log($('#asda').val())
        console.log('Click happened');*/
    }
    render() {
        const year = new Date().getFullYear();

        return (
            <footer className="site_footer full_row wow fadeIn">
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12">
                            <ul className="reset copyright wow fadeInUp">
                                <li>&#169; {year}. FoPark   </li>
                            </ul>
                        </div>
                        
                    </div>
                </div> 
            </footer>
            
        );
    }
}


module.exports = Footer;
