<?php



if ( get_magic_quotes_gpc() ) {



    $_POST      = array_map( 'stripslashes_deep', $_POST );



    $_GET       = array_map( 'stripslashes_deep', $_GET );



    $_COOKIE    = array_map( 'stripslashes_deep', $_COOKIE );



    $_REQUEST   = array_map( 'stripslashes_deep', $_REQUEST );



}



$options = array (



 



	array( "name" => "General Settings",



			"type" => "title"),



	 



	array( "type" => "open"),



	



	array( "name" => "Header Logo",



		"desc" => "Enter the Logo URL",



		"id" => "logo",



		"type" => "text",



		"std" => ""),	



	



	array( "name" => "Google Analytics Code",



		"desc" => "Copy & Paste your Google Analytics Code here",



		"id" => "analytics",



		"type" => "textarea",



		"std" => ""),	



	



	array( "type" => "close"),	



	



	array( "name" => "Title Settings",



			"type" => "title"),



	 



	array( "type" => "open"),	



	



	array( "name" => "Home Page Meta Title",



		"desc" => "Enter the Home Page Title here",



		"id" => "htitle",



		"type" => "text",



		"std" => ""),



	



	array( "name" => "Home Page Meta Keywords",



		"desc" => "Enter the Home Page Keywords here",



		"id" => "hkeywords",



		"type" => "text",



		"std" => ""),



		



	array( "name" => "Home Page Meta Description",



		"desc" => "Enter the Home Page Description here",



		"id" => "hdescription",



		"type" => "textarea",



		"std" => ""),



		



	array( "type" => "close"),	



	



	



	



	



	



		array( "name" => "Header Settings",



			"type" => "title"),



	



	 



	array( "type" => "open"),	



	



	array( "name" => "Enter Email id",



		"desc" => "Enter Email id",



		"id" => "email_id",



		"type" => "text",



		"std" => ""),







	array( "name" => "Enter Phone Number",



		"desc" => "Enter the phone",



		"id" => "enter_phone",



		"type" => "text",



		"std" => ""),


	array( "type" => "close"),	
	

array( "name" => "Footer Contact Settings",



			"type" => "title"),



	 



	array( "type" => "open"),

	

		array( "name" => "Enter Location",



		"desc" => "Enter Location.",



		"id" => "location_footer",



		"type" => "textarea",



		"std" => ""),					



	array( "name" => "Enter Mobile Number",



		"desc" => "Enter Mobile Number",



		"id" => "ftr_mobile",



		"type" => "text",



		"std" => ""),
		
		
		
			array( "name" => "Enter Opening Time",



		"desc" => "Enter Opening time",



		"id" => "ftr_time",



		"type" => "text",



		"std" => ""),
		

	

array( "type" => "close"),	



	array( "name" => "Social Settings",



			"type" => "title"),



	 



	array( "type" => "open"),



	



	array( "name" => "Facebook",



		"desc" => "Enter your Facebook Id.",



		"id" => "facebook",



		"type" => "text",



		"std" => ""),					







	array( "name" => "Twitter",



		"desc" => "Enter your twitter Id.",



		"id" => "tweet",



		"type" => "text",



		"std" => ""),



	



		array( "name" => "Google Plus",



		"desc" => "Enter your twitter Id.",



		"id" => "googleplus",



		"type" => "text",



		"std" => ""),	



		







	array( "name" => "Linked In",



		"desc" => "Enter your Linked In Id.",



		"id" => "linkedin",



		"type" => "text",



		"std" => ""),



			



		



	



				



		



);







if ( 'save' == $_REQUEST['action'] ) {



	foreach ($options as $value) {



		if( $_REQUEST[ $value['id'] ] == '' ) {



			designpixi_update_option( $value['id'], ' ' );



		} else {



			if ( is_array($_REQUEST[ $value['id'] ]) ) {



				$cats = "-1";



				foreach($_REQUEST[ $value['id'] ] as $cat){



					$cats .= "," . $cat;



				}



				designpixi_update_option( $value['id'], str_replace("-1,", "", $cats) );



			}



			else { designpixi_update_option( $value['id'], stripslashes($_REQUEST[ $value['id'] ]) ); }



		}



	}







} else if( 'reset' == $_REQUEST['action'] ) {



	foreach ($options as $value) {



		delete_option( $value['id'] ); 



	}



}







$i = 0; 



if ( $_REQUEST['action'] == 'save' ) echo '<div id="message" class="updated fade"><p><strong>' . DesignPixi_THEMENAME . ' settings saved.</strong></p></div>'; 



?>

<div class="wrap rm_wrap">
<div id="icon-options-general" class="icon32"></div>
<h2><?php echo DesignPixi_THEMENAME ?> Settings</h2>
<br />
<form method="post">
  <div class="rm_opts">
    <?php foreach ($options as $value) {



            











            switch ( $value['type'] ) {



             



            case "open":



            ?>
    <?php break;



             



            case "close":



            ?>
  </div>
  </div>
  <br />
  <?php break;	case "title":	$i++;	?>
  <div class="rm_section">
  <div class="rm_title">
    <h3><img src="<?php echo DesignPixi_ADMIN_IMAGES . '/trans.png' ?>" class="inactive" alt=""><?php echo $value['name']; ?></h3>
    <span class="submit">
    <input name="save<?php echo $i; ?>" type="submit" value="Save changes" />
    </span>
    <div class="clearfix"></div>
  </div>
  <div class="rm_option" >
  <?php break;	case 'text':?>
  <div class="rm_input rm_text">
    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
    <input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( designpixi_get_option( $value['id'] ) != "") { echo stripslashes(designpixi_get_option( $value['id'])  ); } else { echo $value['std']; } ?>" style="width: 415px; border-color: #ccc;" />
    <small><?php echo $value['desc']; ?></small>
    <div class="clearfix"></div>
  </div>
  <?php break;	case 'image':  ?>
  <div class="rm_input rm_text">
    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
    <input type="text" name="<?php echo $value[ 'id' ] ?>" id="<?php echo $value[ 'id' ] ?>" value="<?php if ( designpixi_get_option( $value['id'] ) != "") { echo stripslashes(designpixi_get_option( $value['id'])  ); } else { echo $value['std']; } ?>" style="width: 415px; border-color: #ccc;" />
    <?php echo	'<input type="button" id="button' . $meta_box[ 'id' ] . '" value="Browse" style="width: 60px;" class="button button-designpixi-upload" rel="' . $post->ID . '" />';?> <small><?php echo $value['desc']; ?> </small>
    <div class="clearfix"></div>
  </div>
  <?php	break;	case 'textarea':?>
  <div class="rm_input rm_textarea">
    <label for="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></label>
    <textarea name="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( designpixi_get_option( $value['id'] ) != "") { echo stripslashes(designpixi_get_option( $value['id']) ); } else { echo $value['std']; } ?>



</textarea>
    <small><?php echo $value['desc']; ?></small>
    <div class="clearfix"></div>
  </div>
  <?php break;



            }



            }



            ?>
  <input type="hidden" name="action" value="save" />
</form>
</div>
</div>
<?php 



/**



 * Returns the value of an option from the db if it exists.



 */



function designpixi_get_option( $name ) {



	$options = get_option( DesignPixi_THEMEOPTIONS );



	if ( isset($options[$name]) ) {



		return $options[$name];



	} else {



		return false;



	}



}



/**



 * Updates/Adds an option to the options db.



*/



function designpixi_update_option( $name, $value ) {



	$options = get_option( DesignPixi_THEMEOPTIONS );



	if ( $options and !isset($options[$name]) ) { // Adds new value...



		$options[$name] = $value;



		return update_option( DesignPixi_THEMEOPTIONS, $options );



	} else {



		if ( $value != $options[$name] ) { // ...or updates it



			$options[$name] = $value;



			return update_option( DesignPixi_THEMEOPTIONS, $options );



		} else {



			return false;



		}



	}



}



?>
