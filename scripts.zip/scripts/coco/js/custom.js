// sticky sidebar



  $('[data-toggle="popover"]').popover();
  $('[data-toggle="tooltip"]').tooltip();
  // header scroll
  $(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 2) {
      $("header").addClass("white");
    }
    else {
      $("header").removeClass("white");
    }
  });
  $('.modal').on('hidden.bs.modal', function(e) {
    if ($('.modal').hasClass('show')) {
      $('body').addClass('modal-open');
    }
  });
  // $("body").removeClass("modal-open");
  // scroll nav
  // word limit
 /* $(document).ready(function() {
    var maxLength = 70;
    $(".show-read-more").each(function() {
      var myStr = $(this).text();
      if ($.trim(myStr).length > maxLength) {
        var newStr = myStr.substring(0, maxLength);
        var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
        $(this).empty().html(newStr);
        $(this).append(' <a href="javascript:void(0);" class="read-more">read more...</a>');
        $(this).append('<span class="more-text">' + removedStr + '</span>');
      }
    });
    $(".read-more").click(function() {
      $(this).siblings(".more-text").contents().unwrap();
      $(this).remove();
    });
  });*/
  // remove
  // date picker
  $(".datepicker").datepicker({
    format: 'yyyy-mm-dd',
    startView: "2",
    getDate: true,
    autoHide: true
  });
  // change password
  $("#changepassword").change(function() {
    if ($(this).prop('checked')) {
      $(".show-hide").addClass("open");
    }
    else {
      $(".show-hide").removeClass("open");
    }
  });
  // menu toggle


  // close responsive
  $(".header-menu-toggle, .close-header-menu, .navigation a, .menu_overlay_menu").click(function() {
    $(".navigation").toggleClass('open');
    $(".header-menu-toggle").toggleClass('open');
    $("body").toggleClass('overflow');
    $(".menu_overlay_menu").toggleClass('open');
  });
  // side menu
  $(".menu-toggle").click(function() {
    $(".sidebar-navigation").addClass('open');
    $("body").addClass('overflow');
    $(".side-menu-items-overlay").addClass('open');
  });
  $(".sidebar-navigation ul li a, .sidebar-navigation h4, .side-menu-items-overlay").click(function() {
    $(".sidebar-navigation").removeClass('open');
    $("body").removeClass('overflow');
    $(".side-menu-items-overlay").removeClass('open');
  });
  // sidemenu links close
  $(".cart-toggle").click(function() {
    $(".cart-mini-mobile").addClass('open');
    $("body").addClass('overflow');
    $(".cart-overlay ").addClass('open');
  });
  $(".cart-mini-mobile h3, .cart-overlay, .cart-close").click(function() {
    $(".cart-mini-mobile").removeClass('open');
    $("body").removeClass('overflow');
    $(".cart-overlay").removeClass('open');
  });
  // Cache selectors
  var lastId,
    topMenu = $(".cl_to_scroll li"),
    topMenuHeight = topMenu.outerHeight() + 75,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function() {
      var item = $($(this).attr("href"));
      if (item.length) {
        return item;
      }
    });
  // Bind click handler to menu items
  // so we can get a fancy scroll animation
  menuItems.click(function(e) {
    var href = $(this).attr("href"),
      offsetTop = href === "#" ? 0 : $(href).offset().top - topMenuHeight + 0;
    $('html, body').stop().animate({
      scrollTop: offsetTop
    }, 300);
    e.preventDefault();
  });
  // Bind to scroll
  $(window).scroll(function() {
    // Get container scroll position
    var fromTop = $(this).scrollTop() + topMenuHeight + 75;
    // Get id of current scroll item
    var cur = scrollItems.map(function() {
      if ($(this).offset().top < fromTop)
        return this;
    });
    // Get the id of the current element
    cur = cur[cur.length - 1];
    var id = cur && cur.length ? cur[0].id : "";
    if (lastId !== id) {
      lastId = id;
      // Set/remove active class
      menuItems
        .parent().removeClass("active")
        .end().filter("[href='#" + id + "']").parent().addClass("active");
    }
  });

// listing fixed
$(window).scroll(function() {
  if ($(window).scrollTop() >= 300) {
    $('.listing-restaurant-filters').addClass('fixed');
  }
  else {
    $('.listing-restaurant-filters').removeClass('fixed');
  }
});
// search scroll to top
$(".listing-restaurant-filters .search-list").click(function() {
  $("html, body").animate({
    scrollTop: 0
  }, "slow");
  return false;
});
// location focus
$('#change-location').on('shown.bs.modal', function() {
  $('.search-location input').focus();
});
// loader
$('.loader').on('click', function() {
  var $this = $(this);
  var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> loading...';
  if ($(this).html() !== loadingText) {
    $this.data('original-text', $(this).html());
    $this.html(loadingText);
  }
  setTimeout(function() {
    $this.html($this.data('original-text'));
  }, 2000);
});
// loader
$('.loader-2').on('click', function() {
  var $this = $(this);
  var loadingText = '';
  if ($(this).html() !== loadingText) {
    $this.data('original-text', $(this).html());
    $this.html(loadingText);
    $this.addClass("loader-image");
  }
  setTimeout(function() {
    $this.html($this.data('original-text'));
  }, 500);
  setTimeout(function() {
    $this.removeClass("loader-image");
  }, 500);
});
// modal loader
$('.modal').on('shown.bs.modal', function() {
  $('.modal-dialog').addClass("loaders");
  setTimeout(function() {
    $('.modal-dialog').removeClass("loaders")
  }, 500);
});
// pagination
$(document).ready(function() {
  var list = $(".loadmore-page li");
  var numToShow = 5;
  var button = $(".loading");
  var numInList = list.length;
  list.hide();
  if (numInList > numToShow) {
    button.show();
  }
  else {
    button.hide();
  }
  list.slice(0, numToShow).show();
  button.click(function() {
    var showing = list.filter(':visible').length;
    list.slice(showing - 1, showing + numToShow).fadeIn();
    var nowShowing = list.filter(':visible').length;
    if (nowShowing >= numInList) {
      button.hide();
    }
  });
});
// active class dynamic
$(document).ready(function() {
  $(".navigation [href]").each(function() {
    if (this.href == window.location.href) {
      $(this).addClass("active");
    }
  });
});
// equal height
// equl height
;
(function($, window, document, undefined) {
  'use strict';
  var $list = $('.address_list_check'),
    $items = $list.find('.address_list'),
    setHeights = function() {
      $items.css('height', 'auto');
      var perRow = Math.floor($list.width() / $items.width());
      if (perRow == null || perRow < 2) return true;
      for (var i = 0, j = $items.length; i < j; i += perRow) {
        var maxHeight = 0,
          $row = $items.slice(i, i + perRow);
        $row.each(function() {
          var itemHeight = parseInt($(this).outerHeight());
          if (itemHeight > maxHeight) maxHeight = itemHeight;
        });
        $row.css('height', maxHeight);
      }
    };
  setHeights();
  $(window).on('resize', setHeights);
})(jQuery, window, document);
// footer closepanel
$("footer .col-sm-3 h3").click(function() {
  $(this).parent().toggleClass('open');
});
// type click new
$('.form-icon input:text').click(
  function() {
    $(this).val('');
  });
// sticky responsive size
// filter
$('.mobile-filter').on('click', function() {
  var text = $(".mobile-filter i").text() === 'filter_list' ? 'clear' : 'filter_list';
  $(".mobile-filter i").text(text);
  $(".sort-options").toggleClass('show');
});
$(document).ready(function() {



      // sticky         


  // Optimalisation: Store the references outside the event handler:
  var $window = $(window);

  function checkWidth() {
    var windowsize = $window.width();
    if (windowsize > 1023) {

      // sticky
      $('.cart-mini').stickySidebar({
      topSpacing: 88,
      bottomSpacing: 30,
      innerWrapperSelector: '.menu_width',
      });

        // sticky
      $('.sub_menu').stickySidebar({
      topSpacing: 88,
      bottomSpacing: 30,
      innerWrapperSelector: '.menu-tab',
      });  

       $('#filter-form').stickySidebar({
      topSpacing: 88,
      bottomSpacing: 0,
      innerWrapperSelector: '.owl-padd',
      });     


    }
  }
  // Execute on load
  checkWidth();

  // Bind event listener
  $(window).resize(checkWidth);

  $('.home-innercate').owlCarousel({
    lazyLoad: true,
    items: 5,
    autoplay: true,
    nav: true,
    dots: true,
    responsive: {
      0: {
        items: 1,
        nav: true
      },
      600: {
        items: 3,
        nav: false
      },
      1000: {
        items: 4,
        nav: true,
        loop: false
      }
    },
    loop: false,
    navText: ["<i class='material-icons'>chevron_left</i>", "<i class='material-icons'>chevron_right</i>"]
  });
  $('.popu-cate').owlCarousel({
    lazyLoad: true,
    items: 4,
    autoplay: true,
    margin: 25,
    nav: true,
    dots: false,
    loop: false,
    responsive: {
      0: {
        items: 1,
        nav: true
      },
      600: {
        items: 3,
        nav: false
      },
      1000: {
        items: 4,
        nav: true,
        loop: false
      },
    },
    navText: ["<i class='material-icons'>chevron_left</i>", "<i class='material-icons'>chevron_right</i>"]
  });
  // equl height
  (function($, window, document, undefined) {
    'use strict';
    var $list = $('.myaccount'),
      $items = $list.find('.address_list'),
      setHeights = function() {
        $items.css('height', 'auto');
        var perRow = Math.floor($list.width() / $items.width());
        if (perRow == null || perRow < 2) return true;
        for (var i = 0, j = $items.length; i < j; i += perRow) {
          var maxHeight = 0,
            $row = $items.slice(i, i + perRow);
          $row.each(function() {
            var itemHeight = parseInt($(this).outerHeight());
            if (itemHeight > maxHeight) maxHeight = itemHeight;
          });
          $row.css('height', maxHeight);
        }
      };
    setHeights();
    $(window).on('resize', setHeights);
  })(jQuery, window, document);

});
//Overflow Menu
window.onresize = navigationResize;
navigationResize();
function navigationResize() {
  $('.sub_menu ul li.more').before($('#overflow > li'));
  var $navItemMore = $('.sub_menu ul > li.more'),
    $navItems = $('.sub_menu ul > li:not(.more)'),
    navItemMoreWidth = navItemWidth = $navItemMore.width(),
    windowWidth = $(".sub_menu").width(),
    navItemMoreLeft, offset, navOverflowWidth;
  $navItems.each(function() {
    navItemWidth += $(this).width();
  });
  navItemWidth > windowWidth ? $navItemMore.show() : $navItemMore.hide();
  while (navItemWidth > windowWidth) {
    navItemWidth -= $navItems.last().width();
    $navItems.last().prependTo('#overflow');
    $navItems.splice(-1, 1);
  }
  navItemMoreLeft = $('.sub_menu ul .more').offset().left;
  navOverflowWidth = $('#overflow').width();
  offset = navItemMoreLeft + navItemMoreWidth - navOverflowWidth;
}
// listing fixed
// $(window).scroll(function() {
//   if ($(window).scrollTop() >= 500) {
//     $('.sub_menu').addClass('sub-menu-fixed');
//   }
//   else {
//     $('.sub_menu').removeClass('sub-menu-fixed');
//   }
// });

// equal height
// equl height
;( function( $, window, document, undefined )
{
'use strict';

var $list = $( '.custom_row ul' ),
$items = $list.find( 'li' ),
setHeights = function()
{
$items.css( 'height', 'auto' );

var perRow = Math.floor( $list.width() / $items.width() );
if( perRow == null || perRow < 2 ) return true;

for( var i = 0, j = $items.length; i < j; i += perRow )
{
var maxHeight = 0,
$row = $items.slice( i, i + perRow );

$row.each( function()
{
var itemHeight = parseInt( $( this ).outerHeight() );
if ( itemHeight > maxHeight ) maxHeight = itemHeight;
});
$row.css( 'height', maxHeight );
}
};


setHeights();
$( window ).on( 'resize', setHeights );


})( jQuery, window, document );