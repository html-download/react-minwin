import React, {Component} from 'react';

class Lot extends Component {
    constructor(props){
        super(props);
        
        this.state = {
            error: null,
            isLoaded: false,
            lot: {},
            available: 0,
            occupied: 0,
            noData: 0,
            reserved: 0
        };
        this.params = {
            //fopark_url: 'http://localhost:5001',
            fopark_url: 'https://api6.fopark-api.com',
            fopark_key: 'd5a3c692930824c95141fb18c07fe2102b3a0c96af4227f5'
        };
        this.updateOccupancy = this.updateOccupancy.bind(this);
    }

    updateOccupancy(){
        fetch(`${this.params.fopark_url}/lot/occupancy?client_name=auburn&name=${this.props.match.params.lotID}`, {
            'headers': new Headers({
                'X-api-key': this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    let lot_name = result.lot_name
                    const markers = [];
                    const disabledZones = [];
                    this.setState({
                        available: 0,
                        occupied: 0,
                        noData: 0,
                        reserved: 0
                    });
                    for(let zone in localStorage){
                        if(localStorage.hasOwnProperty(zone)){
                            const zoneValue = localStorage.getItem(zone);
                            if(zoneValue === 'false'){
                                disabledZones.push(zone);
                            }
                        }
                    }
                    result.lot_status.forEach((stall) => {
                        const [lat, lng] = stall.coords.split(',');
                        const reserved = stall.reserve_flag;
                        let icon;
                        switch(stall.status){
                            case 0:
                                icon = 'green.png';
                                break;
                            case 1:
                                icon = 'red.png';
                                break;
                            default:
                                icon = 'orange.png';
                                break;
                        }
                        if(reserved){
                            icon = 'purple.png';
                        }
                        if(stall.zone === 'ada'){
                            icon = 'green-blue.png';
                        }
                        if(!disabledZones.includes(`${stall.zone}_selected`)){
                            markers.push({
                                stallNumber: stall.stall_num,
                                lat: parseFloat(lat),
                                lng: parseFloat(lng),
                                reserved: reserved,
                                status: stall.status,
                                icon: icon,
                                isOpen: false,
                                lot_name : lot_name
                            });
                            if(stall.status === 0 && !reserved){
                                this.setState({
                                    available: this.state.available + 1
                                });
                            } else if (stall.status === 1){
                                this.setState({
                                    occupied: this.state.occupied +1
                                });
                            } else if (stall.status === 2){
                                this.setState({
                                    noData: this.state.noData +1
                                });
                            } else if (reserved){
                                this.setState({
                                    reserved: this.state.reserved +1
                                });
                            }
                        }
                    });

                    this.props.setMarkers(markers);
                },
                (error) => {

                }
            )
    }

    componentDidMount(){
        console.log("props");
        fetch(`${this.params.fopark_url}/lot/summary?client_name=auburn&name=${this.props.match.params.lotID}`, {
            'headers': new Headers({
                'X-api-key': this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    this.setState({
                        isLoaded: true,
                        lot: result.occupancies
                    });
                    console.log(this.state.lot)
                    const [neLat, neLng] = this.state.lot.overlay_coords_ne.split(',');
                    const [swLat, swLng] = this.state.lot.overlay_coords_sw.split(',');
                    const bounds = {
                        'ne': {
                            'lat': neLat,
                            'lng': neLng
                        },
                        'sw': {
                            'lat': swLat,
                            'lng': swLng
                        }
                    };
                    this.props.updateMapBounds(bounds.ne, bounds.sw);
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            );
        this.interval = setInterval(
            () => {
                this.updateOccupancy();
            }, 15000
        );
        this.updateOccupancy();
    }

    componentWillUnmount(){
        clearInterval(this.interval);
    }

    render() {
        const { error, isLoaded, lot} = this.state;

        if(error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if(!isLoaded) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else {
            return (
                <div className="my-3 p-3 bg-white rounded box-shadow" style={{
                    position: 'absolute',
                    //top: '1rem',
                    left: 0,
                    margin: '1rem 1rem'
                }}>
                    <h6 className="border-bottom border-gray pb-2 mb-0">
                        <div>{lot.title}</div>
                    </h6>
                    <em>This lot <span style={{color: '#00f'}}>requires a permit</span></em>
                    <ul style={{
                        listStyle: 'none',
                        margin: 0,
                        padding: 0,
                        fontSize: '14px'
                    }}>
                        {this.state.available > 0 ? <li>&nbsp;<img src='/images/icons/green.png' alt=''/>&nbsp;Available:&nbsp;<span>{this.state.available}</span> </li> : null }
                        {this.state.occupied > 0 ? <li>&nbsp;<img src='/images/icons/red.png' alt=''/>&nbsp;Occupied:&nbsp;<span>{this.state.occupied}</span> </li> : null }
                        {this.state.reserved > 0 ? <li>&nbsp;<img src='/images/icons/purple.png' alt=''/>&nbsp;Reserved:&nbsp;<span>{this.state.reserved}</span> </li> : null }
                        {this.state.noData > 0 ? <li>&nbsp;<img src='/images/icons/orange.png' alt=''/>&nbsp;No Data:&nbsp;<span>{this.state.noData}</span> </li> : null }
                    </ul>
                    <a href={`https://www.google.com/maps/dir//${lot.entrance_coords}`} target="_blank" rel="noopener">Directions</a>
                </div>
            )
        }
    }
}

export default Lot;