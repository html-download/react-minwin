<?php include ('../inc/header.php'); ?>

<section class="page_banner">
  <div class="container">
    <h1 class="animated fadeInDown">Our Client's Feedback</h1>
    <p class="desc animated fadeInUp mb0">Technoduce is proud of its client relationships. A large part of our success is owed to the trust they have placed upon us. View what some of them have to say</p>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="testimonial_video blue full_row">
  <div class="container">
    <ul class="boxes reset col4">
      <li>
        <div class="box">
          <div class="img">          
            <amp-img src="<?php echo $baseurl;?>images/testimonial/img1.jpg" alt="ISO" width="400" height="260" layout="responsive"></amp-img>
            <a on="tap:video1"><i class="fa fa-play"></i></a>
          </div>
          <div class="content">
            <h3>Client Name</h3>
            <p>United Status</p>
          </div> <!--box-->
        </div> <!--box-->
      </li>
      <li>
        <div class="box">
          <div class="img">          
            <amp-img src="<?php echo $baseurl;?>images/testimonial/img2.jpg" alt="ISO" width="400" height="260" layout="responsive"></amp-img>
            <a on="tap:video2"><i class="fa fa-play"></i></a>
          </div>
          <div class="content">
            <h3>Client Name</h3>
            <p>United Status</p>
          </div> <!--box-->
        </div> <!--box-->
      </li>
      <li>
        <div class="box">
          <div class="img">          
            <amp-img src="<?php echo $baseurl;?>images/testimonial/img3.jpg" alt="ISO" width="400" height="260" layout="responsive"></amp-img>
            <a on="tap:video3"><i class="fa fa-play"></i></a>
          </div>
          <div class="content">
            <h3>Client Name</h3>
            <p>United Status</p>
          </div> <!--box-->
        </div> <!--box-->
      </li>
      <li>
        <div class="box">
          <div class="img">          
            <amp-img src="<?php echo $baseurl;?>images/testimonial/img4.jpg" alt="ISO" width="400" height="260" layout="responsive"></amp-img>
            <a on="tap:video4"><i class="fa fa-play"></i></a>
          </div>
          <div class="content">
            <h3>Client Name</h3>
            <p>United Status</p>
          </div> <!--box-->
        </div> <!--box-->
      </li>
    </ul>
  </div> <!--container-->
</section> <!--clients-->

<section class="testimonials grey">
  <div class="container">
    <ul class="reset">
      <li>
        <div class="info">
          <amp-img src="<?php echo $baseurl;?>images/testimonial/tarek-saab.jpg" alt="Tarek Saab" width="140" height="140" layout="responsive"></amp-img>
          <h4>Tarek Saab<span>Buiret</span></h4>
        </div>
        <p>We have worked with Technoduce on several occasions; will we work them again? absolutely. While our teams are fully dedicated on unfinished projects, and our clients requests getting bigger, there was no other solution than looking for outsourcing.</p>
      </li>
      <li>
        <div class="info">
          <amp-img src="<?php echo $baseurl;?>images/testimonial/akhigbe-olakunle.jpg" alt="Akhigbe Olakunle" width="140" height="140" layout="responsive"></amp-img>
          <h4>Akhigbe Olakunle<span>Nigeria</span></h4>
        </div>
        <p>I would like to recommend Technoduce team on their patience, seriousness and professionalism. I'm glad we chose your company to develop our website.</p>
      </li>
      <li>
        <div class="info">
          <amp-img src="<?php echo $baseurl;?>images/testimonial/agim-meta.jpg" alt="Agim Meta" width="140" height="140" layout="responsive"></amp-img>
          <h4>Agim Meta<span>Albania</span></h4>
        </div>
        <p>Your script is the best on the market,and your service also.I am very happy with this script.I will order in the future plugin or module that I need from you. Thank you for all.</p>
      </li>
      <li>
        <div class="info">
          <amp-img src="<?php echo $baseurl;?>images/testimonial/james-alex.jpg" alt="James Alex" width="140" height="140" layout="responsive"></amp-img>
          <h4>James Alex<span>Kuwait</span></h4>
        </div>
        <p>The software is fine and complete while the support offered is exceptional. They fully and completely addressed any problems reported to them within 24 hours even on Saturdays! I wish other SW companies had the same level of support.</p>
      </li>
      <li>
        <div class="info">
          <amp-img src="<?php echo $baseurl;?>images/testimonial/johnathon-norton.jpg" alt="Johnathon Norton" width="140" height="140" layout="responsive"></amp-img>
          <h4>Johnathon Norton<span>USA</span></h4>          
        </div>
        <p>I'm very happy with the service and the software I'll be more than happy to share a Testimonial to help your business. I'm at work right now but I'll be off work this week end I'll work on it then.</p>        
      </li>
      <li>
        <div class="info">
          <amp-img src="<?php echo $baseurl;?>images/testimonial/edmond-ng.jpg" alt="Edmond Ng" width="140" height="140" layout="responsive"></amp-img>
          <h4>Edmond Ng<span>Malaysia</span></h4>
        </div>
        <p>In order to develop the Supermain, we had made several surveys and we found that Technoduce is the best among all. As we know, there is a lot of excellent programmer from India with multiple of experiences and talent.</p>
        <p>Technoduce is a good supporter and always there to support us in various kinds of ways.</p>
      </li>
    </ul>            
  </div> <!--container-->
</section> <!--testimonials-->

<amp-lightbox id="video1" class="video" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner md">
			<div class="dialog_content">
				<a on="tap:video1.close" class="close"><i class="fi close"></i></a>
				<amp-vimeo data-videoid="122301077" layout="responsive" width="480" height="270"></amp-vimeo>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<amp-lightbox id="video2" class="video" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner md">
			<div class="dialog_content">
				<a on="tap:video2.close" class="close"><i class="fi close"></i></a>
				<amp-vimeo data-videoid="121880061" layout="responsive" width="480" height="270"></amp-vimeo>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<amp-lightbox id="video3" class="video" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner md">
			<div class="dialog_content">
				<a on="tap:video3.close" class="close"><i class="fi close"></i></a>
				<amp-vimeo data-videoid="114017092" layout="responsive" width="480" height="270"></amp-vimeo>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<amp-lightbox id="video4" class="video" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner md">
			<div class="dialog_content">
				<a on="tap:video4.close" class="close"><i class="fi close"></i></a>
				<amp-vimeo data-videoid="122301078" layout="responsive" width="480" height="270"></amp-vimeo>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<?php include ('../inc/footer.php'); ?>