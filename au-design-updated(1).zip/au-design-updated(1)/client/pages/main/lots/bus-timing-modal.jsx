'use strict';
const Actions = require('./actions');
const Modal = require('../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const UserIdentity = require('../../../helpers/user-identity');

const Link = ReactRouter.Link;
const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    show: PropTypes.bool
};


class ModalForm extends React.Component {

    render() {
        const rows = this.props.bus_timing === undefined ? (
                <tr key="1">
                    <td colSpan={3} style={{'textAlign' : 'center'}}>
                        Something Wrong!
                    </td>
                </tr>
            ) : this.props.bus_timing.map((record, index) => {
                index++;
            return (
                <tr key={index}>
                    <td>
                        {record.vehicle_id}
                    </td>
                    <td>{record.arrived}</td>
                    <td>{record.difference}</td>
                </tr>
            );
        });
        return (
            <Modal
                id="bus_route_timings"
                header={false}
                footer={false}
                show={this.props.show}
                onClose={Actions.hideBusTiming}>
                <h4>Bus Timing</h4>
                    <div className="container">
                        <table className="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th className="stretch">Vehicle ID</th>
                                    <th className="stretch">Arrivals</th>
                                    <th className="status">Remaining Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                {rows}
                            </tbody>
                        </table>
                    </div>
                <a className="btn" onClick={Actions.hideBusTiming}>Close</a>
            </Modal>
        );
    }
}

ModalForm.propTypes = propTypes;


module.exports = ModalForm;
