'use strict';
const ClassNames = require('classnames');
const ControlGroup = require('./control-group.jsx');
import Editable from 'react-x-editable';
const ObjectAssign = require('object-assign');
const PropTypes = require('prop-types');
const React = require('react');
const renderHTML = require('react-render-html');

const propTypes = {
    autoCapitalize: PropTypes.string,
    disabled: PropTypes.bool,
    hasError: PropTypes.bool,
    help: PropTypes.string,
    inputClasses: PropTypes.object,
    groupClasses: PropTypes.object,
    labelClasses: PropTypes.object,
    label: PropTypes.string,
    hideLabel: PropTypes.bool,
    labelFor: PropTypes.string,
    labelPositionBottom: PropTypes.bool,
    name: PropTypes.string,
    id: PropTypes.string,
    onChange: PropTypes.func,
    placeholder: PropTypes.string,
    type: PropTypes.string,
    defaultChecked: PropTypes.bool,
    showButtons: PropTypes.bool,
    checked: PropTypes.bool,
    validation: PropTypes.bool,
    value: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ])
};
const defaultProps = {
    type: 'text',
    autoCapitalize: 'off'
};

class TextControl extends React.Component {
    constructor(props){
        super(props);
    }

    value() {

        return this.input.value;
    }

    setValue(value) {
        this.input.value = value;
        return true;
    }

    render() {
        const inputClasses = ClassNames(ObjectAssign({
            'form-control': true
        }, this.props.inputClasses));

        return (
            <ControlGroup
                hasError={this.props.hasError}
                label={this.props.label}
                hideLabel={this.props.hideLabel}
                groupClasses={this.props.groupClasses}
                labelClasses={this.props.labelClasses}
                labelFor={this.props.id}
                labelPositionBottom={this.props.labelPositionBottom}
                help={this.props.help}>

                {(this.props.prependElement && this.props.prependElementNotString) ? (this.props.prependElement) : ''}
                {(this.props.prependElement && !this.props.prependElementNotString) ? (renderHTML(this.props.prependElement)) : ''}
                
                <div className="side-input">
                    <Editable
                        ref={(c) => (this.input = c)}
                        name={this.props.name}
                        dataType={this.props.type}
                        disabled={this.props.disabled ? true : false}
                        showButtons={ this.props.showButtons ? false: true }
                        title={this.props.placeholder}
                        value={this.props.value}
                        mode='inline'
                        validate={(value) => {
                            if(!value && this.props.validation){
                                return `${this.props.name} cannot be blank!`;
                            } 
                        }}
                     />
                </div>
                {(this.props.appendElement && this.props.appendElementNotString) ? (this.props.appendElement) : ''}
                {(this.props.appendElement && !this.props.appendElementNotString) ? (renderHTML(this.props.appendElement)) : ''}
            </ControlGroup>
        );
    }
}

TextControl.propTypes = propTypes;
TextControl.defaultProps = defaultProps;


module.exports = TextControl;
