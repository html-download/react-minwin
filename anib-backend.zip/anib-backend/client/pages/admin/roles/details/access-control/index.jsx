'use strict';
const Actions = require('./actions');
const CommonHelper = require('../../../../../helpers/common-functions');
const UserHelper = require('../../../../../helpers/user-identity');
const React = require('react');
const Store = require('./store');

import * as ReactDOM from 'react-dom';
import { enableRipple } from '@syncfusion/ej2-base';
enableRipple(true);

import { TreeViewComponent } from '@syncfusion/ej2-react-navigations';

class AccessControl extends React.Component {   

    constructor(props) {

        super(props);
        
        this.state = Store.getState();
        
        this.treeview = null;

        this.isChecked = true;

        this.nodeChecked = this.nodeChecked.bind(this);

        Actions.getRole(this.props.id);
    }    

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    componentDidMount() {
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
      }

    onStoreChange() {

        this.setState(Store.getState());
    }

    nodeChecked() {
        Actions.update(this.props.id, {role_json: this.treeview.checkedNodes });        
    }
    
    render() {                
        
        if(this.state.loading) { 
            return (
                <div>Loading...</div>
            )
        }        

        return (
            
            <div id='treeparent'>
                <div id='sample'>
                    <TreeViewComponent fields={this.state} ref={i => (this.treeview = i)} showCheckBox={this.isChecked} nodeChecked={this.nodeChecked}/>
                </div>
            </div>
        )
    }
}
module.exports = AccessControl;
