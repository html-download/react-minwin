/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Bannerlist', {
    listbannerId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'listbanner_id'
    },
    listbannerTitle: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'listbanner_title'
    },
    listbannerImage: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'listbanner_image'
    },
    listbannerVideoUrl: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'listbanner_video_url'
    },
    listbannerUrl: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'listbanner_url'
    },
    listbannerStatus: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Deactive',
      field: 'listbanner_status'
    },
    listsort: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'listsort'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_bannerlist'
  });
};
