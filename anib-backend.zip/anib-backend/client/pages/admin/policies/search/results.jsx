'use strict';
const Actions = require('./actions');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const ViewModal = require('./view-form');


const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array
};

class Results extends React.Component {

    getTableData(id, value, data) {

        return (
            <td onClick={(e) => {Actions.getPolicy(id)}}>{value}</td>
        );
    }

    checkStatusType(status) {
        
        let statusLable = '';
        if (parseInt(status) === 1) {
            statusLable = <label className="status green">Active</label>;
        } else if (parseInt(status) === 2) {
            statusLable = <label className="status pink">Unpaid</label>;
        } else if (parseInt(status) === 3) {
            statusLable = <label className="status yellow">Policy Inusred</label>;
        }        
        return statusLable;
    }

    getTableDocuData(id, policy_document, certificate_document) {

        return (
            <td>
                <a target="_blank" href={policy_document}>
                    <img src="/public/media/images/car-insurance.png" style={ {width:"35%"} }/>
                </a> &nbsp;&nbsp;&nbsp;
                <a target="_blank" href={certificate_document}>
                    <img src="/public/media/images/policy.png" style={ {width:"35%"} }/>
                </a>
            </td>
        );
    }

    getStatusData(id, value) {

        return (
            <td>
                { this.checkStatusType(value) }
            </td>
        );
    }

    getTaskView(id, value) {

        return (
            <td>
                <Link to={`/admin/deals/${id}`} >{value}</Link>
            </td>
        );
    }

    getCustomerView(id, value) {

        return (
            <td>                
                <Link to={`/admin/customers/${id}`} >{value}</Link>
            </td>
        );
    }


    render() {        

        const rows = (this.props.data && this.props.data.length > 0) ? this.props.data.map((record) => {

            return (
                <tr className="c-pointer" key={record.deal_quote_key} >
                    { this.getTableData(record.deal_quote_key, record.policy_number,record) }
                    { this.getStatusData(record.deal_quote_key, record.deal_payment_status) }
                    { this.getTaskView(record.deal_quote_key, record.deal_number) }
                    { this.getCustomerView(record.deal_quote_key, record.customer_first_name) }
                    { this.getTableData(record.deal_quote_key, record.insurence_product_name,record) }
                    { this.getTableData(record.deal_quote_key, record.premium_value,record) }
                    { this.getTableData(record.deal_quote_key, record.vehicle_insured_value,record) }
                    { this.getTableData(record.deal_quote_key, record.created_at,record) }
                    { this.getTableDocuData(record.deal_quote_key, record.policy_document_path, record.certificate_path) }
                </tr>
            );
        }) : (
            <tr key='0'>
                <td colSpan={9} className="text-center">
                    No record(s) found!
                </td>
            </tr>
        );

        return (
            <div className="table-responsive">
                <table className="table table-hover white_table">
                    <thead>
                        <tr>
                            <th>Policy No</th>
                            <th>Status</th>
                            <th>Enquiry</th>
                            <th>Customer</th>
                            <th>Product Name</th>
                            <th>Premium (AED)</th>
                            <th>Sum Insured (AED)</th>
                            <th>Created ON</th>
                            <th style={ {width: "10%"} }>Documents</th>
                        </tr>
                    </thead>
                    {
                        this.props.list_loading ? (
                            <tbody>
                                <tr key='0'>
                                    <td colSpan={9} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='1'>
                                    <td colSpan={9} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='2'>
                                    <td colSpan={9} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='3'>
                                    <td colSpan={9} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>                                
                            </tbody>
                        ) : (
                            <tbody>
                                {rows}
                            </tbody>
                        )
                    }
                </table>
                <ViewModal 
                    is_view_policy = {this.props.is_view_policy}
                    Actions = {Actions}
                    {...this.props.modal_data}
                />
            </div>
        );
    }
}

Results.propTypes = propTypes;


module.exports = Results;
