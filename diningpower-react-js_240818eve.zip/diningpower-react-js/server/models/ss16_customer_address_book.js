/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16CustomerAddressBook', {
    addressId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'address_id'
    },
    addressKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'address_key'
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'customer_key'
    },
    addressTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'address_type_id'
    },
    address: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'address'
    },
    customerLatitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'customer_latitude'
    },
    customerLongitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'customer_longitude'
    },
    city: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'city'
    },
    location: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'location'
    },
    company: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'company'
    },
    flatNo: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'flat_no'
    },
    apartment: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'apartment'
    },
    streetName: {
      type: DataTypes.STRING(150),
      allowNull: false,
      field: 'street_name'
    },
    postalCode: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'postal_code'
    },
    comments: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'comments'
    },
    landmark: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'landmark'
    },
    alternateContact: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'alternate_contact'
    },
    deliverInstruction: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'deliver_instruction'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    status: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'status'
    }
  }, {
    tableName: 'ss16_customer_address_book'
  });
};
