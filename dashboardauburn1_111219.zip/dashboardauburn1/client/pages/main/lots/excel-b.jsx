'use strict';
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const moment = require('moment-timezone');
const Config = require('../../../../config.js');

const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array
};


class ExportData extends React.Component {
    render() {
        return (
            <table id="export_data">
                <tbody>
                    <tr>
                        <th>Client Name</th>
                        <th><b  style={{'textTransform' : 'capitalize'}}>{Config.get('/client')}</b></th>
                        <th>Lot Name</th>
                        <th><b style={{'textTransform' : 'uppercase'}}>{this.props.lot.title}</b></th>
                    </tr>
                    <tr>
                        <th>From Date</th>
                        <th><b>{ moment(this.props.historical_date, 'MM/DD/YYYY').subtract(this.props.historical_day - 1, "days").format('MM/DD/YYYY').toString() }</b></th>
                        <th>To Date</th>
                        <th><b>{this.props.historical_date}</b></th>
                    </tr>
                    <tr key="1">
                        <td colSpan={4} style={{'textAlign' : 'center'}}>
                            
                        </td>
                    </tr>
                    <tr key={`root`} colSpan={4} style={{'textAlign' : 'center'}}>
                        <th>Occupancy by Hour</th>
                        {
                            this.props.data === undefined ? (
                                <td colSpan={4} style={{'textAlign' : 'center'}}>
                                    Something Wrong!
                                </td>
                            ) : this.props.data.map((record, index) => {
                                return (
                                  <th><b>{moment(record.date, 'DD-MM-YYYY').format('MM/DD/YYYY').toString()}</b></th>
                                );
                            })}
                    </tr>
                    <tr colSpan={4} style={{'textAlign' : 'center'}}>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                    {/*rows*/}
                    {
                    this.props.time_permanent_array === undefined ? (
                        <tr key={index} colSpan={4} style={{'textAlign' : 'center'}}>
                            <td colSpan={2} style={{'textAlign' : 'center'}}>
                                Something Wrong!
                            </td>
                        </tr>
                    ) : this.props.time_permanent_array.map((time, timeIndex) => {
                            return (
                                <tr key={timeIndex} colSpan={4} style={{'textAlign' : 'center'}}>
                                    <th>{time.toUpperCase()}</th>
                                    {
                                        this.props.data === undefined ? (
                                            <td colSpan={4} style={{'textAlign' : 'center'}}>
                                                Something Wrong!
                                            </td>
                                        ) : this.props.data.map((record, index) => {
                                            return (
                                              <th><b>{record.percentage[this.props.rail_time_array[timeIndex]] ? parseFloat(record.percentage[this.props.rail_time_array[timeIndex]]).toFixed(2) : 0}</b></th>
                                            );
                                    })}
                                </tr>
                            );
                    })

                    }
                    <tr style={{'textAlign' : 'center'}}>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                    </tr>
                    <tr key={`peak_percen`} style={{'textAlign' : 'center'}}>
                        <th>Peak percentage</th>
                        {
                            this.props.data === undefined ? (
                                    <th style={{'textAlign' : 'center'}}>
                                        0
                                    </th>
                                ) : this.props.data.map((percentage_record, percentage_record_index) => {
                                    let arr = Object.values(percentage_record.percentage);
                                    let min = Math.min(...arr);
                                    let max = Math.max(...arr);
                                    
                                    return percentage_record.percentage === undefined ? (
                                        <th key={`${percentage_record_index}_root`} style={{'textAlign' : 'center'}}>
                                            0.00
                                        </th>
                                    ) : (
                                        <th key={`${percentage_record_index}_root`} style={{'textAlign' : 'center'}}>
                                            {max === 0 ? 'NIL' : parseFloat(max).toFixed(2)}
                                        </th>
                                    )
                                }) 
                            } 
                        }
                    </tr>
                    <tr key={`peak_time`} style={{'textAlign' : 'center'}}>
                        <th>Peak Time</th>
                        {
                            this.props.data === undefined ? (
                                    <th style={{'textAlign' : 'center'}}>
                                        0
                                    </th>
                                ) : this.props.data.map((percentage_record, percentage_record_index) => {
                                    let arr = Object.values(percentage_record.percentage);
                                    let max = Math.max(...arr);
                                    let index = arr.indexOf(max);

                                    return percentage_record.percentage === undefined ? (
                                        <th key={`${percentage_record_index}_rootss`} style={{'textAlign' : 'center'}}>
                                            0
                                        </th>
                                    ) : (
                                        <th key={`${percentage_record_index}_rootss`} style={{'textAlign' : 'center'}}>
                                            {max === 0 ? 'NIL' : this.props.time_permanent_array[index] ? this.props.time_permanent_array[index] : null}
                                        </th>
                                    )
                                }) 
                            } 
                        }
                    </tr>
                    
                </tbody>
            </table>
        );
    }
}

ExportData.propTypes = propTypes;


module.exports = ExportData;
