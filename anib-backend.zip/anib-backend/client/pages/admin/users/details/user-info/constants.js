'use strict';
const FluxConstant = require('flux-constant');

module.exports = FluxConstant.set([
    'CUSTOMER_DETAILS',
    'CUSTOMER_DETAILS_RESPONSE',
    'GET_NATIONALITY_RESULTS',
    'GET_NATIONALITY_RESULTS_RESPONSE',
    'EDITABLE_SHOW',
    'EDITABLE_HIDE',
    'UPDATE_DATE_FIELD',
    'NATIONALITY_RESULTS',
    'NATIONALITY_RESULTS_RESPONSE',    
    'UPDATE_DOB',
    'DISABLE_LOADER'
]);
