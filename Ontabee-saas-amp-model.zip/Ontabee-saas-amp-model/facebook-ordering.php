<?php include ('inc/header.php'); ?>

<div class="page_banner bg5">
	<div class="container">
		<h1 class="head wow fadeInDown">Facebook Ordering</h1>
		<h2 class="head wow fadeInUp">Integrate Facebook Ordering App To Your Restaurant Website Now With Ontabee.</h2>		
		<img src="images/facebook-ordering.png" class="style1 wow fadeInUp" alt="Facebook Ordering" data-wow-duration="1.2s">
	</div> <!--container-->
</div> <!--page_banner-->

<section class="style1 text-center">
	<div class="container">
		<h2 class="head wow fadeInUp">Facebook ordering a smarter way to enhance your business</h2>
		<p class="md1 wow fadeInUp mb30">Now allow your customers to order food directly on your Facebook page. Ontabee has come up with new Facebook ordering feature for restaurants. Integrating our Facebook ordering application helps you add and engage more customers to your business. Our online Facebook ordering application supports on both the web and mobile platform (Android & iPhone). Now you can easily manage your business orders through your Facebook page itself. Ontabee's mobile Facebook ordering application is well suitable for any kinds of single or multiple chains of restaurants, pubs, pizza hut, bars, boutique, sweets & chocolate ordering and much more.</p>
		<h3 class="mb0 wow fadeInUp">Promote your Brand | Gain more Customers | Increase your Sales</h3>
	</div>
</section> <!--page_banner-->

<section class="grey text-center">
	<div class="container md">		
		<p class="mb20"><img src="images/forbes-logo.png" class="style1 wow fadeInUp" alt="forbes"></p>
		<p class="md">"Facebook ordering may be the biggest technology leap coming in the next year, as nearly 100 percent of restaurant owners say they plan to have a Facebook presence by next year."</p>
	</div>
</section> <!--page_banner-->

<section>
	<div class="container text-center">
		<h2 class="head mb40 wow fadeInUp">How your customers can order food through your Facebook page?</h2>		
		<div class="row">
			<div class="col-sm-6 pull-right">
				<img src="images/facebook-menu.png" class="wow zoomIn" alt="facebook menu">
			</div>
			
			<div class="col-sm-6 text-left">			
				<h2 class="head small wow fadeInUp">1. Integrating Facebook ordering for your restaurants</h2>
				<p>Integrating mobile Facebook ordering is now easier with Ontabee. A direct path to order food is created through Facebook by enabling a call to action button.</p>
			</div>
		</div>
	</div>
</section>

<section class="grey">
	<div class="container text-center">
		<div class="row">
			<div class="col-sm-6">
				<img src="images/facebook-order.png" class="wow zoomIn" alt="facebook order">
			</div>
			
			<div class="col-sm-6 text-left">			
				<h2 class="head small wow fadeInUp">2. Ordering through Facebook</h2>
				<p>Once your customer clicks on "order now" button, menu items are displayed. The Customer can select whatever they want and can order directly from your Facebook page itself.</p>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="container text-center">
		<div class="row">
			<div class="col-sm-6 pull-right">
				<img src="images/facebook-notification.png" class="wow zoomIn" alt="facebook notification">
			</div>
			
			<div class="col-sm-6 text-left">			
				<h2 class="head small wow fadeInUp">3. Notification sent to restaurant</h2>
				<p>After placing the order through Facebook ordering app, the order is sent directly to your restaurant. The customer gets notified on the confirmation of order. The restaurant starts preparing the order and gets delivered to the customer at the specified time and place.</p>
			</div>
		</div>
	</div>
</section>

<section class="grey">
	<div class="container text-center">
		<div class="row">
			<div class="col-sm-6">
				<img src="images/facebook-promote.png" class="wow zoomIn" alt="facebook menu">
			</div>
			
			<div class="col-sm-6 text-left">			
				<h2 class="head small wow fadeInUp">4. Promote your restaurant brand</h2>
				<p>The customer placing an order on your business Facebook page goes viral among their friends, which naturally increase your business brand and create more interest towards your restaurant.</p>
			</div>
		</div>
	</div>
</section>

<section class="text-center">
	<div class="container">
		<h2 class="head wow fadeInUp">Ontabee lets you create online food ordering through Facebook</h2>
		<p class="md1 wow fadeInUp">Ontabee, now even specialize in Facebook payment integration for restaurants. We help our customers to get orders from the most popular social media platforms, which actually increases the growth of restaurant business. Facebook orders get automatically sync and updated in restaurant back end. We make use of latest tools and technology to develop Facebook ordering app, to provide efficient service for the restaurant that their customer expects today.</p>
	</div>
</section> <!--page_banner-->

<?php include('inc/footer.php');?>