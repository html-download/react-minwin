'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {
    loading: false,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    navBarOpen: false,
    dropdownOpen: false,
    data: {}
};
const reducer = function (state, action) {

    if (action.type === Constants.TOGGLE_NAVBAR) {
        return ObjectAssign({}, state, {
            navBarOpen: action.value
        });
    }

    if (action.type === Constants.TOGGLE_OPEN){
       return ObjectAssign({}, state, {
           dropdownOpen: action.value
       });
    }

    if (action.type === Constants.GET_USER_ADMIN){
       return ObjectAssign({}, state, {
          loading: true
       });
    }

    if (action.type === Constants.GET_USER_ADMIN_RESPONSE){

        const validation  = ParseValidation(action.response);
        
        const data =  action.response.data ? action.response.data : {};
        return ObjectAssign({}, state, {
            loading: false,
            data: data
        });
    }

    return state;
}

module.exports = Redux.createStore(reducer, initialState);
