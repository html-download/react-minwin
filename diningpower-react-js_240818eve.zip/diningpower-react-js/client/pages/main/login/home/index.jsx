const Actions = require('../actions');
const moment = require('moment');
//const GoogleLogin = require('react-google-login');
//const GoogleLogin = require('react-google-login-component');

const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');
const CheckboxControl = require('../../../../components/form/checkbox-control.jsx');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;

const responseGoogle = (response) => {
  console.log(response);
}

class LoginSPage extends React.Component {
    constructor(props) {

        super(props);

        //Actions.getUserCreds();

        this.input = {};
        this.state = Store.getState();
    }
    responseGoogle (googleUser) {
        var id_token = googleUser.getAuthResponse().id_token;
        var googleId = googleUser.getId();
        
        console.log({ googleId });
        console.log({accessToken: id_token});
        //anything else you want to do(save to localStorage)...
    }
    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.username) {
            this.input.username.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.login({
            username: this.input.username.value(),
            password: this.input.password.value()
        });
    }

    render() {

        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success" className="alert alert-success">
                Success. Redirecting...
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.username = c)}
                    name="username"
                    hideLabel={true}
                    placeholder="Email"
                    hasError={this.state.hasError.username}
                    help={this.state.help.username}
                    disabled={this.state.loading}
                />
                <TextControl
                    ref={(c) => (this.input.password = c)}
                    name="password"
                    hideLabel={true}
                    placeholder="Password"
                    type="password"
                    hasError={this.state.hasError.password}
                    help={this.state.help.password}
                    disabled={this.state.loading}
                    onChange={this.handlePasswordChange}
                />
                <div className="form-group mtb10 mb20 remember">
                    <CheckboxControl
                       ref={(c) => (this.input.forgot = c)}
                       name="forgot"
                       id="forgot"
                       inputClasses={{ 'checkbox': true }}
                       groupClasses={{ 'auto_wid': true }}
                       hasError={this.state.hasError.forgot}
                       help={this.state.help.forgot}
                       disabled={this.state.loading}
                       value='1'
                       labelClasses={{ 'checkbox': true }}
                       labelFor="forgot"
                       label= {['Remember Me']}
                       labelPositionBottom={true}
                   />
                    <Link to="/login/forgot" className="lh20 pull-right link lh14" id="forget"> Forgot password?</Link>
                </div>
                <ControlGroup hideLabel={true} hideHelp={true}>
                    <Button
                        type="submit"
                        inputClasses={{ 'full': true }}
                        disabled={this.state.loading}>

                        Sign in
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <section className="login-register">
                <Helmet>
                    <title>Login</title>
                </Helmet>
                <div className="container">
                    <div className="login-left equal">
                        <div className="login-img">
                        <img src="/public/media/images/login.png" alt="Login"/>
                        </div>
                    </div>
                    <div className="login-right equal">
                        <div className="custom-modal">
                                <div className="modal-dialog">
                                    <div className="modal-content login-part">
                                        <div className="modal-header">
                                            <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                                            <h4 className="modal-title">Sign in...welcome back!</h4>
                                            <h4 className="sub-title">New to Dining Power?  
                                                <Link to="/signup"> Sign up</Link>
                                            </h4>
                                            <div className="social_login">
                                                Sign in with 
                                                <a href="#"> Facebook</a> or 
                                                {/*<GoogleLogin socialId="yourClientID"
                                                 className="google-login"
                                                 scope="profile"
                                                 prompt="select_account"
                                                 fetchBasicProfile={false}
                                                 responseHandler={this.responseGoogle}
                                                 buttonText="Login With Google"/>*/}
                                                {/*<GoogleLogin
                                                    clientId="658977310896-knrl3gka66fldh83dao2rhgbblmd4un9.apps.googleusercontent.com"
                                                    buttonText="Login"
                                                    onSuccess={responseGoogle}
                                                    onFailure={responseGoogle}
                                                  />*/}
                                                <span>or</span>
                                            </div>
                                        </div>
                                        <div className="modal-body">
                                            <form onSubmit={this.handleSubmit.bind(this)} className="w100 m0" autoComplete="off">
                                                {alerts}
                                                {formElements}
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        
                    </div>
                </div>
            </section>

        );
    }
}


module.exports = LoginSPage;
