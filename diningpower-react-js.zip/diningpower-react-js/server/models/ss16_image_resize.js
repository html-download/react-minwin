/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16ImageResize', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    logoWidth: {
      type: DataTypes.INTEGER(5),
      allowNull: false,
      field: 'logo_width'
    },
    logoHeight: {
      type: DataTypes.INTEGER(5),
      allowNull: false,
      field: 'logo_height'
    },
    itemListWidth: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_list_width'
    },
    itemListHeight: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_list_height'
    },
    itemDetailWidth: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_detail_width'
    },
    itemDetailHeight: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_detail_height'
    },
    itemCartWidth: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_cart_width'
    },
    itemCartHeight: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_cart_height'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_image_resize'
  });
};
