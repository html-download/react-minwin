<?php
	error_reporting(E_ALL);
	require_once __DIR__ . '/vendor/autoload.php';
	use PhpAmqpLib\Connection\AMQPStreamConnection;
	use PhpAmqpLib\Message\AMQPMessage;
	//print_r("Activating");

	global $pdo;
	try{
         //$pdo  = new PDO("mysql:host=192.168.1.179;dbname=ontabee_domains", "svnuser", "pXc9nbmrnC");
         $pdo  = new PDO("mysql:host=localhost;dbname=ontabee_domains", "ontabee_domuser", "Hp7bgUAVWeTuUCgM");

	  	if(!$pdo)
	    	exit("Database not connected");
	  	}
	catch(Exception $e)
	{
		//var_dump($e);
	}

  	$__useLibreSSL = null;
  	$__randomFile = null;

  	$queries = array();
	parse_str($_SERVER['QUERY_STRING'], $queries);



  	$activation_key_is = strtolower(preg_replace("/[^a-zA-Z0-9'-]+/", '', $queries['activation_key']));
  	$query = $pdo->prepare("SELECT domain, email, name, password FROM domains WHERE activation_key LIKE :activation_key");
	$query->bindParam(":activation_key", $activation_key_is, FILTER_SANITIZE_STRING);
	$query->execute();
	$domainName = $query->fetchColumn(0);

	$query = $pdo->prepare("SELECT domain, email, name, password FROM domains WHERE activation_key LIKE :activation_key");
	$query->bindParam(":activation_key", $activation_key_is, FILTER_SANITIZE_STRING);
	$query->execute();
	$email = $query->fetchColumn(1);

	$query = $pdo->prepare("SELECT domain, email, name, password FROM domains WHERE activation_key LIKE :activation_key");
	$query->bindParam(":activation_key", $activation_key_is, FILTER_SANITIZE_STRING);
	$query->execute();
	$name = $query->fetchColumn(2);

	$query = $pdo->prepare("SELECT domain, email, name, password FROM domains WHERE activation_key LIKE :activation_key");
	$query->bindParam(":activation_key", $activation_key_is, FILTER_SANITIZE_STRING);
	$query->execute();
	$passwordis = $query->fetchColumn(3);

	if($domainName !== "") {
		$connection = new AMQPStreamConnection('52.2.181.157', 5672, 'guest', 'nfXahTN5L2HG');
		//$connection = new AMQPStreamConnection('104.238.72.168', 5672, 'guest', 'nfXahTN5L2HG');
		$channel = $connection->channel();

		$channel->queue_declare('ontabee.activation', false, true, false, false);

		$msg = new AMQPMessage('{ "db_name": "' .$domainName . '", "email": "' .$email . '", "name": "' .$name . '", "passwordis": "' .$passwordis . '" }');
		$test = $channel->basic_publish($msg, '', 'ontabee.activation');
		
		$channel->close();
		$connection->close();
		header("Refresh: 1; URL= /activation-thankyou?domain=" .$domainName);
	}
	else {
		//header("Location: /thankyou?success=1");
	}
?>