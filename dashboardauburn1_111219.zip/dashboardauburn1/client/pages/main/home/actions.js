const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const UserIdentity = require('../../../helpers/user-identity');

const apiUrl = UserIdentity.apiUrl;


class Actions {

    static getLotList(url, getLotAvgTime) {

        ApiActions.get(
            url,
            undefined,
            Store,
            Constants.GET_LOTLIST,
            Constants.GET_LOTLIST_RESPONSE,
            (err, response) => {
                if (!err) {
                    getLotAvgTime()
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static showZoneHistoricalModal(loadHistorical, zone) {
        localStorage.setItem('dashboard_zone_selected', zone);
        Store.dispatch({
            type: Constants.SHOW_ZONE_HISTORICAL,
            zone: zone
        });
        loadHistorical()
    }

    static hideZoneHistoricalModal() {

        Store.dispatch({
            type: Constants.HIDE_ZONE_HISTORICAL
        });
    }

    static loadHistorical(data) {

        ApiActions.get(
            `/api/history`,
            data,
            Store,
            Constants.SAVE_MAP_ARRAY,
            Constants.SAVE_MAP_ARRAY_RESPONSE,
            (err, response) => {
                if (!err) {
                    //this.showLotHistoricalModal()
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static loadHistoricalDownload(data, getHistoricalExport) {

        ApiActions.get(
            `/api/history/download`,
            data,
            Store,
            Constants.SAVE_MAP_ARRAY_DOWNLOAD,
            Constants.SAVE_MAP_ARRAY_DOWNLOAD_RESPONSE,
            (err, response) => {
                if (!err) {
                    getHistoricalExport()
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    

    static setHistoricalDate(value, data) {
        Store.dispatch({
            type: Constants.SET_HISTORICAL_DATE,
            date : value
        });

        this.loadHistorical(data)
    }

    static setHistoricalDay(value) {
        localStorage.setItem('dashboard_zone_day_selected', value);

        Store.dispatch({
            type: Constants.SET_HISTORICAL_DAY,
            day : value
        });
    }

    static getLotAvgTime(url, lot_name) {

        ApiActions.get(
            url,
            undefined,
            Store,
            Constants.GET_STALLLIST,
            Constants.GET_STALLLIST_RESPONSE,
            (err, response) => {
                if (!err) {
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

}


module.exports = Actions;
