var Path=window.location.protocol+'//'+window.location.host;

	function show_banner_video(url)
	{
		document.getElementById('banner_iframe_src').src = url;
	}
	
	function submit_add_event(id)
	{
		if($('#event_exist_name_'+id).val()!='')
		{
			$('.eventErrorMsg').addClass('hide');
			var formData = $('#add_event_'+id).serialize();
			$('.event_loader').show();
			$('.buttons').hide();
			$.ajax({
				url:Path+"/add-event.html",
				type:"post",
				data:formData,
				success:function(data)
				{
					if(data==-1)
					{
						$('.eventErrorMsg').text("Event name already exist!");
						$('.eventErrorMsg').removeClass('hide');
						$('.buttons').show();
						$('.event_loader').hide();
					}
					else if(data==-2)
					{
						$('.eventErrorMsg').text("The item already added to the selected event! Please choose another event!");
						$('.eventErrorMsg').removeClass('hide');
						$('.buttons').show();
						$('.event_loader').hide();
					}
					else if(data==1 || data==2)
					{
						location.reload();
					}
				},
				error:function(data)
				{
					
				}
			});
		}
	}
	
	function submit_create_new_event_form(id)
	{
		$('.eventErrorMsg').addClass('hide');
		if(jQuery('#create_new_event_'+id).valid())
		{
			var formData = $('#create_new_event_'+id).serialize();
			$('.event_loader').show();
			$('.buttons').hide();
			$.ajax({
				url:Path+"/create-event.html",
				type:"post",
				data:formData,
				success:function(data)
				{
					if(data==-1)
					{
						$('.eventErrorMsg').text("Event name already exist!");
						$('.eventErrorMsg').removeClass('hide');
						$('.buttons').show();
						$('.event_loader').hide();
					}
					else if(data==-2)
					{
						$('.eventErrorMsg').text("The item already added to the selected event! Please choose another event!");
						$('.eventErrorMsg').removeClass('hide');
						$('.buttons').show();
						$('.event_loader').hide();
						$('.create_event_form').hide();
						$('.add_event_form').show();
					}
					else if(data==1 || data==2)
					{
						location.reload();
					}
				},
				error:function(data)
				{
					
				}
			});
		}
	}
	function submit_create_event_form(form_name)
	{
		$('.eventErrorMsg').addClass('hide');
		if(jQuery('#'+form_name).valid())
		{
			var formData = $('#'+form_name).serialize();
			$('.event_loader').show();
			$('.buttons').hide();
			$.ajax({
				url:Path+"/create-event.html",
				type:"post",
				data:formData,
				success:function(data)
				{
					if(data==-1)
					{
						$('.eventErrorMsg').text("Event name already exist!");
						$('.eventErrorMsg').removeClass('hide');
						$('.buttons').show();
						$('.event_loader').hide();
					}
					else if(data==-2)
					{
						$('.eventErrorMsg').text("The item already added to the selected event! Please choose another event!");
						$('.eventErrorMsg').removeClass('hide');
						$('.buttons').show();
						$('.event_loader').hide();
						$('.create_event_form').hide();
						$('.add_event_form').show();
					}
					else if(data==1 || data==2)
					{
						location.reload();
					}
				},
				error:function(data)
				{
					
				}
			});
		}
	}
	
	function show_create_event_form()
	{
		$('.create_event_form').show();
		$('.add_event_form').hide();
		$('.eventErrorMsg').addClass('hide');
	}
	
	function show_add_event_form()
	{
		$('.create_event_form').hide();
		$('.eventErrorMsg').addClass('hide');
		$('.add_event_form').show();
	}
	
	function show_add_event_popup()
	{
		$('.error_validate').text('');
	}
	
	function wishlist(item_id,customer_id,val)
	{
		var wishlist_url=Path+"/events.html";
		$.ajax({
				url:Path+"/add-to-wishlist.html",
				type:"get",
				data:"item_id="+item_id+"&customer_id="+customer_id,
				success:function(data)
				{
					if(data==1)
					{
						$(val).removeAttr( "onclick" );
						$(val).removeAttr( "href" );
						$(val).removeAttr( "title" );
						$(val).attr("href", wishlist_url);
						$(val).attr("title", "Wishlist");
						$("#add_wishlist_"+item_id).css("color", "#ebc000");
					}
					else
					{
						alert("Some error occured!");
					}
				},
				error:function(data)
				{
					
				}
			});
	}
	
	function load_more_events(t_records,type)
	{
		if(type=="sss")
		{
			type="";
		}
		var limit=4;
		var total_records=t_records;
		var offset=$('.offset_val').val();
		$('.load_more_loader').show();
		$('.load_more').hide();
		$.ajax({
			url:Path+"/load_more.html",
				type:"get",
				data:"limit="+limit+"&offset="+offset+"&type="+type,
				success:function(data){
					var new_data=data.split("---");
					if(new_data[0]=='' || new_data[1]==total_records)
					{
						$('#events_list').append(new_data[0]);
						$('.load_more').hide();
						$('.load_more_loader').hide();
					}
					else
					{
						$('#events_list').append(new_data[0]);
						$('.load_more_loader').hide();
						$('.load_more').show();
					}
					$('.offset_val').val(new_data[1]);
				},
				error:function(data)
				{
					
				}
		});
	}
	
	function setupLabel() 
	{
		if ($('.label_check input').length) 
		{
			$('.label_check').each(function () {
				$(this).removeClass('c_on');
			});
			$('.label_check input:checked').each(function () {
				$(this).parent('label').addClass('c_on');
			});
		}
		if ($('.label_radio input').length) 
		{
			$('.label_radio').each(function () {
				$(this).removeClass('r_on');
			});
			$('.label_radio input:checked').each(function () {
				$(this).parent('label').addClass('r_on');
			});
		}
	}
	$(document).ready(function () {
		$('.label_check, .label_radio').click(function () {
			setupLabel();
		});
		setupLabel();
		$(".custom-select").each(function () {

		});
		$(".custom-select").change(function () {
			var selectedOption = $(this).find(":selected").text();
			$(this).next(".holder").text(selectedOption);
		}).trigger('change');
	});
	
	function submit_signup_form()
	{
		var gen=$('#gender').val();
		var bday=$('#bday').val();
		var bmonth=$('#bmonth').val();
		var byear=$('#byear').val();
		var i=0; var j=0;
		if(gen=='')
		{
			$('#gen_er').show();
		}
		else
		{
			$('#gen_er').hide();
			i=1;
		}
		if(bday=='' && bmonth=='' && byear=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Date of Birth");
		}
		else if(bday=='' && bmonth=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Date and Month of Birth");
		}
		else if(bday=='' && byear=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Date and Year of Birth");
		}
		else if(bmonth=='' && byear=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Month and Year of Birth");
		}
		else if(bmonth=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Month of Birth");
		}
		else if(byear=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Year of Birth");
		}
		else if(bday=='')
		{
			$('#dob_er').show();
			$('#dob_er').text("Choose Day of Birth");
		}
		else
		{
			$('#dob_er').hide();
			j=1;
		}
		
		if($("#signup").valid() && i==1 && j==1)
		{
			$("#signup").submit();
		}
	}
	
	function remove_from_fav(customer_id,item_id)
	{
		if(confirm("Are you sure you want to remove from wishlist?"))
		{
			$("#favourite_"+item_id).css('opacity','0.3');
			$.ajax({
				url:Path+"/remove-from-wishlist.html",
				type:"get",
				data:"item_id="+item_id+"&customer_id="+customer_id,
				success:function(data)
				{
					if(data==1)
					{
						$("#favourite_"+item_id).hide();
					}
					else
					{
						alert("Some error occured!");
					}
				},
				error:function(data)
				{
					
				}
			});
		}
	}

