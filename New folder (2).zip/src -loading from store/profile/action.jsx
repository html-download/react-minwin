import Constants from './constants.jsx';
import Store from './store.jsx';


class Actions {
	static getresponse(value) {
		
		return Store.dispatch({
			type: Constants.GET_PROFILE_RESPONSE,
            value: value
		})
	   

	}

}

export default Actions;

