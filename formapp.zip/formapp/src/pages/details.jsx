import React, {Component} from 'react';

class details extends Component{

constructor(props){
	super(props);
		this.state={

			details: []
	};
}

componentDidMount()
{
    var retrievedData = localStorage.getItem("datas");
    var detail = JSON.parse(retrievedData);
    this.setstate ={details: detail }
    console.log(details);
}


	render(){
		return(

			<div><p>{this.state.details}
				
			</p></div>

		)
	}
}

export default details;
