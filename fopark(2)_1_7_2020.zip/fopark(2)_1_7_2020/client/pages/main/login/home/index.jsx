import { GoogleLogin } from 'react-google-login';
//import lStyles from '/public/media/css/style.css';
const Actions = require('../actions');
const moment = require('moment');
const ObjectAssign = require('object-assign');
//const GoogleLogin = require('react-google-login');
//const GoogleLogin = require('react-google-login-component');

//const Config = require('../../../../../config.js');

const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const React = require('react');
const ReactHelmet = require('react-helmet');
const ReactRouter = require('react-router-dom');
const Spinner = require('../../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../../components/form/text-control.jsx');
const CheckboxControl = require('../../../../components/form/checkbox-control.jsx');
const UserIdentity = require('../../../../helpers/user-identity');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;
const Redirect = ReactRouter.Redirect;

class LoginSPage extends React.Component {
    constructor(props) {

        super(props);

        //Actions.getUserCreds();

        this.input = {};
        this.state = Store.getState();
        this.handleRemember = this.handleRemember.bind(this);
    }
    handleRemember(event) {
        const target = event.target;
        const checked = target.type === "checkbox" 
                        ? target.checked 
                        : target.value;
        if (checked === true) {
            this.setState(ObjectAssign(this.state, {
                checkboxCondition: true
            }));
        } else {
            this.setState(ObjectAssign(this.state, {
                checkboxCondition: false
            }));
        }
    }
    responseGoogle (googleUser) {
        var id_token = googleUser.getAuthResponse().id_token;
        var googleId = googleUser.getId();
        var profile = googleUser.getBasicProfile();
        
        Actions.googlelogin({
            email: profile.getEmail(),
            name: profile.getGivenName(),
            last_name: profile.getFamilyName(),
            google_id: googleId,
            token: id_token
        }, this.props.history);
        //anything else you want to do(save to localStorage)...
    }
    componentDidMount() {
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.username) {
            this.input.username.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.login({
            username: this.input.username.value(),
            password: this.input.password.value()
        }, this.props.history);
    }

    render() {
        if (UserIdentity._checkUserIdentity()) {
            return <Redirect to='/dashboard' push />;
        }
        const alerts = [];

        if (this.state.success) {
            alerts.push(<div key="success" className="alert alert-success">
                Success. Redirecting...
            </div>);
        }

        if (this.state.error) {
            alerts.push(<div key="danger" className="alert alert-danger">
                {this.state.error}
            </div>);
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.username = c)}
                    name="username"
                    hideLabel={true}
                    placeholder="Username"
                    hasError={this.state.hasError.username}
                    help={this.state.help.username}
                    disabled={this.state.loading}
                />
                <TextControl
                    ref={(c) => (this.input.password = c)}
                    name="password"
                    hideLabel={true}
                    placeholder="Password"
                    type="password"
                    hasError={this.state.hasError.password}
                    help={this.state.help.password}
                    disabled={this.state.loading}
                    onChange={this.handlePasswordChange}
                />
                <div className="form-group mtb10 mb20 remember">
                    <CheckboxControl
                       ref={(c) => (this.input.remember = c)}
                       name="remember"
                       id="remember"
                       inputClasses={{ 'checkbox': true }}
                       groupClasses={{ 'auto_wid': true }}
                       hasError={this.state.hasError.remember}
                       help={this.state.help.remember}
                       disabled={this.state.loading}
                       onChange={this.handleRemember}
                       value={this.state.checkboxCondition ? "1" : ""}
                       labelClasses={{ 'checkbox': true }}
                       labelFor="remember"
                       label= {['Remember Me']}
                       labelPositionBottom={true}
                   />
                    <Link to="/login/forgot" className="lh20 pull-right link lh14" id="forget"> Forgot password?</Link>
                </div>
                <ControlGroup hideLabel={true} hideHelp={true}>
                    <Button
                        type="submit"
                        inputClasses={{ 'full': true }}
                        disabled={this.state.loading}>

                        Sign in
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <section className="login-register">
                {/*<style dangerouslySetInnerHTML={{ __html: '/public/media/css/style.css' }} />*/}
                <Helmet>
                    <title>Login</title>
                </Helmet>
                <div className="container">
                    <img src="/public/media/images/logo-w.png" alt="FOPARK" />
                    <div className="login-right">
                        <div className="custom-modal">
                                <div className="modal-dialog">
                                    <div className="modal-content login-part">
                                        <div className="modal-header">
                                            <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                                            <h4 className="modal-title">Sign in...welcome back!</h4>
                                        </div>
                                        <div className="modal-body">
                                            <form onSubmit={this.handleSubmit.bind(this)} className="w100 m0" autoComplete="off">
                                                {alerts}
                                                {formElements}
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        </div>
                        
                    </div>
                </div>
            </section>
            

        );
    }
}


module.exports = LoginSPage;
