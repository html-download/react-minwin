/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorItemUndo', {
    itemUndoId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'item_undo_id'
    },
    itemUndoKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'item_undo_key'
    },
    itemId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'item_id'
    },
    itemName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'item_name'
    },
    itemDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'item_description'
    },
    itemNumber: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'item_number'
    },
    itemInternalDescription: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'item_internal_description'
    },
    alternateKeyword: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'alternate_keyword'
    },
    itemPricePerUnit: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'item_price_per_unit'
    },
    pickupPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'pickup_price'
    },
    delDpPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'del_dp_price'
    },
    delRPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'del_r_price'
    },
    premiumPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'premium_price'
    },
    costPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'cost_price'
    },
    itemArchived: {
      type: DataTypes.ENUM('Yes','No'),
      allowNull: false,
      defaultValue: 'No',
      field: 'item_archived'
    },
    itemApproved: {
      type: DataTypes.ENUM('Yes','No','Rejected'),
      allowNull: false,
      defaultValue: 'No',
      field: 'item_approved'
    },
    itemStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      defaultValue: 'Deactive',
      field: 'item_status'
    },
    itemImage: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'item_image'
    },
    sort: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      defaultValue: '0',
      field: 'sort'
    },
    approvedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'approved_datetime'
    },
    rejectedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'rejected_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    isIngredient: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'is_ingredient'
    },
    itemType: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'item_type'
    },
    itemPackagePrice: {
      type: "DOUBLE",
      allowNull: false,
      field: 'item_package_price'
    },
    itemPackageUnit: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'item_package_unit'
    },
    additionalVendor: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'additional_vendor'
    },
    parentVendorItem: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'parent_vendor_item'
    },
    offerflag: {
      type: DataTypes.INTEGER(2),
      allowNull: false,
      field: 'Offerflag'
    },
    discountpercent: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'discountpercent'
    },
    discountamount: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'discountamount'
    },
    offeredamount: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'offeredamount'
    },
    itemAvailableStatus: {
      type: DataTypes.ENUM('open','close'),
      allowNull: false,
      defaultValue: 'open',
      field: 'item_available_status'
    },
    deliveryType: {
      type: DataTypes.STRING(20),
      allowNull: false,
      defaultValue: '1,2,3,4',
      field: 'delivery_type'
    },
    mealPeriod: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '1',
      field: 'meal_period'
    },
    availability: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'availability'
    },
    taxable: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'yes',
      field: 'taxable'
    },
    discontinued: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'discontinued'
    },
    recipeType: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '1',
      field: 'recipe_type'
    },
    minimumQuantity: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'minimum_quantity'
    },
    maximumQuantity: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'maximum_quantity'
    },
    servesMin: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'serves_min'
    },
    servesMax: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'serves_max'
    },
    caloriesMin: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'calories_min'
    },
    caloriesMax: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'calories_max'
    },
    caloryType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '1',
      field: 'calory_type'
    },
    preparationDays: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'preparation_days'
    },
    preparationMinutes: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'preparation_minutes'
    },
    popularity: {
      type: DataTypes.INTEGER(4),
      allowNull: true,
      defaultValue: '1',
      field: 'popularity'
    },
    itemPriceByModifiers: {
      type: DataTypes.STRING(200),
      allowNull: true,
      field: 'item_price_by_modifiers'
    },
    discontinuedUntil: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'discontinued_until'
    },
    vendorItemStatus: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '1',
      field: 'vendor_item_status'
    },
    revoked: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '0',
      field: 'revoked'
    }
  }, {
    tableName: 'ss16_vendor_item_undo'
  });
};
