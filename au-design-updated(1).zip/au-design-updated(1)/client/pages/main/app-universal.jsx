const React = require('react');
const ReactRouter = require('react-router-dom');
const RouteRedirect = require('../../components/route-redirect.jsx');
const UserIdentity = require('../../helpers/user-identity');

const Route = ReactRouter.Route;
const Switch = ReactRouter.Switch;
const Redirect = ReactRouter.Redirect;

/*App Management*/
const Navbar = require('./navbar.jsx');
const Footer = require('./footer.jsx');
const About = require('./about/index.jsx');
const Contact = require('./contact/index.jsx');
const NotFound = require('./not-found.jsx');
const Terms = require('./terms-conditions/index.jsx');
const ParkingInfo = require('./parking-info/index.jsx');

/*Dashboard*/
const Home = require('./home/index.jsx');

/*Login Management*/
const Login = require('./login/home/index.jsx');
const LoginForgot = require('./login/forgot/index.jsx');
const LoginLogout = require('./login/logout/index.jsx');
const LoginReset = require('./login/reset/index.jsx');
const LoginActivation = require('./login/activation/index.jsx');
const Signup = require('./signup/index.jsx');

/*Lots Management*/
const Lots = require('./lots/index.jsx');
const Lot = require('./lots/Lot.js');
const Zones = require('./lots/ZoneList.js');

class AppUniversal extends React.Component {
    render() {
        if (UserIdentity._checkUserToken() === null) {
            return (
                    <span>
                        <Route component={Navbar} />
                        <Switch>
                            <Route path="/" exact component={NotFound} />
                            <RouteRedirect from="/moved" to="/" code={301} />
                            <Redirect to="/" />
                            <Route component={NotFound} />
                        </Switch>
                    </span>
                );
            } else {
                return (
                    <div className="login-outer">
                        <Route component={Navbar} />
                        <Switch>
                            <Route path="/" exact component={Lots} />
                            <Route path="/lots" exact component={Lots} />
                            <Route path="/lots/:lotID" exact component={Lot}/>
                            <Route path="/zones" exact component={Zones} />
                            <Route path="/about" exact component={About} />
                            <Route path="/parking-info" exact component={ParkingInfo} />
                            <Route path="/terms" exact component={Terms} />
                            <Route path="/contact" exact component={Contact} />
                            <Route path="/login" exact component={Login} />
                            <Route path="/login/forgot" exact component={LoginForgot} />
                            <Route path="/login/reset/:email/:key" component={LoginReset} />
                            <Route path="/login/activation/:email/:key" component={LoginActivation} />
                            <Route path="/login/logout" exact component={LoginLogout} />
                            <Route path="/signup" exact component={Signup} />
                            
                            <Route component={NotFound} />
                            <RouteRedirect from="/moved" to="/" code={301} />
                            <Redirect to="/" />
                        </Switch>
                        <Footer />
                    </div>);
            }
    }
}


module.exports = AppUniversal;
