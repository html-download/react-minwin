/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorFinancialDynamicPrice', {
    dynamicPriceId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'dynamic_price_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    pricePercentage: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'price_percentage'
    },
    priceValue: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'price_value'
    },
    startPrice: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'start_price'
    },
    endPrice: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'end_price'
    },
    type: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'type'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      field: 'status'
    }
  }, {
    tableName: 'ss16_vendor_financial_dynamic_price'
  });
};
