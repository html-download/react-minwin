"use strict";
const Accodation = require("./sub-policy-accodation.jsx");
const React = require("react");
const ReactHelmet = require("react-helmet");
const ReactRouter = require("react-router-dom");

const Link = ReactRouter.Link;
const Helmet = ReactHelmet.Helmet;

class PolicyComparePage extends React.Component {
  constructor(props) {
    super(props);
    this.toggleChange = this.toggleChange.bind(this);
    this.state = { show: true };
  }
  toggleChange(event, index) {
    event.preventDefault();
    this.setState({ show: !this.state.show });
  }

   componentDidMount() {    
    window.scrollTo(0, 0);
  }

  render() {
    return (
      <section>
        <Helmet>
          <title>Policy Compare</title>
        </Helmet>
        <section className="empty-banner" />
        <section className="light_bg compare_details">
          <div className="container">
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/choose-policy">Choose Policy</Link>
                </li>
                <li className="breadcrumb-item" aria-current="page">
                  Order summary
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Upload Documents
                </li>
              </ol>
            </nav>

            <div className="table-responsive table-wrap">
              <table className="compare_table top">
                <thead>
                  <tr>
                    <th>
                      <h5 style={{ fontSize: "24px" }}>Compare</h5>
                    </th>
                    <th>
                      <div className="product-image">
                        <div className="product-img">
                          <img src="/public/media/images/c1.png" alt="" />
                        </div>
                        <h5>Union Insurance Silver Garage</h5>
                        <button className="remove">×</button>
                      </div>
                      <Link to="/order-summary">
                      <button  className="btn compare_btn">
                        AED 15,803
                      </button>
                      </Link>
                    </th>
                    <th>
                      <div className="product-image">
                        <div className="product-img">
                          <img src="/public/media/images/c2.png" />
                        </div>
                        <h5>Oriental Insurance</h5>
                        <button className="remove">×</button>
                      </div>
                      <Link to="/order-summary">
                      <button  className="btn compare_btn">
                        AED 15,803
                      </button>
                      </Link>
                    </th>
                    <th>
                      <div className="product-image">
                        <div className="product-img">
                          <img src="/public/media/images/c3.png" />
                        </div>
                        <h5>Adamjee Insurance Garge</h5>
                        <button className="remove">×</button>
                      </div>
                    <Link to="/order-summary">
                      <button  className="btn compare_btn">
                        AED 15,803
                      </button>
                      </Link>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td
                      colspan="4"
                      className={`toggle-td ${
                        this.state.show === true ? "open" : " "}`} >
                      <button
                        className="btn-open"
                        onClick={event => {this.toggleChange(event);}}>
                       
                        Overview
                      </button>
                      <div className="show_panel">
                        <table className="compare_sub_table">
                          <tbody>
                            <tr>
                              <td>Excess</td>
                              <td>AED 350</td>
                              <td>AED 350</td>
                              <td>AED 350</td>
                            </tr>
                            <tr>
                              <td>Driver Cover</td>
                              <td>AED 350</td>
                              <td>AED 350</td>
                              <td>AED 350</td>
                            </tr>
                            <tr>
                              <td>Third Party Liability</td>
                              <td>UAE Only</td>
                              <td>UAE Only</td>
                              <td>UAE Only</td>
                            </tr>
                            <tr>
                              <td>Damage To Your Vehicle</td>
                              <td>UAE & Oman</td>
                              <td>UAE & Oman</td>
                              <td>UAE</td>
                            </tr>
                            <tr>
                              <td>Roadside Assistance </td>
                              <td>Included</td>
                              <td>Included</td>
                              <td>Included</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </td>
                  </tr>
                  <Accodation />
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </section>
    );
  }
}

module.exports = PolicyComparePage;
