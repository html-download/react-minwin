$(document).ready(function(){
	//Fixed Header  
	$(window).on('load scroll resize orientationchange', function () {
		var scroll = $(window).scrollTop();
		if (scroll >= 50) {
			$(".site_header").addClass("fixed");
		} else {
			$(".site_header").removeClass("fixed");
		}		
	});

	new WOW().init();

	//Current Page
	$("[href]").each(function() {
		if (this.href == window.location.href) {
			$(this).addClass("current_page");
		}
	});

	//Offers
	$('.offers_list').owlCarousel({
		loop: true,
		margin: 20,		
		mouseDrag: false,
		dots: false,
		responsiveClass: true,
		nav: true,
		responsive: {
		  0: {
			items: 1,
			stagePadding: 50
		  },
		  640: {
			items: 1,
			stagePadding: 50
		  },
		  1000: {
			items: 4
		  }
		}
	});

	$('.offers_home').owlCarousel({
		loop: true,
		margin: 0,		
		mouseDrag: false,
		dots: false,
		nav: true,
		items: 1
	});

	//Tooltip
	$('[data-toggle="tooltip"]').tooltip({
		html: true
	});
	$('[rel="tooltip"]').tooltip();
	
	//Popover	
	$('[data-toggle="popover"]').popover({
		html: true,
        content: function () {
			var clone = $($(this).data('popover-content')).clone(true).removeClass('hide');
			$("body").addClass("step_popover");
            return clone;
        }
    });
	
	$('body').on('click', function (e) {
		$('[data-toggle="popover"]').each(function () {
			if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
				$("body").removeClass("step_popover");
				$(this).popover('hide');
				return;
			}
		});
	});

	$('body, .close_popover').on('hidden.bs.popover', function (e) {
		$(e.target).data("bs.popover").inState = { click: false, hover: false, focus: false }
	});

	//Modal
	$('.modal').on('hidden.bs.modal', function (e) {
		if($('.modal').hasClass('show')) {
			$('body').addClass('modal-open');
		}    
	});

	//Floating Label
	$(document).on('focus active', '.form-group.icon .form-control',function(){
		$('label[for='+$(this).attr('id')+']').parent().addClass('has-value');
	});
	$(document).on('blur', '.form-group.icon .form-control',function(){
		$('label[for='+$(this).attr('id')+']').parent().removeClass('has-value');
	});
	$('.form-group.icon .form-control').on('blur',function(){
		if($(this).val() == ''){
			$(this).parent().removeClass("has-value");
		}else{
			$(this).parent().addClass("has-value");
		}
	});

	//OTP
	$('.otp input').keyup(function(){
		if($(this).val().length==$(this).attr("maxlength")){
			$(this).next().focus();
		}
	});

	//How Works
	$('.laundry_works').click(function(e) {
		e.stopPropagation();
		$('#laundry_works').addClass('show');
		$('#how_it_works').removeClass('show');
	});
	$('.how_it_works').click(function(e) {
		e.stopPropagation();
		$('#how_it_works').addClass('show');
		$('#laundry_works').removeClass('show');
	});

	//Mini Cart
	$('.top_cart, div.mini_cart').click(function(e) {
		e.stopPropagation();
		$('body').addClass('open_cart modal-open');
	});	
	$('#mini_cart').on('click', function () {
		$('body').removeClass('open_cart modal-open');
	});	

	//Sorting
	window.onscroll = function() {myFunction()};
	var navbar = document.getElementById("sorting");
	var sticky = navbar.offsetTop-70;
	function myFunction() {
		if (window.pageYOffset >= sticky) {
			$('body').addClass('sticky')
		} else {
			$('body').removeClass('sticky')
		}
	};

	//Star Rating
	$('.stars label').on('mouseover', function(){
		var onStar = parseInt($(this).data('value'), 10);
		$(this).parent().children('label.star').each(function(e){
		  if (e < onStar) {
			$(this).addClass('hover');
		  }
		  else {
			$(this).removeClass('hover');
		  }
		});    
	  }).on('mouseout', function(){
		$(this).parent().children('label.star').each(function(e){
		  $(this).removeClass('hover');
		});
	});
	
	$('.stars label').on('click', function(){
	var onStar = parseInt($(this).data('value'), 10);
	var stars = $(this).parent().children('label.star');
	
	for (i = 0; i < stars.length; i++) {
		$(stars[i]).removeClass('selected');
	}
	
	for (i = 0; i < onStar; i++) {
		$(stars[i]).addClass('selected');
	}    
	});	



	

});

/*equal height*/
setHeights	= function()
{
	var $list		= $( '.equal' ),
		$items		= $list.find( '.height' );
		
	$items.css( 'height', 'auto' );
	var perRow = Math.floor( $list.width() / $items.width() );
	if( perRow == null || perRow < 2 ) return true;
	for( var i = 0, j = $items.length; i < j; i += perRow )
	{
		var maxHeight	= 0,
			$row		= $items.slice( i, i + perRow );

		$row.each( function()
		{
			var itemHeight = parseInt( $( this ).outerHeight() );
			if ( itemHeight > maxHeight ) maxHeight = itemHeight;
		});
		$(window).on('load', $row.css( 'height', maxHeight ));
	}
};	
$(document).ready(function(){
	setHeights();
	$( window ).on( 'resize', setHeights );
});

window.addEventListener("wheel", function(e) {
	setHeights();
});
$(document).mousemove(function(event){
	setHeights();
});

// datepicker
$('[data-toggle="datepicker"]').datepicker({
	autoHide: true
});

$('[data-toggle="timepicker"]').timepicker();


// Cache selectors
var lastId,
    topMenu = $(".item_menu li"),
    topMenuHeight = topMenu.outerHeight() + 95,
    // All list items
    menuItems = topMenu.find("a"),
    // Anchors corresponding to menu items
    scrollItems = menuItems.map(function(){
      var item = $($(this).attr("href"));
      if (item.length) { return item; }
    });

menuItems.click(function(e){
  var href = $(this).attr("href"),
      offsetTop = href === "#" ? 0 : $(href).offset().top-topMenuHeight+0;
  $('html, body').stop().animate({ 
      scrollTop: offsetTop
  }, 300);
  e.preventDefault();
});

// Bind to scroll
$(window).scroll(function(){
   // Get container scroll position
   var fromTop = $(this).scrollTop()+topMenuHeight;
   
   // Get id of current scroll item
   var cur = scrollItems.map(function(){
     if ($(this).offset().top < fromTop)
       return this;
   });
   // Get the id of the current element
   cur = cur[cur.length-1];
   var id = cur && cur.length ? cur[0].id : "";
   
   if (lastId !== id) {
       lastId = id;
       // Set/remove active class
       menuItems
         .parent().removeClass("active")
         .end().filter("[href='#"+id+"']").parent().addClass("active");
   }                   
});


// filter toggle

$('.filter-toggle, .filter-overlay, .close-filter').click(function(e) {
		e.stopPropagation();
		$('body').toggleClass('open_filter');
	});	