const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const UserIdentity = require('../../../helpers/user-identity');

const apiUrl = UserIdentity.apiUrl;


class Actions {
    static saveStall(data, history, updateOccupancy) {

        ApiActions.put(
            `${apiUrl}/stall`,
            data,
            Store,
            Constants.SAVE_STALL,
            Constants.SAVE_STALL_RESPONSE,
            (err, response) => {
                if (!err) {
                    Toaster.success('Stall data updated successfully! please wait...data updating..');
                    updateOccupancy()
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    static getOccupancy(url) {

        ApiActions.get(
            url,
            undefined,
            Store,
            Constants.UPDATE_OCCUPANCY,
            Constants.UPDATE_OCCUPANCY_RESPONSE,
            (err, response) => {
                if (!err) {
                    Toaster.success('Data updated!');
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static getSummary(url, updateMapBounds, updateOccupancy, getOverlayImage, getLastMessage) {

        ApiActions.get(
            url,
            undefined,
            Store,
            Constants.GET_SUMMARY,
            Constants.GET_SUMMARY_RESPONSE,
            (err, response) => {
                if (!err) {
                    getOverlayImage();
                    updateOccupancy();
                    getLastMessage();
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static saveStatusHybrid(data, history, updateOccupancy, isStatus = true) {

        ApiActions.put(
            `${apiUrl}/lot`,
            data,
            Store,
            Constants.SAVE_STATUS_HYBRID,
            Constants.SAVE_STATUS_HYBRID_RESPONSE,
            (err, response) => {
                if (!err) {
                	if (isStatus) {
                		Toaster.success('Lot Unavailable status updated successfully');
                	} else {
                		Toaster.success('Lot Hybrid status updated successfully');
                	}
                    updateOccupancy();
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static showLotMessageModal() {
        Store.dispatch({
            type: Constants.SHOW_LOT_MESSAGE
        });
    }

    static hideLotMessageModal() {

        Store.dispatch({
            type: Constants.HIDE_LOT_MESSAGE
        });
    }

    static showZoneHistoricalModal() {
        Store.dispatch({
            type: Constants.SHOW_ZONE_HISTORICAL
        });
    }

    static hideZoneHistoricalModal() {

        Store.dispatch({
            type: Constants.HIDE_ZONE_HISTORICAL
        });
    }

    static showLotHistoricalModal(loadHistorical) {
        Store.dispatch({
            type: Constants.SHOW_LOT_HISTORICAL
        });
        loadHistorical()
    }

    static hideLotHistoricalModal() {

        Store.dispatch({
            type: Constants.HIDE_LOT_HISTORICAL
        });
    }

    static setTimeLimit(value) {

        Store.dispatch({
            type: Constants.SET_TIME_LIMIT,
            time_limit : value
        });
    }

    static initTimeLimit(value) {

        Store.dispatch({
            type: Constants.INIT_TIME_LIMIT
        });
    }

    static loadHistorical(data) {

        ApiActions.get(
            `/api/history`,
            data,
            Store,
            Constants.SAVE_MAP_ARRAY,
            Constants.SAVE_MAP_ARRAY_RESPONSE,
            (err, response) => {
                if (!err) {
                    
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static setHistoricalDate(value, data) {
        Store.dispatch({
            type: Constants.SET_HISTORICAL_DATE,
            date : value
        });

        this.loadHistorical(data)
    }

    static loadHistoricalDownload(data, getHistoricalExport) {

        ApiActions.get(
            `/api/history/download`,
            data,
            Store,
            Constants.SAVE_MAP_ARRAY_DOWNLOAD,
            Constants.SAVE_MAP_ARRAY_DOWNLOAD_RESPONSE,
            (err, response) => {
                if (!err) {
                    getHistoricalExport()
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    
    static setHistoricalDay(value) {
        localStorage.setItem('dashboard_zone_day_selected', value);

        Store.dispatch({
            type: Constants.SET_HISTORICAL_DAY,
            day : value
        });
    }

    static createLotMessage(data, passingData) {
        ApiActions.post(
            `${apiUrl}/lot/msg`,
            data,
            Store,
            Constants.CREATE_MESSAGE,
            Constants.CREATE_MESSAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                    Toaster.success('Lot message saved successfully');
                    this.getLotMessage(passingData);
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static updateLotMessage(data, passingData) {
        
        ApiActions.put(
            `${apiUrl}/lot/msg`,
            data,
            Store,
            Constants.UPDATE_MESSAGE,
            Constants.UPDATE_MESSAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                    Toaster.success('Lot message updated successfully');
                    this.getLotMessage(passingData);
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static getLotMessage(data) {
        ApiActions.get(
            `${apiUrl}/lot/msg`,
            data,
            Store,
            Constants.GET_LOT_MESSAGE,
            Constants.GET_LOT_MESSAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                    //Toaster.success('Lot message saved successfully');
                } else {
                    //Toaster.error(err);
                }

            }
        );
    }

    static deleteLotMessage(data, passingData) {
        ApiActions.delete(
            `${apiUrl}/lot/msg`,
            data,
            Store,
            Constants.DELETE_LOT_MESSAGE,
            Constants.DELETE_LOT_MESSAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                    Toaster.error('Lot message deleted successfully!');
                    this.getLotMessage(passingData);
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    
    static getOverlay(url) {

        ApiActions.get(
            url,
            undefined,
            Store,
            Constants.GET_OVERLAY_IMAGE,
            Constants.GET_OVERLAY_IMAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static updateOverlayLoaded() {
        Store.dispatch({
            type: Constants.UPDATE_OVERLAY_LOAD
        });
    }
    
    static showInfoWindowModal(stallBaseArray) {
        Store.dispatch({
            type: Constants.SHOW_INFO_WINDOW_MODAL,
            stallMarkerArray : stallBaseArray
        });
    }

    static hideInfoWindowModal() {
        Store.dispatch({
            type: Constants.HIDE_INFO_WINDOW_MODAL,
            stallMarkerArray : {}
        });
    }

    static toggleInfoWindowModal() {
        Store.dispatch({
            type: Constants.TOGGLE_INFO_WINDOW_MODAL,
            stallMarkerArray : {}
        });
    }

    static onChangePopupEnabled(checked) {
        Store.dispatch({
            type: Constants.TOGGLE_POPUP_ENABLED,
            checked : checked
        });
    }

    static recentInfoWindowCloseUpdate() {
        Store.dispatch({
            type: Constants.RECENT_CLOSE_UPDATE
        });
    }
}


module.exports = Actions;
