<?php include ('inc/header.php'); ?>

<section class="banner full_row">
  <div class="container">
    <h1 class="animated fadeInDown">Building robust and scalable web & mobile apps for all industries of startups, SME & fortune 500 companies</h1>
    <p class="desc animated fadeInUp">Launch your own online food ordering marketplace.</p>
    <p class="animated fadeInUp">Like <b>FoodPanda</b>, Zomato, <b>Just eat</b>.</p>
    <p class="action mb0 animated fadeInUp">
      <a href="<?php echo $baseurl;?>contact-us" title="Get a Quote" class="btn line">Get a Quote</a>
      <a href="<?php echo $baseurl;?>restaurant-menu-ordering-application" title="Live Demo" class="btn green">Live Demo</a>
    </p>    
  </div> <!--container-->
</section> <!--banner-->

<section class="clients home full_row">
  <div class="container">
    <h2 class="head">Our fortune clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="mobile full_row">
  <div class="container">
    <div class="content">
      <h3 class="head_desc">Mobile Services</h3>
      <h2 class="head">Mobile app development</h2>
      <p>We exhibit world class quality in delivering mobile application development, web applications and prominent products across all industrial verticals with utmost precision and uniqueness in functionality. We serve our clients with dedication to deliver profitable projects dedication to deliver profitable projects. </p>
    
      <a href="<?php echo $baseurl;?>mobile-application-development" class="btn green">Learn More</a>
    </div> <!--content-->
    
    <div class="boxes">
      <div class="box_col">
        <div class="box ios">
          <i class="icon apple"></i>
          <h3>iPhone Application Development</h3>
          <p>Extensive experience with iOS app development services enables us to craft bespoke solutions for large and small enterprises rapidly and efficiently.</p>
          <a href="<?php echo $baseurl;?>iphone-application-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </div> <!--box_col-->

      <div class="box_col">
        <div class="box mb30 android">
          <i class="icon android"></i>
          <h3>Android Application Development</h3>
          <p>We offers top-notch, flawless and dynamic Android app development services all around the globe.</p>
          <a href="<?php echo $baseurl;?>android-application-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
        
        <div class="box react">
          <i class="icon react"></i>
          <h3>React Native Application Development</h3>
          <p>Reliable and scalable react native app development for both Android and iOS platforms in single code base.</p>
          <a href="<?php echo $baseurl;?>react-native-app-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </div> <!--box_col-->
    </div> <!--boxes-->
  </div> <!--container-->
</section> <!--mobile-->

<section class="web full_row">
  <div class="container relative">
    <h3 class="head_desc">Web Services</h3>
    <h2 class="head line">Web app development</h2>

    <ul class="boxes reset col3">
    <li>
        <div class="box react">
          <i class="icon react"></i>
          <h3>ReactJS Application Development</h3>
          <p>Build interactive UI and lightweight web applications in React JS which provides better performance.</p>
          <a href="<?php echo $baseurl;?>react-js-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box angular">
          <i class="icon angular"></i>
          <h3>AngularJS Application Development</h3>
          <p>Rich user experience web app development using AngularJS for all suitable web applications with MVC.</p>
          <a href="<?php echo $baseurl;?>angularjs-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      
      <li>
        <div class="box yii">
          <i class="icon yii"></i>
          <h3>YII Web Application Development</h3>
          <p>Build the industry-leading web solutions for several industry verticals like food, transportation, etc.</p>
          <a href="<?php echo $baseurl;?>yii-application-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box laravel">
          <i class="icon laravel"></i>
          <h3>Laravel Application Development</h3>
          <p>It offers a wide range of projects, including social media, m-commerce using MVC interface, ORM, queuing system,  authentication. </p>
          <a href="<?php echo $baseurl;?>laravel-application-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>

      <li>
        <div class="box nodejs">
          <i class="icon nodejs"></i>
          <h3>NodeJS Application Development</h3>
          <p>Develop server-side and chat based applications, real-time applications shared with multi users and multiple devices  by using Node.js.</p>
          <a href="<?php echo $baseurl;?>node-js-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box stack">
          <i class="icon stack"></i>
          <h3>Full Stack Application Development</h3>
          <p>Full stack web development with UX, UI, front-end, back-end by using latest tools and technologies like React JS, Yii2, Laravel, Node.js.</p>
          <a href="<?php echo $baseurl;?>full-stack-web-development" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      
      
    </ul> <!--boxes-->
  </div> <!--container-->

  <span class="bg"></span>
</section> <!--web-->

<section class="products full_row">
  <div class="content_head full_row">
    <div class="container relative">
      <h3 class="head_desc">Our Products</h3>
      <h2 class="head">Get the ready-made solution for your business</h2>
    </div> <!--container-->
  </div> <!--content_head-->

  <div class="container md relative">
    <ul class="boxes reset col3">
    <li>
        <div class="box foodpurby">
          <div class="img">
            <amp-img src="<?php echo $baseurl;?>images/foodpurby-logo-white.png" alt="Foodpurby" width="180" height="100" layout="responsive"></amp-img>
          </div>
          <div class="content">
            <h3>Food ordering system</h3>
            <p>A readymade online food ordering and delivery system like FoodPanda, Zomato, JustEat, Postmates, etc for your online restaurant business.</p>
            <a href="<?php echo $baseurl;?>" class>See More <i class="fa fa-arrow-right"></i></a>
          </div> <!--box-->
        </div> <!--box-->
      </li>
      <li>
        <div class="box grobino">
          <div class="img">
            <amp-img src="<?php echo $baseurl;?>images/grobino-logo-white.png" alt="Grobino" width="180" height="100" layout="responsive"></amp-img>
          </div>
          <div class="content">
            <h3>Grocery ordering software</h3>
            <p>Grobino provides end-to-end e-grocery ordering and delivery software, for customers' online shopping experience and the store's order fulfillment through payment processing & delivery for supermarkets, grocer’s chains.</p>
            <a href="<?php echo $baseurl;?>" class>See More <i class="fa fa-arrow-right"></i></a>
          </div> <!--box-->
        </div> <!--box-->
      </li>
      <li>
        <div class="box cropla">
          <div class="img">
            <amp-img src="<?php echo $baseurl;?>images/cropla-logo-white.png" alt="Cropla" width="180" height="100" layout="responsive"></amp-img>
          </div>
          <div class="content">
            <h3>Taxi dispatch system</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur varius quam in augue euismod.</p>
            <a href="<?php echo $baseurl;?>restaurant-menu-ordering-application" class>See More <i class="fa fa-arrow-right"></i></a>
          </div> <!--box-->
        </div> <!--box-->
      </li>
      
    </ul> <!--boxes-->
  </div> <!--container-->
</section> <!--products-->

<section class="clients find_us full_row">
  <div class="container">
    <h3 class="head_desc">Find us on</h3>
    <h2 class="head">Verified & trusted development firm by</h2>
    <ul class="reset">
      <li>
          <a href="https://extract.co/technoduce" target="_blank">
            <amp-img src="<?php echo $baseurl;?>images/extract.png" alt="Extract" width="180" height="80" layout="responsive"></amp-img>
          </a>
      </li>
      <li>
          <a href="https://clutch.co/profile/technoduce-info-solutions" target="_blank">
            <amp-img src="<?php echo $baseurl;?>images/clutch.png" alt="Clutch" width="180" height="80" layout="responsive"></amp-img>
          </a>
      </li>
      <li>
          <a href="https://www.appfutura.com/developers/technoduce-info-solutions-pvt-ltd" target="_blank">
            <amp-img src="<?php echo $baseurl;?>images/app-futura.png" alt="App Futura" width="180" height="80" layout="responsive"></amp-img>
          </a>
      </li>
      <li>
          <a href="https://www.goodfirms.co/companies/view/927/technoduce-info-solutions-pvt-ltd" target="_blank">
            <amp-img src="<?php echo $baseurl;?>images/goodfirms.png" alt="GoodFirms" width="180" height="80" layout="responsive"></amp-img>
          </a>
      </li>
      <li>
          <a href="company/technoduce-info-solutions-private-limited-iso.pdf" target="_blank">
            <amp-img src="<?php echo $baseurl;?>images/iso.png" alt="ISO" width="180" height="80" layout="responsive"></amp-img>
          </a>
      </li>
    </ul>

    <div class="years full_row mb30">
      <span>Years of experience</span>
      <span class="year">7+</span>
      <span>We are a team of 70+ who are dedicated to serving the customers and have been functioning in the IT industry since 2011.</span>
    </div> <!--years-->

    <div class="row facts">
      <div class="col_3">
        <span>50+</span><b>Countries</b>
      </div> <!--col_3-->
      <div class="col_3">
        <span>70+</span><b>Professionals</b>
      </div> <!--col_3-->
      <div class="col_3">
        <span>90+</span><b>Projects</b>
      </div> <!--col_3-->
      <div class="col_3">
        <span>99%</span><b>Satisfaction</b>
      </div> <!--col_3-->
    </div> <!--facts-->
  </div> <!--container-->
</section> <!--clients-->

<?php include ('inc/footer.php'); ?>