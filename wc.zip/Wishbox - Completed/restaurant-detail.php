<?php include ('inc/header.php'); ?>

<div class="site_page full_row">
    <section class="detail full_row" style="background-image:url(assets/img/restaurants.jpg)">
        <span class="fav added" data-toggle="tooltip" title="Remove from Favorites"><i class="la la-heart-o"></i></span>

        <div class="vendor_logo">
            <span><img src="assets/img/logo/3.jpg"></span>
        </div> <!--vendor_logo-->

        <div class="vendor_info full_row">
            <div class="vendor_status full_row mb5">
                <span class="location"><i class="fi pin3"></i>Abu Hamour</span>
                <span class="green">Open</span>
                <span class="red">Closed</span>
                <span class="tag">Recommended</span>
            </div> <!--vendor_status-->

            <h1>Ananas Restaurant & Cafeteria</h1>
            <p class="desc">Diner, Breakfast, Burgers, Sandwiches</p>

            <ul class="user_features">
                <li><span>QR 30</span><span>Minimum</span></li>
                <li><span>35-40 mins</span><span>Delivery Time</span></li>
                <li>
                    <span class="icons">
                        <i class="fi cash" data-toggle="tooltip" title="Case on Delivery"></i>
                        <i class="fi credit-card2" data-toggle="tooltip" title="Online Payment"></i>
                        <i class="lni-emoji-smile" data-toggle="tooltip" title="Smile Points"></i>
                    </span>
                    <span>Payment</span>
                </li>
            </ul> <!--features-->
            
            <div class="vendor_features">
                <p class="icons">
                    <i class="fi scooter1" data-toggle="tooltip" title="Delivery"></i> 
                    <i class="fi shopping-bag" data-toggle="tooltip" title="Pickup"></i> 
                    <i class="fi table" data-toggle="tooltip" title="Table Booking"></i>
                </p>
                <div class="ratings">
                    <span><b><i class="lni-star-filled"></i>4.5</b> Ratings  &  120+ Reviews</span>                       
                </div> <!--ratings-->
            </div> <!--vendor_features-->
        </div> <!--vendor_info-->
    </section> <!--detail-->

    <section id="sorting" class="sorting full_row">
        <div class="float-left">
            <ul class="category_menu nav nav-tabs detail_tabs">
                <li><a data-toggle="tab" href="#items" class="active"><i class="fi dinner"></i><span>Menu</span></a></li>
                <li><a data-toggle="tab" href="#table_booking"><i class="fi table"></i><span>Table Booking</span></a></li>
                <li><a data-toggle="tab" href="#ratings"><i class="la la-star-o"></i><span>Ratings & Reviews</span></a></li>
                <li><a data-toggle="tab" href="#info"><i class="la la-info-circle"></i><span>Info</span></a></li>
            </ul> <!--category_menu-->
        </div>

        <div class="float-right">
            <div class="switch float-left">
                <span>Veg Only</span>
                <input id="veg" type="checkbox" class="hide">
                <label for="veg"></label>                
            </div> <!--switch-->

            <div class="form-group icon">
                <label for="item_search"><i class="la la-search"></i></label>
                <input id="item_search" type="text" class="form-control" placeholder="Search for dishes...">
            </div> <!--form-group-->
        </div>
    </section> <!--sorting-->

    <section class="item_details full_row">
        <div class="tab-content full_row">
            <div id="items" class="tab-pane fade show active full_row" data-sticky_parent>
                <div class="item_menu" data-sticky_column>
                    <ul>
                        <li><a href="#offered">Offered Items</a></li>
                        <li><a href="#most">Most Selling</a></li>
                        <li><a href="#chinese">Chinese Food</a></li>
                        <li><a href="#biryani">Biryani & Rice Feasts</a></li>
                        <li><a href="">Chinese Food</a></li>
                        <li><a href="">Burger</a></li>
                        <li><a href="">Club</a></li>
                        <li><a href="">Cold Beverages</a></li>
                        <li><a href="">Desserts</a></li>
                        <li><a href="">Egg</a></li>
                        <li><a href="">Fish</a></li>
                        <li><a href="">Grills</a></li>
                        <li><a href="">Hot Beverages</a></li>
                        <li><a href="">Mutton</a></li>
                        <li><a href="">Non Veg</a></li>
                    </ul>
                </div> <!--item_menu-->
                
                <div class="item_listing" data-sticky_column>
                    <h3 id="offered">Offered Items</h3>
                    <p class="desc grey">3 items</p>

                    <ul class="offer_items equal">
                        <li>
                            <div class="content">
                                <div class="img" style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)">
                                    <span>Buy 1 Get 1 Offer</span>
                                </div> <!--img-->

                                <div class="item_detail">
                                    <h5 class="height"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                                    <div class="price">QR 20</div>
                                    <div class="action added">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div><!--content-->
                        </li>
                        <li>
                            <div class="content">
                                <div class="img" style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)">
                                    <span>Buy 1 Get 1 Offer</span>
                                </div> <!--img-->

                                <div class="item_detail">
                                    <h5 class="height"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div><!--content-->
                        </li>
                        <li>
                            <div class="content">
                                <div class="img" style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)">
                                    <span>Buy 1 Get 1 Offer</span>
                                </div> <!--img-->

                                <div class="item_detail">
                                    <h5 class="height"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div><!--content-->
                        </li>
                        <li>
                            <div class="content">
                                <div class="img" style="background-image:url(assets/img/items/Pepper-Chicken-Gravy.jpg)">
                                    <span>Buy 1 Get 1 Offer</span>
                                </div> <!--img-->

                                <div class="item_detail">
                                    <h5 class="height"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div><!--content-->
                        </li>
                        <li>
                            <div class="content">
                                <div class="img" style="background-image:url(assets/img/items/Smoked-Butter-Chicken-Rice-Feast.jpg)">
                                    <span>Buy 1 Get 1 Offer</span>
                                </div> <!--img-->

                                <div class="item_detail">
                                    <h5 class="height"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div><!--content-->
                        </li>
                        <li>
                            <div class="content">
                                <div class="img" style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)">
                                    <span>Buy 1 Get 1 Offer</span>
                                </div> <!--img-->

                                <div class="item_detail">
                                    <h5 class="height"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div><!--content-->
                        </li>
                    </ul> <!--offer_items-->

                   <h3 id="most">Most Selling</h3>
                    <p class="desc grey">3 items</p>

                            <ul class="offer_items items">
                        <li>
                            <div class="item_detail full">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action added">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>        
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="img" style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></div>
                            <div class="item_detail">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>        
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="img" style="background-image:url(assets/img/items/Pepper-Chicken-Gravy.jpg)"></div>
                            <div class="item_detail">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>        
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul> <!--offer_items-->



                    <h3 id="chinese">Chinese Food</h3>
                    <p class="desc grey">3 items</p>

                    <ul class="offer_items items">
                        <li>
                            <div class="item_detail full">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action added">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="img" style="background-image:url(assets/img/items/Smoked-Butter-Chicken-Rice-Feast.jpg)"></div>
                            <div class="item_detail">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item_detail full">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul> <!--offer_items-->

                    <h3 id="biryani">Biryani & Rice Feasts</h3>
                    <p class="desc grey">3 items</p>

                    <ul class="offer_items items">
                        <li>
                            <div class="item_detail full">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action added">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="item_detail full">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="img" style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></div>
                            <div class="item_detail">
                                <h5><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5> 
                                <span class="offer">Buy 1 Get 1 Offer</span>
                                <p class="desc grey">Donec ultricies molestie nisl. Praesent mollis, arcu vitae porta pellentesque, magna purus sollicitudin velit, laoreet blandit diam nulla nec mauris. Phasellus imperdiet ipsum eget imperdiet lobortis. Aenean pharetra lobortis consequat.</p>
                                <div class="full_row mt10">
                                    <div class="price">QR 20</div>
                                    <div class="action">
                                        <a class="add_cart" data-toggle="modal" data-target="#modal_choice">Add</a>
                                        <div class="qty_box">                                            
                                            <span><i class="la la-minus"></i></span>		
                                            <input type="text" class="form-control" value="2" readonly>
                                            <span><i class="la la-plus"></i></span>
                                        </div> <!--qty_box-->
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul> <!--offer_items-->
                </div> <!--item_listing-->
            </div> <!--items-->

            <div id="table_booking" class="tab-pane fade full_row">
                <div class="container">
                    <h4>1. Choose your booking details</h4>
                    <div class="form-group mb10">
                        <p class="label">Choose your date</p>
                        <ul class="select_box">
                            <li>
                                <input name="date" id="d1" type="radio" class="hide">
                                <label for="d1">Today<span>15</span></label>
                            </li>
                            <li>
                                <input name="date" id="d2" type="radio" class="hide">
                                <label for="d2">Tomorrow<span>16</span></label>
                            </li>
                            <li>
                                <input name="date" id="d3" type="radio" class="hide" checked>
                                <label for="d3">Wednesday<span>17</span></label>
                            </li>
                            <li>
                                <input name="date" id="d4" type="radio" class="hide">
                                <label for="d4">Thursday<span>18</span></label>
                            </li>
                            <li>
                                <input name="date" id="d5" type="radio" class="hide">
                                <label for="d5">Friday<span>19</span></label>
                            </li>
                            <li>
                                <input name="date" id="d6" type="radio" class="hide">
                                <label for="d6">Saturday<span>20</span></label>
                            </li>
                            <li>
                                <input name="date" id="d7" type="radio" class="hide">
                                <label for="d7">Sunday<span>21</span></label>
                            </li>
                        </ul> <!--select_box-->
                    </div> <!--form-group-->
                    
                    <div class="form-group mb10">
                        <p class="label">Choose your time</p>
                        <ul class="select_box">
                            <li>
                                <input name="time" id="t1" type="radio" class="hide">
                                <label for="t1">PM<span>4:30</span></label>
                            </li>
                            <li>
                                <input name="time" id="t2" type="radio" class="hide">
                                <label for="t2">PM<span>5:00</span></label>
                            </li>
                            <li>
                                <input name="time" id="t3" type="radio" class="hide">
                                <label for="t3">PM<span>5:30</span></label>
                            </li>
                            <li>
                                <input name="time" id="t4" type="radio" class="hide">
                                <label for="t4">PM<span>6:00</span></label>
                            </li>
                            <li>
                                <input name="time" id="t5" type="radio" class="hide">
                                <label for="t5">PM<span>6:30</span></label>
                            </li>
                            <li>
                                <input name="time" id="t6" type="radio" class="hide" checked>
                                <label for="t6">PM<span>7:00</span></label>
                            </li>
                            <li>
                                <input name="time" id="t7" type="radio" class="hide">
                                <label for="t7">PM<span>7:30</span></label>
                            </li>
                            <li>
                                <input name="time" id="t8" type="radio" class="hide">
                                <label for="t8">PM<span>8:00</span></label>
                            </li>
                            <li>
                                <input name="time" id="t9" type="radio" class="hide">
                                <label for="t9">PM<span>8:30</span></label>
                            </li>
                            <li>
                                <input name="time" id="t10" type="radio" class="hide">
                                <label for="t10">PM<span>9:00</span></label>
                            </li>
                            <li>
                                <input name="time" id="t11" type="radio" class="hide">
                                <label for="t11">PM<span>9:30</span></label>
                            </li>
                            <li>
                                <input name="time" id="t12" type="radio" class="hide">
                                <label for="t12">PM<span>10:00</span></label>
                            </li>
                            <li>
                                <input name="time" id="t13" type="radio" class="hide">
                                <label for="t13">PM<span>10:30</span></label>
                            </li>
                        </ul> <!--select_box-->
                    </div> <!--form-group-->
                    
                    <div class="form-group">                        
                        <p class="label">Number of Guests</p>
                        <ul class="select_box circle">
                            <li>
                                <input name="guests" id="g1" type="radio" class="hide">
                                <label for="g1">1</label>
                            </li>
                            <li>
                                <input name="guests" id="g2" type="radio" class="hide">
                                <label for="g2">2</label>
                            </li>
                            <li>
                                <input name="guests" id="g3" type="radio" class="hide">
                                <label for="g3">3</label>
                            </li>
                            <li>
                                <input name="guests" id="g4" type="radio" class="hide">
                                <label for="g4">4</label>
                            </li>
                            <li>
                                <input name="guests" id="g5" type="radio" class="hide" checked>
                                <label for="g5">5</label>
                            </li>
                            <li>
                                <input name="guests" id="g6" type="radio" class="hide">
                                <label for="g6">6</label>
                            </li>
                            <li>
                                <input name="guests" id="g7" type="radio" class="hide">
                                <label for="g7">7</label>
                            </li>
                            <li>
                                <input name="guests" id="g8" type="radio" class="hide">
                                <label for="g8">8</label>
                            </li>
                            <li>
                                <input name="guests" id="g9" type="radio" class="hide">
                                <label for="g9">9</label>
                            </li>
                            <li>
                                <input name="guests" id="g10" type="radio" class="hide">
                                <label for="g10">10</label>
                            </li>
                            <li>
                                <input name="guests" id="g11" type="radio" class="hide">
                                <label for="g11">10+</label>
                            </li>
                            <li>
                                <input name="guests" id="g12" type="radio" class="hide">
                                <label for="g12">15+</label>
                            </li>
                            <li>
                                <input name="guests" id="g13" type="radio" class="hide">
                                <label for="g13">20+</label>
                            </li>
                        </ul> <!--select_box-->
                    </div> <!--form-group-->

                    <h4>2. Enter guest details</h4>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group icon">
                                <label for="smobile"><i class="lni-mobile"></i><span class="grey">Mobile Number</span></label>
                                <input id="smobile" type="text" class="form-control">
                            </div> <!--form-group-->
                            
                            <div class="form-group icon">
                                <label for="sname"><i class="la la-user"></i><span class="grey">Name</span></label>
                                <input id="sname" type="text" class="form-control">
                            </div> <!--form-group-->
                            
                            <div class="form-group icon">
                                <label for="semail"><i class="fi mail"></i><span class="grey">Email Address</span></label>
                                <input id="semail" type="text" class="form-control">
                            </div> <!--form-group-->

                            <div class="form-group">
                                <textarea class="form-control" placeholder="Your Comments"></textarea>
                            </div> <!--form-group-->

                            <div class="form-group action icon mb20">
                                <button class="btn full submit">book your table <i class="la la-arrow-right"></i></button>
                            </div> <!--form-group-->
                        </div>
                        <div class="col-sm-6 text-center">
                            <img src="assets/img/table-infographic.svg" class="table_infographic">
                        </div>
                    </div>
                </div> <!--container-->
            </div> <!--table_booking-->

            <div id="ratings" class="tab-pane fade full_row">
                <div class="container">
                    <div class="overall_ratings float-left relative">
                        <span class="count">4.0</span>                        
                        <span class="overall_star star_4"></span>
                        <p class="grey regulars mb0">Based on 25 reviews</p>
                    </div> <!--overall_ratings-->

                    <a data-dismiss="modal" data-toggle="modal" data-target="#modal_ratings" class="btn line mt15 small float-right"><i class="la la-plus-circle"></i> Add Rating</a>

                    <ul class="reviews full_row mt30 mb10">
                        <li class="no_reviews">
                            <img src="assets/img/reviews.svg">
                            <p>There are no reviews yet.</p>
                            <p>Be the first to review <b>"Ananas Restaurant & Cafeteria"</b></p>
                            <a data-dismiss="modal" data-toggle="modal" data-target="#modal_ratings" class="btn line mt10 small"><i class="la la-plus-circle"></i> Add Rating</a>                            
                        </li>
                        <li>
                            <div class="user_info">
                                <span class="img">BN<img src="assets/img/user1.jpg"></span>
                                <span class="name">Bahira Nadirah</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                        <li>
                            <div class="user_info">
                                <span class="img">TK</span>
                                <span class="name">Taj Kaseeb</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                        <li>
                            <div class="user_info">
                                <span class="img">JA<img src="assets/img/user2.jpg"></span>
                                <span class="name">Jubayr Amid</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                        <li>
                            <div class="user_info">
                                <span class="img">KR<img src="assets/img/user3.jpg"></span>
                                <span class="name">Khuzaimah Raghid</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                    </ul>

                    <p class="show_more full_row">
                        <a class="btn">Show More</a>
                    </p>
                </div> <!--container-->
            </div> <!--ratings-->

            <div id="info" class="tab-pane fade full_row">
                <div class="container">
                    <div class="vendor_address full_row mb20">
                        <ul class="full_row">
                            <li>
                                <i class="fi pin3"></i>
                                <h4 class="mb10">Ananas Restaurant & Cafeteria</h4>
                                <p class="mb0 grey">
                                    <span class="block">Opposite Prestige Laundry, Al Matar Al Qadeem St,</span>
                                    <span class="block">Old Airport Area, Doha.</span>
                                </p>
                            </li>
                            <li>
                                <i class="fi call"></i><span class="grey">+98765432101, +98765432101</span>
                            </li>
                        </ul>

                        <div id="vendor_location" class="full_row"></div>
                    </div> <!--vendor_address-->

                    <div class="working_hours full_row">
                        <h4 class="mb5">Working Hours</h4>
                        <ul>
                            <li>
                                <i class="la la-clock-o"></i> Sunday to Wednesday
                                <span class="block">6:00 AM - 4:00 PM</span>
                                <span class="block">4:01 PM - 11:59 PM</span>
                            </li>
                            <li>
                                <i class="la la-clock-o"></i> Thursday to Saturday
                                <span class="block">6:00 AM - 4:00 PM</span>
                                <span class="block">4:01 PM - 11:59 PM</span>
                            </li>
                        </ul>
                    </div> <!--working_hours-->
                </div> <!--container-->
            </div> <!--info-->
        </div> <!--tab-content-->
    </section> <!--item_details-->
</div> <!--site_page-->

<div id="modal_choice" class="modal fade" role="dialog">
	<div class="modal-dialog md">
		<div class="modal-content">
            <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>
            <div class="item_info">
                <span class="img" style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                <div>
                    <span class="grey regular block">Customize</span>
                    <h3 class="mb5">Chicken Keema Wrap</h3>
                    <span class="price">QR 20</span>
                </div>
            </div> <!--item_info-->
            
			<div class="modal-body">
                <div class="form-group mb10">
                    <h5><span>Sweet Treat</span><span>(Choose 1)</span></h5>
                    <ul class="choices">
                        <li>
                            <input id="c1" type="checkbox" class="hide">
                            <label for="c1" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="c2" type="checkbox" class="hide">
                            <label for="c2" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="c3" type="checkbox" class="hide">
                            <label for="c3" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="c4" type="checkbox" class="hide">
                            <label for="c4" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                    </ul> <!--choices-->
                </div> <!--form-group-->

                <div class="form-group mb10 has-error">
                    <h5><span>Add on FRIES!</span><span>(Choose items from the list)</span></h5>
                    <ul class="choices">
                        <li>
                            <input id="c5" type="checkbox" class="hide">
                            <label for="c5" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="c6" type="checkbox" class="hide">
                            <label for="c6" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="c7" type="checkbox" class="hide">
                            <label for="c7" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="c8" type="checkbox" class="hide">
                            <label for="c8" class="checkbox"><span>Strawberry Shake</span> <span class="price">QR 1</span></label>
                        </li>
                    </ul> <!--choices-->
                </div> <!--form-group-->

                <div class="form-group mb10">
                    <h5><span>Sizes</span></h5>
                    <ul class="choices">
                        <li>
                            <input id="s1" type="radio" name="size" class="hide">
                            <label for="s1" class="radio"><span>Medium</span> <span class="price">QR 1</span></label>
                        </li>
                        <li>
                            <input id="s2" type="radio" name="size" class="hide">
                            <label for="s2" class="radio"><span>Large</span> <span class="price">QR 1</span></label>
                        </li>
                    </ul> <!--choices-->
                </div> <!--form-group-->
			</div> <!--modal-body-->

            <div class="choice_footer">
                <span class="float-left price">Total: QR 23</span>
                <button class="btn float-right"><i class="la la-plus-circle"></i> Add Item</button>
            </div> <!--choice_footer-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_choice-->

<div id="modal_ratings" class="modal fade" role="dialog">
	<div class="modal-dialog sm">
		<div class="modal-content">
            <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>            
			<div class="modal-body">
                <span class="user_tag">KR</span>
                <h4 class="mb15">Khuzaimah Raghid</h4>

                <div class="form-group stars">
                    <input id="star1" name="star" type="radio" class="hide" value="1">
                    <label for="star1" class="star" data-value='1'><i class="lni-star-filled"></i></label>
                    <input id="star2" name="star" type="radio" class="hide" value="2">
                    <label for="star2" class="star" data-value='2'><i class="lni-star-filled"></i></label>
                    <input id="star3" name="star" type="radio" class="hide" value="3">
                    <label for="star3" class="star" data-value='3'><i class="lni-star-filled"></i></label>
                    <input id="star4" name="star" type="radio" class="hide" value="4">
                    <label for="star4" class="star" data-value='4'><i class="lni-star-filled"></i></label>
                    <input id="star5" name="star" type="radio" class="hide" value="5">
                    <label for="star5" class="star" data-value='5'><i class="lni-star-filled"></i></label>
                </div> <!--form-group-->

                <div class="form-group">
                    <textarea class="form-control" placeholder="Enter your comments"></textarea>
                </div> <!--form-group-->

                <div class="form-group">
                    <span class="img" style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"><i class="fi close"></i></span>
                    <input id="f1" type="file" class="hide">
                    <label for="f1" class="upload add"><i class="la la-plus-circle"></i></label>

                    <input id="f2" type="file" class="hide">
                    <label for="f2" class="upload">
                        <span><i class="fi upload"></i> Drag a file here or <b>browse</b> for a file to upload</span>
                    </label>
                </div> <!--form-group-->

                <button class="btn">Add Rating</button>
			</div> <!--modal-body-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_ratings-->





<?php include ('inc/footer.php'); ?>

<script type="text/javascript">
        //Image Popup
    $('.images.gallery').each(function() {
        $(this).magnificPopup({
            delegate: 'a',
            type: 'image',
            closeOnContentClick: false,
            closeBtnInside: false,
            mainClass: 'mfp-with-zoom mfp-img-mobile',
            image: {
                verticalFit: true
            },
            gallery: {
                enabled: true
            },
            zoom: {
                enabled: true,
                duration: 300,
                opener: function(element) {
                    return element.find('img');
                }
            }       
        });
    });
</script>


<script>
    var map;
    function initMapsd() {
        var latlng = new google.maps.LatLng(11.0195206,76.9572537);
        map = new google.maps.Map(document.getElementById('vendor_location'), {
        center: latlng,
        disableDefaultUI: true,        
        zoom: 16
        });

        var marker = new google.maps.Marker({
        map: map,
        position: latlng,
        icon: "assets/img/pin-shop.png"
   });
    }

initMapsd();

    </script>