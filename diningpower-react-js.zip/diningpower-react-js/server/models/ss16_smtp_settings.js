/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16SmtpSettings', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    smtpHost: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'smtp_host'
    },
    smtpUsername: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'smtp_username'
    },
    smtpPassword: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'smtp_password'
    },
    smtpPort: {
      type: DataTypes.STRING(25),
      allowNull: false,
      field: 'smtp_port'
    },
    transportLayerSecurity: {
      type: DataTypes.STRING(11),
      allowNull: false,
      field: 'transport_layer_security'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    trash: {
      type: DataTypes.ENUM('Default','Deleted'),
      allowNull: false,
      defaultValue: 'Default',
      field: 'trash'
    }
  }, {
    tableName: 'ss16_smtp_settings'
  });
};
