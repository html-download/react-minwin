import React, {Component} from 'react';
//components
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';
class Detail extends Component{

   constructor(props) {
    super(props);
    this.toggle = this.toggle.bind(this);
     this.state = {
      activeTab: '1'
    };
}


 toggle(tab) {
    if (this.state.activeTab !== tab) {
      this.setState({
        activeTab: tab
      });
    }
  }
render(){

  var id = this.props.match.params.id
  var name= this.props.match.params.name
  console.log('url_id', id)
   console.log('url_id', name)

return(

    <div>

    <section className="dark-information">
        <div className="container">
            <div className="info">
                <div className="images"><img src={require('../assets/img/re1.png')} alt="" /></div>
                <div className="full_row">
                    <span className="active">Open</span>
                    <a href="#login" className="ratings" data-toggle="modal" data-target="#login"> <i className="fa fa-star"></i> 4.3 <span>692 Ratings</span></a>
                </div>
                <div className="full_row">
                    <h2>{name}</h2>
                    <p>Cafe, Chinese food, Deserts, Pizza, Thai Food</p>
                </div>
                <div className="full_row">
                    <div className="d-table">
                        <div className="d-table-cell">
                            <div className="borderd">
                                <p><span>6 KM</span> Distance</p>
                                <p><span>45 mins</span> Pickup Time</p>
                                <p><span>10.00 KR</span> Min Order</p>
                                <p><span>Online</span> Payment </p>
                            </div>
                        </div>
                        <div className="d-table-cell">
                            <a href="#" className="btn btn-primary-border"><i className="fa fa-star-o"></i> Add Favourite</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
   
    <section className="bg-row text-center">
        <div className="container">
          {/*  <ul className="nav nav-tabs" role="tablist">
                <li className="nav-item">
                    <a className="nav-link active" id="menu-tab" data-toggle="tab" href="#menu" role="tab" aria-controls="menu" aria-selected="true">Menu</a>
                </li>
                <li className="nav-item">
                    <a className="nav-link" id="ratings-tab" data-toggle="tab" href="#ratings" role="tab" aria-controls="ratings" aria-selected="false">Ratings</a>
                </li>
                <li className="nav-item">
                    <a className="nav-link" id="info-tab" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="false">Info</a>
                </li>
            </ul>*/}
        <Nav tabs className="nav nav-tabs">
          <NavItem>
            <NavLink
              className={classnames({ active: this.state.activeTab === '1' })}
              onClick={() => { this.toggle('1'); }}
            >
              Menu
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink
              className={classnames({ active: this.state.activeTab === '2' })}
              onClick={() => { this.toggle('2'); }}
            >
             Ratings
            </NavLink>
          </NavItem>
           <NavItem>
            <NavLink
              className={classnames({ active: this.state.activeTab === '3' })}
              onClick={() => { this.toggle('3'); }}
            >
           Info
            </NavLink>
          </NavItem>
        </Nav>
        </div>
    </section>

    <section className="grey-bg">
        <div className="container">
 <TabContent activeTab={this.state.activeTab}>
          <TabPane tabId="1">
            <Row>
              <Col sm="12">
                                   <div className="mobile-bottom">
        <a href="javascript:void(0)" className="menu-toggle"> Menu </a>
        <a href="cart.html" className="cart-toggle"> Cart <span>( 3 Items )</span> </a>
    </div>
                    <div className="row" data-sticky_parent>
                      
                        <div className="col-md-3 menu_navigation">
                            <div className="sidebar-navigation" data-sticky_column>
                                <div className="border-boxed">
                                    <h3 className="title-border upper">Menu Items</h3>
                                    <ul>
                                        <li className="active"><a href="#35">Non Veg Soup</a></li>
                                        <li><a href="#36">Veg Soup</a></li>
                                        <li><a href="#37">Chettinad</a></li>
                                        <li><a href="#38">Snacks & Rolls</a></li>
                                        <li><a href="#39">Veg Starters</a></li>
                                        <li><a href="#40">Non Veg Briyani</a></li>
                                        <li><a href="#41">Rich & Noodles</a></li>
                                        <li><a href="#42">Veg Briyani</a></li>
                                        <li><a href="#43">Non Veg Main Course</a></li>
                                        <li><a href="#44">Veg Main Course</a></li>
                                        <li><a href="#45">Breads</a></li>
                                        <li><a href="#46">Beverages</a></li>
                                        <li><a href="#47">Cold Coffee</a></li>
                                        <li><a href="#48">Desserts</a></li>
                                        <li><a href="#49">Milk Shake</a></li>
                                        <li><a href="#50">Palav</a></li>
                                        <li><a href="#51">Pizza</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                      
                        <div className="col-md-5">
                            <div className="item-full-content">
                                <div id="35">
                                    <h2>Non Veg Soup</h2>
                                    <ul>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader" data-target="#ing_modal" data-toggle="modal"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader" data-target="#ing_modal" data-toggle="modal"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader" data-target="#ing_modal" data-toggle="modal"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader" data-target="#ing_modal" data-toggle="modal"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader" data-target="#ing_modal" data-toggle="modal"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader" data-target="#ing_modal" data-toggle="modal"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <div id="36">
                                    <h2>Veg Briyani</h2>
                                    <ul>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /></div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="img"><img src={require('../assets/img/item1.png')} className="img-responsive" /> </div>
                                            <h3>Arabic Grill Fish With Bread</h3>
                                            <p className="show-read-more">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes,</p>
                                            <div className="d-table w100">
                                                <div className="d-table-cell">
                                                    <span className="price">26.32 KR </span>
                                                </div>
                                                <div className="d-table-cell">
                                                    <button className="btn btn-border-primary loader added"> <i className="fa fa-plus"></i> Add </button>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
           
                        <div className="col-md-4 cart-mini-mobile">
                            <div className="cart-mini" data-sticky_column>
                                <div className="cart-mini-inner">
                                    <h3>Your Cart <span className="items"><i className="icon-basket"></i> 3</span></h3>
                                    <div className="cart-mini-body">
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>Item</th>
                                                    <th>Qty</th>
                                                    <th className="text-right">Price</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                    <h4>Chicken Soup</h4></td>
                                                    <td><span className="quantity"> <button className="min">-</button> 
                                                    <input type="text" value="2" />
                                                        <button className="max" >+</button>
                                                    </span> </td>
                                                    <td className="text-right">99KR</td>
                                                    <th><a href="javascript:void(0)" className="remove re-ui"><i className="fa fa-minus-circle"></i></a></th>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h4>Chicken Soup</h4></td>
                                                    <td> <span className="quantity"> <button className="min">-</button> 
                                                    <input type="text" value="2" /><button className="max">+</button></span> </td>
                                                    <td className="text-right">99KR</td>
                                                    <th><a href="javascript:void(0)" className="remove re-ui"><i className="fa fa-minus-circle"></i></a></th>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <h4>Chicken Soup</h4></td>
                                                    <td> <span className="quantity"> <button className="min">-</button> 
                                                    <input type="text" value="2" /><button className="max">+</button></span> </td>
                                                    <td className="text-right">99KR</td>
                                                    <th><a href="javascript:void(0)" className="remove re-ui"><i className="fa fa-minus-circle"></i></a></th>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div className="cart-mini-footer">
                                        <table className="table table-condensed">
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        Subtotal
                                                    </td>
                                                    <td>297.00 KR</td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        Delivery Fee
                                                    </td>
                                                    <td>10.00 KR</td>
                                                </tr>
                                                <tr className="fin_ful_cart">
                                                    <td>Total Amount</td>
                                                    <td>307.00 KR</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div className="btn-checkout">
                                        <button className="btn btn-primary loader" onclick="location.href='cart.html'">Checkout</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
              </Col>
            </Row>
          </TabPane>
          <TabPane tabId="2">
            <Row>
              <Col sm="12">
                    <div className="ratings-header">
                        <div className="d-table w100">
                            <div className="d-table-cell">
                                <h3 className="title-border">Ratings & Reviews</h3>
                            </div>
                            <div className="d-table-cell">
                                <a href="#ratings-add" data-toggle="modal" data-target="#ratings-add" className="btn btn-secondary pull-right">Add Review</a>
                            </div>
                        </div>
                    </div>

                    <div className="ratings-body">
                        <ul>

                            <li>
                                <div className="head-user">
                                    <i className="icon-user"></i>
                                    <h3>Chirstopher A.Lyles</h3>
                                    <form>
                                         <span className="star-rating view_only">
                                        <input id="star-5" type="radio" name="star" />
                                        <label className="star" for="star-5"></label>
                                        <input id="star-4" type="radio" checked="" name="star" />
                                        <label className="star" for="star-4"></label>
                                        <input id="star-3" type="radio" name="star" />
                                        <label className="star" for="star-3"></label>
                                        <input id="star-2" type="radio" name="star" />
                                        <label className="star" for="star-2"></label>
                                        <input id="star-1" type="radio" name="star" />
                                        <label className="star" for="star-1"></label>
                                </span>

                                    </form>
                                    <span className="date">03/29/2017</span>
                                </div>
                                <div className="user-content full_row">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec</p>
                                </div>
                            </li>

                            <li>
                                <div className="head-user">
                                    <i className="icon-user"></i>
                                    <h3>Chirstopher A.Lyles</h3>
                                    <form>
                                         <span className="star-rating view_only">
                                        <input id="star-5" type="radio" name="star" />
                                        <label className="star" for="star-5"></label>
                                        <input id="star-4" type="radio" checked="" name="star" />
                                        <label className="star" for="star-4"></label>
                                        <input id="star-3" type="radio" name="star" />
                                        <label className="star" for="star-3"></label>
                                        <input id="star-2" type="radio" name="star" />
                                        <label className="star" for="star-2"></label>
                                        <input id="star-1" type="radio" name="star" />
                                        <label className="star" for="star-1"></label>
                                </span>

                                    </form>
                                    <span className="date">03/29/2017</span>
                                </div>
                                <div className="user-content full_row">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec</p>
                                </div>
                            </li>

                            <li>
                                <div className="head-user">
                                    <i className="icon-user"></i>
                                    <h3>Chirstopher A.Lyles</h3>
                                    <form>
                                         <span className="star-rating view_only">
                                        <input id="star-5" type="radio" name="star" />
                                        <label className="star" for="star-5"></label>
                                        <input id="star-4" type="radio" checked="" name="star" />
                                        <label className="star" for="star-4"></label>
                                        <input id="star-3" type="radio" name="star" />
                                        <label className="star" for="star-3"></label>
                                        <input id="star-2" type="radio" name="star" />
                                        <label className="star" for="star-2"></label>
                                        <input id="star-1" type="radio" name="star" />
                                        <label className="star" for="star-1"></label>
                                </span>

                                    </form>
                                    <span className="date">03/29/2017</span>
                                </div>
                                <div className="user-content full_row">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec</p>
                                </div>
                            </li>

                            <li>
                                <div className="head-user">
                                    <i className="icon-user"></i>
                                    <h3>Chirstopher A.Lyles</h3>
                                    <form>
                                        <span className="star-rating view_only">
                                        <input id="star-5" type="radio" name="star" />
                                        <label className="star" for="star-5"></label>
                                        <input id="star-4" type="radio" checked="" name="star" />
                                        <label className="star" for="star-4"></label>
                                        <input id="star-3" type="radio" name="star" />
                                        <label className="star" for="star-3"></label>
                                        <input id="star-2" type="radio" name="star" />
                                        <label className="star" for="star-2"></label>
                                        <input id="star-1" type="radio" name="star" />
                                        <label className="star" for="star-1"></label>
                                </span>

                                    </form>
                                    <span className="date">03/29/2017</span>
                                </div>
                                <div className="user-content full_row">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec</p>
                                </div>
                            </li>

                        </ul>
                    </div>
              </Col>
            </Row>
          </TabPane>
           <TabPane tabId="3">
            <Row>
              <Col sm="12">
               <div className="tab-pane" id="info" role="tabpanel" aria-labelledby="info-tab">

                    <div className="border-boxed">

                        <div className="row">
                            <div className="col-sm-6">
                                <h3 className="title-border upper">Address</h3>
             
                            </div>
                            <div className="col-sm-6">
                                <div id="map"></div>
                            </div>
                        </div>

                        <div className="row">
                            <div className="col-sm-6">
                                <h3 className="title-border upper">Delivery Hours</h3>
                                <table className="table-striped table">
                                    <tbody>
                                        <tr>
                                            <td>Monday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Tuesday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr className="active">
                                            <td>Wednesday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Thursday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Friday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Saturday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Sunday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div className="col-sm-6">
                                <h3 className="title-border upper">Takeaway Hours</h3>
                                <table className="table-striped table">
                                    <tbody>
                                        <tr>
                                            <td>Monday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Tuesday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr className="active">
                                            <td>Wednesday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Thursday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Friday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Saturday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                        <tr>
                                            <td>Sunday</td>
                                            <td>00.00-23.00</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>

                </div>
               
              </Col>
            </Row>
          </TabPane>

        </TabContent>



        </div>
    </section>



    </div>
    )
    


   }

 }

export default Detail;

   
