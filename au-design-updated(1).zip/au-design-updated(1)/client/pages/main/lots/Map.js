/* eslint-disable no-undef */

import React, {Component} from 'react';
import { withScriptjs, withGoogleMap, GoogleMap, Marker, GroundOverlay, InfoWindow, OverlayView } from "react-google-maps";
import { compose, withStateHandlers } from "recompose";
import GeoLocation from 'react-geolocation';
const UserIdentity = require('../../../helpers/user-identity');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();

//const MapComponent = withScriptjs(withGoogleMap( props => (
const MapComponent = compose(
  withStateHandlers((index) => ({
    isOpen: false,
    showInfo: '0'
  }), {
    onToggleOpen: ({ isOpen }) => (index) => ({
      isOpen: !isOpen,
      index: 2
    }),
    showInfo: ({ showInfo, isOpen }) => (a, lat, lng) => ({
      isOpen: true,
      showInfoIndex: a,
      showInfoLat: lat,
      showInfoLng: lng
    })
  }),
  withScriptjs,
  withGoogleMap
)(props =>
        <GoogleMap
            ref={props.onMapMounted}
            defaultCenter={props.defaultCenter}
            defaultZoom={props.defaultZoom}
            streetViewControl={false}
            defaultMapTypeId={ google.maps.MapTypeId.SATELLITE }
            defaultTilt={0}
            center={props.center}
            zoom={props.zoom}
            options={{draggable:true}}
            onBoundsChanged={props.onBoundsChanged}
            defaultOptions={{
                scrollwheel: false,
                disableDefaultUI: true,
                zoomControl: true,
                draggable: false,
                mapTypeControl: false
            }}
        >
            {
                (props.overlay_url !== "" && props.overlay_coords_ne !== "" && props.overlay_coords_sw !== "")  ? (
                        <OverlayView
                          key={Math.random()}
                          bounds={new google.maps.LatLngBounds(
                                new google.maps.LatLng(props.overlay_coords_sw_lat, props.overlay_coords_sw_lng),
                                new google.maps.LatLng(props.overlay_coords_ne_lat, props.overlay_coords_ne_lng)
                            )}
                          draggable={true}
                          mapPaneName={OverlayView.OVERLAY_LAYER}>
                          <div style={{ 'background' : "url('"+props.overlay_url+"') center center no-repeat", backgroundSize : 'contain', 'height': '100%'}}>
                          </div>
                        </OverlayView>
                    ) : null
            }
            {props.markers.map( marker => {

console.log("props.overlay_url", props.overlay_url);
                let lat = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.stallNumber &&  props.showInfoLat !== undefined) ? props.showInfoLat : marker.lat;
                let lng = (props.showInfoIndex !== undefined && props.showInfoIndex === marker.stallNumber &&  props.showInfoLng !== undefined) ? props.showInfoLng : marker.lng;
                return (
                    <Marker
                        key={marker.stallNumber}
                        position={{'lat': lat, 'lng': lng}}
                        defaultAnimation={(marker.is_user === 2) ? google.maps.Animation.BOUNCE : true}
                        icon={`/public/media/images/icons/${marker.icon}`}
                        draggable={false} 
                        onClick={() => { props.showInfo(marker.stallNumber, marker.lat, marker.lng) }}
                        //onDragEnd={(event) => { props.showInfo(marker.stallNumber, event.latLng.lat(), event.latLng.lng());}}
                    >
                        { false && props.isOpen && props.showInfoIndex === marker.stallNumber && 
                            /*<InfoWindow id="info{props.showInfoIndex}">
                                <div style={{width: '100%', 'float' : "left", 'margin' : '0px', 'backgroundColor' : '#f5f5dc', height: '100%' }}>
                                    <h4 className="lot_tit">Lot</h4>
                                    <p className="lot_name">No : {marker.stallNumber}</p>
                                    <p className="lot_name">Latitude : {props.showInfoLat}</p>
                                    <p className="lot_name">Longitude : {props.showInfoLng}</p> 
                                    <p className="lot_name">Status : <img src={`/images/icons/${marker.icon}`} alt="test"/></p> 
                                    <button className="btn btn-success" type="button" style={{marginLeft: '35%', 'display' : 'none' }} data-key={marker.stallNumber}  onClick={new Map().saveStallValue(marker.stallNumber, props.showInfoLat, props.showInfoLng, marker.lot_name)}>Save</button>
                                </div>
                            </InfoWindow>*/
                            <InfoWindow id="info{props.showInfoIndex}">
                                <div>
                                    <ul className="reset zone-info">
                                        <li>
                                            <div className="form-group">
                                                <label>Stall Num:</label>
                                                <input type="text" className="form-control" value={marker.stallNumber} disabled={true}/>
                                                <span style={{'fontSize' : '10px'}}>(cannot edit)</span>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="form-group">
                                                <label>Zone:</label>
                                                <input type="text" name={`zone_${props.showInfoIndex}`} id={`zone_${props.showInfoIndex}`} className="form-control" defaultValue={marker.zone}/>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="form-group">
                                                <label>Alt ID:</label>
                                                <input type="text" name={`alt_id_${props.showInfoIndex}`} id={`alt_id_${props.showInfoIndex}`} className="form-control" defaultValue={marker.altId}/>
                                            </div>
                                        </li>
                                        <li className="veh_pic">
                                            <div className="form-group">
                                                <label>Pic:</label>
                                                <img src="https://lh5.googleusercontent.com/-6muTmaY7-f4/AAAAAAAAAAI/AAAAAAAAYko/rz85-88Jl7M/photo.jpg" alt="" width="60" style={{float: "left"}}/>

                                                <div className="form-group w70">
                                                    <input id={`unavailable_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" />
                                                    <label htmlFor={`unavailable_${props.showInfoIndex}`} className="checkbox">Unavailable</label>
                                                </div>
                                                <div className="form-group w70">
                                                    <input id={`reserved_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" defaultChecked={marker.reserve_flag === 1}/>
                                                    <label htmlFor={`reserved_${props.showInfoIndex}`} className="checkbox">Reserved</label>
                                                </div>  
                                            </div>
                                        </li>
                                        <li>
                                            <div className="form-group">
                                                <input id={`qa_flag_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" defaultChecked={marker.qa_flag === 1}/>
                                                <label htmlFor={`qa_flag_${props.showInfoIndex}`} className="checkbox">QA Flag</label>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="form-group">
                                                <input id={`context_${props.showInfoIndex}`} name="checkbox" type="checkbox" className="hide" defaultChecked={marker.context_flag === 1}/>
                                                <label htmlFor={`context_${props.showInfoIndex}`} className="checkbox">Context Flag</label>
                                            </div>
                                        </li>
                                        <li>
                                            <div className="form-group">
                                                <label>Current Loc:</label>
                                                <label>{props.showInfoLat}, {props.showInfoLng}</label>
                                            </div>
                                        </li>
                                    </ul>
                                    <div className="form-group action mb0">
                                        <button className="btn grey">HIDE in App</button>
                                        <button className="btn" onClick={()=>{ new Map().saveStallValue(marker.stallNumber, props.showInfoLat, props.showInfoLng, marker.lot_name, props.showInfoIndex)}} >Save</button>
                                    </div>
                                </div>
                            </InfoWindow>
                        }
                    </Marker>
                )
            })}
            <GeoLocation />
        </GoogleMap>
);

class Map extends Component {
    constructor(props) {
        super(props);
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.saveStallValue = this.saveStallValue.bind(this);
    }
    componentDidMount(){
        //console.log('test')
    }
    saveStallValue(stallNumber, latitude, longitude, lotName, showInfoIndex) {
        let zone = $("#zone_"+showInfoIndex).val();
        let alt_id = $("#alt_id_"+showInfoIndex).val();
        let unavailable = $("#unavailable_"+showInfoIndex).prop("checked") ? 1 : 0;
        let reserved = $("#reserved_"+showInfoIndex).prop("checked") ? 1 : 0;
        let qa_flag = $("#qa_flag_"+showInfoIndex).prop("checked") ? 1 : 0;
        let context = $("#context_"+showInfoIndex).prop("checked") ? 1 : 0;

        let data = {
                'stall_num' : stallNumber,
                'lot_name' : lotName,
                'reserve_flag' : reserved,
                'zone' : zone,
                'qa_flag' : qa_flag,
                'context_flag' : context,
                'coords' : latitude+','+longitude
            };

        fetch(`${this.params.fopark_url}/stall`, {
            method: "put",
            'headers': new Headers({
                'X-api-key': this.params.fopark_key,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }),
            body: JSON.stringify(data)

        })
            .then(response => response.json())
            .then(
                (result) => {
                    Toaster.success('Stall data updated successfully! please wait...data updating..');
                    
                    //this.props.history.push(`/lots/${lotName}`);
                    console.log("Data saved!");
                    //console.log("result", result);
                },
                (error) => {
                    
                    console.log("error", error);
                }
            );
    }
    render(){
        let position = 'relative';
        if (this.props.id !== undefined) {
            position = 'fixed';
        }
        //console.log("props.markers", this.props);
        let overlay_coords_ne_lat, overlay_coords_ne_lng, overlay_coords_sw_lat, overlay_coords_sw_lng;

        if (this.props.overlay_coords_ne !== "") {
            overlay_coords_ne_lat = parseFloat(this.props.overlay_coords_ne.split(',')[0]);
            overlay_coords_ne_lng = parseFloat(this.props.overlay_coords_ne.split(',')[1]);
            overlay_coords_sw_lat = parseFloat(this.props.overlay_coords_sw.split(',')[0]);
            overlay_coords_sw_lng = parseFloat(this.props.overlay_coords_sw.split(',')[1]);
        }
        if (!this.props.isOverlayLoaded) {
            return <div className="loader"></div>
        }
        return (
            <MapComponent
                googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${UserIdentity.googleApiKey}&libraries=places`}
                loadingElement={<div style={{ height: `100%` }} />}
                containerElement={<div style={{ position: position, 'zIndex': 1, left: 0, top: 0, right: 0, bottom: 0, padding: '0' }} />}
                mapElement={<div style={{ height: `100%` }} />}
                defaultCenter={{
                    'lat': 32.6063355,
                    'lng': -85.4905577
                }}
                defaultZoom={17}
                center={this.props.center}
                zoom={this.props.zoom}
                markers={this.props.markers}
                draggable={false} 
                overlay_coords_ne={this.props.overlay_coords_ne}
                overlay_coords_sw={this.props.overlay_coords_sw}
                overlay_url={this.props.overlay_url}
                overlay_coords_ne_lat={overlay_coords_ne_lat}
                overlay_coords_ne_lng={overlay_coords_ne_lng}
                overlay_coords_sw_lat={overlay_coords_sw_lat}
                overlay_coords_sw_lng={overlay_coords_sw_lng}
            >
            </MapComponent>
        )
    }
}

export default Map;