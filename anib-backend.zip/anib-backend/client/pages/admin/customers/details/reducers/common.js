'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');


const initialState = {
    loading: false,
    deals_data: [],
    deals_data_loading: true,
    policy_data: [],
    customer_notes: [],
    customer_notes_loading: true,
    customer_docs: [],
    customer_docs_loading: true,
    first_licence_age_data: [],
    is_view_policy: false,
    policy_detail: {}
};

const reducer = function (state = initialState, action) {

    switch (action.type) {

        case Constants.GET_DEALS_RESULTS:
            return ObjectAssign({}, state, {
                deals_data : [],
                deals_data_loading: true
            });
            break;
        case Constants.GET_DEALS_RESULTS_RESPONSE:
            if (action.response && action.response.status === 200) {
                return ObjectAssign({}, state, {
                    deals_data : action.response.data,
                    deals_data_loading: false
                });
            }
            return state;
            break;
        case Constants.GET_POLICY_RESULTS:
            return ObjectAssign({}, state, {
                policy_data : []
            });
            break;
        case Constants.GET_POLICY_RESULTS_RESPONSE:
            if (action.response && action.response.status === 200) {
                return ObjectAssign({}, state, {
                    policy_data : action.response.data
                });
            }
            return state;
            break;
        case Constants.GET_NOTE_RESULT:
            return ObjectAssign({}, state,{
                customer_notes : [],
                customer_notes_loading: true
            });
            break;
        case Constants.GET_NOTE_RESULT_RESPONSE:                        
            if (action.response.status === 200) {
                return ObjectAssign({}, state,{
                    customer_notes : action.response.data,
                    customer_notes_loading: false
                });
            }
            break;
        case Constants.HIDE_POLICY_MODAL:
            return ObjectAssign({}, state,{
                is_view_policy : false,
                policy_detail:{}
            });
            break;
        case Constants.VIEW_POLICY:
            return ObjectAssign({}, state,{
                is_view_policy : true,
                policy_detail:{}
            });
            break;
        case Constants.VIEW_POLICY_RESPONSE:            
            if (action.response.status === 200) {
                return ObjectAssign({}, state,{
                    is_view_policy : true,
                    policy_detail: action.response.data ? action.response.data : {}
                });
            }
            break;
        case Constants.GET_DOCU_RESULT:
            return ObjectAssign({}, state,{
                customer_docs : [],
                customer_docs_loading: true
            });
            break;
        case Constants.GET_DOCU_RESULT_RESPONSE:
            if (action.response.status === 200) {
                return ObjectAssign({}, state,{
                    customer_docs_loading: false,
                    customer_docs : action.response.data
                });
            }
            break;
        default:
            return state;
            break;
    }
};

module.exports = reducer;
