const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'SEND_MESSAGE',
    'SEND_MESSAGE_RESPONSE'
]);
