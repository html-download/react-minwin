<?php 
	session_start();
	if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') {
		$protocol  = "https://";
	} else {
		$protocol  = "http://";
	}
	$baseurl=$protocol.$_SERVER['HTTP_HOST'].'/';
	$currenturl=$protocol.$_SERVER['HTTP_HOST'].$_SERVER['REDIRECT_URL'];
	$blog = substr(trim($_SERVER['REQUEST_URI'], '/'), 0, 4);

	$mySite = "https://www.ontabee.com";
	
	
	/* If the referrer is from outside the domain, store the url in a session */
	if(substr($_SERVER['HTTP_REFERER'], 0, strlen($mySite)) !== $mySite) {
	   
	    $_SESSION['referer'] = $_SERVER['HTTP_REFERER'];
	}
?>
<!DOCTYPE HTML>
<html lang="en"> 
<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>	
	<?php include 'settings.php'; ?>

	<?php if ($blog === 'blog'): ?>
	<title><?php 
			if( is_single() || is_page() ): single_post_title('', true);
			elseif( is_category() ): single_cat_title(); echo ' | '; bloginfo('name');
			elseif( is_tag() ): single_tag_title(); echo ' | '; bloginfo('name');
		endif; ?>
	</title>
	<?php else: ?>
	<!-- seo -->
	<title><?php echo $title; ?></title>
	<meta name="description" content="<?php echo $description; ?>" />
	<meta name="keywords" content="<?php echo $keywords; ?>" />
	
	<!-- og -->
	<meta name="og:title" content="<?php echo $title; ?>" />
	<meta name="og:description" content="<?php echo $description; ?>" />
	<?php endif; ?>
	
	<meta property="og:image:secure_url" content="<?php echo $baseurl.$logo;?>" />	
	<?php if(isset($img)) {	foreach($img as $image): ?>
	<meta property="og:image:secure_url" content="<?php echo $baseurl.$image;?>" />
	<?php endforeach; } ?>
		
	<!-- seo main tags -->
	<meta name="robots" content="follow,index,all" />
	<meta name="distribution" content="Global" />
	<meta name="Revisit-after" content="7 days" />
	<meta name="language" content="EN-US" />
	<meta name="doc-type" content="Public" />
	<meta name="application-name" content="Ontabee.com" />
	<link rel="dns-prefetch" href="//www.ontabee.com" />
	<link rel="preload" href="/css/style.css" />
	<meta name="og:type" content="company" />
	<meta name="og:image" content="/images/logo.png" />
	
	<!--twitter-->
	<meta name="twitter:card" content="summary" /> 
	<meta name="twitter:site" content="@ontabee" /> 
	<meta name="twitter:title" content="Ontabee"/>

	<!-- New SEO Tags -->
	<meta name="language" content="en"/>
	<meta name="Expires" content="never"/>
	<meta name="Distribution" content="Global"/>
	<meta name="search engines" content="ALL"/> 
	<?php if(isset($style)) {	foreach($style as $styles): ?>
	<link rel="stylesheet" href="<?php echo $baseurl.'css/'.$styles ?>" type="text/css">
	<?php endforeach; } ?>
	<link rel="stylesheet" href="<?php echo $baseurl.'css/responsive.min.css'?>" type="text/css">
	<link rel="shortcut  icon" href="/images/favicon.ico" type="image/x-icon" />
	<!-- pre section -->
	<link rel="preconnect" href="//secure.livechatinc.com" />
	<link rel="preconnect" href="//www.ontabee.com" />
	<link rel="prefetch" href="<?php echo $currenturl; ?>" />
	<link rel="prefetch" href="https://vars.hotjar.com" />
	<link rel="prefetch" href="https://fonts.googleapis.com" />
	<link rel="prefetch" href="https://cdn.livechatinc.com" />
	<link rel="prefetch" href="http://cdn.livechatinc.com" />


	<!-- pre section end-->

	<meta property="og:url" content="<?php echo $currenturl; ?>" />
	<link rel="canonical" href="<?php echo $currenturl; ?>" />

	<script type="application/ld+json">
	{
	  "@context": "http://schema.org",
	  "@type": "Organization",
	  "name" : "Ontabee",
	  "url" : "https://www.ontabee.com/",
	  "logo" : "https://www.ontabee.com/images/logo.png",
	  "potentialAction" : {
		"@type" : "SearchAction",
		"target" : "https://www.ontabee.com/?s={search_term}",
		"query-input" : "required name=search_term"
	  }
	}
	</script>
	<script type="application/ld+json">
	{
	"@context": "http://schema.org",
	"@type": "WebSite",
	"@id": "#website",
	"name": "Free online food ordering & delivery system, software for restaurant | Ontabee",
	"alternateName": "Free online food ordering & delivery system, software | Ontabee",
	"url": "https://www.ontabee.com/",
	"potentialAction": {
	"@type": "SearchAction",
	"target": "https://www.ontabee.com/?s={search_term_string}",
	"query-input": "required name=search_term_string"
	}
	}
	</script>
	<script type="application/ld+json">
		{
		"@context": "https://schema.org",
		"@type": "FAQPage",
		"mainEntity": [
		{
		"@type": "Question",
		"name": "Is Android and iOS are native app?",
		"acceptedAnswer": 
		{
		"@type": "Answer",
		"text": "Yes, native apps only."
		}
		},
		
		{
		"@type": "Question",
		"name": "Can I use my own logo/brand/content?",
		"acceptedAnswer": {
		"@type": "Answer",
		"text": "Yes, you can use own logo, brand, content."
		}
		},
			
		{
		"@type": "Question",
		"name": "Are there any limits for menu items?",
		"acceptedAnswer": {
		"@type": "Answer",
		"text": "Nope, you can add N number of items."
		}
		},
		{
		"@type": "Question",
		"name": "I have more than one outlet, will Ontabee work for me?",
		"acceptedAnswer": {
		"@type": "Answer",
		"text": "Yes, Our food ordering system works with N number of outlets."
		}
		},
		{
		"@type": "Question",
		"name": "Can I use Ontabee in my country?",
		"acceptedAnswer": {
		"@type": "Answer",
		"text": "Yes, you can use food ordering system in your country. Because it supports multi-language and multi-currencies."
		}
		},
		{
		"@type": "Question",
		"name": "What type of store can Ontabee be used for?",
		"acceptedAnswer": {
		"@type": "Answer",
		"text": "Ontabee can be used for Food, restaurant, cakes, pizza, flower, dress, etc."
		}
		},
			
		{
		"@type": "Question",
		"name": "What are the deliverables of Ontabee?",
		"acceptedAnswer": {
		"@type": "Answer",
		"text":"Ontabee is provided with Admin web back end panel. Order receiving app on both web and Android platform. Customer front end panel on both the web and mobile (Android & iOS). Delivery staff with the delivery app on Android."
		}
		}]
		}
    </script>



	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-MV7TSV9');</script>
	<!-- End Google Tag Manager -->	
	
	
	
	<!--[if lt IE 9]>
		<script src="/js/html5shiv.min.js"></script>
	<![endif]-->	
		<!-- Begin Inspectlet Asynchronous Code -->
	<script type="text/javascript">
	(function() {
	window.__insp = window.__insp || [];
	__insp.push(['wid', 1610649757]);
	var ldinsp = function(){
	if(typeof window.__inspld != "undefined") return; window.__inspld = 1; var insp = document.createElement('script'); insp.type = 'text/javascript'; insp.async = true; insp.id = "inspsync"; insp.src = ('https:' == document.location.protocol ? 'https' : 'http') + '://cdn.inspectlet.com/inspectlet.js?wid=1610649757&r=' + Math.floor(new Date().getTime()/3600000); var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(insp, x); };
	setTimeout(ldinsp, 0);
	})();
	</script>
	<!-- End Inspectlet Asynchronous Code -->
	<!-- Bitrix24 -->
    <script>
	(function(w,d,u){
		var s=d.createElement('script');s.async=true;s.src=u+'?'+(Date.now()/60000|0);
		var h=d.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);
	})(window,document,'https://cdn.bitrix24.com/b11978079/crm/tag/call.tracker.js');
</script>
<!-- Bitrix24 end-->
</head>
<body <?php if ($blog !== 'blog'): ?>class="<?=basename($_SERVER['PHP_SELF'],'.php')?>-page"<?php endif; ?>>

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MV7TSV9"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<script>
     awesomeAnalytics(); // beacon conversion metrics
   </script>
<header class="site_header" itemtype="http://schema.org/LocalBusiness">
<div class="container">
	<div class="top_info">
		<a href="skype:<?php echo $skype; ?>?call" title="Call us using Skype"><?php echo $skype; ?><i class="fa fa-skype"></i></a>
		<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>&text=hi" class="whatsapp" target="_blank" title="WhatsApp Your Requirement"><?php echo $mobile; ?><i class="fa fa-whatsapp"></i></a>
		<a href="mailto:<?php echo $email; ?>" title="<?php echo $email; ?>"><?php echo $email; ?><i class="fa fa-envelope-o"></i></a>

		<span><a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>&text=hi" class="whatsapp" title="WhatsApp Your Requirement"><i class="fa fa-whatsapp"></i>WhatsApp</a></span>
		<span><a href="tel:<?php echo $mobile; ?>" class="call" title="Call"><i class="fa fa-phone"></i>Call Now</a></span>
	</div> <!--top_info-->
	
	<div class="site_logo">
		<a href="<?php echo $baseurl;?>"><img itemprop="image" src="/images/logo.png" alt="Ontabee"></a>
		<a id="mobile_nav"><i class="fi menu"></i></a>
	</div> <!--site_logo-->
	
	<div class="site_menu">
		<nav class="full_row">
			<ul class="reset" itemscope itemtype="http://www.schema.org/SiteNavigationElement">
				<li itemprop="name"> <a itemprop="url" href="<?php echo $baseurl;?>" class="link">Home</a> </li>
				<li itemprop="name"> <a class="sublink">Products <i class="fa fa-angle-down"></i></a></a> 
					<div class="submenu">
						<ul class="icon">
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>online-ordering-system-for-restaurants" title="Website Ordering">Website Ordering 
								<span>Start taking online orders</span> <i class="fi cart-browser"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>food-ordering-app-for-restaurants" title="Mobile App Ordering ">Mobile App Ordering 
								<span>Place order in an easy way</span> <i class="fi mobile-cart"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>food-delivery-app" title="Delivery App ">Delivery App 
								<span>Get everything delivered</span> <i class="fi food-bag"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>food-order-receiving-app" title="Order Receiving App">Order Receiving App 
								<span>Automated Receiving Software</span> <i class="fi cart"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>food-ordering-software-admin-dashboard" title="Super Admin Dashboard">Super Admin Dashboard
								<span>Your Brand. Our Solution</span> <i class="fi monitor2"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>restaurant-ordering-software-dashboard" title="Restaurant Dashboard">Restaurant Dashboard
								<span>Restaurant Management Software</span> <i class="fi monitor2"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>restaurant-self-ordering-kiosk-system" title="">Kiosk Ordering System
								<span>Restaurant self ordering system</span> <i class="fi cart"></i></a>
							</li>
						</ul>
					</div> <!--submenu-->
				</li>
				<li itemprop="name" class="hide"> <a class="sublink">Company <i class="fa fa-angle-down"></i></a></a> 
					<div class="submenu"> 
						<ul class="icon">
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>about-us" title="About Ontabee">About Ontabee
								<span>Who are we?</span> <i class="fi user"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>pricing" title="Pricing">Pricing
								<span>Straightforward pricing</span> <i class="fi price"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>case-studies" title="Case Studies">Case Studies
								<span>Our Success</span> <i class="fi fa fa-file-text-o"></i></a>
							</li>
							<li itemprop="name">
								<a itemprop="url" href="<?php echo $baseurl;?>tools-and-technology" title="Tools and Technology">Tools and Technology
								<span>Latest technologies</span> <i class="fi bulb"></i></a>
							</li>
						</ul>
					</div> <!--submenu-->
				</li>
				<li itemprop="name"> <a itemprop="url" href="<?php echo $baseurl;?>features" class="link" title="Features">Features</a> </li>
				<li itemprop="name"> <a itemprop="url" href="<?php echo $baseurl;?>pricing" class="link" title="Pricing">Pricing</a></li>
				<li itemprop="name"> <a itemprop="url" href="<?php echo $baseurl;?>portfolio" class="link" title="Portfolio">Portfolio</a></li>
				<li itemprop="name" class="hide"> <a itemprop="url" href="<?php echo $baseurl;?>contact" class="link" title="Contact">Contact</a> </li>
				<li class="last"> <a data-toggle="modal" data-target="#modal_form" class="btn demo">Live Demo</a> </li>				
				<li itemprop="name" class="last"> <a itemprop="url" href="<?php echo $baseurl;?>signup" class="btn link">Start My Free Trial</a> </li>
				
			</ul>
		</nav> 
	</div> <!--site_menu-->
</div> <!--container-->
</header> <!--site_header-->

  