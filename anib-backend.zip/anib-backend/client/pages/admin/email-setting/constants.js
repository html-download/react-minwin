'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([
    'GET_CONFIG_RESULT',
    'GET_CONFIG_RESULT_RESPONSE',
    'SAVE_CONFIG_RESULT',
    'SAVE_CONFIG_RESULT_RESPONSE'
]);
