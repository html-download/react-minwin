<?php include ('inc/header.php'); ?>

<div class="page_banner style5 bg1">
	<div class="container floating_label pad0">
		<div class="col-sm-8">
			<h1 class="head wow fadeInDown">Leading Edge Software For Food Professionals/Chef!!</h1>
			<h2 class="head wow fadeInUp">Boost your sales with online orders!!!!</h2>
		</div>
		
		<div class="col-sm-4 text-center">
			<form id="alternative" method="post" name="alternative" action="<?php echo $baseurl;?>signup" class="wow fadeInUp">
				<h4>Ready to establish your restaurant up for success?</h4>			
				<label class="icon">Your name
					<input type="text" name="try_name" class="form-control" required="required">
					<i class="fa fa-user-o"></i>
				</label>
				<label class="icon">Email Id
					<input type="email" name="try_email" class="form-control" required="required">
					<i class="fa fa-envelope-o"></i>
				</label>
				<input type="hidden" value="" name="try_url">
				<input type="submit" class="btn" value="Submit">
			</form>
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Complete Food Ordering Software for Professional Kitchen/Chef</h2>
		<p class="mb0 wow fadeInUp">Ontabee is the superior software provider for professional kitchen or chef and also have 5+ years of experience & continuous product development. We have built the revenue-boosting website for restaurant and takeaways & integrate it with our online food ordering software. With the help of our food ordering system, you will receive online orders through your very own website, which is delivered to your existing mobile call and also in person. It is suitable for all kind of professional kitchens which regardless of size or area of business. Get your very own, fully customizable online food ordering system for your restaurant business quickly and easy to set up.</p>
	</div>
</section>

<section class="grey">
	<div class="container md1 text-center">
		<h2 class="head wow fadeInUp">Why Successful Restaurant Choose Ontabee's Restaurant Management System?</h2>
		<p class="wow fadeInUp">Ontabee is the one-stop solution for restaurant management system for an unbelievable restaurant business. It is an interactive mobile app for the restaurant which provides the customer an updated and impressive digital restaurant menu. Ontabee also observes and manages the restaurant’s overall process and offers better customer service, increased daily sales, reduced manual errors and strong processing of payment.</p>
		<ul class="reset purpose">				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi alarm"></i>Notification
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi file-close"></i>Cancel Order
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi cloud-server"></i>Automated
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi time-wait"></i>No Waiting Time
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi fast-food"></i>No Order Confusion
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi track"></i>Track Order
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi setting"></i>Menu Management
				</div>
			</li>				
			<li class="wow zoomIn">
				<div class="content">
					<i class="fi map-location"></i>Access Anywhere
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section>

<section class="half bg3 process">
	<div class="center">
		<div class="container">
			<div class="col-sm-6 pull-right">
				<h2 class="head">Food Ordering Process</h2>
				<ul class="reset">
					<li>
						<i class="fi fast-food"></i>
						<p>The customer can place an order by mobile app or website.</p>
					</li>
					<li>
						<i class="fi tick"></i>
						<p>The restaurant receives an order via web back-end and order receiving the app.</p>
					</li>
					<li>
						<i class="fi bill"></i>
						<p>Order is prepared and sent notification to the delivery boy with the order details.</p>
					</li>
					<li>
						<i class="fi truck"></i>
						<p>Food is delivered to the customer at their place and send the notification to the restaurant.</p>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>

<section class="grey">
	<div class="container text-center">
		<h2 class="head wow fadeInUp">Why Go Online ordering system for the restaurant?</h2>
		<p class="mb30 md1 wow fadeInUp">Be smart - Get ahead of the food industry business! The food business is very highly competitive and also successful business. Ontabee is the most comprehensive food ordering software, orders & management solution provider to the food business through this you can find everything you need to get ahead of the game.</p>
		<ul class="reset timeline">
			<li>
				<i class="fi user wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Develop Your Customer</h2>
					<p>Every marketing effort of your concern will benefit only your business. Your customers will make an order directly from your website, and your management system will help you build your own customer database.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi fast-food wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Never Ever Miss an Order</h2>
					<p>Online order is sent directly to your email address which is synchronized with your profile dashboard, where you can accept or reject an order.</p>
				</div>
			</li>
			<li>
				<i class="fi money-hand wow zoomIn"></i>
				<div class="content wow fadeInLeft">
					<h2 class="head">Increase Your Sales</h2>
					<p>An online ordering system begins up a window of opportunity for customers. This leads to a massive order per customer and changes to increased sales for the restaurant.</p>
				</div>
			</li>
			<li class="right">
				<i class="fi cloud-server wow zoomIn"></i>
				<div class="content wow fadeInRight">
					<h2 class="head">Open 24/7/365 days</h2>
					<p>Your restaurant's online ordering website will be working for you, a customer can place their order when the restaurant is open. No more rushed restaurant staff, bustled phone calls, transcription errors, or customers losing your menu.</p>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section>

<section class="app_feature style2">	
	<div class="container pad0">		
		<h2 class="head wow fadeInUp">Features of Mobile Food Ordering Software</h2>
		<p class="mb40 md1 wow fadeInUp">Ontabee is a food-business focused solution that offers feature-rich and powerful mobile application to allow restaurants with an unmatched digital presence in a mobile-first world. Enhance online food ordering experience for your customers with your own mobile food ordering application.</p>

		<ul class="reset text-right">
			<li class="wow fadeInLeft" data-wow-duration="1s">
				<i class="fa fa-list-ul"></i>
				<h4>Categories</h4>
				<p>Admin can add and display a different kind of categories in an easy way to format and advertise among customers.</p>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="1.5s">
				<i class="fa fa-history"></i>
				<h4>Order History</h4>
				<p>A brief order history can make you keep track and monitor the customer previous order item.</p>
			</li>
			<li class="wow fadeInLeft" data-wow-duration="2s">
				<i class="fa fa-user-o"></i>
				<h4>My Profile</h4>
				<p>Let your customers keep their personal information updated under 'My profile' feature.</p>
			</li>
		</ul>
		
		<div class="img">
			<img src="images/mobile-app1.png" class="wow zoomIn" alt="mobile application" data-wow-duration="1.2s">
		</div>
		
		<ul class="reset last text-left">
			<li class="wow fadeInRight" data-wow-duration="1s">
				<i class="fa fa-line-chart"></i>
				<h4>Reports & Analytics</h4>
				<p>Track order history and get deep customer insights with reports and dashboards to make decisions.</p>
			</li>
			<li class="wow fadeInRight" data-wow-duration="1.5s">
				<i class="fa fa-percent"></i>
				<h4>Offers</h4>
				<p>Highlight the latest offers and discounts to make your customers stick around your brand!</p>
			</li>
			<li class="wow fadeInRight" data-wow-duration="2s">
				<i class="fa fa-bell-o"></i>
				<h4>Push Notifications</h4>
				<p>The best way to send personalized notifications for offers, event-deals & discounts, special messages and more.</p>
			</li>
		</ul>	
	</div> <!--container-->	
</section> <!--page_banner-->

<section class="half bg2">
	<div class="center">
		<div class="container">
			<div class="col-sm-6 pull-right">
				<h2 class="head wow fadeInUp">The Benefit Of Professional Kitchen Management</h2>
				<ul class="reset list1">
					<li class="wow fadeInUp">Improve Productivity & Efficiency</li>
					<li class="wow fadeInUp">Enhance Profits which Suits any kind of Restaurant professionals, MasterChef etc.,</li>
					<li class="wow fadeInUp">Increase Control, secure to use Interface</li>
					<li class="wow fadeInUp">Build Effective Business Processes</li>
					<li class="wow fadeInUp">Easy Set-up, Free Technical Support</li>
					<li class="wow fadeInUp">Track individual item cook times.</li>
				</ul>
			</div>
		</div>
	</div>
</section> <!--page_banner-->

<?php include('inc/footer.php');?>