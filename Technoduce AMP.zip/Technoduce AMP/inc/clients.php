<ul class="reset">
	<li><amp-img src="<?php echo $baseurl;?>images/clients/jll.png" alt="Jll" width="180" height="80" layout="responsive"></amp-img></li>
	<li><amp-img src="<?php echo $baseurl;?>images/clients/jll.png" alt="Jll" width="180" height="80" layout="responsive"></amp-img></li>
	<li><amp-img src="<?php echo $baseurl;?>images/clients/jll.png" alt="Jll" width="180" height="80" layout="responsive"></amp-img></li>
	<li><amp-img src="<?php echo $baseurl;?>images/clients/jll.png" alt="Jll" width="180" height="80" layout="responsive"></amp-img></li>
	<li><amp-img src="<?php echo $baseurl;?>images/clients/jll.png" alt="Jll" width="180" height="80" layout="responsive"></amp-img></li>
</ul>