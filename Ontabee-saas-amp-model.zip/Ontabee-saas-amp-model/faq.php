<?php include ('inc/header.php'); ?>

<div class="cms_page full_row">
	<div class="page_banner">
		<div class="container">
			<h1 class="head wow fadeInDown">FAQ</h1>
			<h2 class="head small wow fadeInUp">Level up your online ordering system</h2>
		</div> <!--container-->
	</div> <!--page_banner-->
	
	<div class="container">
		<div class="cms_content">
			<div id="accordion">
				<div class="panel">
					<h4 class="panel-title">
						<a href="#faq1" data-toggle="collapse" data-parent="#accordion">Why Ontabee for free?</a>
					</h4>
					<div id="faq1" class="panel-collapse collapse in">
						<div class="panel-body">
							<p>You can get detailed knowledge about the performance of our product in real-time for a single restaurant. After that, you wish to run a Multi-branch for a restaurant with a mobile app for Android and iOS to increase the revenue level you have to upgrade the pricing plan.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq2" class="collapsed" data-toggle="collapse" data-parent="#accordion">Is there a setup fee?</a>
					</h4>
					<div id="faq2" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Yes, There is a setup cost of $<?php echo $setupprice?> USD and that is One Time.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq3" class="collapsed" data-toggle="collapse" data-parent="#accordion">Do you have more than 5 outlets?</a>
					</h4>
					<div id="faq3" class="panel-collapse collapse">
						<div class="panel-body">
							<p><a href="/contact"> Contact us</a> for custom pricing.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq4" class="collapsed" data-toggle="collapse" data-parent="#accordion">I don't have a domain name, What can I do?</a>
					</h4>
					<div id="faq4" class="panel-collapse collapse">
						<div class="panel-body">
							<p>We can help you set up.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq5" class="collapsed" data-toggle="collapse" data-parent="#accordion">Is there any contract?</a>
					</h4>
					<div id="faq5" class="panel-collapse collapse">
						<div class="panel-body">
							<p>You aren't locked into any long-term commitment. You can cancel or change your plan at any time.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq6" class="collapsed" data-toggle="collapse" data-parent="#accordion">Are there any hidden charges?</a>
					</h4>
					<div id="faq6" class="panel-collapse collapse">
						<div class="panel-body">
							<p>No hidden charges.</p>
						</div>
					</div>					
					
					<h4 class="panel-title">
						<a href="#faq8" class="collapsed" data-toggle="collapse" data-parent="#accordion">Will my data be secured?</a>
					</h4>
					<div id="faq8" class="panel-collapse collapse">
						<div class="panel-body">
							<p>We don't share or sell any client information. We can sign NDA (Non-Disclosure Agreement) document.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq9" class="collapsed" data-toggle="collapse" data-parent="#accordion">Who do I contact regarding technical support?</a>
					</h4>
					<div id="faq9" class="panel-collapse collapse">
						<div class="panel-body">
							<p>You can reach us anytime by mail at <a href="mail:support@ontabee.com">support@ontabee.com</a> (or) WhatsApp +91 90039 60003 for instant support.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq10" class="collapsed" data-toggle="collapse" data-parent="#accordion">Which languages are supported?</a>
					</h4>
					<div id="faq10" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Ontabee supports multiple languages and currencies.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq11" class="collapsed" data-toggle="collapse" data-parent="#accordion">When will I get my website and App?</a>
					</h4>
					<div id="faq11" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Once payment received, within 72 business working hours (Excluding our Indian government holidays and International holidays) you will get the Website and App.</p>
						</div>
					</div>

					<h4 class="panel-title">
						<a href="#faq12" class="collapsed" data-toggle="collapse" data-parent="#accordion">Do you help me with the customization?</a>
					</h4>
					<div id="faq12" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Yes, we can customise our product based on your needs.</p>
						</div>
					</div>

					<h4 class="panel-title">
						<a href="#faq13" class="collapsed" data-toggle="collapse" data-parent="#accordion">Is Android and iOS are native app?</a>
					</h4>
					<div id="faq13" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Yes, native apps only.</p>
						</div>
					</div>
					<h4 class="panel-title">
						<a href="#faq14" class="collapsed" data-toggle="collapse" data-parent="#accordion">Can I use my own logo/brand/content?</a>
					</h4>
					<div id="faq14" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Yes, you can use own logo, brand, content. </p>
						</div>
					</div>
					<h4 class="panel-title">
						<a href="#faq15" class="collapsed" data-toggle="collapse" data-parent="#accordion">Are there any limits for menu items?</a>
					</h4>
					<div id="faq15" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Nope, you can add N number of items.</p>
						</div>
					</div>
					<h4 class="panel-title">
						<a href="#faq16" class="collapsed" data-toggle="collapse" data-parent="#accordion">Can I use my own domain name/website with Ontabee?</a>
					</h4>
					<div id="faq16" class="panel-collapse collapse">
						<div class="panel-body">
							<p>Yes, you can use own domain name.</p>
						</div>
					</div>
					
					<h4 class="panel-title">
						<a href="#faq17" class="collapsed" data-toggle="collapse" data-parent="#accordion">Still, have any queries?</a>
					</h4>
					<div id="faq17" class="panel-collapse collapse">
						<div class="panel-body">
							<p><a href="/contact">  Contact us</a> for more details.</p>
						</div>
					</div>
				</div> <!--panel-->
			</div> <!--accordion-->
		</div> <!--cms_content-->
	</div> <!--container-->
</div> <!--cms_page-->

<?php include('inc/footer.php');?>