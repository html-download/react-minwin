/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16CustomerInviteBook', {
    inviteId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'invite_id'
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'customer_key'
    },
    customerId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'customer_id'
    },
    emailAddress: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'email_address'
    },
    status: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'status'
    },
    createdUserId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_user_id'
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_at'
    },
    updatedUserId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'updated_user_id'
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'updated_at'
    }
  }, {
    tableName: 'ss16_customer_invite_book'
  });
};
