import React, {Component} from 'react'; 
import PropTypes from 'prop-types'; 
import ClassName from 'classnames';
import ControlGroup from './control-group';

class InputControl extends Component {
	constructor(props) {
		super(props);
	} 

	value() {
		return this.input.value;
	}

	/*type() {
		return this.input.type;
	}*/

	render () {
		
		let lableClasses = ClassName(Object.assign({
			'checkbox' : true
		}, this.props.labelClasses ));

		let inputClasses = ClassName(Object.assign({
			'form-control' : true
		}), this.props.inputClasses)

		return (
			<ControlGroup 
			  groupClasses={this.props.groupClasses}
			  >
			    <label htmlFor={this.props.name} className={lableClasses}>{this.props.title}</label>
			    <input
			    	ref={ (c) => (this.input = c)} 
			      	className={inputClasses}
			      	name={this.props.name}
			      	type={this.props.type}
			      	value={this.props.value}
		         	placeholder={this.props.placeholder} 
		         	onChange ={this.props.onChange}
			    />
			  </ControlGroup>
		)
	}
} 
InputControl.propTypes = {
	name: PropTypes.string,
	type: PropTypes.oneOf(['text', 'number']).isRequired,
	value:  PropTypes.string,
	placeholder: PropTypes.string,
	onChange: PropTypes.func,
	groupClasses: PropTypes.object
}

export default InputControl;