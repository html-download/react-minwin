/* global window */
'use strict';
const ApiActions = require('../../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../../helpers/toaster');


class Actions {

    static getDrivingDetails(id) {

        this.getCountryResults();
        this.getDrivingExperience();
        ApiActions.get(
            `/customer-driving-profile/${id}`,
            undefined,
            Store,
            Constants.DRIVING_DETAILS,
            Constants.DRIVING_DETAILS_RESPONSE
        );
    }
    
    static changeLoader() {

        Store.dispatch({
            type: Constants.DISABLE_LOADER            
        });
    }
    
    static saveDrivingDetails(data) {
        
        ApiActions.post(
            '/customer-driving-profile/attribute-save',
            data,
            Store,
            Constants.DRIVING_DETAILS,
            Constants.DRIVING_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        this.removeEditable(data.attribute_key);
                        Toaster.success('Driving details has been updated.');
                    }
                }
            }
            
        );
    }

    static getCountryResults() {
        
        ApiActions.get(
            '/country',
            undefined,
            Store,
            Constants.GET_COUNTRY_RESULTS,
            Constants.GET_COUNTRY_RESULTS_RESPONSE
        );
    }

    static getDrivingExperience() {
        
        ApiActions.get(
            '/customer-driving-profile/license-age-list',
            undefined,
            Store,
            Constants.GET_DRIVING_EXPERIENCE_RESULTS,
            Constants.GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE
        );
    }

    static addEditable(field) {
        
        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });

    } 

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });

    }         
    
    static datePicker(date,field) {
        
        Store.dispatch({
            type: Constants.UPDATE_DATE_FIELD,
            date: date,
            field:field
        });

    }
}


module.exports = Actions;
