import React from 'react';  
import {Label, Input } from 'reactstrap';
import PropTypes from 'prop-types'; 
import ClassName from 'classnames';
const Radiobox = (props) => {

let groupClasses = ClassName(Object.assign({
    'form-group' : true
  }, props.groupClasses));
  
  let lableClasses = ClassName(Object.assign({
    'radio' : true
  },props.labelClasses ));

  let inputClasses = ClassName(Object.assign({
    'radio' : true
  }), props.inputClasses)

    return( 
  
    <div className={groupClasses}>
       <label>{props.title}</label>
    <div className="d-block">
    {(props.options.length === 0 || props.options === undefined) ? null : props.options.map((option, index) => {
        return (
          <div className="d-inline" key={index}>
          
            <input
             className={inputClasses}
              id = {props.name + index}
              name={props.name}
              onChange={props.onChange}
              value={option}
              
              type="radio" /> 
          <Label key={option} htmlFor={props.name + index} className={lableClasses}>{option}</Label>
          </div>
        );
      })}
    </div>
  </div>
);

}

Radiobox.propTypes={
  name:PropTypes.string,
  title: PropTypes.string,
  type: PropTypes.oneOf(['checkbox', 'radio']),
  options: PropTypes.array,
  onChange: PropTypes.func
};


export default Radiobox;