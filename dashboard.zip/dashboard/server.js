'use strict';
const Composer = require('./index');

const Config = require('./config');
const moment = require('moment-timezone');
var request = require('request')
var CronJob = require('cron').CronJob;

Composer((err, server) => {

    if (err) {
        throw err;
    }

    server.start(() => {
		const History = server.plugins['hapi-mongo-models'].History;
    	
    	new CronJob('0 */30 * * * *', function() {
    		request(`${Config.get('/apiUrl')}/client/lots?name=auburn`,{
				  	method: "GET",
				  	headers: {
						'X-api-key': Config.get('/historicalApiToken'),
						'Content-Type': 'application/json'
			     	}
				}, function(error, response, body) {
			        if (!error && response.statusCode == 200) {
			            console.log('cron finished on '+ moment().tz(Config.get('/timeZone')).format("MMM DD, YYYY h:mmA"));
			            History.create(JSON.parse(body), (err, user) => {
							//console.log("err", err);
							//console.log("user", user);
			            });
		        	}
	    		})
		}, null, true, Config.get('/timeZone'));

        console.log('Started the plot device on port ' + server.info.port);
    });
});
