<?php include ('inc/header.php'); ?>  

<div class="page_banner style4 bg1">
	<div class="container floating_label pad0">
		<div class="col-sm-8">
			<h1 class="head wow fadeInDown">Limetray Alternative</h1>
			<h2 class="head wow fadeInUp">Paying lot for Limetray? <br>Looking for a better alternative?</h2>
			<p class="wow fadeInUp">Ontabee provides a perfect online restaurant ordering system.</p>
		</div>
		
		<div class="col-sm-4 text-center">
			<form id="alternative" method="post" name="alternative" action="<?php echo $baseurl;?>signup" class="wow fadeInUp">
				<h4>Start your <span>Free Trial</span></h4>			
				<label class="icon">Your name
					<input type="text" name="try_name" class="form-control" required="required">
					<i class="fa fa-user-o"></i>
				</label>
				<label class="icon">Email Id
					<input type="email" name="try_email" class="form-control" required="required">
					<i class="fa fa-envelope-o"></i>
				</label>
				<input type="hidden" value="" name="try_url">
				<input type="submit" class="btn" value="Try Ontabee for Free">
			</form>
		</div>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey text-center">
	<div class="container md">
		<h2 class="head wow fadeInUp">Looking for Limetray Alternative?</h2>
		<p class="mb0 wow fadeInUp">Get the best alternative to Limetray. Ontabee provides the best and smarter solution for your online restaurant ordering system. Ontabee provides the best ordering platform for any on demand business. Our ordering platform is more flexible for the users to order and get it delivered on time. Ontabee offers all the features, which you need to run an online restaurant ordering system at just $<?php echo $price;?>. Our online ordering features helps to you easily build and run the store. Some of the features provided by Ontabee are multiple outlet, unlimited orders, live chat integration, basic report generation, loyalty point conversion, order for later, website ordering, mobile responsive, coupon, ratings, custom domain, credit card service, order receiving app for Android, delivery app for Android, customer app in your brand name along with the customer support. </p>
	</div>
	
	<div class="container">
		<div class="compare">
			<div class="col-sm-6 wow fadeInUp first">
				<h2>Ontabee</span></h2>
				<ul class="reset">
					<li><i class="fi tick"></i>Sales Optimized Website</li>
					<li><i class="fi tick"></i>Branded Mobile Apps</li>
					<li><i class="fi tick"></i>Pre-Order</li>
					<li><i class="fi tick"></i>Unlimited Orders</li>
					
					
				</ul>
			</div>			
			<span class="vs"><b>VS</b></span>
			<div class="col-sm-6 wow fadeInUp last">
				<h2>Limetray</h2>
				<ul class="reset">
					<li><i class="fi tick"></i>Sales Optimized Website</li>
					<li><i class="fi tick"></i>Branded Mobile Apps</li>
					<li><i class="fi tick"></i>Pre-Order</li>
					<li><i class="fi tick"></i>Unlimited Orders</li>
				</ul>
			</div>
			
			<p class="mb0 text-center">* Pricing data from Limetray as of July 2019</p>
		</div>
	</div> <!--container-->
</section>

<section class="text-center">
	<div class="container">
		<h2 class="head wow fadeInUp">What do you get for $0 from Ontabee?</h2>
		<p class="mb30 wow fadeInUp">Our perfect online ordering system provides these for free with zero setup cost</p>
		
		<div class="row">
			<div class="col-md-6 text-center">
				<img src="images/dashboard.png" class="wow zoomIn mb30" alt="Online Ordering">
			</div>
			
			<div class="col-md-6 text-left wow fadeInUp">
				<ul class="reset list1 style1">
					<li>Single Outlet </li>
					<li>Unlimited Orders</li>
					<li>Integrate Live Chat</li>
					<li>Basic Reports</li>
					<li>Pictures in Menu</li>
					<li>Order for Later</li>
					<li>Website Ordering</li>
					<li>Mobile Responsive</li>
				</ul>
				<p class="mb0 wow fadeInUp">Our Ontabee free trial offers full access to all the above features, allowing you to run and monitor your business in real-time. We aim at providing competitive solutions for your business. Also, we make sure you get maximum ROI with our enterprise online restaurant ordering system.</p>
			</div>
		</div>
	</div>
</section>

<section class="text-center grey">
	<div class="container">
		<h2 class="head wow fadeInUp">You get complete sales optimized website with Ontabee</h2>
		<p class="mb30 wow fadeInUp">Interested in Ontabee? Here is our <a href="<?php echo $baseurl;?>pricing">Pricing Plan</a></p>
		
		<div class="row">
			<div class="col-sm-6 text-center pull-right">
				<img src="images/graph.png" class="wow zoomIn mb30" alt="graph">
			</div>
				
			<div class="col-sm-6">
				<ul class="reset list1 text-left">
					<li>No Hidden Cost</li>
					<li>Get custom plan for multiple outlets </li>
					<li>Order receiving app provided (Android) </li>
					<li>You get a delivery app (Android).</li>
				</ul>
			</div>
		</div>
	</div>
</section>

<?php include('inc/footer.php');?>