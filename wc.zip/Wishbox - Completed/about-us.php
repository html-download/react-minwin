<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <!-- cms banner -->
  <section class="cms-page-banner text-center">
    <div class="container">
      <h2>About WishBox</h2>
      <ul class="br_ul reset">
        <li><a href="/">Home</a></li>
        <li><span>About WishBox</span></li>
      </ul>
    </div>
  </section>
  <!-- cms banner -->
  <section class="cms-full-content">
    <div class="container mx-1150">
      <div class="box-up">
        <h3>Vision</h3>
        <p>To be a global technology solution provider, meeting requirements of every individual by delivering innovative solutions.</p>
        <h3>Mission</h3>
        <p>To be a global technology solution provider, meeting real-time requirements of every individual by delivering innovative solutions.</p>
        <ul>
          <li>Aspiring for WishBox to be the most user-friendly platform in the region</li>
          <li>Simplifying and executing customer needs with perfection.</li>
          <li>Together creating a winning platform</li>
          <li>Innovating / elevating e-commerce to the next level</li>
          <li>Driving technology to its best</li>
          <li>Smart city for a smarter world</li>
        </ul>
        <h3>Who are we ?</h3>
        <p>Wishbox Technologies is a software solution provider driven by innovation-led applications that implement different technologies in full scope with platforms targeted to deliver a robust, user-friendly interface to enhance business.</p>
        <h3>Introducing WishBox App</h3>
        <p>Wishbox App, is a free, downloadable first of its kind app in Qatar, is a multi-vendor app that gives access to reach thousands of potential customers in your neighborhood.</p>
        <p>A must-have business tool to increase brand awareness, sell your services and products and help grow business grow manifold.</p>
        <h3>Our Promise</h3>
        <p>Creating happiness by being a ‘one-stop solution’ to fulfill all our customer’s primary needs and wishes.</p>
      </div>
    </div>
  </section>
  <!-- myaccount -->
</div>
<!-- site -->
<?php include ('inc/footer.php'); ?>