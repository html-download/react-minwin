const Form = require('./form.jsx');
const React = require('react');
const ReactRouter = require('react-router-dom');
const ReactHelmet = require('react-helmet');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;

class SignupPage extends React.Component {
    constructor(props) {
        super(props);
        this.handleModalClick = this.handleModalClick.bind(this);
    }
    handleModalClick(event) {
        //event.preventDefault();
        //event.stopPropagation();
    }
    render() {
        return (
            <section className="login-register">
                <Helmet>
                    <title>Signup</title>
                </Helmet>
                <div className="container">
                    <div className="login-left equal">
                        <div className="login-img">
                        <img src="/public/media/images/login.png" alt="Forget Password" />
                        </div>
                    </div>
                    <div className="login-right equal">
                        <div className="custom-modal">
                                <div className="modal-dialog">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                                            <h4 className="modal-title">Create an Account</h4>
                                            <h4 className="sub-title">Have a Dining Power account? 
                                                <Link to="/login"> Sign in</Link>
                                            </h4>

                                            <div className="social_login">
                                                Sign up with 
                                                <a href="#"> Facebook</a> or 
                                                <a href="#"> Google</a>
                                                <span>or</span>
                                            </div>
                                        </div>
                                        <div className="modal-body">
                                            <Form />
                                        </div>
                                </div>
                                    
                                </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}


module.exports = SignupPage;
