<?php
	if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') {
		$protocol  = "https://";
	} else {
		$protocol  = "http://";
	}
	$baseurl = $protocol.$_SERVER['HTTP_HOST'].'/';
	$currenturl = $protocol.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	$activePage = basename($_SERVER['PHP_SELF'],'.php');
	include 'settings.php';
	include 'menu.php';
?>
<!doctype html>
<html amp lang="en" class="<?=basename($_SERVER['PHP_SELF'],'.php')?>-page">
<head>
	<meta charset="UTF-8"/>	
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
	<link rel="icon" type="image/ico" href="<?php echo $baseurl;?>images/logo.png" />

	<meta name="robots" content="nofollow,noindex,all" />

	<!-- seo -->
	<title><?php echo $title; ?></title>
	<meta name="description" content="<?php echo $description; ?>" />
	<meta name="keywords" content="<?php echo $keywords; ?>" />
		
	<link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

	<script async src="https://cdn.ampproject.org/v0.js"></script>
	<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
	<script async custom-element="amp-selector" src="https://cdn.ampproject.org/v0/amp-selector-0.1.js"></script>
	<script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
	<script async custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js"></script>
	<script async custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js"></script>
	<script async custom-element="amp-accordion" src="https://cdn.ampproject.org/v0/amp-accordion-0.1.js"></script>
	<script async custom-element="amp-lightbox" src="https://cdn.ampproject.org/v0/amp-lightbox-0.1.js"></script>		
	<script async custom-element="amp-youtube" src="https://cdn.ampproject.org/v0/amp-youtube-0.1.js"></script>
	<script async custom-element="amp-vimeo" src="https://cdn.ampproject.org/v0/amp-vimeo-0.1.js"></script>
	<script async custom-element="amp-install-serviceworker" src="https://cdn.ampproject.org/v0/amp-install-serviceworker-0.1.js"></script>
	<style amp-custom>
		<?php include __DIR__ . '/../css/style.css'; ?>
		<?php include __DIR__ . '/../css/'.$style; ?>
		<?php include __DIR__ . '/../css/icons.css'; ?>
	</style>

	<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>
<body>
<amp-install-serviceworker src="/serviceworker.js" layout="nodisplay"></amp-install-serviceworker>

<header class="site_header full_row">
	<div class="container">
		<ul class="reset top_info">
			<li class="contact">
				<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp; ?>&text=hi" title="WhatsApp Your Requirement"><?php echo $mobile;?><i class="fa fa-whatsapp"></i></a>
				<a href="mailto:<?php echo $email;?>" title="<?php echo $email;?>"><?php echo $email;?><i class="fa fa-envelope-o"></i></a>
				<a href="skype:<?php echo $skype; ?>?call" title="Call us using Skype"><?php echo $skype; ?><i class="fa fa-skype"></i></a>
			</li>
		</ul> <!--top_info-->

		<div class="site_logo">
			<a href="<?php echo $baseurl;?>">
				<amp-img src="<?php echo $baseurl;?>images/logo.png" alt="Technoduce" width="225" height="46" layout="responsive"></amp-img>
			</a>
			<div role="button" on="tap:sidebar.toggle" tabindex="0" class="toggle hide">
				<i class="fa fa-bars"></i>
			</div>
		</div> <!--site_logo-->

		<nav class="site_menu">
			<ul class="reset">
				<li><a href="<?php echo $baseurl;?>" <?php if($activePage=='index') echo "class='active'"; ?>>Home</a></li>
				<li><a class="arrow">Company</a>
					<div class="sub_menu">
						<ul class="reset icon">
							<?php echo $company;?>
						</ul>	
					</div> <!--sub_menu-->
				</li>
				<li class="custom"><a class="arrow">Services</a>
					<div class="sub_menu">
						<div class="sub_menu_list">
							<ul class="reset">
								<li><h3><i class="fa fa-desktop"></i> Web Development</h3></li>
								<?php echo $webServices;?>
							</ul>
							<ul class="reset center">
								<li><h3><i class="fa fa-mobile"></i> Mobile Development</h3></li>
								<?php echo $mobileServices;?>
							</ul>	
							<ul class="reset">
								<li><h3><i class="fa fa-code"></i> Hire developers</h3></li>
								<?php echo $hireDevelopers;?>
							</ul>	
						</div> <!--sub_menu_list-->
					</div> <!--sub_menu-->
				</li>
				<li><a class="arrow">Products</a>
					<div class="sub_menu">
						<ul class="reset icon">
							<?php echo $products;?>
						</ul>	
					</div> <!--sub_menu-->
				</li>
				<li><a class="arrow">Resources</a>
					<div class="sub_menu">
						<ul class="reset icon">
							<?php echo $resources;?>
						</ul class="reset">	
					</div> <!--sub_menu-->
				</li>
				<li><a href="<?php echo $baseurl;?>contact-us">Contact</a></li>
			</ul>
		</nav>
	</div> <!--container-->
</header>

<amp-sidebar id="sidebar" layout="nodisplay" side="left">
	<div role="button" aria-label="close sidebar" on="tap:sidebar.toggle" tabindex="0" class="close">✕</div>
	<ul class="reset">
		<li><a href="<?php echo $baseurl;?>">Home</a></li>
		<li>
			<amp-accordion animate>
				<section>
					<h3>Company</h3>
					<ul class="reset">
						<?php echo $company;?>
					</ul>
				</section>
			</amp-accordion>
		</li>
		<li>
			<amp-accordion animate>
				<section>
					<h3>Services</h3>
					<div class="services">
						<amp-accordion animate>
							<section>
								<h3 class="arrow">Web Development</h3>
								<ul class="reset">
									<?php echo $webServices;?>
								</ul>
							</section>
							<section>
								<h3 class="arrow">Mobile Development</h3>
								<ul class="reset">
									<?php echo $mobileServices;?>
								</ul>
							</section>
							<section>
								<h3 class="arrow">Hire developers</h3>
								<ul class="reset">
									<?php echo $hireDevelopers;?>
								</ul>
							</section>
						</amp-accordion>
					</div>
				</section>
			</amp-accordion>
		</li>
		<li>
			<amp-accordion animate>
				<section>
					<h3 class="arrow">Products</h3>
					<ul class="reset">
						<?php echo $products;?>
					</ul>
				</section>
			</amp-accordion>
		</li>
		<li>
			<amp-accordion animate>
				<section>
					<h3>Resources</h3>
					<ul class="reset">
						<?php echo $resources;?>
					</ul>
				</section>
			</amp-accordion>
		</li>
		<li><a href="<?php echo $baseurl;?>contact-us">Contact</a></li>
	</ul>
</amp-sidebar>

  