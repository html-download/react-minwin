/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const CommonFunctions = require('../../../../helpers/common-functions');
const Constants = require('./constants');
const Store = require('./store');
const Toaster = require('../../../../helpers/toaster');
const Qs = require('qs');


class Actions {

    static showCreateNew(data) {
        
        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW
        });
    }

    static hideCreateNew(data) {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }

    static getCustomerDetails(id) {
                        
        ApiActions.get(
            `/customer/${id}`,
            undefined,
            Store,
            Constants.GET_SINGLE_CUSTOMER_DETAILS,
            Constants.GET_SINGLE_CUSTOMER_DETAILS_RESPONSE,
        );
    }    

    static getResults(data) {

        this.getUserResults();
        this.getYear();

        ApiActions.get(
            '/deal',
            Object.assign(data, { is_pagination: 1 }),
            Store,
            Constants.GET_RESULTS,
            Constants.GET_RESULTS_RESPONSE
        );
    }

    static getNationalityResults() {
        
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }

    static getUserResults() {
        
        ApiActions.get(
            '/user',
            undefined,
            Store,
            Constants.GET_USER_DETAILS,
            Constants.GET_USER_DETAILS_RESPONSE
        );
    }

    static getCutomerResults(customer_type) {
        
        ApiActions.get(
            '/customer',
            {customer_type:customer_type},
            Store,
            Constants.GET_CUTOMER_RESULTS,
            Constants.GET_CUTOMER_RESULTS_RESPONSE
        );
    }

    static getYear() {
        
        ApiActions.get(
            '/year',
            undefined,
            Store,
            Constants.GET_YEAR_RESULTS,
            Constants.GET_YEAR_RESULTS_RESPONSE
        );
    }

    static getMake(data) {
        
        ApiActions.get(
            '/vehicle-brand',
            data,
            Store,
            Constants.GET_MAKE_RESULTS,
            Constants.GET_MAKE_RESULTS_RESPONSE
        );
    }

    static getMakeModel(data) {
        
        ApiActions.get(
            '/vehicle-brand-model',
            data,
            Store,
            Constants.GET_MAKE_MODEL_RESULTS,
            Constants.GET_MAKE_MODEL_RESULTS_RESPONSE
        );
    }

    static getTrim(data) {
        
        ApiActions.get(
            '/vehicle-brand-model-trim',
            data,
            Store,
            Constants.GET_TRIM_RESULTS,
            Constants.GET_TRIM_RESULTS_RESPONSE
        );
    }

    static getEnquiryType() {
        
        ApiActions.get(
            '/deal/enquiry-type',
            undefined,
            Store,
            Constants.GET_ENQUIRY_TYPE_RESULTS,
            Constants.GET_ENQUIRY_TYPE_RESULTS_RESPONSE
        );
    }
       

    static createNew(data, history, searchData, returnAction) {

        ApiActions.post(
            '/deal',
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {

                if (!err) {                    
                    returnAction.hideDealModal();
                    Toaster.success('Enquiry saved successfully!');
                    history.push(`/admin/deals/${response.data.deal_key}`);
                }
            }
        );
    }

    static addEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_SHOW,
            field: field
        });
    }

    static removeEditable(field) {

        Store.dispatch({
            type: Constants.EDITABLE_HIDE,
            field: field
        });
    }    

    static togglePipeline(type) {

        Store.dispatch({
            type: Constants.TOGGLE_PIPELINE
        });

    } 

    static resetStore() {

        Store.dispatch({
            type: Constants.RESET_STORE
        });

    } 
    
}


module.exports = Actions;
