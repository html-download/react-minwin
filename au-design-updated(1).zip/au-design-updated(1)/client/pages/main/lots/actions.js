/* global window */
'use strict';
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const LotStore = require('./lot-store');
const Qs = require('qs');
const UserIdentity = require('../../../helpers/user-identity');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();

const apiUrl = UserIdentity.apiUrl;


class Actions {
    static showCreateNew(lot_name, address, LatLng, title, percentage, color, lot_status) {
        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW,
            lot_name : lot_name,
            address : address,
            LatLng : LatLng,
            title : title,
            percentage : percentage, 
            color : color,
            lot_status:  lot_status
        });
    }

    static showCreateNewMap(lot_name, address, LatLng, title, percentage, color, lot_status) {
        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW_MAP,
            lot_name : lot_name,
            address : address,
            LatLng : LatLng,
            title : title,
            percentage : percentage, 
            color : color,
            lot_status:  lot_status
        });
    }

    static hideCreateNew() {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }

    static hideCreateNewMap() {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW_MAP
        });
    }
    static hideTermsModal() {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW_MAP
        });
    }
    
    static getOccupancy(url, isShowToast = false) {

        ApiActions.get(
            url,
            undefined,
            LotStore,
            Constants.UPDATE_OCCUPANCY,
            Constants.UPDATE_OCCUPANCY_RESPONSE,
            (err, response) => {
                if (!err) {
                    if (isShowToast) {
                        Toaster.success('Data updated!')
                    }
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static getSummary(
        url, 
        updateMapBounds, 
        updateOccupancy, 
        updateBusTiming, 
        updateBikeTiming, 
        updateLotMessage,
        getOverlayImage) {

        ApiActions.get(
            url,
            undefined,
            LotStore,
            Constants.GET_SUMMARY,
            Constants.GET_SUMMARY_RESPONSE,
            (err, response) => {
                if (!err) {
                    getOverlayImage();
                    updateBusTiming();
                    updateBikeTiming();
                    updateOccupancy();
                    updateLotMessage();
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    static getBusTimings(url) {

        ApiActions.get(
            url,
            undefined,
            LotStore,
            Constants.GET_BUS_TIMING,
            Constants.GET_BUS_TIMING_RESPONSE,
            (err, response) => {
                if (!err) {
                    //updateOccupancy();
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static getBikeTimings(url, data) {

        ApiActions.get(
            url,
            data,
            LotStore,
            Constants.GET_BIKE_TIMING,
            Constants.GET_BIKE_TIMING_RESPONSE,
            (err, response) => {
                if (!err) {
                    //updateOccupancy();
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    

    static updateMapCenter(latLng, zoom) {

        LotStore.dispatch({
            type: Constants.UPDATE_MAP_CENTER,
            latLng : latLng,
            zoom : zoom
        });
    }

    static showBusTiming() {
        LotStore.dispatch({
            type: Constants.SHOW_BUS_TIMING
        });
    }

    static hideBusTiming() {
        LotStore.dispatch({
            type: Constants.HIDE_BUS_TIMING
        });
    }

    static getLotMessage(data) {

        ApiActions.get(
            `${apiUrl}/lot/msg`,
            data,
            LotStore,
            Constants.GET_LOT_MESSAGE,
            Constants.GET_LOT_MESSAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                    if (response.lot_messages && response.lot_messages.length > 0 ) {
                        let result = response.lot_messages;
                        result.forEach((lot_message) => {
                            (lot_message.message != '') ? Toaster.info(`Note: ${lot_message.message}`) : null
                        })

                    }
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static getOverlay(url) {
        ApiActions.get(
            url,
            undefined,
            LotStore,
            Constants.GET_OVERLAY_IMAGE,
            Constants.GET_OVERLAY_IMAGE_RESPONSE,
            (err, response) => {
                if (!err) {
                } else {
                    Toaster.error(err);
                }

            }
        );
    }

    static updateOverlayLoaded() {
        LotStore.dispatch({
            type: Constants.UPDATE_OVERLAY_LOAD
        });
    }
}


module.exports = Actions;
