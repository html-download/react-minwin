import {fitBounds} from 'google-map-react/utils';
const Actions = require('./actions');
const React = require('react');
const ReactHelmet = require('react-helmet');
const UserIdentity = require('../../../helpers/user-identity');
const DateTimeHelper = require('../../../helpers/date-time');
const ToasterContainer = require('../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const ReactTooltip = require('react-tooltip');
const Store = require('./lot-store');
const moment = require('moment');
const ModalForm = require('./bus-timing-modal.jsx');
//const Config = require('../../../../config.js');

//import LotList from './LotList.js';
//import ZoneList from './ZoneList';
//import Lot from './Lot';
import Map from './Map';

const Helmet = ReactHelmet.Helmet;

class LotsPage extends React.Component {
    constructor(props){
        super(props);
        this.state = Store.getState();
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.updateOccupancy = this.updateOccupancy.bind(this);
        this.toggleNav = this.toggleNav.bind(this);
        this.updateMapBounds = this.updateMapBounds.bind(this);
        this.editMapBounds = this.editMapBounds.bind(this);
        this.updateMapCenter = this.updateMapCenter.bind(this);
        this.setMarkers = this.setMarkers.bind(this);
        this.saveLocation = this.saveLocation.bind(this);
        this.openRetriveLocation = this.openRetriveLocation.bind(this);
        this.currentAddressGet = this.currentAddressGet.bind(this);
        this.updateBusTiming = this.updateBusTiming.bind(this);
        this.updateBikeTiming = this.updateBikeTiming.bind(this);
        this.openBusTiming = this.openBusTiming.bind(this);
        this.updateLotMessage = this.updateLotMessage.bind(this);
        this.getOverlayImage = this.getOverlayImage.bind(this);
    }
    timer() {
        let seconds = this.state.remaining_bus_seconds;
        var days        = Math.floor(seconds/24/60/60);
        var hoursLeft   = Math.floor((seconds) - (days*86400));
        var hours       = Math.floor(hoursLeft/3600);
        var minutesLeft = Math.floor((hoursLeft) - (hours*3600));
        var minutes     = Math.floor(minutesLeft/60);
        var remainingSeconds = seconds % 60;
        function pad(n) {
            return (n < 10 ? "0" + n : n);
        }

        document.getElementById('countdown').innerHTML = pad(hours) + ":" + pad(minutes) + ":" + pad(remainingSeconds);
        if (seconds == 0) {
            clearInterval(this.seconds_interval);
            //document.getElementById('countdown').innerHTML = "Arrived";
        } else {
            seconds--;
            this.setState({'remaining_bus_seconds': seconds})
        }
    }
    openBusTiming(event) {
        Actions.showBusTiming();
    }

    toggleNav() {
        this.setState({'showSideNav': !this.state.showSideNav})
    }

    updateMapCenter(center, zoom) {
        this.setState({center: null, zoom: null});
        this.setState({center: center, zoom: zoom});

    }

    updateMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    editMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    setMarkers(markers) {
        this.setState({'markers': markers});
    }

    saveLocation(isSave) {
        if (isSave) {
            if (UserIdentity._checkCurrentAddress() !== null) {
                localStorage.setItem(`saved_address_${UserIdentity._checkUserToken()}`, JSON.stringify(UserIdentity._checkCurrentAddress()));
            } 
        } else {
            if (UserIdentity._checkSavedAddress() !== null) {
                localStorage.removeItem(`saved_address_${UserIdentity._checkUserToken()}`);
            } 
        }
        
        this.setState({'isLoaded': true})
    }
    openRetriveLocation () {
        if (UserIdentity._checkCurrentAddress() !== null && UserIdentity._checkSavedAddress() !== null) {
            window.open('https://www.google.com/maps/dir/'+UserIdentity._checkCurrentAddress().lat+','+UserIdentity._checkCurrentAddress().lng+'/'+UserIdentity._checkSavedAddress().lat+','+UserIdentity._checkSavedAddress().lng)
        }
    }

    updateOccupancy(){
        let url = `${this.params.fopark_url}/lot/occupancy?client_name=${UserIdentity.client}&name=${this.props.match.params.lotID}`;
        Actions.getOccupancy(url, this.state.isShowToast);
    }

    getOverlayImage() {
        let url = `${this.params.fopark_url}/lot/overlay?client_name=${UserIdentity.client}&lot_name=${this.props.match.params.lotID}`;
        Actions.getOverlay(url);
    }

    updateBusTiming(){
        if (this.state.bus_timing_api !== null) {
            Actions.getBusTimings(this.state.bus_timing_api);
        }
    }

    updateBikeTiming(){
        if (this.state.bike_timing_api !== null) {
            Actions.getBikeTimings('/api/bike/count',{ 
                'url' : this.state.bike_timing_api,
                'bearer' : this.state.bike_timing_api_auth
            });
        }
    }

    updateLotMessage(){
        Actions.getLotMessage({ 
            'id' : this.state.lot_id,
            'current' : 1
        });
    }

    componentDidMount(){
        let url = `${this.params.fopark_url}/lot/summary?client_name=${UserIdentity.client}&name=${this.props.match.params.lotID}`;
        Actions.getSummary(url, this.updateMapBounds, this.updateOccupancy, this.updateBusTiming, this.updateBikeTiming, this.updateLotMessage, this.getOverlayImage);

        this.interval = setInterval(
            () => {
                this.updateOccupancy();
            }, 10000
        );
        this.bus_interval = setInterval(
            () => {
                this.updateBusTiming();
            }, 60000
        );

        this.bike_interval = setInterval(
            () => {
                this.updateBikeTiming();
            }, 60000
        );

        this.message_interval/* = setInterval(
            () => {
                this.updateLotMessage();
            }, 60000
        )*/;

        /*this.seconds_interval = setInterval(
            () => {
                this.timer();
            }, 1000
        );*/
        //this.updateOccupancy();

        this.setState({'mapHeight': window.innerHeight, 'mapWidth': window.innerWidth});
        if (this.state.center && this.state.zoom) {
            this.updateMapCenter(this.state.center, this.state.zoom);
        }
        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

    }

    componentWillUnmount() {
        Actions.updateOverlayLoaded()
        clearInterval(this.interval);
        clearInterval(this.bus_interval);
        clearInterval(this.bike_interval);
        clearInterval(this.message_interval);
        this.unsubscribeStore();
    }
    onStoreChange() {

        this.setState(Store.getState());
    }
    currentAddressGet () {
        if (navigator.geolocation) {
          // Can use geolocation, proceed with getting the location
          navigator.geolocation.getCurrentPosition(this.savePosition, this.positionError);
        } else {
          // Can't use geolocation, we should tell the user
          Toaster.error('Your browser doesn\'t support geolocation');
        }
    }
    savePosition(position) {
        
        let latLng = {
          lat : position.coords.latitude,
          lng : position.coords.longitude
        };

        localStorage.setItem(`current_address_${UserIdentity._checkUserToken()}`, JSON.stringify(latLng));
        if (UserIdentity._checkCurrentAddress() !== null) {
            Actions.updateMapCenter(latLng, 17);
        }
    }
    positionError() {
        Toaster.error('Sorry! There was an error getting your location.');
    }
    render() {
        const { error, loading, lot, bus_timing, bus_timing_index, remaining_bus_minutes} = this.state;

        /*if (!loading) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else if (error) {
            return <div className="msg_box text-center">
                <h6 className="msg"><i className="fa fa-exclamation-triangle" aria-hidden="true"></i> 
                    Uh Oh! Looks like there is a connection issue. Please try refreshing the app.
               </h6>
                <a onClick={ () => {this.updateLotList()}} ><i className="fa fa-refresh" data-tip="Click to refresh lots"></i></a>
               
                <ReactTooltip />
            </div>;
        }  else {*/
            return (
                <div className="" id="lots">
                    {loading ? (
                        <div className="loader"></div>
                    ) : ''}
                    <ReactTooltip />
                    <section className="">
                        <Helmet>
                            <title>{lot.title === null ? this.props.match.params.lotID : lot.title}</title>
                        </Helmet>
                        <div className="box3">
                            <h6 className="lowder">
                                {lot.title}
                            </h6>
                            <em>This lot <span style={{color: '#00f'}}>requires a permit</span></em>
                            <ul>
                                {this.state.available > 0 ? <li>&nbsp;<img src='/public/media/images/icons/green.png' alt=''/>&nbsp;Available:&nbsp;<span>{this.state.available}</span> </li> : null }
                                {this.state.occupied > 0 ? <li>&nbsp;<img src='/public/media/images/icons/red.png' alt=''/>&nbsp;Occupied:&nbsp;<span>{this.state.occupied}</span> </li> : null }
                                {this.state.reserved > 0 ? <li>&nbsp;<img src='/public/media/images/icons/purple.png' alt=''/>&nbsp;Reserved:&nbsp;<span>{this.state.reserved}</span> </li> : null }
                                {this.state.noData > 0 ? <li>&nbsp;<img src='/public/media/images/icons/orange.png' alt=''/>&nbsp;No Data:&nbsp;<span>{this.state.noData}</span> </li> : null }
                            </ul>
                            {
                                UserIdentity._checkUserAddress() !== null ? (
                                        <a href={`https://www.google.com/maps/dir/${lot.entrance_coords}/${parseFloat(UserIdentity._checkUserAddress().lat)},${parseFloat(UserIdentity._checkUserAddress().lng)}`} target="_blank" rel="noopener">Direction to destination</a>
                                ) : ''
                            }
                            
                        </div>

                        { this.state.bike_count > 0 ? (
                            <div className="box-view box1">
                                <h5 className="route green"><i className="fa fa-bicycle"></i> {this.state.bike_count} - Available</h5>
                                <a target="_blank" href={`https://www.google.com/maps/dir/${this.state.lot.entrance_coords}/${this.state.bike_lat_lng}`} rel="noopener" className="text-center rte btns">Show Route</a>
                            </div>
                        ) : (
                            <div className="box-view box1" key="13">
                                <h5 className="route red" key="3"><i className="fa fa-bicycle"></i> Not Available</h5>
                                <a target="_blank" href={`https://www.google.com/maps/dir/${this.state.lot.entrance_coords}/${this.state.bike_lat_lng}`} rel="noopener" className="text-center rte btns">Show Route</a>
                            </div>
                        )}

                        { bus_timing.length > 0 ? (
                            <div className="box-view box2" key="11">

                                <h5 className="route green" key="1"><i className="fa fa-bus"></i> Available </h5>
                                <div className="bus_time"> in</div> 
                                <div className="bus_time hrs" id="countdown"> {remaining_bus_minutes} min's</div>
                                
                                <a target="_blank" href={`https://www.google.com/maps/dir/${this.state.lot.entrance_coords}/${this.state.bus_lat_lng}`} rel="noopener" className="rte btns">Show Route</a>
                                <i title="click to view all timings" className="fa fa-info-circle timings" onClick={this.openBusTiming} ></i>
                            </div>
                        ) : (
                            <div className="box-view box2" key="12">
                                <h5 className="route red" key="2"><i className="fa fa-bus"></i> Not Available</h5>
                                <a target="_blank" href={`https://www.google.com/maps/dir/${this.state.lot.entrance_coords}/${this.state.bus_lat_lng}`} rel="noopener" className="rte btns">Show Route</a>
                            </div>
                        )}
                             
                            
                        
                            {
                                UserIdentity._checkSavedAddress() !== null ? (
                                    <div className="box-view box4">
                                        <a role="button" className="w100" onClick={() => { this.openRetriveLocation()}}><i className="fa fa-map-marker"></i> Retrive Location</a>
                                        <a data-tip="Click to clear saved location" className="refresh" onClick={() => {this.saveLocation(false)}}><i className="fa fa-refresh" aria-hidden="true"></i></a>
                                    </div>
                                ) : (
                                    <div className="box-view box4">
                                        <a role="button" className="w100 save_loc" onClick={() => {this.saveLocation(true)}}> <i className="fa fa-map-marker"></i> Save Current Location</a>
                                    </div>
                                )
                            }
                            
                        <div className="box-view box5" style={{ 'display' : 'block'}} onClick={this.currentAddressGet}>
                            <a  className="text-center"> 
                                <img src={`/public/media/images/icons/current_loc.png`} alt="Current Location" /> 
                            </a>
                        </div>  
                        
                        <Map
                            markers={this.state.markers}
                            center={this.state.center}
                            zoom={this.state.zoom}
                            history={this.props.history}
                            id={this.props.match.params.lotID}
                            {...this.state}
                        />
                        <div className="main">
                         </div>
                    </section>
                    <ModalForm 
                        {...this.state}
                    />
                </div>
            );
        //}
    }
}


module.exports = LotsPage;
