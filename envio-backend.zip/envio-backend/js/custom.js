//Animation
new WOW().init();

//dropdown menu
$("ul.dropdown-menu label, .event").on('click', function(event) {
    event.stopPropagation();
});


//Custom scrollbar
jQuery(document).ready(function(){
	jQuery('.scrollbar-inner').scrollbar();
});

// Date Time Picker
$(".datepicker").datetimepicker({		
	minView: 2,
	format: "dd-M-yyyy",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

$(".datetime").datetimepicker({		
	format: "dd-M-yyyy - HH:ii P",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});

// Select2
$(document).ready(function() {
    $('.basic').select2();
});

//task_action
$(".task_action").click(function(){    
    $(".tasks").toggleClass("closed"); 
    $(".booking").toggleClass("leftclosed");
    $(this).toggleClass("active");
});

//agent_action
$(".agent_action").click(function(){    
	$(".agent").toggleClass("closed"); 
	$(".booking").toggleClass("rightclosed");
	$(this).toggleClass("active");
});

//Task detail
$(".location li h5,.location li .address").click(function(){    
	$(".task-detail").slideDown(); 
	$(".task-detail").addClass("open"); 
	$(".task-section").addClass("closed");
	$(".task-section").slideUp();
});

//Task detail Close
$(".task-close").click(function(){    
	$(".task-section").slideDown(); 
	$(".task-section").removeClass("closed"); 
	$(".task-detail").removeClass("open");
	$(".task-detail").slideUp(); 
});

//Agent detail
$(".agentlist li a").click(function(){    
	$(".agent-detail").slideDown(); 
	$(".agent-detail").addClass("open"); 
	$(".agent-section").addClass("closed");
	$(".agent-section").slideUp();
});

//Agent detail Close
$(".agent-close").click(function(){    
	$(".agent-section").slideDown(); 
	$(".agent-section").removeClass("closed"); 
	$(".agent-detail").removeClass("open");
	$(".agent-detail").slideUp(); 
});

//Search
$(".search").click(function(){  
	$(this).next('.search-option').addClass("open"); 
});

$(".close-search").click(function(){  
	$(this).parents('.search-option').removeClass("open"); 
});

// Dropdown Not to Close 
$(".filter-menu").on('click', function(event) { event.stopPropagation(); });

// Select 2 Without Search 
$(document).ready(function() {
	$(".lang").select2({minimumResultsForSearch: -1});
});

$(".language").click(function(){    
	$('body').addClass("lng"); 
});

