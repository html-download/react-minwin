/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Customer', {
    customerId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'customer_id',
      autoIncrement : true
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'customer_key'
    },
    customerName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'customer_name'
    },
    customerLastName: {
      type: DataTypes.STRING(100),
      allowNull: true,
      field: 'customer_last_name'
    },
    customerEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'customer_email'
    },
    username: {
      type: DataTypes.STRING(256),
      allowNull: true,
      field: 'username'
    },
    passwordHash: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'password_hash'
    },
    customerOrgPassword: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'customer_org_password'
    },
    customerMobile: {
      type: DataTypes.STRING(20),
      allowNull: true,
      defaultValue: '',
      field: 'customer_mobile'
    },
    customerGender: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      field: 'customer_gender'
    },
    customerDob: {
      type: DataTypes.DATEONLY,
      allowNull: true,
      field: 'customer_dob'
    },
    authKey: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'auth_key'
    },
    resetToken: {
      type: DataTypes.STRING(100),
      allowNull: true,
      defaultValue: '',
      field: 'reset_token'
    },
    resetExpires: {
      type: DataTypes.STRING(100),
      allowNull: true,
      defaultValue: '',
      field: 'reset_expires'
    },
    customerActivationKey: {
      type: DataTypes.STRING(100),
      allowNull: true,
      field: 'customer_activation_key'
    },
    customerActivationStatus: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'customer_activation_status'
    },
    customerType: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      defaultValue: '1',
      field: 'customer_type'
    },
    fbUserId: {
      type: DataTypes.STRING(124),
      allowNull: true,
      field: 'fb_user_id'
    },
    fbUserAccessToken: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'fb_user_access_token'
    },
    googleUserId: {
      type: DataTypes.STRING(124),
      allowNull: true,
      field: 'google_user_id'
    },
    googleUserAccessToken: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'google_user_access_token'
    },
    customerStatus: {
      type: DataTypes.ENUM('Active','Deactive','Not Activated','Deleted'),
      allowNull: true,
      defaultValue: 'Not Activated',
      field: 'customer_status'
    },
    messageStatus: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      defaultValue: '0',
      field: 'message_status'
    },
    customerLastLogin: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'customer_last_login'
    },
    isLogin: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      defaultValue: '0',
      field: 'isLogin'
    },
    isForgot: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      defaultValue: '0',
      field: 'isForgot'
    },
    customerIpAddress: {
      type: DataTypes.STRING(128),
      allowNull: true,
      defaultValue: '',
      field: 'customer_ip_address'
    },
    deviceId: {
      type: DataTypes.STRING(255),
      allowNull: true,
      field: 'device_id'
    },
    deviceType: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      field: 'device_type'
    },
    pushNotification: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      defaultValue: '1',
      field: 'push_notification'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'modified_datetime'
    },
    signupPhone: {
      type: DataTypes.INTEGER(20),
      allowNull: true,
      field: 'signup_phone'
    },
    otp: {
      type: DataTypes.STRING(16),
      allowNull: true,
      field: 'otp'
    }
  }, {
	timestamps : false,
    tableName: 'ss16_customer'
  });
};
