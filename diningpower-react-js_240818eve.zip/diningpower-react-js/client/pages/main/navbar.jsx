const React = require('react');
const PropTypes = require('prop-types');
const ReactRouter = require('react-router-dom');
const Favicon = require('react-favicon');

const SignupForm = require('./signup-popup/index.jsx');
const LoginForm = require('./login/popup/index.jsx');
const ForgotForm = require('./login/forgot-popup/index.jsx');
const UserIdentity = require('../../helpers/user-identity');

const Link = ReactRouter.Link;

const propTypes = {
    location: PropTypes.object
};
class Navbar extends React.Component {
    constructor(props) {
        super(props);
        this.handleModalClick = this.handleModalClick.bind(this);
    }
    handleModalClick(event) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
    }
    componentDidMount() {
        localStorage.setItem('setStorage', null);
    }
    render() {
        return (<header className="site_header full_row">
                    <Favicon url="/public/media/images/favicon.png"/>
                    <div className="container animated fadeInDown">
                        <div className="site_logo">
                            <Link to="/"><img src="/public/media/images/logo.png" alt="Logo"/></Link>
                        </div> 
                        
                        <div className="site_menu">
                            { UserIdentity._checkUserIdentity() 
                                ? 
                                (
                                    <nav className="full_row">
                                        <ul className="reset">
                                            <li className="dropdown accounts">
                                                <a className="acc_menu" data-toggle="dropdown">
                                                <span>My Account</span>
                                            <i className="fa fa-angle-down"></i>
                                            </a>
                                            <ul className="dropdown-menu">
                                                <li>
                                                    <Link to="/invite-friend" className="icon"> <i className="fa fa-user-o"></i> Invite Friend</Link>
                                                </li>
                                                <li>
                                                    <Link to="/rewards" className="icon"> <i className="fa fa-cutlery"></i> Reward</Link>
                                                </li>
                                                <li>
                                                    <Link to="/my-rewards" className="icon"> <i className="fa fa-trophy"></i> My-Reward</Link>
                                                </li>
                                                <li>
                                                    <Link to="/login/logout" className="icon logout"> <i className="fa fa-sign-out"></i> Sign Out</Link>
                                                </li>
                                            </ul>                            
                                        </li>
                                        </ul>
                                    </nav>
                                )
                                : (this.props.location.pathname === '/signup' || this.props.location.pathname === '/login' || this.props.location.pathname === '/login/forgot') ? '' :
                                (
                                    <ul className="reset">
                                        <li> 
                                            <div className="dropdown custom-drop signup">
                                                <span className="new">New to Dining Power?</span>
                                                <a className="dropdown-toggle" id="signup_btn" type="button" data-toggle="dropdown" role="button">Signup</a>
                                                <div className="dropdown-menu">
                                                    <SignupForm />
                                                </div>
                                            </div>
                                        </li>
                                        <li id="login-popup">
                                            <div className="dropdown custom-drop">
                                                <a className="dining_login_btn dropdown-toggle" id="login_btn" type="button" data-toggle="dropdown" role="button">Login</a>
                                                <div className="dropdown-menu">
                                                    <div className="custom-modal" onClick={this.handleModalClick}>
                                                        <div className="modal-dialog">
                                                            <LoginForm />
                                                            <ForgotForm />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        
                                        
                                    </ul>
                                )
                            }
                        </div>
                    </div>
                </header> 
        );
    }
}

Navbar.propTypes = propTypes;


module.exports = Navbar;
