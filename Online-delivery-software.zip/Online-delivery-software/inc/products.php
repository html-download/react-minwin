<?php
/**
 * Updates Module custom post type
 */
add_action('init', 'products_post_type_register');
function products_post_type_register() {
	register_post_type( 'products' ,
						array(
							'label' => 'Products',
							'singular_label' => 'products',
							'public' => true,
							'show_ui' => true,
							//'menu_icon' => get_stylesheet_directory_uri() . '/images/productsmonials-icon.png', 
							'capability_type' => 'post',
							'hierarchical' => false,
							'rewrite' => true,
							'show_in_nav_menus' => true,
							'supports' => array('title','thumbnail','editor')
						)
					);

	add_filter('manage_edit-products_columns', 'products_edit_columns');

	function products_edit_columns($columns){
		$columns = array(
			'cb' 	=> '<input type="checkbox" />',
			'title' => 'products',
			'author'=> 'Author',
			'date'	=>'Date'
		);

		return $columns;
	}
}

?>