'use strict';
const Actions = require('./actions');
const Store = require('./store');
const Alert = require('../../../../components/alert.jsx');
const Button = require('../../../../components/form/button.jsx');
const ControlGroup = require('../../../../components/form/control-group.jsx');
const LinkState = require('../../../../helpers/link-state.js');
const Modal = require('../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../components/form/spinner.jsx');
const TextControl = require('../../../../components/form/text-control.jsx');
const ReactSelectControl = require('../../../../components/form/react-select-control.jsx');
const CommonHelper = require('../../../../helpers/common-functions');
const DateHelper = require('../../../../helpers/date-time');
const Async = require('async');

const propTypes = {
    email: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
    mobile_no: PropTypes.string,
    show: PropTypes.bool,
    name: PropTypes.string,
    nationality: PropTypes.string
};

class CreateNewForm extends React.Component {

    constructor(props) {

        super(props);

        this.els = {};
        this.state = Store.getState();

        this.updateDOB = this.updateDOB.bind(this);
        this.checkMobileNumber = this.checkMobileNumber.bind(this);
        this.handleUserTypeChange = this.handleUserTypeChange.bind(this);
        Actions.getUserTypes();
        Actions.getUsers();
        Actions.getNationalityResults();
        this.user_types = CommonHelper.getUserTypes();
        
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    onStoreChange() {                

        this.setState(Store.getState());
    }

    componentDidUpdate() {

        if (this.props.show && this.state.name && this.state.name.length === 0) {
            this.els.name.focus();
        }
    }

    checkMobileNumber(e) {

        let inputValue = e.target.value;
        let mobileNumber  = inputValue.replace(/\D/g,'');
        e.target.value = mobileNumber.substring(0, 10);
    }

    onSubmit(event) {

        event.preventDefault();
        event.stopPropagation();


        let formData = {
            customer_type: this.els.customer_type.value() ? this.els.customer_type.value() : 1,
            email: this.els.email.value() ? this.els.email.value() : '',
            mobile_number: this.els.mobile_no.value() ? this.els.mobile_no.value() : '',

            /**Corportate Fileds */
            short_name: this.els.short_name.value() ? this.els.short_name.value() : '',
            company_name: this.els.company_name.value() ? this.els.company_name.value() : '',
            vat_reg_no: this.els.vat_reg_no.value() ? this.els.vat_reg_no.value() : '',
            phone_number: this.els.phone_number.value() ? this.els.phone_number.value() : '',
            website: this.els.website.value() ? this.els.website.value() : '',
            fax: this.els.fax.value() ? this.els.fax.value() : '',
            ho_country: this.els.ho_country.value() ? this.els.ho_country.value() : '',
            city: this.els.city.value() ? this.els.city.value() : '',
            country: this.els.country.value() ? this.els.country.value() : '',
            location: this.els.location.value() ? this.els.location.value() : '',

            /** Individual Fields */
            first_name: this.els.name.value() ? this.els.name.value() : '',
            /* arabic_first_name: this.els.arabic_first_name.value() ? this.els.arabic_first_name.value() : '', */
            last_name: this.els.last_name.value() ? this.els.last_name.value() : '',
            /* arabic_last_name: this.els.arabic_last_name.value() ? this.els.arabic_last_name.value() : '', */
            nationality_id: this.els.nationality.value() ? this.els.nationality.value() : '',
            gender: this.els.gender.value() ? this.els.gender.value() : '',
            dob: this.state.dob ? DateHelper._getDbFormat(this.state.dob) : '',
            /* source: this.els.source.value() ? this.els.source.value() : '', */
        };

        /* Async.forEachOf(this.state.roles, (value, index, callback) => {

            formData[value.column_name] = this.els[value.column_name].value();
        }); */

        Actions.createNew(formData, this.props.history, this.props.searchData, this.props.parentAction);
    }

    updateDOB(date) {
                
        Actions.updateDOB(date);
    }

    handleUserTypeChange(e) {
        this.setState({
            is_corporate: (e === 2) ? true : false
        });
    }

    render() {
        
        let alert;

        if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }

        /* const roleFormElements = this.state.roles ? this.state.roles.map((value, index) => {

            return (<ReactSelectControl
                ref={(c) => (this.els[value.column_name] = c)}
                key={ value.column_name }
                name="value.label"
                label={value.label}
                onChange={() => {}}
                hasError={this.state.hasError[value.column_name]}
                help={this.state.help[value.column_name]}
                disabled={this.state.loading}
                groupClasses={{'rq': true}}
                inputClasses={{'select-modal': true}}
                labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                options={ CommonHelper.getOptionData(this.state.users,'user_key','username') }
            />);
        }) : ''; */
        
        const nationalityData = CommonHelper.getOptionData(this.state.nationality_data, 'nationality_key', 'nationality_name');

        const formElements = <fieldset>
            {alert}
            <div className="form-box-horizandal">

                <ReactSelectControl
                    ref={(c) => (this.els.customer_type = c)}
                    name="customer_type"
                    label="Customer Type"
                    onChange={ (e) => this.handleUserTypeChange(e) }
                    hasError={this.state.hasError.customer_type}
                    help={this.state.help.customer_type}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    inputClasses={{'select-modal': true}}
                    labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    options={[ {label: 'Individual', value: 1}, {label: 'Corporate', value: 2}]}
                />
                <TextControl
                    ref={(c) => (this.els.mobile_no = c)}
                    name="mobile_no"
                    label="Mobile Number"                    
                    onChange={LinkState.bind(this)}
                    onChange={ (e) => this.checkMobileNumber(e) }
                    hasError={this.state.hasError.mobile_no}
                    help={this.state.help.mobile_no}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    placeholder="Enter the mobile number with Country code"
                    labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                />
                <TextControl
                    ref={(c) => (this.els.email = c)}
                    name="email"
                    label="Email Id"                    
                    onChange={LinkState.bind(this)}
                    hasError={this.state.hasError.email}
                    help={this.state.help.email}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                />
                

                <div className="corporat_section" style={ this.state.is_corporate ? {display:'block'} : {display:'none'} }>
                    <TextControl
                        ref={(c) => (this.els.short_name = c)}
                        name="short_name"
                        label="Short Name"                    
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.short_name}
                        help={this.state.help.short_name}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.company_name = c)}
                        name="company_name"
                        label="Company Name"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.company_name}
                        help={this.state.help.company_name}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />                    
                    <TextControl
                        ref={(c) => (this.els.vat_reg_no = c)}
                        name="vat_reg_no"
                        label="VAT Reg No"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.vat_reg_no}
                        help={this.state.help.vat_reg_no}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />                    
                    <TextControl
                        ref={(c) => (this.els.phone_number = c)}
                        name="phone_number"
                        label="Phone Number"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.phone_number}
                        help={this.state.help.phone_number}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.website = c)}
                        name="website"
                        label="Website"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.website}
                        help={this.state.help.website}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.fax = c)}
                        name="fax"
                        label="FAX"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.fax}
                        help={this.state.help.fax}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.ho_country = c)}
                        name="ho_country"
                        label="HO Country"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.ho_country}
                        help={this.state.help.ho_country}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.city = c)}
                        name="city"
                        label="City"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.city}
                        help={this.state.help.city}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.country = c)}
                        name="country"
                        label="Country"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.country}
                        help={this.state.help.country}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                    <TextControl
                        ref={(c) => (this.els.location = c)}
                        name="location"
                        label="location"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.location}
                        help={this.state.help.location}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />
                </div>

                <div className="individual_section" style={ this.state.is_corporate ? {display:'none'} : {display:'block'} }>

                    <TextControl
                        ref={(c) => (this.els.name = c)}
                        name="name"
                        label="First Name"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.name}
                        help={this.state.help.name}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />

                    {/* <TextControl
                        ref={(c) => (this.els.arabic_first_name = c)}
                        name="arabic_first_name"
                        label="Arabic First Name"
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.arabic_first_name}
                        help={this.state.help.arabic_first_name}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    /> */}
                    
                    <TextControl
                        ref={(c) => (this.els.last_name = c)}
                        name="last_name"
                        label="Last Name"                    
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.last_name}
                        help={this.state.help.last_name}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    />

                    {/* <TextControl
                        ref={(c) => (this.els.arabic_last_name = c)}
                        name="arabic_last_name"
                        label="Arabic Last Name"                    
                        onChange={LinkState.bind(this)}
                        hasError={this.state.hasError.arabic_last_name}
                        help={this.state.help.arabic_last_name}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                    /> */}
                    
                    <ReactSelectControl
                        ref={(c) => (this.els.nationality = c)}
                        name="nationality"
                        label="Nationality"                    
                        onChange={() => {}}
                        hasError={this.state.hasError.nationality}
                        help={this.state.help.nationality}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        inputClasses={{'select-modal': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                        options={ nationalityData }
                    />
                    <ReactSelectControl
                        ref={(c) => (this.els.gender = c)}
                        name="gender"
                        label="Gender"                    
                        onChange={() => {}}
                        hasError={this.state.hasError.gender}
                        help={this.state.help.gender}
                        disabled={this.state.loading}
                        groupClasses={{'rq': true}}
                        inputClasses={{'select-modal': true}}
                        labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                        options={ [{label: 'Male', value: 1},{ label: 'Female', value: 2 }] }
                    />
                    <TextControl
                        ref={(c) => (this.els.dob = c)}
                        name="dob"
                        label="DOB"
                        hasError={this.state.hasError.dob}
                        help={this.state.help.dob}
                        disabled={this.state.loading}
                        validation={true}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true}}   
                        defaultValue={ (this.state.dob !== undefined && this.state.dob !== "") ? DateHelper._getDefaultFormat(this.state.dob) : ''}
                        isKeyEnable={true}
                        onChange={(e) => { this.updateDOB(e)}}
                        isDatePicker={true}
                        maxDate={ new Date() }
                    />
                </div>                
                {/* roleFormElements  */}
                {/* <TextControl
                    ref={(c) => (this.els.source = c)}
                    name="source"
                    label="Source"                    
                    onChange={LinkState.bind(this)}
                    hasError={this.state.hasError.source}
                    help={this.state.help.source}
                    disabled={this.state.loading}
                    groupClasses={{'rq': true}}
                    labelClasses={{'left-side': true, 'control-label': false,'req': true}}
                /> */}
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'actions': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn': true, 'btn-white': true }}
                        disabled={this.state.loading}
                        onClick={this.props.parentAction.hideCreateCustomer}
                        >
                        Close
                    </Button>
                    <Button
                        type="submit"
                        inputClasses={{ 'btn': true, 'btn-primary': true }}
                        disabled={this.state.loading}>
                        <Spinner space="right" show={this.state.loading} />
                        Create
                    </Button>
                </ControlGroup>
            </div>
        </fieldset>;
       
        return (
            <Modal
                header="Add New Customer"
                show={this.props.show}
                onClose={this.props.parentAction.hideCreateCustomer}
                groupClasses={{'model_design1': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>
                <form onSubmit={this.onSubmit.bind(this)}>
                    { formElements }
                </form>
            </Modal>
        );
    }
}

CreateNewForm.propTypes = propTypes;


module.exports = CreateNewForm;
