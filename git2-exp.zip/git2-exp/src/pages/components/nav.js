import React, {Component} from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Nav from 'react-bootstrap/Nav';

class Navi extends Component{

render(){

	return(

<Container>
  <div className="topnav">
  <Row>
  <Col sm={6}></Col>
    <Col sm={6}>
        <Nav defaultActiveKey="/home" as="ul">
  <Nav.Item as="li">
    <Nav.Link href="/home">Active</Nav.Link>
  </Nav.Item>
  <Nav.Item as="li">
    <Nav.Link>Link</Nav.Link>
  </Nav.Item>
  <Nav.Item as="li">
    <Nav.Link >Link</Nav.Link>
  </Nav.Item>
</Nav>
    </Col>
  </Row>
  </div>
</Container>

	
		);
	}
}

export default Navi;