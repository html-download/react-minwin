 $(document).ready(function(){

$('[data-toggle="tooltip"]').tooltip();

$('[data-toggle="popover"]').popover();

$(".table-fixed").tableHeadFixer(); 


// password
$(".password_toggler").click(function() {
  $(this).toggleClass("open");
  var input = $(".passToggle");
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }

});


// outside click close

$('body').on('click', function (e) {
    $('[data-toggle="popover"]').each(function () {
        //the 'is' for buttons that trigger popups
        //the 'has' for icons within a button that triggers a popup
        if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            $(this).popover('hide');
        }
    });
});


// loader
$('.loader').on('click', function() {
   var $this = $(this);
   var loadingText = '<i class="fas fa-circle-notch fa-spin"></i> loading...';
   if ($(this).html() !== loadingText) {
      $this.data('original-text', $(this).html());
      $this.html(loadingText);
   }
   setTimeout(function() {
      $this.html($this.data('original-text'));
   }, 9000);
});


// click
$('.table-box-sidebar a').on('click',  function(){
	$(this).toggleClass("active");
});





});
