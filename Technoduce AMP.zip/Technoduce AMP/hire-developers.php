<?php include ('inc/header.php'); ?>

<section class="page_banner web">
  <div class="container">
    <div class="content">      
      <div class="img">
        <amp-img class="animated zoomIn" src="<?php echo $baseurl;?>images/android-logo.png" alt="Hire android developer" width="300" height="300" layout="responsive"></amp-img>
      </div>
      
      <h1 class="animated fadeInDown">Hire Developers</h1>
      <p class="desc mb20 animated fadeInUp">Hire our developers exhibiting wise talents and ethical attitude towards web and mobile app developments using knowledge in multiple technologies.</p>
      <a href="<?php echo $baseurl;?>contactus" target="_blank" class="btn line animated fadeInUp">Get free quote</a>
    </div>
  </div> <!--container-->
</section> <!--page_banner-->

<section class="clients pt25">
  <div class="container">
    <h2 class="head">Our branded happy clients</h2>
    <?php include ('inc/clients.php'); ?>
  </div> <!--container-->
</section> <!--clients-->

<section class="dark pb20">
  <div class="container md text-center">
    <h2 class="head style1 mb20 white">Hire web developers</h2>
    <p class="white mb30">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit vulputate urna sit amet, consectetur adipiscing elit.</p>

    <ul class="boxes reset col3 text-left">
      <li>
        <div class="box php">
            <i class="icon php"></i>
            <h3>Hire PHP Developers</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc aliquet.</p>
            <a href="<?php echo $baseurl;?>hire-php-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box angular">
            <i class="icon angular"></i>
            <h3>Hire AngularJS Developers</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc aliquet.</p>
            <a href="<?php echo $baseurl;?>hire-angularjs-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box react">
            <i class="icon react"></i>
            <h3>Hire ReactJS Developers</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc aliquet.</p>
            <a href="<?php echo $baseurl;?>hire-react-js-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box nodejs">
            <i class="icon nodejs"></i>
            <h3>Hire NodeJS Developers</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc aliquet.</p>
            <a href="<?php echo $baseurl;?>hire-node-js-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box stack">
            <i class="icon stack"></i>
            <h3>Hire Full Stack Developers</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc aliquet.</p>
            <a href="<?php echo $baseurl;?>hire-full-stack-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>      
  </div> <!--container-->
</section> <!--clients-->

<section class="products full_row">
  <div class="content_head full_row">
    <div class="container relative">
      <h2 class="head mb20 style1">Hire mobile app developers</h2>
      <p class="white md mb30">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ac ultricies sapien. Suspendisse at auctor nunc, aliquet vulputate urna sit amet, consectetur adipiscing elit vulputate urna sit amet, consectetur adipiscing elit.</p>
    </div> <!--container-->
  </div> <!--content_head-->

  <div class="container md relative text-left">
    <ul class="boxes reset col3">
      <li>
        <div class="box ios">
            <i class="icon apple"></i>
            <h3>Hire iPhone developers</h3>
            <p>Extensive experience with iOS app development services enables us to craft bespoke solutions for large and small enterprises rapidly and efficiently.</p>
            <a href="<?php echo $baseurl;?>hire-android-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box android">
          <i class="icon android"></i>
          <h3>Hire Android developers</h3>
          <p>We offers top-notch, flawless and dynamic Android app development services all around the globe.</p>
          <a href="<?php echo $baseurl;?>hire-iphone-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
      <li>
        <div class="box react">
          <i class="icon react"></i>
          <h3>React Native developers</h3>
          <p>Reliable and scalable react native app development for both Android and iOS platforms in single code base.</p>
          <a href="<?php echo $baseurl;?>hire-react-native-developer" class>See More <i class="fa fa-arrow-right"></i></a>
        </div> <!--box-->
      </li>
    </ul> <!--boxes-->
  </div> <!--container-->
</section> <!--products-->

<section class="half green white">
  <div class="bg bg1 left"></div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_right">
        <h2 class="head style1">We specialize in..</h2>
        <ul class="lists mb0">
          <li>Responsive web application development</li>
          <li>Innovative website designing</li>
          <li>Detailed search engine optimization</li>
          <li>Building of e-commerce platforms</li>
          <li>Developing mobile applications for various purposes and industries</li>
          <li>Optimizing websites to mobile internet</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<section>
	<div class="container md text-center">
    <h2 class="head style1">Need to develop? Hire us!</h2>
    <p>Boost your business to new levels at lower investments, by hiring our skilled line of developers. We give you the flexibility of hiring our resources on a monthly, weekly or hourly basis in accordance with your needs. The teams at our company deliver to the end-use innovative experiences on various platforms across diverse industrial spheres.</p>
    <p>The skilled and highly qualified developers will assist you to devise profitable strategies that cater to your business needs. The company offers services to a wide dimension of industries, always exceeding the expectations of clients placing their trust on us. Connect directly to our teams and interact with them as you would with your in-house team.</p>
    <a href="<?php echo $baseurl;?>portfolio" class="btn mt10">View portfolio</a>        
  </div> <!--container-->
</section>

<section class="half dark white">
  <div class="bg bg2 video right">
    <a on="tap:video"><i class="fa fa-play"></i></a>
  </div>

	<div class="container">
    <div class="row">
      <div class="col_6 pull_left">
        <h2 class="head style1">Why hire us?</h2>
        <ul class="lists mb0">
          <li>Highly skilled and experienced developers</li>
          <li>Direct interaction with clients to give personalized approach to all projects</li>
          <li>Our developers are in sync with the latest trends and technological advancements</li>
          <li>Constant updating of relevant features</li>
          <li>Use of latest technology and programming software</li>
          <li>Continuous engagement with all clients</li>
        </ul>
      </div>
    </div>
  </div> <!--container-->
</section>

<amp-lightbox id="video" layout="nodisplay">
	<div class="dialog_main">
		<div class="dialog_inner md">
			<div class="dialog_content">
				<a on="tap:video.close" class="close"><i class="fi close"></i></a>
        <amp-vimeo data-videoid="122301077" layout="responsive" width="480" height="270"></amp-vimeo>
			</div> <!--dialog_content-->
		</div> <!--dialog_inner-->   
	</div> <!--dialog_main--> 
</amp-lightbox>

<?php include ('inc/footer.php'); ?>