<section class="forms-bottom">
<div class="container">

<h3>How can I set up Facebook ordering for my restaurant? </h3>
<p class="subs">Integrating Ontabee Facebook ordering to your restaurant can skyrocket your success. </p>


<form id="facebookordering" method="post" name="facebookordering" action="/mail/facebook-ordering.php">
<div class="row">
<div class="col-md-6">
<p>Name <span class="fa fa-circle"></span></p>
<input type="text" name="fa_name" id="fa_name" required="required" placeholder="Enter Your Name">
</div>

<div class="col-md-6">
<p>Email Id <span class="fa fa-circle"></span></p>
<input type="email" name="fa_email" id="fa_email" required="required" placeholder="Enter Your Email id">
</div>
</div>


<div class="row">
<div class="col-md-6">
<p>Phone Number <span class="fa fa-circle"></span></p>
<input type="tel" name="fa_tel" id="fa_tel" required="required" placeholder="Enter Your Phone Number">

<input type="hidden" name="fa_country" id="fa_country" value="">
<input type="hidden" name="fa_dial" id="fa_dial" value="">
<input type="hidden" name="fa_url" id="fa_url" value="">
<input type="hidden" name="for_name" id="for_name" value="">

</div>

<div class="col-md-6">
<p>Restaurant Name  <span class="fa fa-circle"></span></p>
<input type="text" name="fa_rn" id="fa_rn" required="required" placeholder="Enter Restaurant Name">
</div>
</div>


<div class="row">
<div class="col-md-6">
<div id="captchas">
<div class="g-recaptcha" data-sitekey="6LfjoBoUAAAAALHCqdh56PhHZIDJoKndjug1dc7n"></div>
</div>
</div>
<div class="col-md-6">
<input type="submit" value="Submit">
</div>
</div>


</form>

</div>
</section>
