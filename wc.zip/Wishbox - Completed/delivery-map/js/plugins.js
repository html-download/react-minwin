document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.bundle.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap-select.min.js" ></scr'+'ipt>');
