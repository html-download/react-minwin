const React = require('react');
const ReactHelmet = require('react-helmet');
//const Config = require('../../../../config.js');

const Helmet = ReactHelmet.Helmet;

class HomePage extends React.Component {
    render() {

        return (
            <div className="content-wrapper">
                <Helmet>
                    <title>Welcome to AU Parking</title>
                </Helmet>
                <section className="content">
                    <div className="row dashboard">
                        <div className="col-xs-3">
                            <div className="box blue">
                                <i className="fa fa-paper-plane"></i>
                                <h5>Total Booking</h5>
                                <span>34,245</span>
                            </div>
                        </div> 
                        <div className="col-xs-3">
                            <div className="box grey">
                                <i className="fa fa-paper-plane"></i>
                                <h5>Total Vehicles</h5>
                                <span>34,245</span>
                            </div>
                        </div> 
                        <div className="col-xs-3">
                            <div className="box purple">
                                <i className="fa fa-paper-plane"></i>
                                <h5>Parked Vehicles</h5>
                                <span>34,245</span>
                            </div>
                        </div> 
                        <div className="col-xs-3">
                            <div className="box red">
                                <i className="fa fa-paper-plane"></i>
                                <h5>Reserved Vehicles</h5>
                                <span>34,245</span>
                            </div>
                        </div> 
                    </div>

                    <div className="clear"></div>

                    <div className="row new_data">
                        <div className="col-sm-6">
                            <div className="box">
                                <div className="box-header with-border">
                                    <h1 className="box-title">Today Sales - <span>Tuesday, April 24, 2018</span></h1>              
                                </div> 

                                <div className="box-body">
                                    <table className="table table-bordered table-striped">
                                        <tbody>
                                            <tr>
                                                <td>Total Vehicles</td>
                                                <td>100</td>
                                            </tr>
                                            <tr>
                                                <td>Total Sales</td>
                                                <td>80</td>
                                            </tr>
                                            <tr>
                                                <td>Pending Vehicles</td>
                                                <td>25</td>
                                            </tr>
                                            <tr>
                                                <td>Delivered Vehicles</td>
                                                <td>15</td>
                                            </tr>
                                            <tr>
                                                <td>Rejected Vehicles</td>
                                                <td>10</td>
                                            </tr>
                                        </tbody>
                                    </table>            
                                </div>
                            </div> 
                        </div> 

                        <div className="col-sm-6">
                            <div className="box">
                                <div className="box-header with-border">
                                    <h1 className="box-title">This Week - <span>Tuesday, April 24, 2018</span></h1>              
                                </div> 

                                <div className="box-body">
                                    <table className="table table-bordered table-striped">
                                        <tbody>
                                            <tr>
                                                <td>Total Vehicles</td>
                                                <td>100</td>
                                            </tr>
                                            <tr>
                                                <td>Total Sales</td>
                                                <td>80</td>
                                            </tr>
                                            <tr>
                                                <td>Pending Vehicles</td>
                                                <td>25</td>
                                            </tr>
                                            <tr>
                                                <td>Delivered Vehicles</td>
                                                <td>15</td>
                                            </tr>
                                            <tr>
                                                <td>Rejected Vehicles</td>
                                                <td>10</td>
                                            </tr>
                                        </tbody>
                                    </table>            
                                </div> 
                            </div> 
                        </div> 
                    </div>
                </section>
              </div>
            
        );
    }
}


module.exports = HomePage;
