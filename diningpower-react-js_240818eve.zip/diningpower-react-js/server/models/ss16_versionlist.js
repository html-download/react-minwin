/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Versionlist', {
    versionId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'version_id'
    },
    versionName: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'version_name'
    }
  }, {
    tableName: 'ss16_versionlist'
  });
};
