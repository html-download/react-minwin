/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Admin', {
    id: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    roleId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'role_id'
    },
    firstName: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'first_name'
    },
    lastName: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'last_name'
    },
    adminName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'admin_name'
    },
    adminEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'admin_email'
    },
    adminPassword: {
      type: DataTypes.STRING(128),
      allowNull: false,
      defaultValue: '',
      field: 'admin_password'
    },
    adminStatus: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'admin_status'
    },
    address: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'address'
    },
    phone: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'phone'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    adminLastLogin: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'admin_last_login'
    },
    accountBalance: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'account_balance'
    }
  }, {
    tableName: 'ss16_admin'
  });
};
