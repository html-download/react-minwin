<?php $title = 'On-demand delivery software development with latest Tools &amp; technologies' ?>
<?php $description = 'Onlinedeliverysoftware.com uses latest tools and technology to develop an on-demand food delivery software for the restaurant. We provide the app on both the web and mobile platform.' ?>
<?php $keywords = 'On-demand delivery tracking software, on-demand delivery tracking system, transport tracking software, logistics delivery system' ?>


<?php include ("header.php")?>

<section class="thankyou text-center">
<div class="container">

<i class="fa fa-check"></i>
<h2>Thank you!</h2>

<p>We have received your information successfully. We will get back to you shortly.</p>

<a href="/">Back To Home</a>

</div>
</section>



<?php include ("footer.php")?>