/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorOutlet', {
    outletId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'outlet_id'
    },
    vendorId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      field: 'vendor_id'
    },
    outletKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'outlet_key'
    },
    outletName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'outlet_name'
    },
    outletContactAddress: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'outlet_contact_address'
    },
    outletContactName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'outlet_contact_name'
    },
    outletConatctNumber: {
      type: DataTypes.STRING(256),
      allowNull: false,
      field: 'outlet_conatct_number'
    },
    outletEmergencyContactNumber: {
      type: DataTypes.STRING(256),
      allowNull: false,
      field: 'outlet_emergency_contact_number'
    },
    outletContactEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'outlet_contact_email'
    },
    outletCity: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'outlet_city'
    },
    outletArea: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'outlet_area'
    },
    outletLatitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'outlet_latitude'
    },
    outletLongitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'outlet_longitude'
    },
    outletStatus: {
      type: DataTypes.ENUM('Active','Deactive','Deleted'),
      allowNull: false,
      field: 'outlet_status'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_vendor_outlet'
  });
};
