<?php include ('inc/header.php'); ?>

<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Tools and Technology</h1>
		<h2 class="head small wow fadeInUp">Build & manage your online food ordering software for free</h2>
	</div> <!--container-->
</div> <!--page_banner-->

<section class="grey text-center technology">	
	<div class="container">
		<h2 class="head wow fadeInUp">Application and Data</h2>
		<ul class="reset technology">
			<li>
				<div class="content">
					<i class="html"></i>
					<span class="title">HTML5</span>
					<span>Languages</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="css"></i>
					<span class="title">CSS3</span>
					<span>Languages</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="bootstrap"></i>
					<span class="title">Bootstrap</span>
					<span>Front-End Framework</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="jquery"></i>
					<span class="title">jQuery</span>
					<span>UI Libraries</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="js"></i>
					<span class="title">JavaScript</span>
					<span>Languages</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="php"></i>
					<span class="title">PHP</span>
					<span>Languages</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="yii"></i>
					<span class="title">Yii2 Framework</span>
					<span>Framework</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="node"></i>
					<span class="title">Node.js</span>
					<span>Framework (Full Stack)</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="sql"></i>
					<span class="title">MySQL</span>
					<span>Database</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="redis"></i>
					<span class="title">Redis</span>
					<span>In-memory Databases</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="amazon"></i>
					<span class="title">Amazon EC2</span>
					<span>Cloud Hosting</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="java"></i>
					<span class="title">Java</span>
					<span>Languages</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="ios"></i>
					<span class="title">Objective-C</span>
					<span>Languages</span>
				</div>
			</li>
		</ul>
		
		<h2 class="head wow fadeInUp">Utilities</h2>
		<ul class="reset technology">
			<li>
				<div class="content">
					<i class="analytics"></i>
					<span class="title">Google Analytics</span>
					<span>General Analytics</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="maps"></i>
					<span class="title">Google Maps</span>
					<span>Mapping APIs</span>
				</div>
			</li>
		</ul>
		
		<h2 class="head wow fadeInUp">DevOps</h2>
		<ul class="reset technology style1">
			<li>
				<div class="content">
					<i class="bitBucket"></i>
					<span class="title">BitBucket</span>
					<span>Code collaboration & Version Control</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="android"></i>
					<span class="title">Android Studio</span>
					<span>Integrated Development Environment</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="xcode"></i>
					<span class="title">Xcode</span>
					<span>Integrated Development Environment</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="jenkins"></i>
					<span class="title">Jenkins</span>
					<span>Continuous Integration</span>
				</div>
			</li>
			<li>
				<div class="content">
					<i class="capistrano"></i>
					<span class="title">Capistrano</span>
					<span>Server Configuration & Automation</span>
				</div>
			</li>
		</ul>
		
		<h2 class="head wow fadeInUp">Business Tools</h2>
		<ul class="reset technology mb0">
			<li>
				<div class="content">
					<i class="apps"></i>
					<span class="title">Google Apps</span>
					<span>Productivity Suite</span>
				</div>
			</li>
		</ul>
	</div> <!--container-->
</section> <!--section-->

<?php include('inc/footer.php');?>