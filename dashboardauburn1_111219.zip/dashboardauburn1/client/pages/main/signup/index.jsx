import { GoogleLogin } from 'react-google-login';
import FacebookLogin from 'react-facebook-login';
const Actions = require('./actions');
const Form = require('./form.jsx');
const React = require('react');
const ReactRouter = require('react-router-dom');
const ReactHelmet = require('react-helmet');
const UserIdentity = require('../../../helpers/user-identity');

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;
const Redirect = ReactRouter.Redirect;

class SignupPage extends React.Component {
    constructor(props) {
        super(props);
        this.handleModalClick = this.handleModalClick.bind(this);
    }
    responseFacebook (fbUser) {
console.log("fbUser", fbUser);
        //anything else you want to do(save to localStorage)...
    }
    responseGoogle (googleUser) {
        var id_token = googleUser.getAuthResponse().id_token;
        var googleId = googleUser.getId();
        var profile = googleUser.getBasicProfile();
        
        Actions.googlelogin({
            email: profile.getEmail(),
            name: profile.getGivenName(),
            last_name: profile.getFamilyName(),
            google_id: googleId,
            token: id_token
        });
        //anything else you want to do(save to localStorage)...
    }
    handleModalClick(event) {
        /*console.log("1", 1);
        var googleId = '100581757152729652650';
        var id_token = 'eyJhbGciOiJSUzI1NiIsImtpZCI6ImI4NjNiNTM0MDY5YmZjMD…clx0w8tBDschmoXS1H1EU23ViqGTqQmKD6N2RyyL8lxxecB5Q';
        var profile =  { 
            email : "senthilkumar.t@technoduce.com",
            familyName : "T",
            givenName : "Senthilkumar",
            googleId : "100581757152729652650",
            imageUrl : "https://lh6.googleusercontent.com/-Q24DKb8nbEk/AAAAAAAAAAI/AAAAAAAAAAs/c89QjFJUE2M/s96-c/photo.jpg",
            name : "Senthilkumar T"
        }
        Actions.googlelogin({
            email: profile.email,
            name: profile.givenName,
            last_name: profile.familyName,
            google_id: googleId,
            token: id_token,
        });*/
        
        //event.preventDefault();
        //event.stopPropagation();
    }
    render() {
        if (UserIdentity._checkUserIdentity()) {
            return <Redirect to='/' push />;
        }
        return (
            <section className="login-register">
                <Helmet>
                    <title>Signup</title>
                </Helmet>
                <div className="container">
                    <div className="login-left equal">
                        <div className="login-img">
                        <img src="/public/media/images/login.png" alt="Forget Password" onClick={this.handleModalClick} />
                        </div>
                    </div>
                    <div className="login-right equal">
                        <div className="custom-modal">
                                <div className="modal-dialog">
                                    <div className="modal-content">
                                        <div className="modal-header">
                                            <button type="button" className="close hide" data-dismiss="modal">&times;</button>
                                            <h4 className="modal-title">Create an Account</h4>
                                            <h4 className="sub-title">Have a Dining Power account? 
                                                <Link to="/login"> Sign in</Link>
                                            </h4>

                                            <div className="social_login">
                                                Sign up with 
                                                <FacebookLogin
                                                textButton="Facebook"
                                                cssClass="my-facebook-button-class"
                                                appId="459650901161146"
                                                autoLoad={true}
                                                //fields="name,email,picture"
                                                //onClick={this.responseGoogle}
                                                callback={this.responseFacebook} />
                                                 or 
                                                <GoogleLogin
                                                    clientId="166146453561-ussorp9dv61ct1r3k0c0t5ti1bpskscc.apps.googleusercontent.com"
                                                    buttonText="Google"
                                                    onSuccess={this.responseGoogle}
                                                    onFailure={this.responseGoogle}
                                                    className="google-login"
                                                    scope="profile"
                                                    prompt="select_account"
                                                    />
                                                <span>or</span>
                                            </div>
                                        </div>
                                        <div className="modal-body">
                                            <Form />
                                        </div>
                                </div>
                                    
                                </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}


module.exports = SignupPage;
