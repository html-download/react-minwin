/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorCommunication', {
    communicationId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'communication_id'
    },
    vendorId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'vendor_id'
    },
    sendEmail: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'send_email'
    },
    sendFax: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'send_fax'
    },
    sendSms: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'send_sms'
    },
    notifyEmail: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'notify_email'
    },
    notifyEmailGroup: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'notify_email_group'
    },
    notifyTablet: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'notify_tablet'
    },
    orderConfirmation: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'order_confirmation'
    },
    autoVoice: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'auto_voice'
    },
    autoVoiceNumber: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'auto_voice_number'
    },
    delDpFaxingTemplate: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'del_dp_faxing_template'
    },
    delRFaxingTemplate: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'del_r_faxing_template'
    },
    pickupFaxingTemplate: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '0',
      field: 'pickup_faxing_template'
    },
    faxingTemplateNote: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'faxing_template_note'
    },
    reportEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'report_email'
    },
    reportNote: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'report_note'
    },
    noorderSend: {
      type: DataTypes.ENUM('yes','no'),
      allowNull: false,
      defaultValue: 'no',
      field: 'noorder_send'
    },
    sendDailySummary: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_daily_summary'
    },
    sendDailyPerformance: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_daily_performance'
    },
    sendDailyDelivery: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_daily_delivery'
    },
    sendDailyCalback: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_daily_calback'
    },
    sendWeeklySummary: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_weekly_summary'
    },
    sendWeeklyPerformance: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_weekly_performance'
    },
    sendWeeklyDelivery: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_weekly_delivery'
    },
    sendWeeklyCalback: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      defaultValue: '2',
      field: 'send_weekly_calback'
    },
    communicationNotes: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'communication_notes'
    }
  }, {
    tableName: 'ss16_vendor_communication'
  });
};
