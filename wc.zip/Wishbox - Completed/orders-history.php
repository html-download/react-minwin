<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- acc page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi clock2"></i>
            <h2>Orders History</h2>
            <p>View your Order Details, Status, Track Order, Reorder and Cancel Order</p>
          </div>
          <div class="white-30 my-orders">
            <ul class="reset">
              <li>
                <div class="boxed">
                  <a href="/details" class="img" style="background-image: url(assets/img/logo/1.jpg);"></a>
                  <a href="/details" class="title">Eat More</a>
                  <!-- order details -->
                  <div class="or-details">
                    <!-- div -->
                    <div>
                      Order ID
                      <span class="pinks">#000280441</span>
                    </div>
                    <div>
                      Order date
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                    <!-- div -->
                    <div>
                      amount
                      <span>QR 50</span>
                    </div>
                    <div>
                      Order Type
                      <span>Delivery</span>
                    </div>
                    <!-- div -->
                  </div>
                  <!-- order details -->
                  <div class="or-links">
                    <div><button class="btn white">Reorder</button>
                      <button data-target="#modal_orders" data-toggle="modal" class="btn white">View Order</button>
                    </div>
                    <div class="green text-bold">Delivered</div>
                  </div>
                </div>
              </li>
              <li>
                <div class="boxed">
                  <a href="/details" class="img" style="background-image: url(assets/img/logo/2.jpg);"></a>
                  <a href="/details" class="title">Pastamasta Taste food</a>
                  <!-- order details -->
                  <div class="or-details">
                    <!-- div -->
                    <div>
                      Order ID
                      <span class="pinks">#000280441</span>
                    </div>
                    <div>
                      Order date
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                    <!-- div -->
                    <div>
                      amount
                      <span>QR 50</span>
                    </div>
                    <div>
                      Order Type
                      <span>Delivery</span>
                    </div>
                    <!-- div -->
                  </div>
                  <!-- order details -->
                  <div class="or-links">
                    <div><button data-target="#track_orders" data-toggle="modal"  class="btn white pink-line">Track Order</button> <button data-target="#modal_orders" data-toggle="modal" class="btn white">View Order</button></div>
                    <div class="pink text-bold">On Way</div>
                  </div>
                </div>
              </li>
              <li>
                <div class="boxed">
                  <a href="/details" class="img" style="background-image: url(assets/img/logo/3.jpg);"></a>
                  <a href="/details" class="title">Hot Pot Restaurants</a>
                  <!-- order details -->
                  <div class="or-details">
                    <!-- div -->
                    <div>
                      Order ID
                      <span class="pinks">#000280441</span>
                    </div>
                    <div>
                      Order date
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                    <!-- div -->
                    <div>
                      amount
                      <span>QR 50</span>
                    </div>
                    <div>
                      Order Type
                      <span>Delivery</span>
                    </div>
                    <!-- div -->
                  </div>
                  <!-- order details -->
                  <div class="or-links">
                    <div><button data-target="#modal_orders" data-toggle="modal" class="btn white">View Order</button></div>
                    <div class="blue text-bold">Preparing</div>
                  </div>
                </div>
              </li>
              <li>
                <div class="boxed">
                  <a href="/details" class="img" style="background-image: url(assets/img/logo/4.jpg);"></a>
                  <a href="/details" class="title">Semeru Catering</a>
                  <!-- order details -->
                  <div class="or-details">
                    <!-- div -->
                    <div>
                      Order ID
                      <span class="pinks">#000280441</span>
                    </div>
                    <div>
                      Order date
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                    <!-- div -->
                    <div>
                      amount
                      <span>QR 50</span>
                    </div>
                    <div>
                      Order Type
                      <span>Delivery</span>
                    </div>
                    <!-- div -->
                  </div>
                  <!-- order details -->
                  <div class="or-links">
                    <div><button data-target="#modal_orders" data-toggle="modal" class="btn white">View Order</button></div>
                    <div class="violet text-bold">Confirmed</div>
                  </div>
                </div>
              </li>
              <li>
                <div class="boxed">
                  <a href="/details" class="img" style="background-image: url(assets/img/logo/1.jpg);"></a>
                  <a href="/details" class="title">Eat More</a>
                  <!-- order details -->
                  <div class="or-details">
                    <!-- div -->
                    <div>
                      Order ID
                      <span class="pinks">#000280441</span>
                    </div>
                    <div>
                      Order date
                      <span>07/20/2019 11:10 AM</span>
                    </div>
                    <!-- div -->
                    <div>
                      amount
                      <span>QR 50</span>
                    </div>
                    <div>
                      Order Type
                      <span>Delivery</span>
                    </div>
                    <!-- div -->
                  </div>
                  <!-- order details -->
                  <div class="or-links">
                    <div><button data-target="#modal_orders" data-toggle="modal" class="btn white">View Order</button></div>
                    <div class="orange text-bold">Pending</div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <!-- acc page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<!-- modal orders -->
<div id="modal_orders" class="modal order_modal fade" role="dialog">
  <div class="modal-dialog mx-600">
    <div class="modal-content">
      <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>
      <div class="item_info">
        
        <div>
          <h3 class="mb5">Hot Pot Restaurants</h3>
          <div class="flex-space-between">
            <span class="price grey medium">QR 20</span>
            <span class="medium uppercase t-green">Delivered</span>
          </div>
        </div>
      </div>
      <!--item_info-->
      <div class="modal-body">
        <div class="order-list">
          <ul>
            <li>
              <div class="flex-box">
                <div>
                  <div class="content-title">
                    <h5 class="height" style="height: 20px;"><img src="assets/img/non-veg.svg">Super Spicy Sandwich</h5>
                  </div>
                </div>
                <div class="grey regular">
                  1 x QR 40
                </div>
              </div>
            </li>
              <li>
              <div class="flex-box">
                <div>
                  <div class="content-title">                    
                    <h5 class="height" style="height: 20px;"><img src="assets/img/non-veg.svg">Boneless Ginger Chicken</h5>
                  </div>
                </div>
                <div class="grey regular">
                  1 x QR 40
                </div>
              </div>
            </li>
            <li>
              <div class="flex-box">
                <div>
                  <div class="content-title">
                    <h5 class="height" style="height: 20px;"><img src="assets/img/non-veg.svg">Masala Chicken Tikka Wrap</h5>
                  </div>
                </div>
                <div class="grey regular">
                  1 x QR 40
                </div>
              </div>
            </li>

                <li>
              <div class="flex-box">
                <div>
                  <div class="content-title">                    
                    <h5 class="height" style="height: 20px;"><img src="assets/img/non-veg.svg">Executive Chicken Biryani</h5>
                  </div>
                </div>
                <div class="grey regular">
                  1 x QR 40
                </div>
              </div>
            </li>

          </ul>
        </div>
      </div>
      <!--modal-body-->

      <!-- bill details -->
      <div class="bill-content">
        <div>
        <p class="text-black medium">Bill Details</p>
        </div>
        <div>
                <p>Sub Total <span>QR 80</span></p>
                <p>Tax <span>QR 10</span></p>
                <p>Delivery Fee <span>QR 15</span></p>
                <p>Packaging Charge <span>QR 15</span></p>
                <p class="pink">Discount Value <b>(wishbox50)</b> <span>- QR 10</span></p>
                <p class="pink">Smile Points <span>- QR 15</span></p>
                <p class="total">Total Amount <span>- QR 15</span></p>
      </div>
      </div>

      <!-- bill details -->

      <!-- delivery address footer -->
      <div class="dl_address_footer">
        <h4>Delivery Details</h4>
        <p class="grey"><i class="fi calendar3"></i> 08/24/2019   07:30 AM</p>
        <p class="grey mb0"><i class="fi pin3"></i> Opposite Prestige Laundry, Al Mattar Al Qadeem 2nd Street, Old Airport Area, Doha.</p>
      </div>
      <!-- delivery address footer -->
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!--modal_choice-->
<!-- modal orders -->


<!-- track order -->
<div id="track_orders" class="modal track_order_modal fade" role="dialog">
  <div class="modal-dialog md">
    <div class="modal-content">
      <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>
      <div class="track_order_info">
        <div>
          <h3 class="mb5"><span class="t-pink">#000280440</span> - Hot Pot Restaurants</h3>
          <p class="medium mb0">Estimated Time <span class="t-pink">30 mins</span></p>
        </div>
        <div>
          <p class="mb0 grey medium">Driver: <span class="t-pink">John Peter, +98765432101</span></p>
        </div>
      </div>
      <!--item_info-->
      <!-- map -->
      <div id="map" class="cs-map"></div>
      <!-- map -->
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!-- track order -->


<?php include ('inc/footer.php'); ?>