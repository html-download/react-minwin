'use strict';
const Cookie = require('cookie');
const Config = require('../../config');
import axios from 'axios';

const cookies = Cookie.parse(document.cookie);

module.exports = {

    upload: function (url,data,store,request,response,callback) {
        
        store.dispatch({
            type: request
        });        
        axios.post(`${Config.get('/apiUrl')}${url}`, data, {
            headers: {
                Authorization: 'Bearer ' + cookies.token,
                Accept: 'application/json'
            }
            
        }).then(result => {                                    
            if(result.data.status === 200) {
                store.dispatch({
                    type: response,
                    response:result.data
                });
            }            
        }).catch(error => {
            console.log(error);
        });
    }

};