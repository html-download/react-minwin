<!DOCTYPE HTML>
<html lang="en-US">
<!--<![endif]-->

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta content="global" name="Distribution">
    <meta content="index, follow" name="Robots">
    <meta content="7 days" name="Revisit-after">

    <title><?php echo $title; ?></title>
<meta name="description" content="<?php echo $description; ?>" />
<meta name="keywords" content="<?php echo $keywords; ?>" />
<!-- title og -->
<meta name="og:title" content="<?php echo $title; ?>" />
<meta name="og:description" content="<?php echo $description; ?>" />


    <meta name="language" content="en" />
    <meta name="Expires" content="never" />
    <meta name="Distribution" content="Global" />
    <meta name="search engines" content="ALL" />
    <meta name="copyright" content="https://www.onlinedeliverysoftware.com/" />

    <link rel="prefetch" href="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
<!-- pre section end-->

<meta property="og:url" content="<?php echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />

    <meta name="theme-color" content="#e06857" />

    <!-- stylesheet -->
    <link href="https://fonts.go.com/css?family=Source+Sans+Pro" rel="stylesheet">

    <link rel="icon" href="img/favicon.png" type="image/png">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/animate.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">


    <!-- scripts -->
    <script src="js/jquery-2.1.4.min.js">
    </script>

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-KBXRN68');
    </script>
    <!-- End Google Tag Manager -->
</head>

<body class="<?=basename($_SERVER['PHP_SELF'],'.php')?>-page">
    <div class="contentInner" id="pagewrap">
        <div class="containersin show">
            <!-- header -->
            <header class="headerSection">
                <div class="container">
                    <div class="row">
                        <div class="col-md-2">
                            <a href="/"><img alt="Online Delivery Software" src="img/logo.png">
                            </a>
                            <a href="javascript:void(0)" class="resMenu"><i class="fa fa-bars"></i></a>
                        </div>
                        <div class="col-md-10">

                                 <ul id="menu-main-menu" class="navigator">
                                    <li <?php if (basename($_SERVER['PHP_SELF']) == 'delivery-management-system-features.php') echo 'class="active"' ?>><a href="/delivery-management-system-features">Features</a></li>
                                    <li <?php if (basename($_SERVER['PHP_SELF']) == 'delivery-software-tools-technologies.php') echo 'class="active"' ?> ><a href="/delivery-software-tools-technologies">Technology</a></li>
                                    <li <?php if (basename($_SERVER['PHP_SELF']) == 'delivery-app-portfolio.php') echo 'class="active"' ?>><a href="/delivery-app-portfolio">Portfolio</a></li>
                                    <li <?php if (basename($_SERVER['PHP_SELF']) == 'about-us.php') echo 'class="active"' ?>><a href="/about-us">About us</a></li>
                                    <li <?php if (basename($_SERVER['PHP_SELF']) == 'contact-us.php') echo 'class="active"' ?>><a href="/contact-us">Contact us</a></li>
                                    <li class="requestDemo"><a href="#">Try Live Demo</a></li>
                                </ul>

                        </div>
                    </div>
                </div>
            </header>
            <!-- header -->