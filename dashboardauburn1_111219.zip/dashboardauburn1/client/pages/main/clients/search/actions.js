/* global window */
'use strict';
const ApiActions = require('../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Qs = require('qs');
const ToasterContainer = require('../../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const UserIdentity = require('../../../../helpers/user-identity');

const apiUrl = UserIdentity.apiUrl;


class Actions {
    static getResults(data) {

        ApiActions.get(
            `${apiUrl}/client_list`,
            data,
            Store,
            Constants.GET_RESULTS,
            Constants.GET_RESULTS_RESPONSE
        );
    }

    static changeSearchQuery(data, history) {

        history.push({
            pathname: '/admin/accounts',
            search: `?${Qs.stringify(data)}`
        });

        window.scrollTo(0, 0);
    }

    static showCreateNew() {

        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW
        });
    }

    static hideCreateNew() {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }

    static showUpdate() {

        Store.dispatch({
            type: Constants.SHOW_UPDATE
        });
    }

    static hideUpdate() {

        Store.dispatch({
            type: Constants.HIDE_UPDATE
        });
    }
    static createNew(data, history) {

        ApiActions.post(
            `${apiUrl}/client`,
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {

                if (!err) {
                    this.hideCreateNew();

                    const path = `/clients`;

                    history.push(path);

                    window.scrollTo(0, 0);
                }
            }
        );
    }
    static statusUpdate(data, msg) {

        ApiActions.put(
            `${apiUrl}/client`,
            data,
            Store,
            Constants.UPDATE_CLIENT_STATUS,
            Constants.UPDATE_CLIENT_STATUS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (data.active_flag) {
                        Toaster.success(msg);
                    } else {
                        Toaster.error(msg);
                    }
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
    static delete(data, history) {

        ApiActions.delete(
            `${apiUrl}/client`,
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {

                if (!err) {
                    
                    Toaster.success('Client deleted successfully!');
                    const path = `/clients`;

                    history.push(path);

                    window.scrollTo(0, 0);
                }
            }
        );
    }
}


module.exports = Actions;
