'use strict';
const ClassNames = require('classnames');
const ControlGroup = require('./control-group.jsx');
const DateHelper = require('../../helpers/date-time.js');
const ObjectAssign = require('object-assign');
const PropTypes = require('prop-types');
const React = require('react');
const renderHTML = require('react-render-html');
import DatePicker from "react-datepicker";


const propTypes = {
    autoCapitalize: PropTypes.string,
    disabled: PropTypes.bool,
    hasError: PropTypes.bool,
    help: PropTypes.string,
    inputClasses: PropTypes.object,
    groupClasses: PropTypes.object,
    labelClasses: PropTypes.object,
    label: PropTypes.string,
    hideLabel: PropTypes.bool,
    labelFor: PropTypes.string,
    labelPositionBottom: PropTypes.bool,
    name: PropTypes.string,
    id: PropTypes.string,
    onChange: PropTypes.func,
    placeholder: PropTypes.string,
    type: PropTypes.string,
    defaultChecked: PropTypes.bool,
    isDatePicker: PropTypes.bool,
    dateFormat: PropTypes.string,
    isTimePicker: PropTypes.bool,    
    timeFormat: PropTypes.string,
    minutesInterval: PropTypes.number,
    checked: PropTypes.bool,
    value: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    defaultValue: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number
    ]),
    prependElement : PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    prependElementNotString : PropTypes.bool,
    appendElement: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.object
    ]),
    appendElementNotString : PropTypes.bool,
    isKeyEnable: PropTypes.bool,
};
const defaultProps = {
    type: 'text',
    autoCapitalize: 'off'
};

class TextControl extends React.Component {
    constructor(props){
        super(props);
        
        this.state = {
          type: this.props.type,
          startDate: new Date()
        }

        this.handleChange = this.handleChange.bind(this);
        this.showHide = this.showHide.bind(this);
    }

    focus() {

        return this.input.focus();
    }

    value() {

        if(this.props.type === 'file') {
            alert("test");
        }
        return this.input.value;
    }

    setValue(value) {
        this.input.value = value;
        return true;
    }

    showHide(e){
        e.preventDefault();
        e.stopPropagation();
        
        this.setState(ObjectAssign(this.state, {
            type: this.state.type === 'input' ? 'password' : 'input'
        }));
    }

    handleChange(date) {
        
        if(this.props.isDatePicker) {
            var format = "DD MMMM, YYYY";
            if(this.props.dateFormat) {
                format = this.props.dateFormat;
            }            
        } else if(this.props.isTimePicker) {
            var format = "hh:mm a";
            if(this.props.timeFormat) {
                format = this.props.timeFormat;
            }
        }

        this.setState({
          startDate: date
        });
        
        date = (date !== '') ? DateHelper._changeFormat(date,format): '';
        
        this.props.onChange ? this.props.onChange(date) : null;
    }
    render() {
        
        const inputClasses = ClassNames(ObjectAssign({
            'form-control': true
        }, this.props.inputClasses));

        const passwordClass = ClassNames({
          'btn': true
        });

        let passwordViewer;
        if (this.props.type === 'password') {
            passwordViewer = <button type="button" style={{'zIndex' : 9999}} className={passwordClass} data-toggle={this.props.id} onClick={this.showHide}>
                {this.state.type === 'input' ? <i className="fa fa-eye-slash"></i> : <i className="fa fa-eye"></i>}
            </button>;
        }

        return (
            <ControlGroup
                hasError={this.props.hasError}
                label={this.props.label}
                hideLabel={this.props.hideLabel}
                groupClasses={this.props.groupClasses}
                labelClasses={this.props.labelClasses}
                labelFor={this.props.id}
                labelPositionBottom={this.props.labelPositionBottom}
                help={this.props.help}>

                <div className="side-input right-side">
                    {(this.props.prependElement && this.props.prependElementNotString) ? (this.props.prependElement) : ''}
                    {(this.props.prependElement && !this.props.prependElementNotString) ? (renderHTML(this.props.prependElement)) : ''}
                    {
                        this.props.isDatePicker ? (                               
                                
                                <DatePicker
                                    ref={(c) => (this.input = c)}
                                    key={ this.props.isKeyEnable ? `${Math.floor((Math.random() * 1000))}-${this.props.name}` : ""}
                                    selected={this.state.startDate}
                                    onChange={ this.handleChange}
                                    className={inputClasses}
                                    selected={this.props.defaultValue}
                                    dateFormat={ (this.props.dateFormat) ? this.props.dateFormat : "d MMMM, yyyy" }
                                    name={this.props.name}
                                    id={this.props.id}
                                    disabled={this.props.disabled ? 'disabled' : undefined}
                                    showYearDropdown
                                    dateFormatCalendar="MMMM"
                                    scrollableYearDropdown
                                    yearDropdownItemNumber={40}
                                    maxDate={ this.props.maxDate ? this.props.maxDate : null }
                                    minDate={ this.props.minDate ? this.props.minDate : null }
                                />                                
                                
                            ) : this.props.isTimePicker ? (
                                
                                <DatePicker
                                    ref={(c) => (this.input = c)}
                                    key={ this.props.isKeyEnable ? `${Math.floor((Math.random() * 1000))}-${this.props.name}` : ""}
                                    selected={this.state.startDate}
                                    timeInputLabel="Time:"
                                    onChange={this.handleChange}
                                    showTimeSelect                                    
                                    showTimeSelectOnly
                                    timeIntervals={15}
                                    dateFormat={ (this.props.timeFormat) ? this.props.timeFormat : "hh:mm aa" }
                                    timeCaption="Time"
                                    timeIntervals={ (this.props.minutesInterval) ? this.props.minutesInterval : 30 }
                                    className={this.props.inputClasses}
                                />
                            ) : (
                                <input
                                    ref={(c) => (this.input = c)}
                                    key={ this.props.isKeyEnable ? `${Math.floor((Math.random() * 1000))}-${this.props.name}` : ""}
                                    type={this.state.type}
                                    autoCapitalize={this.props.autoCapitalize}
                                    className={inputClasses}
                                    name={this.props.name}
                                    id={this.props.id}
                                    placeholder={this.props.placeholder}
                                    value={this.props.value}
                                    defaultValue={this.props.defaultValue}
                                    disabled={this.props.disabled ? 'disabled' : undefined}
                                    onChange={this.props.onChange}
                                    checked={this.props.checked}
                                    defaultChecked={this.props.defaultChecked}
                                />
                            )
                    }
                    
                    {(this.props.appendElement && this.props.appendElementNotString) ? (this.props.appendElement) : ''}
                    {(this.props.appendElement && !this.props.appendElementNotString) ? (renderHTML(this.props.appendElement)) : ''}
                </div>

                {passwordViewer}
            </ControlGroup>
        );
    }
}

TextControl.propTypes = propTypes;
TextControl.defaultProps = defaultProps;


module.exports = TextControl;
