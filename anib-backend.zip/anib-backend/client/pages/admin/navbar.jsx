"use strict";
const PropTypes = require("prop-types");
const React = require("react");
const ReactRouter = require("react-router-dom");
const ClassNames = require("classnames");
import { Dropdown, DropdownMenu, DropdownToggle } from "reactstrap";

const Link = ReactRouter.Link;
const propTypes = {
  location: PropTypes.object
};

class Navbar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      navBarOpen: false,
      dropdownOpen: false
    };
    this.toggle = this.toggle.bind(this);
  }

  componentWillReceiveProps() {
    this.setState({ navBarOpen: false });
  }

  classForPath(pathPattern) {
    return ClassNames({
      active: this.props.location.pathname.match(pathPattern)
    });
  }

  toggleMenu() {
    this.setState({ navBarOpen: !this.state.navBarOpen });
  }

  toggle() {
    this.setState(prevState => ({
      dropdownOpen: !prevState.dropdownOpen
    }));
  }

  render() {
    const navBarCollapse = ClassNames({
      "navbar-collapse": true,
      collapse: !this.state.navBarOpen
    });

    return (
      <header className="header">
        <div className="container-fluid">
          <div className="logo">
            <Link to="/admin/deals">
              <img src="/public/media/images/logo.png" align="logo" />{" "}
            </Link>
          </div>

          <div className="navigation">
            <ul className="reset">
              <li>
                <Link
                  to="/admin/deals"
                  className={this.classForPath(/^\/admin\/deals/)}
                >
                  <i className="icon-layers" /> Enquiry
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/customers"
                  className={this.classForPath(/^\/admin\/customers/)}
                >
                  <i className="icon-people" /> Customers
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/tasks"
                  className={this.classForPath(/^\/admin\/tasks/)}
                >
                  <i className="icon-target" /> Tasks
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/policies"
                  className={this.classForPath(/^\/admin\/policies/)}
                >
                  <i className="icon-support" /> Policies
                </Link>
              </li>
              <li>
                <Link
                  to="/admin/users"
                  className={this.classForPath(/^\/admin\/users/)}
                >
                  <i className="icon-user" /> Users
                </Link>
              </li>  
              <li>
                <Link
                  to="/admin/roles"
                  className={this.classForPath(/^\/admin\/roles/)}
                >
                  <i className="icon-users" /> Roles
                </Link>
              </li>             
            </ul>
          </div>
          <div className="user-profile">
            <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
              <DropdownToggle
                caret
                className="dropdown-toggle-admin"
                tag="button"
              >
                <span>
                  <img src="/public/media/images/profile_av.jpg" />
                </span>
                Super Admin
              </DropdownToggle>
              <DropdownMenu>
                <div className="user-header">
                  <p>
                    <img src="/public/media/images/profile_av.jpg" />{" "}
                    <span className="name"> Super Admin</span>{" "}
                    <span className="role">Admin</span>{" "}
                  </p>
                </div>
                <Link
                  className="dropdown-item"
                  onClick={this.toggle}
                  to="/admin/account-setting"
                >
                  <i className="icon-user" /> Account Settings
                </Link>
                <Link
                  className="dropdown-item"
                  onClick={this.toggle}
                  to="/admin/email-setting"
                >
                  <i className="icon-envelope-open" /> Email Settings
                </Link>
                <a
                  href="/login/logout"
                  onClick={this.toggle}
                  className={"dropdown-item"}
                >
                  <i className="icon-logout" />Logout{" "}
                </a>
              </DropdownMenu>
            </Dropdown>
          </div>
        </div>
      </header>
    );
  }
}

Navbar.propTypes = propTypes;

module.exports = Navbar;
