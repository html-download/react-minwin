<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

## Disable Editing in Dashboard
define('DISALLOW_FILE_EDIT', true);

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
//define('DB_NAME', 'ontabee');
define('DB_NAME', 'ontaeeb_blog');

/** MySQL database username */
//define('DB_USER', 'root');
define('DB_USER', 'ontaeeb_bloug');

/** MySQL database password */
//define('DB_PASSWORD', '');
define('DB_PASSWORD', 'ScflRIcJzsWxIS8X');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '#^RJ/z|1yN.?(p8!{5!zIk-gGl>.E4I45xLKNayXwJ*RkuGv @!{}gH9LM,btlcf');
define('SECURE_AUTH_KEY',  '~Z*y>O7T@v|rN_biXYf%9(:)ex>Q$)[30$6o&O@!Q7SJB}V-]//]k bcL4R%]g1C');
define('LOGGED_IN_KEY',    'olX4p: v&l@!LZvCqr:`}IJ((-Z/}tR]I<ZiSM>qwX[lH1d;i-1SD&L0xl/u%t2*');
define('NONCE_KEY',        'w~4dqS]!$C-PLtSr/}R<P*hoc44aCtnG&T#io+S4Fly5o%ka=j)c7n2%BYbM(oa~');
define('AUTH_SALT',        'l}a^ eQkP<U)L`t-d]0cCM(y_X_adrJ^uv][^!blt5.Vl=hm.a&-!Lk2JYZ^D`qX');
define('SECURE_AUTH_SALT', 'w}TRyW4~<V)LX.(t=7GR8T9Q_E7WNqj}6Fv9a:KT:G/C<d$t=$9c2w{NSs[HtC1P');
define('LOGGED_IN_SALT',   ')!KE]bJ:>YXiw6h@?K$]R=OwNkvnJ:A3@p1D>1>;Al6F/O9JaO`?an]V*D}$mDII');
define('NONCE_SALT',       'g6Vb.v^bB)m-?b< NBanVxh]J6M2*O(C?M*ZfSi#9`,s`KE?v0aBskubnQUV$y G');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'bee_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
