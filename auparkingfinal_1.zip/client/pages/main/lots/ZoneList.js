import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import Toggle from 'react-toggle';
const ReactHelmet = require('react-helmet');
const UserIdentity = require('../../../helpers/user-identity');

import Map from './Map';
const Helmet = ReactHelmet.Helmet;

class ZoneList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            zones: [],
            'showSideNav': false,
            'apiKey': {'key': UserIdentity.googleApiKey},
            'center': {
                'lat': 32.593357,
                'lng': -85.495163
            },
            'zoom': 17,
            'mapHeight': 0,
            'mapWidth': 0,
            'markers': [],
            'isOpen' : false,
            overlay_coords_ne : "",
            overlay_coords_sw : "",
            isOverlayLoaded: false,
        }
        this.params = {
            fopark_url: UserIdentity.apiUrl,
            fopark_key: UserIdentity._checkUserToken()
        };
        this.handleToggle = this.handleToggle.bind(this);
        this.toggleNav = this.toggleNav.bind(this);
        this.updateMapBounds = this.updateMapBounds.bind(this);
        this.editMapBounds = this.editMapBounds.bind(this);
        this.updateMapCenter = this.updateMapCenter.bind(this);
        this.setMarkers = this.setMarkers.bind(this);
    }
    handleToggle(event){
        localStorage.setItem(`${event.target.name}_selected`, event.target.checked);
    }
    toggleNav() {
        this.setState({'showSideNav': !this.state.showSideNav})
    }

    updateMapCenter(center, zoom) {
        this.setState({center: null, zoom: null});
        this.setState({center: center, zoom: zoom});

    }

    updateMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    editMapBounds(ne, sw) {
        const bounds = {ne, sw};
        const size = {'width': this.state.mapWidth, 'height': this.state.mapHeight};
        const {center, zoom} = fitBounds(bounds, size);
        this.updateMapCenter(center, zoom);
    }

    setMarkers(markers) {
        this.setState({'markers': markers});
    }

    componentDidMount() {
        fetch(`${this.params.fopark_url}/client/zones?name=auburn`, {
            'headers': new Headers({
                'X-api-key': this.params.fopark_key
            })
        })
            .then(response => response.json())
            .then(
                (result) => {
                    const zones = Object.keys(result.zones).map( (zone) => {
                        const returnZone = result.zones[zone];
                        returnZone.selected = localStorage.getItem(`${result.zones[zone]['name']}_selected`);
                        if(typeof returnZone.selected === 'string'){
                            if(returnZone.selected === 'false'){
                                returnZone.selected = false;
                            }
                            if(returnZone.selected){
                                returnZone.selected = true;
                            }
                        }
                        if(returnZone.selected === null){
                            returnZone.selected = true;
                        }
                        switch(result.zones[zone]['name']){
                            case 'a':
                                returnZone.color = 'rgb(232, 228, 2)';
                                break;
                            case 'b':
                                returnZone.color = 'rgb(69, 255, 25)';
                                break;
                            case 'c':
                                returnZone.color = 'rgb(1, 34, 112)';
                                break;
                            case 'ada':
                                returnZone.color = 'rgb(18, 90, 214)';
                                break;
                            default:
                                returnZone.color = 'rgb(211, 170, 23)';
                                break;
                        }
                        return returnZone;
                    });
                    this.setState({
                        isLoaded: true,
                        zones: zones
                    });
                },
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            );
        this.setState({'mapHeight': window.innerHeight, 'mapWidth': window.innerWidth});
        if (this.state.center && this.state.zoom) {
            this.updateMapCenter(this.state.center, this.state.zoom);
        }
    }

    render() {
        const { error, isLoaded, zones } = this.state;

        if(error) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Error: {error.message}</h6></div>;
        } else if(!isLoaded) {
            return <div className="my-3 p-3 bg-white rounded box-shadow"><h6>Loading...</h6></div>
        } else {
            return (
                <div className="content-wrapper zone-wrap" id="sel_zones">
                    <Helmet>
                        <title>Zones</title>
                    </Helmet>
                    {/*<Map
                            markers={this.state.markers}
                            center={this.state.center}
                            zoom={this.state.zoom}
                            {...this.state}
                        /> */}
                        
                    <section className="content">
                        
                        <div className="my-3 bg-white rounded">
                         <h4 className="border-bottom pb8 border-gray pb-2 mb-0 text-center">
                              Select Zones
                            </h4>
                        <div id="lotlink">
                           
                            <p>Unless noted with in a lot, all zones other than accessible are open to the public after 5pm.</p>
                            <div className="media-outer zone-content">
                            { Object.keys(zones).map( (zone) => {
                                return (
                                    
                                        <div className="media text-muted pt-3" key={zones[zone]['id']}>
                                            <div className="media-body">
                                                <label className="d-flex justify-content-between align-items-center w-100">
                                                    <strong className="text-gray-dark"
                                                     style={{'color': zones[zone].color}}>
                                                     <h6>{zones[zone]['name'].toUpperCase()}</h6>
                                                     </strong>
                                                    <Toggle
                                                        defaultChecked={this.state.zones[zone].selected}
                                                        icons={false}
                                                        onChange={this.handleToggle}
                                                        name={zones[zone]['name']}
                                                    />
                                                </label>
                                            </div>
                                        </div>
                                    
                            )})}
                            </div>
                            </div>
                            <div style={{
                                textAlign: 'right'
                            }}>
                                <button type="button" className="btn btn-primary" onClick={this.props.history.goBack}>Save</button>
                            </div>

                            
                        </div>
                        
                    </section>
                </div>
            );
        }
    }
}

module.exports = ZoneList;