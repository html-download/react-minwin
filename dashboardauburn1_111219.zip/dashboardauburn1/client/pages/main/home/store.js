import {fitBounds} from 'google-map-react/utils';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');
const UserIdentity = require('../../../helpers/user-identity');
const moment = require('moment-timezone');
const Config = require('../../../../config.js');

const initialState = {
    loading: false,
    first_time_loaded: false,
    success: false,
    error: undefined,
    lots : [],
    hasError: {},
    help: {},
    'showSideNav': false,
    'apiKey': {'key': UserIdentity.googleApiKey},
    'center': {
        'lat': 32.593357,
        'lng': -85.495163
    },
    'zoom': 17,
    'mapHeight': 0,
    'mapWidth': 0,
    'markers': [],
    'isOpen' : false,
    isLoaded: false,
    lot: {},
    available: 0,
    occupied: 0,
    noData: 0,
    reserved: 0,
    hybrid_flag : 1,
    lot_name : '',
    client_name : '',
    unavailable : 1,
    show_message_modal : false,
    show_zone_historical : false,
    show_lot_historical : false,
    over_all_total : 0,
    over_all_occupied : 0,
    over_all_percentage : 0,
    zone_percentage_array : [],
    zone_array : [],
    historical_day : 1,
    zone_selected : 'a',
    historical_date : moment().tz(Config.get('/timeZone')).format("MM/DD/YYYY").toString(),
    percentage_array : [ 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00 ],
    time_array : [
        '0:30 am',
        '1:00 am',
        '1:30 am',
        '2:00 am',
        '2:30 am',
        '3:00 am',
        '3:30 am',
        '4:00 am',
        '4:30 am',
        '5:00 am',
        '5:30 am',
        '6:00 am',
        '6:30 am',
        '7:00 am',
        '7:30 am',
        '8:00 am',
        '8:30 am',
        '9:00 am',
        '9:30 am',
        '10:00 am',
        '10:30 am',
        '11:00 am',
        '11:30 am',
        '12:00 pm',
        '12:30 pm',
        '1:00 pm',
        '1:30 pm',
        '2:00 pm',
        '2:30 pm',
        '3:00 pm',
        '3:30 pm',
        '4:00 pm',
        '4:30 pm',
        '5:00 pm',
        '5:30 pm',
        '6:00 pm',
        '6:30 pm',
        '7:00 pm',
        '7:30 pm',
        '8:00 pm',
        '8:30 pm',
        '9:00 pm',
        '9:30 pm',
        '10:00 pm',
        '10:30 pm',
        '11:00 pm',
        '11:30 pm',
        '12:00 am'
    ],
    time_permanent_array : [
        '0:30 am',
        '1:00 am',
        '1:30 am',
        '2:00 am',
        '2:30 am',
        '3:00 am',
        '3:30 am',
        '4:00 am',
        '4:30 am',
        '5:00 am',
        '5:30 am',
        '6:00 am',
        '6:30 am',
        '7:00 am',
        '7:30 am',
        '8:00 am',
        '8:30 am',
        '9:00 am',
        '9:30 am',
        '10:00 am',
        '10:30 am',
        '11:00 am',
        '11:30 am',
        '12:00 pm',
        '12:30 pm',
        '1:00 pm',
        '1:30 pm',
        '2:00 pm',
        '2:30 pm',
        '3:00 pm',
        '3:30 pm',
        '4:00 pm',
        '4:30 pm',
        '5:00 pm',
        '5:30 pm',
        '6:00 pm',
        '6:30 pm',
        '7:00 pm',
        '7:30 pm',
        '8:00 pm',
        '8:30 pm',
        '9:00 pm',
        '9:30 pm',
        '10:00 pm',
        '10:30 pm',
        '11:00 pm',
        '11:30 pm',
        '12:00 am'
    ],
    rail_time_array : [
        '00:00',
        '00:30',
        '01:00',
        '01:30',
        '02:00',
        '02:30',
        '03:00',
        '03:30',
        '04:00',
        '04:30',
        '05:00',
        '05:30',
        '06:00',
        '06:30',
        '07:00',
        '07:30',
        '08:00',
        '08:30',
        '09:00',
        '09:30',
        '10:00',
        '10:30',
        '11:00',
        '11:30',
        '12:00',
        '12:30',
        '13:00',
        '13:30',
        '14:00',
        '14:30',
        '15:00',
        '15:30',
        '16:00',
        '16:30',
        '17:00',
        '17:30',
        '18:00',
        '18:30',
        '19:00',
        '19:30',
        '20:00',
        '20:30',
        '21:00',
        '21:30',
        '22:00',
        '22:30',
        '23:00',
        '23:30'
    ],
    download_array : [],
    avg_time : [],
    zone_time : []
};
const reducer = function (state, action) {

    if (action.type === Constants.GET_LOTLIST) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.GET_LOTLIST_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        let occupied = 0;
        let total = 0;
        let percentage = 0;
        let lots = result.lots;
        let over_all_total = 0;
        let over_all_occupied = 0;
        let over_all_percentage = 0;
        
        let zone_array = UserIdentity.defaultZones;
        //let zone_array = [ 'a', 'ada', 'b', 'c', 'pc-1', 'pc-2', 'pc-3', 'pc-4', /*, 'temp'*/];
        let temp_zone_per_array = [];
        
        if (lots) {
            Object.keys(lots).map((lot) => {
                Object.keys(lots[lot].occupancy).map((zone) => {
                    zone_array.forEach((selected) => {
                        if (selected === zone) {
                            if (temp_zone_per_array[zone]) {
                                temp_zone_per_array[zone] = {
                                    'total' : temp_zone_per_array[zone].total + (lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3]),
                                    'occupied' : temp_zone_per_array[zone].occupied + lots[lot].occupancy[zone][1]
                                }
                            } else {
                                temp_zone_per_array[zone] = {
                                    'total' : lots[lot].occupancy[zone][2] - lots[lot].occupancy[zone][3],
                                    'occupied' : lots[lot].occupancy[zone][1]
                                }
                                
                            }
                            over_all_occupied += lots[lot].occupancy[zone][1];
                        }
                    });
                    if (zone === 'all') {
                        over_all_total += lots[lot].occupancy[zone][2];
                    }
                    
                });
            });
        }

        over_all_percentage = over_all_total > 0 ? Math.ceil((over_all_occupied / over_all_total) * 100) : 0;
        
        let zone_per_array = [];
        Object.keys(temp_zone_per_array).map((element) => {
            let occupied = parseInt(temp_zone_per_array[element].occupied);
            let total = parseInt(temp_zone_per_array[element].total);
            zone_per_array[element] = {
                'total' : total,
                'occupied' : occupied,
                'percentage' : Math.ceil((occupied / total) * 100)

            }
        });

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            lots: result.lots,
            over_all_total: over_all_total,
            over_all_occupied: over_all_occupied,
            over_all_percentage : over_all_percentage,
            zone_percentage_array : zone_per_array,
            zone_array : zone_array,
            first_time_loaded: true
        });
    }

    if (action.type === Constants.SHOW_ZONE_HISTORICAL) {
        return ObjectAssign({}, state, {
            show_zone_historical: true,
            zone_selected:  action.zone
        });
    }

    if (action.type === Constants.HIDE_ZONE_HISTORICAL) {
        return ObjectAssign({}, state, {
            show_zone_historical: false
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;


        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            percentage_array : result.percentage ? result.percentage:  state.percentage_array,
            time_array : result.time ? result.time:  state.time_array,
        });
    }

    if (action.type === Constants.SET_HISTORICAL_DATE) {
        return ObjectAssign({}, state, {
            historical_date: moment(action.date, 'DD-MM-YYYY').format('MM/DD/YYYY').toString()
        });
    }

    if (action.type === Constants.SET_HISTORICAL_DAY) {
        return ObjectAssign({}, state, {
            historical_day: parseInt(action.day)
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY_DOWNLOAD) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SAVE_MAP_ARRAY_DOWNLOAD_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response.data;

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            download_array : result
        });
    }

    if (action.type === Constants.GET_STALLLIST_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        let lot_name = result.lot_name;
                    
        const markers = [];
        const disabledZones = [];
        
        var available_state = 0, occupied_state = 0, noData_state = 0, reserved_state = 0;
        for(let zone in localStorage){
            if(localStorage.hasOwnProperty(zone)){
                const zoneValue = localStorage.getItem(zone);
                if(zoneValue === 'false'){
                    disabledZones.push(zone);
                }
            }
        }
        let duration;
        let total_duration_mins = 0;
        let total_duration_count = 0;

        let zone_time = state.zone_time;
        
        let zone_array = UserIdentity.defaultZones;
        //let zone_array = [ 'a', 'ada', 'b', 'c', 'pc-1', 'pc-2', 'pc-3', 'pc-4', /*, 'temp'*/];
        result.lot_status.forEach((stall) => {
            if (stall.occupancy_duration && stall.occupancy_duration !== null && stall.status !== 2) {
                duration = parseInt(Math.ceil(stall.occupancy_duration / 60))
                total_duration_mins += duration;
                total_duration_count++;
            } else {
                duration = '-';
            }
            
            let zone_duration;
            let zone_total_duration_mins = 0;
            let zone_total_duration_count = 0;
            zone_array.forEach((zone) => {
                if (zone === stall.zone) {
                    if (zone_time[zone]) {
                        if (stall.occupancy_duration && stall.occupancy_duration !== null && stall.status !== 2) {
                            zone_duration = parseInt(Math.ceil(stall.occupancy_duration / 60))
                            zone_total_duration_mins = zone_time[zone].zone_total_duration_mins + zone_duration;
                            zone_total_duration_count = zone_time[zone].zone_total_duration_count + 1;
                            zone_time[zone] = {
                                zone_total_duration_mins : zone_total_duration_mins,
                                zone_total_duration_count : zone_total_duration_count
                            }
                        } 
                    } else {
                        if (stall.occupancy_duration && stall.occupancy_duration !== null && stall.status !== 2) {
                            zone_duration = parseInt(Math.ceil(stall.occupancy_duration / 60))
                            zone_total_duration_mins = zone_duration;
                            zone_total_duration_count = zone_total_duration_count + 1;
                            zone_time[zone] = {
                                zone_total_duration_mins : zone_total_duration_mins,
                                zone_total_duration_count : zone_total_duration_count
                            }
                        } 
                        
                    }
                }
            })
            const [lat, lng] = stall.coords.split(',');
            const reserved = stall.reserve_flag;
            let icon;
            icon = 'green.png';

            if (state.unavailable === 1) {
                if (reserved){
                    icon = 'purple.png';
                } else if(stall.status === 0 && stall.zone === 'ada'){
                    icon = 'green-blue.png';
                } else if(stall.status === 1 && stall.zone === 'ada'){
                     icon = 'red-blue.png';
                } else if(stall.status === 2 && stall.zone === 'ada'){
                     icon = 'orange-blue.png';
                } else if (stall.status === 1){
                    icon = 'red.png';
                } else if (stall.status === 2){
                    icon = 'orange.png';
                } else if (reserved){
                    icon = 'purple.png';
                } else if(stall.status === 0 && !reserved){
                    icon = 'green.png';
                }
            } else {
                icon = 'orange.png';
            }
            
            if(!disabledZones.includes(`${stall.zone}_selected`)){
                markers.push({
                    stallNumber: stall.stall_num,
                    lat: parseFloat(lat),
                    lng: parseFloat(lng),
                    reserved: reserved,
                    status: stall.status,
                    icon: icon,
                    isOpen: false,
                    lot_name : state.lot_name,
                    zone: stall.zone,
                    reserve_flag: stall.reserve_flag,
                    live_flag: stall.live_flag,
                    duration : duration,
                    is_blink : state.time_limit === '' ? false : (duration >= parseInt(state.time_limit)) ? true : false
                });
                if (reserved){
                    reserved_state += 1;
                } else if(stall.status === 0 && !reserved){
                    available_state += 1;
                } else if (stall.status === 1){
                    occupied_state += 1;
                } else if (stall.status === 2){
                    noData_state += 1;
                } /*else if (reserved){
                    reserved_state += 1;
                }*/
            }
        });

        let response = {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            markers : markers,
            available: available_state,
            occupied: occupied_state,
            noData: noData_state,
            reserved: reserved_state,
            total_duration_mins : total_duration_mins,
            total_duration_count : total_duration_count,
            avg_duration_count : total_duration_count > 0 ? Math.ceil(parseInt(total_duration_mins / total_duration_count)) : 0
        }

        let state_array = state.avg_time;
        
        state_array[lot_name] = response.avg_duration_count;

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            avg_time : state_array,
            zone_time : zone_time
        });

    }
    return state;
};


module.exports = Redux.createStore(reducer, initialState);
