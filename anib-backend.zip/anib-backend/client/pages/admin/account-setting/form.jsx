'use strict';
const Actions = require('./actions');
const Alert = require('../../../components/alert.jsx');
const Button = require('../../../components/form/button.jsx');
const CheckboxControl = require('../../../components/form/checkbox-control.jsx');
const ControlGroup = require('../../../components/form/control-group.jsx');
const React = require('react');
const Spinner = require('../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../components/form/text-control.jsx');


class Form extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
        this.toggleChangePassword = this.toggleChangePassword.bind(this);        
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.name) {
            this.input.name.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    toggleChangePassword(checked) {

        Actions.toggleChangePassword(checked);

    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.updateUser({
            profile_image_path: this.profile_image_path.files[0] ? this.profile_image_path.files[0] : undefined,
            first_name: this.input.first_name.value(),
            last_name: this.input.last_name.value(),
            email: this.input.email.value(),
            mobile_number: this.input.mobile_number.value(),
            change_password: this.change_password.checked() ? 1 : 0,
            password: this.change_password.checked() ? this.input.password.value() : '',
            confirm_password: this.change_password.checked() ? this.input.confirm_password.value() : ''
        });
    }

    render() {

        let alert = [];

        if (this.state.success) {
            alert = <Alert
                type="success"
                message="Success. We have received your message."
            />;
        }
        else if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <div className="form-group upload-file">
                    <label className="left-side">Profile Picture</label>
                    <div className="right-side">
                        <input type="file" ref={(input) => { this.profile_image_path = input; }} className="hidden" id="f1" />
                        <label htmlFor="f1" className="form-control c-pointer">Choose file to Upload</label>
                    </div>
                </div>
                {/* <TextControl
                    ref={(c) => (this.input.profile_image_path = c)}
                    ref={(input) => { this.profile_image_path = input; }}
                    isKeyEnable="true"
                    name="profile_image_path"
                    label="Profile Picture"
                    type="file"
                    hasError={this.state.hasError.profile_image_path}
                    help={this.state.help.profile_image_path}
                    disabled={this.state.loading}
                    groupClasses={ {'upload-file': true} }
                    inputClasses={ {'hidden': true} }
                    id="f1"
                    
                    appendElement='<label htmlFor="f1" className="form-control c-pointer">Choose file to Upload</label>'
                /> */}
                <TextControl
                    ref={(c) => (this.input.first_name = c)}
                    isKeyEnable="true"
                    name="first_name"
                    label="Enter First Name"
                    hasError={this.state.hasError.first_name}
                    help={this.state.help.first_name}
                    disabled={this.state.loading}
                    defaultValue={this.props.first_name}
                />
                <TextControl
                    ref={(c) => (this.input.last_name = c)}
                    isKeyEnable="true"
                    name="last_name"
                    label="Enter Last Name"
                    hasError={this.state.hasError.last_name}
                    help={this.state.help.last_name}
                    disabled={this.state.loading}
                    defaultValue={this.props.last_name}
                />
                <TextControl
                    ref={(c) => (this.input.email = c)}
                    isKeyEnable="true"
                    name="email"
                    label="Email Id"
                    hasError={this.state.hasError.email}
                    help={this.state.help.email}
                    disabled={this.state.loading}
                    defaultValue={this.props.email}
                />
                <TextControl
                    ref={(c) => (this.input.mobile_number = c)}
                    isKeyEnable="true"
                    name="mobile_number"
                    label="Phone Number"
                    hasError={this.state.hasError.mobile_number}
                    help={this.state.help.mobile_number}
                    disabled={this.state.loading}
                    defaultValue={this.props.mobile_number}
                />
                <CheckboxControl                    
                    ref={(input) => { this.change_password = input; }}
                    isKeyEnable="true"
                    name="change_password"
                    id="change_password"
                    onChange={(e) => { this.toggleChangePassword(e.target.checked)}}
                    hasError={this.state.hasError.change_password}
                    help={this.state.help.change_password}
                    disabled={this.state.loading}
                    defaultValue={1}
                    inputClasses={{'password-toggle': true, 'form-control': false, 'checkbox': true}}
                    labelClasses={{'checkbox': true, 'left-side': false, 'control-label': false}}
                    labelFor="change_password"
                    label= {['Change Password']}
                    labelPositionBottom={true}
                />

                { 
                    this.state.show_change_password ? (
                            <div className="change-password" style={{ 'display': 'block'}}>
                                <TextControl
                                    ref={(c) => (this.input.password = c)}
                                    isKeyEnable="true"
                                    type="password"
                                    name="password"
                                    label="Enter New Password"
                                    hasError={this.state.hasError.password}
                                    help={this.state.help.password}
                                    disabled={this.state.loading}
                                    groupClasses={{'show_hide': true}}
                                />
                                <TextControl
                                    ref={(c) => (this.input.confirm_password = c)}
                                    isKeyEnable="true"
                                    type="password"
                                    name="confirm_password"
                                    label="Confirm Password"
                                    hasError={this.state.hasError.confirm_password}
                                    help={this.state.help.confirm_password}
                                    disabled={this.state.loading}
                                    groupClasses={{'show_hide': true}}
                                />

                            </div>
                        ) : null
                }
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'full_row': true, 'text-right': true, 'action-bar': true, 'form-group': true}}>
                    <Button
                        type="button"
                        inputClasses={{ 'btn-outline-primary': true, 'no-shadow': true }}
                        disabled={this.state.loading}
                        onClick={(e) => {this.props.history.push('/admin')}}
                        >
                        Cancel
                    </Button>

                    <Button
                        type="submit"
                        inputClasses={{ 'btn-primary': true, 'no-shadow': true }}
                        disabled={this.state.loading}>

                        <Spinner space="right" show={this.state.loading} />
                        Update
                    </Button>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <form onSubmit={this.handleSubmit.bind(this)}>
                {alert}
                {formElements}
            </form>
        );
    }
}


module.exports = Form;
