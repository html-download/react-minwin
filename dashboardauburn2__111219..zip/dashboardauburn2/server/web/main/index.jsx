//'use strict';
const PropTypes = require('prop-types');
const React = require('react');


const propTypes = {
    markup: PropTypes.node,
    helmet: PropTypes.object,
    state: PropTypes.object
};

class MainPage extends React.Component {
    render() {

        return (
            <html>
                <head>
                    {this.props.helmet.title.toComponent()}
                    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                    {this.props.helmet.meta.toComponent()}
                    <link rel="stylesheet" href="/public/core.min.css" />
                    <link rel="stylesheet" href="/public/pages/main.min.css" />
                    <link rel="stylesheet" href="/public/media/bootstrap-datepicker/css/bootstrap-datepicker3.standalone.css" />
                    <link rel="shortcut icon" href="/public/media/favicon.ico" />
                    <script src="/public/media/js/jquery-3.3.1.min.js"></script>
                    {this.props.helmet.link.toComponent()}
                </head>
                <body className="hold-transition skin-blue fixed sidebar-mini">
                        <div id="app-mount"
                            dangerouslySetInnerHTML={{
                                __html: this.props.markup
                            }}
                        />
                        <script id="app-state"
                            dangerouslySetInnerHTML={{
                                __html: this.props.state
                            }}
                        />
                    
                    <script src="/public/pages/main.min.js"></script>
                    <script src="/public/media/js/adminlte.min.js"></script>
                    <script src="/public/media/js/bootstrap.js"></script>
                    <script src="/public/media/js/bootstrap-select.min.js"></script>
                    <script src="/public/media/js/jquery-ui.min.js"></script>
                    <script src="/public/media/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
                    <script src="/public/media/js/highchart/highcharts.js"></script>
                    <script src="/public/media/js/highchart/highcharts-3d.js"></script>
                    <script src="/public/media/js/highchart/exporting.js"></script>
                    <script src="/public/media/js/highchart/export-data.js"></script>
                    <script src="/public/media/js/jquery.knob.js"></script>
                    <script src="/public/media/js/jquery.slimscroll.min.js"></script>
                    <script src="/public/media/js/wow.min.js"></script>
                    <script src="/public/media/js/toastr.min.js"></script>
                    <script src="/public/media/js/moment.min.js"></script>
                    <script src="/public/media/js/datetimepicker.min.js"></script>
                    <script src="/public/media/js/theme-custom.js"></script>
                    <script src="/public/media/js/custom.js"></script>
                </body>
            </html>
        );
    }
}


MainPage.propTypes = propTypes;


module.exports = MainPage;
