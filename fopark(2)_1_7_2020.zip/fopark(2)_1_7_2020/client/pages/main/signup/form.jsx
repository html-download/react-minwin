const Actions = require('./actions');
const Alert = require('../../../components/alert.jsx');
const Button = require('../../../components/form/button.jsx');
const ControlGroup = require('../../../components/form/control-group.jsx');
const React = require('react');
const Spinner = require('../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../components/form/text-control.jsx');
const CheckboxControl = require('../../../components/form/checkbox-control.jsx');

const ObjectAssign = require('object-assign');


class Form extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
        this.handlePasswordChange = this.handlePasswordChange.bind(this);
        this.handleTerms = this.handleTerms.bind(this);
    }
    handleTerms(event) {
        const target = event.target;
        const checked = target.type === "checkbox" 
                        ? target.checked 
                        : target.value;
        if (checked === true) {
            this.setState(ObjectAssign(this.state, {
                checkboxCondition: true
            }));
        } else {
            this.setState(ObjectAssign(this.state, {
                checkboxCondition: false
            }));
        }
    }
    handlePasswordChange(event) {
        let value = event.target.value;
        
        /*set 8 char minimum*/
        if(value.length < 8)
            this.setState(ObjectAssign(this.state, {
                conditionCharacter: false
            }));
        else
            this.setState(ObjectAssign(this.state, {
                conditionCharacter: true
            }));

        /*set one upper case*/
        if(!/[A-Z]/.test(value))
            this.setState(ObjectAssign(this.state, {
                conditionUpperCase: false
            }));
        else
            this.setState(ObjectAssign(this.state, {
                conditionUpperCase: true
            }));

        /*set one number*/
        if(value.match(/\d/))
            this.setState(ObjectAssign(this.state, {
                conditionNumber: true
            }));
        else
            this.setState(ObjectAssign(this.state, {
                conditionNumber: false
            }));

        /*set one lower case*/
        if(!/[a-z]/.test(value))
            this.setState(ObjectAssign(this.state, {
                conditionLowerCase: false
            }));
        else
            this.setState(ObjectAssign(this.state, {
                conditionLowerCase: true
            }));

        /*check all errors active*/
        if (this.state.conditionUpperCase && 
            this.state.conditionLowerCase && 
            this.state.conditionNumber && 
            this.state.conditionCharacter) {
            this.setState(ObjectAssign(this.state, {
                conditionPassword: false
            }));
        } else {
            this.setState(ObjectAssign(this.state, {
                conditionPassword: true
            }));
        }
    }
    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.email) {
            this.input.email.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Actions.sendRequest({
            email: this.input.email.value(),
            name: this.input.name.value(),
            last_name: this.input.last_name.value(),
            password: this.input.password.value(),
            terms: this.input.terms.value(),
        });
    }

    render() {

        let alert = [];

        if (this.state.success) {
            alert = <Alert
                type="success"
                message="Success. Redirecting..."
            />;
        }
        else if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
                <TextControl
                    ref={(c) => (this.input.email = c)}
                    name="email"
                    hideLabel={true}
                    placeholder="Email Address"
                    hasError={this.state.hasError.email}
                    help={this.state.help.email}
                    disabled={this.state.loading}
                />
                <TextControl
                    ref={(c) => (this.input.name = c)}
                    name="name"
                    hideLabel={true}
                    placeholder="First Name"
                    hasError={this.state.hasError.name}
                    help={this.state.help.name}
                    disabled={this.state.loading}
                />
                
                <TextControl
                    ref={(c) => (this.input.last_name = c)}
                    name="last_name"
                    hideLabel={true}
                    placeholder="Last Name"
                    hasError={this.state.hasError.last_name}
                    help={this.state.help.last_name}
                    disabled={this.state.loading}
                />
                <TextControl
                    ref={(c) => (this.input.password = c)}
                    name="password"
                    hideLabel={true}
                    placeholder="Create a Password"
                    type="password"
                    hasError={this.state.hasError.password}
                    help={this.state.help.password}
                    disabled={this.state.loading}
                    onChange={this.handlePasswordChange}
                    groupClasses={{ 'mb0': true }}
                />
                <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{ 'valid': true }}>
                    <span>
                        <i className={this.state.conditionCharacter ? "fa fa-check green" : "fa fa-circle"} aria-hidden="true"></i> 
                        8 characters minimum
                    </span>
                    <span className="pull-right">
                        <i className={this.state.conditionUpperCase ? "fa fa-check green" : "fa fa-circle"} aria-hidden="true"></i>
                        One uppercase character
                    </span>
                    <span>
                        <i className={this.state.conditionNumber ? "fa fa-check green" : "fa fa-circle"}  aria-hidden="true"></i>
                        One number
                    </span>
                    <span className="pull-right">
                        <i className={this.state.conditionLowerCase ? "fa fa-check green" : "fa fa-circle"} aria-hidden="true"></i>
                        One lowercase character
                    </span>
                </ControlGroup>
                <CheckboxControl
                    ref={(c) => (this.input.terms = c)}
                    name="terms"
                    id="terms"
                    inputClasses={{ 'checkbox': true }}
                    hasError={this.state.hasError.terms}
                    help={this.state.help.terms}
                    disabled={this.state.loading}
                    labelClasses={{ 'checkbox f11': true }}
                    labelFor="terms"
                    label= {['By signing up for an account I agree to Dining Power’s <a role="button">Terms of Service</a> and <a role="button">Privacy Policy</a>']}
                    labelPositionBottom={true}
                    onChange={this.handleTerms}
                    value={this.state.checkboxCondition ? "1" : ""}
                    groupClasses={{ 'mtb10': true, 'terms': true }}
                />
                <ControlGroup hideLabel={true} hideHelp={true}>
                    <Button
                        type="submit"
                        inputClasses={{ 'mt24 full': true }}
                        disabled={this.state.loading/* || this.state.conditionPassword*/}>
                        Sign Up
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
                </ControlGroup>
            </fieldset>;
        }

        return (
            <form onSubmit={this.handleSubmit.bind(this)}>
                {alert}
                {formElements}
            </form>
        );
    }
}


module.exports = Form;
