'use strict';
const FluxConstant = require('flux-constant');


module.exports = FluxConstant.set([    
    'GET_RESULTS',    
    'GET_TASK_RESULTS',
    'GET_TASK_RESULTS_RESPONSE',
    'HIDE_CREATE_NEW',
    'SHOW_CREATE_NEW',
    'GET_TASK_UPDATE_STATUS_RESULTS',
    'GET_TASK_UPDATE_STATUS_RESULTS_RESPONSE'
]);
