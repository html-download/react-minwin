'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const CommonFunctions = require('../../../../../helpers/common-functions');


const initialState = {
    hydrated: false,
    loading: false,
    showFetchFailure: false,
    showSaveSuccess: false,
    error: undefined,
    hasError: {},
    help: {},
    id: undefined,
    customer_name: 'Mohammed',
    vehicle: '2019 Bentley First edition SUV',
    cc_eamil: undefined,
    bcc_email: undefined,
    editable_field: undefined,
};
const reducer = function (state = initialState, action) {

    if (action.type === Constants.GET_BASIC_DETAILS) {
        return ObjectAssign({}, state, {
            hydrated: false,
            loading: true
        });
    }

    if (action.type === Constants.GET_BASIC_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);

        let data = (action.response && action.response.data) ? action.response.data : {};

        const stateUpdates = {
            loading: false,
            showSaveSuccess: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
        };

        if (action.response && action.response.status === 200 && action.response.data && CommonFunctions.isEmpty(action.response.data)) {
            id: data.driving_details_key ? data.driving_details_key : undefined;
            first_license_country_id: data.first_license_country_id ? data.first_license_country_id : undefined;
            first_license_age: data.first_license_age ? data.first_license_age : undefined;
            first_license_issue_date: data.first_license_issue_date ? data.first_license_issue_date : undefined;
            uae_license_age: data.uae_license_age ? data.uae_license_age : undefined;
            uae_license_issue_date: data.uae_license_issue_date ? data.uae_license_issue_date : undefined;
        }
    }

    if (action.type === Constants.SAVE_BASIC_DETAILS) {

        let data = (action.response && action.response.data) ? action.response.data : {};

        return ObjectAssign({}, state, {
            loading: true,
        });
    }

    if (action.type === Constants.SAVE_BASIC_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);
        
        const stateUpdates = {
            loading: false,
            showSaveSuccess: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
        };

        if (action.response && action.response.status === 200 && action.response.data && CommonFunctions.isEmpty(action.response.data)) {
            id: data.driving_details_key ? data.driving_details_key : undefined;
            first_license_country_id: data.first_license_country_id ? data.first_license_country_id : undefined;
            first_license_age: data.first_license_age ? data.first_license_age : undefined;
            first_license_issue_date: data.first_license_issue_date ? data.first_license_issue_date : undefined;
            uae_license_age: data.uae_license_age ? data.uae_license_age : undefined;
            uae_license_issue_date: data.uae_license_issue_date ? data.uae_license_issue_date : undefined;
        }

        return ObjectAssign({}, state, stateUpdates);
    }

    if (action.type === Constants.EDITABLE_SHOW) {
        return ObjectAssign({}, state, {
            editable_field: action.field
        });
    }

    if (action.type === Constants.EDITABLE_HIDE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }

    if (action.type === Constants.RESET_STORE) {
        return ObjectAssign({}, state, {
            editable_field: undefined
        });
    }

    return state;
};


module.exports = reducer;
