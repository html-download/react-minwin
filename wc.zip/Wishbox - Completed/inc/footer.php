
<footer class="site_footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				<img src="../assets/img/logo-color.png" class="logo footer">
			</div> <!--col-sm-6-->

			<div class="col-sm-6">
				<ul class="social_links float-right">
					<li><a href="" target="_blank" class="facebook"><i class="lni-facebook-filled"></i></a></li>
					<li><a href="" target="_blank" class="twitter"><i class="lni-twitter-filled"></i></a></li>
					<li><a href="" target="_blank" class="insta"><i class="lni-instagram-filled"></i></a></li>
					<li><a href="" target="_blank" class="youtube"><i class="lni-youtube"></i></a></li>
				</ul> <!--social_links-->
			</div> <!--col-sm-6-->
		</div>

		<ul class="footer_links full_row">
			<li><a href="about-us">About Us</a></li>
			<li><a data-toggle="modal" data-target="#modal_bussiness">Add Business</a></li>
			<li><a href="terms-and-conditions">Vendor Login</a></li>
			<li><a href="terms-and-conditions">Terms and conditions</a></li>
			<li><a href="faq">FAQ</a></li>
			<li><a href="terms-and-conditions">Privacy policy</a></li>
			<li><a href="contact-us">Contact Us</a></li>
		</ul> <!--footer_links-->

		<p class="grey text-center mb0">2019@wishboxonline.com | All Rights Reserved</p>
	</div> <!--container-->
</footer> <!--site_footer-->

<div id="modal_login" class="login modal fade" role="dialog">
	<div class="modal-dialog">		
		<div class="modal-content">
			<a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>

			<div class="modal-body">
				<img src="../assets/img/logo-grey.png" class="logo grey">
				
				<div class="infographic">
					<img src="../assets/img/login.svg">
				</div> <!--infographic-->

				<div class="form">
					<h2>Login</h2>
					<form>
						<div class="form-group icon">
							<label for="lemail"><i class="fi mail"></i><span>Email Address</span></label>
							<input id="lemail" type="text" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group icon change">
							<label for="lpass"><i class="lni-lock"></i><span>Password</span></label>
							<input id="lpass" type="password" class="form-control">
							<a class="change" data-dismiss="modal" data-toggle="modal" data-target="#modal_forgot">Forgot?</a>
						</div> <!--form-group-->

						<div class="form-group action icon">
							<button class="btn full submit">Login <i class="la la-arrow-right"></i></button>
						</div> <!--form-group-->
					</form>

					<div class="form-group social">
						<span>or</span>						
					</div> <!--form-group-->

					<div class="form-group social_login">
						<span><a class="facebook"><i class="lni-facebook-filled"></i> Facebook</a></span>
						<span><a class="google"><i class="lni-google"></i> Google</a></span>
					</div> <!--form-group-->

					<div class="form-group login_footer">
						Don't have an account? <a data-dismiss="modal" data-toggle="modal" data-target="#modal_register">Sign Up</a>
					</div> <!--form-group-->
				</div> <!--form-->
			</div> <!--modal-body-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_login-->

<div id="modal_register" class="login modal fade" role="dialog">
	<div class="modal-dialog">		
		<div class="modal-content">
			<a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>

			<div class="modal-body">
				<img src="../assets/img/logo-grey.png" class="logo grey">
				
				<div class="infographic">
					<img src="../assets/img/register.svg">
				</div> <!--infographic-->

				<div class="form">
					<h2>Sign Up</h2>
					<form>
						<div class="form-group icon">
							<label for="mobile"><i class="lni-mobile"></i><span>Mobile Number</span></label>
							<input id="mobile" type="text" class="form-control">
						</div> <!--form-group-->

						<div class="form-group icon">
							<label for="user"><i class="la la-user"></i><span>Name</span></label>
							<input id="user" type="text" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group icon">
							<label for="remail"><i class="fi mail"></i><span>Email Address</span></label>
							<input id="remail" type="text" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group icon">
							<label for="rpass"><i class="lni-lock"></i><span>Password</span></label>
							<input id="rpass" type="password" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group text-center gender">
							<input type="checkbox" id="gender" class="hide">
							<label for="gender">								
								<span>Male</span>
								<div class="slide"></div>
								<span>Female</span>
							</label>
						</div> <!--form-group-->
						
						<div class="form-group accept text-center grey">
							<input id="accept" type="checkbox" class="hide">
							<label for="accept" class="checkbox">I accept the <a href="terms-conditions" target="_blank">Terms & Conditions</a></label>
						</div> <!--form-group-->

						<div class="form-group action icon">							
							<button class="btn full submit" data-dismiss="modal" data-toggle="modal" data-target="#modal_otp">Continue <i class="la la-arrow-right"></i></button>
						</div> <!--form-group-->
					</form>

					<div class="form-group social">
						<span>or</span>						
					</div> <!--form-group-->

					<div class="form-group social_login">
						<span><a class="facebook"><i class="lni-facebook-filled"></i> Facebook</a></span>
						<span><a class="google"><i class="lni-google"></i> Google</a></span>
					</div> <!--form-group-->

					<div class="form-group login_footer">
						Have an account? <a data-dismiss="modal" data-toggle="modal" data-target="#modal_login">Sign In</a>
					</div> <!--form-group-->
				</div> <!--form-->
			</div> <!--modal-body-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_register-->

<div id="modal_otp" class="login modal fade" role="dialog">
	<div class="modal-dialog">		
		<div class="modal-content">
			<a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>

			<div class="modal-body">
				<img src="../assets/img/logo-grey.png" class="logo grey">
				
				<div class="infographic">
					<img src="../assets/img/otp.svg">
				</div> <!--infographic-->

				<div class="form">
					<h2>OTP Verification</h2>
					<form>
						<p class="grey">Please enter the verification code <span class="block">sent to <b class="black">9876543210</b>.</span></p>
						<div class="form-group icon has-value change">
							<label for="otp"><i class="lni-mobile"></i></label>
							<input id="otp" type="text" class="form-control" value="9876543210" readonly>
							<a class="change" data-dismiss="modal" data-toggle="modal" data-target="#modal_register">Change</a>
						</div> <!--form-group-->
						
						<div class="form-group otp text-center">
							<input type="text" class="form-control" maxlength="1">
							<input type="text" class="form-control" maxlength="1">
							<input type="text" class="form-control" maxlength="1">
							<input type="text" class="form-control" maxlength="1">
						</div> <!--form-group-->

						<div class="form-group action icon">
							<button class="btn full submit">Verify <i class="la la-check"></i></button>
						</div> <!--form-group-->
					</form>

					<div class="form-group login_footer">
						Back to login? <a data-dismiss="modal" data-toggle="modal" data-target="#modal_login">Click Here</a>
					</div> <!--form-group-->
				</div> <!--form-->
			</div> <!--modal-body-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_otp-->

<div id="modal_forgot" class="login modal fade" role="dialog">
	<div class="modal-dialog">		
		<div class="modal-content">
			<a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>

			<div class="modal-body">
				<img src="../assets/img/logo-grey.png" class="logo grey">
				
				<div class="infographic">
					<img src="../assets/img/otp.svg">
				</div> <!--infographic-->

				<div class="form">
					<h2 class="mb">Forgot Password?</h2>
					<p class="grey">Please enter your registered mobile number.</p>

					<form>						
						<div class="form-group icon change has-value">
							<label for="fotp"><i class="lni-mobile"></i></label>
							<input id="fotp" type="text" class="form-control" placeholder="Mobile Number">
							<a class="change hide">Change</a>
						</div> <!--form-group-->
						
						<div class="form-group otp text-center hide">
							<p class="grey full_row mb10">Please enter the verification code <span class="block">sent to <b class="black">9876543210</b>.</span></p>

							<input type="text" class="form-control" maxlength="1">
							<input type="text" class="form-control" maxlength="1">
							<input type="text" class="form-control" maxlength="1">
							<input type="text" class="form-control" maxlength="1">							
						</div> <!--form-group-->

						<div class="form-group action icon">
							<span class="btn full submit continue">Continue <i class="la la-arrow-right"></i></span>
							<button class="btn full submit verify hide">Verify <i class="la la-check"></i></button>
						</div> <!--form-group-->
					</form>

					<div class="form-group login_footer">
						Back to login? <a data-dismiss="modal" data-toggle="modal" data-target="#modal_login">Click Here</a>
					</div> <!--form-group-->
				</div> <!--form-->
			</div> <!--modal-body-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_forgot-->

<div id="modal_bussiness" class="login modal fade" role="dialog">
	<div class="modal-dialog">		
		<div class="modal-content">
			<a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>

			<div class="modal-body">
				<img src="../assets/img/logo-grey.png" class="logo grey">
				
				<div class="infographic">
					<img src="../assets/img/join-us.svg">
				</div> <!--infographic-->

				<div class="form">
					<h2>Join Us</h2>
					<form>
						<div class="form-group">
							<select class="selectpicker hide" title="Choose your service">
								<option>Grocery</option>
								<option>Restaurant</option>
								<option>Laundry</option>
								<option>Other</option>
							</select>
						</div> <!--form-group-->

						<div class="form-group icon">
							<label for="sname"><i class="la la-user"></i><span>Name</span></label>
							<input id="sname" type="text" class="form-control">
						</div> <!--form-group-->

						<div class="form-group icon">
							<label for="Representative"><i class="la la-user"></i><span>Representative Name</span></label>
							<input id="Representative" type="text" class="form-control">
						</div> <!--form-group-->

						<div class="form-group icon">
							<label for="smobile"><i class="lni-mobile"></i><span>Mobile Number</span></label>
							<input id="smobile" type="text" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group icon">
							<label for="semail"><i class="fi mail"></i><span>Email Address</span></label>
							<input id="semail" type="text" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group icon">
							<label for="sAddress"><i class="fi pin3"></i><span>Address</span></label>
							<input id="sAddress" type="text" class="form-control">
						</div> <!--form-group-->
						
						<div class="form-group group">
							<h5>How do you hear us?</h5>
							<input name="How" id="Friend" type="radio" class="hide">
							<label for="Friend" class="radio">By Friend</label>

							<input name="How" id="Facebook" type="radio" class="hide">
							<label for="Facebook" class="radio">By Facebook</label>

							<input name="How" id="Ads" type="radio" class="hide">
							<label for="Ads" class="radio">By Ads</label>
						</div> <!--form-group-->
						
						<div class="form-group">
							<textarea class="form-control" placeholder="Message"></textarea>
						</div> <!--form-group-->

						<div class="form-group action icon">
							<button class="btn full submit">Join Us <i class="la la-arrow-right"></i></button>
						</div> <!--form-group-->
					</form>
				</div> <!--form-->
			</div> <!--modal-body-->
		</div> <!--modal-content-->
	</div><!--modal-dialog-->
</div><!--modal_bussiness-->

<div id="mini_cart">
	<div class="mini_cart">
		
		<div class="empty_cart">
			<img src="assets/img/empty-cart.svg" class="mb10">
			<h5 class="mb10">Your Cart is Empty</h5>
			<p class="grey">Looks like you haven't added anything to your cart yet</p>
			<button class="btn full icon" onclick="location.href='/checkout';">Checkout <i class="la la-arrow-right"></i></button>
		</div> <!--empty_cart-->
	
		
<?php /*

		<div class="heading">
			<h5 class="float-left">Cart <span>5 Items</span></h5>
			<div class="points float-right">
				<i class="lni-emoji-smile"></i>
				<span>5</span> Points
			</div> <!--points-->
		</div> <!--heading-->

		<ul class="mini_cart">
			<li class="vendor">
				<h5>Zam Zam Mandi & Grill</h5>
				<span>Abu Hamour</span>
			</li>
			<li class="item">
				<p><img src="assets/img/non-veg.svg">Super Spicy Sandwich</p>
				<div class="qty_box small float-left">
					<span><i class="la la-minus"></i></span>		
					<input type="text" class="form-control" value="2" readonly>
					<span><i class="la la-plus"></i></span>
				</div> <!--qty_box-->			
				<a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
				<span class="price">QR 20</span>
			</li>
			<li class="item">
				<p><img src="assets/img/veg.svg">Chicken Biryani + Fried Leg + Pepsi</p>
				<div class="qty_box small float-left">
					<span><i class="la la-minus"></i></span>		
					<input type="text" class="form-control" value="2" readonly>
					<span><i class="la la-plus"></i></span>
				</div> <!--qty_box-->
				<span class="price">QR 20</span>
			</li>
			<li class="item">
				<p><img src="assets/img/non-veg.svg">Ghee Rice + Pepper Chicken</p>
				<div class="qty_box small float-left">
					<span><i class="la la-minus"></i></span>		
					<input type="text" class="form-control" value="2" readonly>
					<span><i class="la la-plus"></i></span>
				</div> <!--qty_box-->			
				<a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
				<span class="price">QR 20</span>
			</li>
			<li class="vendor">
				<h5>Zam Zam Mandi & Grill</h5>
				<span>Abu Hamour</span>
			</li>
			<li class="item">				
				<p><img src="assets/img/non-veg.svg">Super Spicy Sandwich</p>
				<div class="qty_box small float-left">
					<span><i class="la la-minus"></i></span>		
					<input type="text" class="form-control" value="2" readonly>
					<span><i class="la la-plus"></i></span>
				</div> <!--qty_box-->			
				<a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
				<span class="price">QR 20</span>
			</li>
			<li class="item">				
				<p><img src="assets/img/veg.svg">Chicken Biryani + Fried Leg + Pepsi</p>
				<div class="qty_box small float-left">
					<span><i class="la la-minus"></i></span>		
					<input type="text" class="form-control" value="2" readonly>
					<span><i class="la la-plus"></i></span>
				</div> <!--qty_box-->
				<span class="price">QR 20</span>
			</li>
			<li class="item">				
				<p><img src="assets/img/non-veg.svg">Ghee Rice + Pepper Chicken</p>
				<div class="qty_box small float-left">
					<span><i class="la la-minus"></i></span>		
					<input type="text" class="form-control" value="2" readonly>
					<span><i class="la la-plus"></i></span>
				</div> <!--qty_box-->			
				<a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
				<span class="price">QR 20</span>
			</li>
		</ul>

		<div class="mini_total regular">
			<div class="float-left">Subtotal <span class="light block grey small">Extra charges may apply</span></div>
			<div class="float-right price">QR 100</div>
			<button class="btn full icon" onclick="location.href='/checkout';">Checkout <i class="la la-arrow-right"></i></button>
		</div> <!--mini_total-->
			*/ ?>

	</div> <!--mini_cart-->
</div> <!--mini_cart-->

<script>
	$("#modal_forgot .continue").click(function(){
		$(this).hide();
		$("#modal_forgot div.otp").show();
		$("#modal_forgot #fotp").attr('readonly','readonly');	
		$("#modal_forgot a.change").show();
		$("#modal_forgot .verify").show();
	});
	$("#modal_forgot a.change").click(function(){
		$(this).hide();
		$("#modal_forgot div.otp").hide();
		$("#modal_forgot #fotp").removeAttr('readonly');
		$("#modal_forgot .verify").hide();
		$("#modal_forgot .continue").show();
	});
</script>

<!-- JS -->
<script src="../assets/js/wow.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/bootstrap-select.min.js"></script>
<script src="../assets/js/owl.carousel.min.js"></script>
<script src="../assets/js/popup.min.js"></script>
<script src="../assets/js/datepicker.min.js"></script>
<script src="../assets/js/jquery.timepicker.min.js"></script>
<script src="../assets/js/sticky-sidebar.js"></script>
<script src="../assets/js/custom.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC9Hp4Tit86Ed0Z98smUFsUy62hrqNTYxI&callback=map"></script>
<script type="text/javascript">
  function initMap() {
  var myLatLng = {lat: 11.0217436, lng: 76.9136443};

  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 16,
    center: myLatLng,
    scrollwheel: false,
    disableDefaultUI: true
  });

  var marker = new google.maps.Marker({
    position: myLatLng,
    map: map,
     icon: "../assets/img/pin-shop.png",
    title: 'Home'
  });
}

initMap();

</script>

</body>
</html>