/* global window */
'use strict';
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const DealStore = require('../deals/details/store');
const DealConstant = require('../deals/details/constants');


class Actions {

    static getDetails(id = null) {

        this.getNationalityResults();
        this.getEmirates();
        this.getDrivingExperience();
        this.getVehicleModelYear();
        this.getEnquiryTypes();
        this.getUserResults();
        this.getCountryResults();
        /* this.getProduct(); */
        this.getPlaceOfRegistration();
        if (id) {
            /* this.getNotes(id);
            this.getDealDocu(id);
            this.getDealTask(id); */
            this.getVehicleTypes(id);
        }
    }

    static getEmirates() {
                
        ApiActions.get(
            '/emirate',
            undefined,
            Store,
            Constants.GET_EMIRATES,
            Constants.GET_EMIRATES_RESPONSE
        );
    }


    static getPlaceOfRegistration() {
                
        ApiActions.get(
            '/place-of-registration',
            undefined,
            Store,
            Constants.GET_PLACE_OF_REGISTRATION,
            Constants.GET_PLACE_OF_REGISTRATION_RESPONSE
        );
    }

    static getVehicleModelYear() {
                
        ApiActions.get(
            '/year',
            undefined,
            Store,
            Constants.GET_VEHICLE_MODEL_YEAR,
            Constants.GET_VEHICLE_MODEL_YEAR_RESPONSE
        );
    }

    static getVehicleBrand(year_id) {

        ApiActions.get(
            `/vehicle-brand?year_id=${year_id}`,
            undefined,
            Store,
            Constants.GET_VEHICLE_BRAND,
            Constants.GET_VEHICLE_BRAND_RESPONSE,
            (err, response) => {

                if (!err && response.status === 200) {
                    DealStore.dispatch({
                        type: DealConstant.LOADING_VEHICLE_BRAND,
                        load: false
                    });
                }
            }
        );
    }

    static getVehicleBrandModel(vehicle_brand_key) {

        ApiActions.get(
            `/vehicle-brand-model?vehicle_brand_id=${vehicle_brand_key}`,
            undefined,
            Store,
            Constants.GET_VEHICLE_BRAND_MODEL,
            Constants.GET_VEHICLE_BRAND_MODEL_RESPONSE
        );
    }

    static getCartTrim(vehicle_brand_model_id) {

        ApiActions.get(
            `/vehicle-brand-model-trim?vehicle_brand_model_id=${vehicle_brand_model_id}`,
            undefined,
            Store,
            Constants.GET_VEHICLE_TRIM,
            Constants.GET_VEHICLE_TRIM_RESPONSE
        );
    }

    static getUserResults() {
        
        ApiActions.get(
            '/user',
            undefined,
            Store,
            Constants.GET_USER_DETAILS,
            Constants.GET_USER_DETAILS_RESPONSE
        );
    }

    static getProduct() {

        ApiActions.get(
            '/underwriter',
            undefined,
            Store,
            Constants.GET_PRODUCT_DETAILS,
            Constants.GET_PRODUCT_DETAILS_RESPONSE            
        );                
    }

    static getVehicleTypes() {
        
        ApiActions.get(
            '/deal/vehicle-type',
            undefined,
            Store,
            Constants.GET_VEHICLE_TYPE,
            Constants.GET_VEHICLE_TYPE_RESPONSE
        );
    }


    static getNationalityResults() {
        
        ApiActions.get(
            '/nationality',
            undefined,
            Store,
            Constants.GET_NATIONALITY_RESULTS,
            Constants.GET_NATIONALITY_RESULTS_RESPONSE
        );
    }

    static getEnquiryTypes() {
        
        ApiActions.get(
            '/deal/enquiry-type',
            undefined,
            Store,
            Constants.GET_ENQUIRY_RESULTS,
            Constants.GET_ENQUIRY_RESULTS_RESPONSE
        );
    }


    static getDrivingExperience() {
        
        ApiActions.get(
            '/customer-driving-profile/license-age-list',
            undefined,
            Store,
            Constants.GET_DRIVING_EXPERIENCE_RESULTS,
            Constants.GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE
        );
    }

   


    static getCountryResults() {
                    
        ApiActions.get(
            '/country',
            undefined,
            Store,
            Constants.GET_COUNTRY_RESULTS,
            Constants.GET_COUNTRY_RESULTS_RESPONSE
        );
    }


    static getDealTask(id) {

        ApiActions.get(
            `/task?task_status=1&deal_id=${id}`,
            undefined,
            Store,
            Constants.GET_DEAL_TASK_RESULT,
            Constants.GET_DEAL_TASK_RESULT_RESPONSE
        );
    }

    static getNotes(id) {
                
        ApiActions.get(
            `/deal-note?deal_id=${id}`,
            undefined,
            Store,
            Constants.GET_NOTE_RESULT,
            Constants.GET_NOTE_RESULT_RESPONSE
        );
    }
    
    static getDealDocu(id) {
        
        ApiActions.get(
            `/deal-document?deal_id=${id}`,
            undefined,
            Store,
            Constants.GET_DEAL_DOCU_DETAILS,
            Constants.GET_DEAL_DOCU_DETAILS_RESPONSE
        );
    }       
}


module.exports = Actions;
