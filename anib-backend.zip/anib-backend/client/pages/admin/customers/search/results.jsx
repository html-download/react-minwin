'use strict';
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');


const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array
};


class Results extends React.Component {
    
    getTableData(id, value) {
        return (
            <td onClick={(e) => {this.props.history.push(`/admin/customers/${id}`)}}>{value}</td>
        )
    }

    render() {

        const rows = (this.props.data && this.props.data.length > 0) ? this.props.data.map((record) => {
            return (
                <tr className="c-pointer" key={record.customer_key}>
                    { this.getTableData(record.customer_key, record.customer_type === 1 ? 'Individual' : 'Corporate') }
                    { this.getTableData(record.customer_key, record.customer_type === 1 ? record.name : record.company_name) }
                    { this.getTableData(record.customer_key, record.email) }
                    { this.getTableData(record.customer_key, record.mobile_number) }
                    { this.getTableData(record.customer_key, record.nationality_name) }
                    { this.getTableData(record.customer_key, record.created_at) }
                    { this.getTableData(record.customer_key, record.modified_at) }
                </tr>
            );
        }) : (
            <tr key='0'>
                <td colSpan={7} className="text-center">
                    No record(s) found!
                </td>
            </tr>
        );

        return (
            <div className="table-responsive">
                <table className="table table-hover white_table">
                    <thead>
                        <tr>
                            <th>Customer Type</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Nationality</th>
                            <th>Created On</th>
                            <th>Updated On</th>
                        </tr>
                    </thead>
                    {
                        this.props.list_loading ? (
                            <tbody>
                                <tr key='0'>
                                    <td colSpan={6} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='1'>
                                    <td colSpan={6} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='2'>
                                    <td colSpan={6} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='3'>
                                    <td colSpan={6} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='4'>
                                    <td colSpan={6} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>

                            </tbody>
                        ) : (
                            <tbody>
                                {rows}
                            </tbody>
                        )
                    }
                </table>
            </div>
        );
    }
}

Results.propTypes = propTypes;


module.exports = Results;
