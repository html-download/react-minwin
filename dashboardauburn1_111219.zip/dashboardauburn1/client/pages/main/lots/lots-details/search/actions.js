/* global window */
'use strict';
const ApiActions = require('../../../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');
const Qs = require('qs');
const ToasterContainer = require('../../../../../components/toaster.jsx');
const Toaster = new ToasterContainer();
const UserIdentity = require('../../../../../helpers/user-identity');

const apiUrl = UserIdentity.apiUrl;


class Actions {
    static getClientResults(data) {

        ApiActions.get(
            `${apiUrl}/client_list`,
            data,
            Store,
            Constants.GET_CLIENT_LOT_RESULTS,
            Constants.GET_CLIENT_LOT_RESULTS_RESPONSE
        );
    }
    static getLotResults(data) {
        ApiActions.get(
            `${apiUrl}/client/lots`,
            data,
            Store,
            Constants.GET_LOT_RESULTS,
            Constants.GET_LOT_RESULTS_RESPONSE
        );
    }

    static changeSearchQuery(data, history) {

        history.push({
            pathname: '/admin/accounts',
            search: `?${Qs.stringify(data)}`
        });

        window.scrollTo(0, 0);
    }

    static showCreateNew() {

        Store.dispatch({
            type: Constants.SHOW_CREATE_NEW
        });
    }

    static hideCreateNew() {

        Store.dispatch({
            type: Constants.HIDE_CREATE_NEW
        });
    }

    static createNew(data, history) {
        ApiActions.post(
            `${apiUrl}/lot`,
            data,
            Store,
            Constants.CREATE_NEW,
            Constants.CREATE_NEW_RESPONSE,
            (err, response) => {

                if (!err) {
                    this.hideCreateNew();

                    const path = `/lots-details/${data.client_name}`;

                    history.push(path);

                    window.scrollTo(0, 0);
                }
            }
        );
    }
    static statusUpdate(data, msg) {

        ApiActions.put(
            `${apiUrl}/lot`,
            data,
            Store,
            Constants.UPDATE_LOT_STATUS,
            Constants.UPDATE_LOT_STATUS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (data.status) {
                        Toaster.success(msg);
                    } else {
                        Toaster.error(msg);
                    }
                } else {
                    Toaster.error(err);
                }

            }
        );
    }
}


module.exports = Actions;
