'use strict';
const Confidence = require('confidence');
const Dotenv = require('dotenv');

Dotenv.config({ silent: true });

const criteria = {
    env: process.env.NODE_ENV
};

const config = {
    $meta: 'This file configures the plot device.',
    projectName: 'FoPark',
    port: {
        web: {
            $filter: 'env',
            test: 8021,
            production: process.env.PORT,
            $default: 8021
        }
    },
    baseUrl: {
        $filter: 'env',
        $meta: 'values should not end in "/"',
        production: 'http://demo33.duceapps.com:8021',
        $default: 'http://192.168.1.103:8021'
    },
    authAttempts: {
        forIp: 50,
        forIpAndUser: 7
    },
    cookieSecret: {
        $filter: 'env',
        //production: process.env.COOKIE_SECRET,
        production: '!k3yb04rdK4tz~4qu4~k3yb04rdd0ss!',
        $default: '!k3yb04rdK4tz~4qu4~k3yb04rdd0gz!'
    },
    mysqlEnvironment: {
        $filter: 'env',
        production: {
            "username": "dinning_duceapps",
            "password": "nwBooj3xQr0ArhgI",
            "database": "dinning_duceapps",
            "host": "localhost",
            "dialect": "mysql"
        },
        $default: {
            "username": "svnuser",
            "password": "pXc9nbmrnC",
            "database": "foodpack_rework",
            "host": "192.168.1.179",
            "dialect": "mysql"
        },
        test: {
            "username": "svnuser",
            "password": "pXc9nbmrnC",
            "database": "foodpack_rework",
            "host": "192.168.1.179",
            "dialect": "mysql"
        }
    },
    nodemailer: {
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        auth: {
            user: 'technoducedevelopers@gmail.com',
            pass: process.env.SMTP_PASSWORD
        }
    },
    system: {
        fromAddress: {
            name: 'DiningPower',
            address: 'technoducedevelopers@gmail.com'
        },
        toAddress: {
            name: 'DiningPower',
            address: 'technoducedevelopers@gmail.com'
        }
    },

};


const store = new Confidence.Store(config);


exports.get = function (key) {

    return store.get(key, criteria);
};


exports.meta = function (key) {

    return store.meta(key, criteria);
};
