/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorItemUndoIngredients', {
    itemUndoIngredientsId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'item_undo_ingredients_id'
    },
    itemUndoId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      field: 'item_undo_id'
    },
    ingredientsTypeId: {
      type: DataTypes.INTEGER(10),
      allowNull: true,
      field: 'ingredients_type_id'
    },
    minimum: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'minimum'
    },
    maximum: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'maximum'
    },
    freeChoice: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'free_choice'
    },
    chargedChoice: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'charged_choice'
    },
    required: {
      type: DataTypes.INTEGER(1),
      allowNull: true,
      field: 'required'
    },
    sortOrder: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'sort_order'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_vendor_item_undo_ingredients'
  });
};
