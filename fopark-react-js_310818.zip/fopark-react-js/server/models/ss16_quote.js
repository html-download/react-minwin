/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Quote', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    quote: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'quote'
    }
  }, {
    tableName: 'ss16_quote'
  });
};
