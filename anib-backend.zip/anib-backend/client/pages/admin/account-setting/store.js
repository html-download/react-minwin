'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {
    loading: false,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    show_change_password: false,

    first_name : undefined,
    last_name : undefined,
    mobile_number : undefined,
    email: undefined,
    profile_image_path : undefined
};
const reducer = function (state, action) {

    if (action.type === Constants.SEND_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: true
        });
    }

    if (action.type === Constants.SEND_MESSAGE_RESPONSE) {
        const validation = ParseValidation(action.response);

        return ObjectAssign({}, state, {
            loading: false,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        });
    }

    if (action.type === Constants.TOGGLE_PASSWORD) {
        return ObjectAssign({}, state, {
            show_change_password: action.checked
        });
    }

    if (action.type === Constants.GET_USER_RESULT) {
        /* return ObjectAssign({}, state, {
            loading: true
        }); */
    }

    if (action.type === Constants.GET_USER_RESULT_RESPONSE) {

        if (action.response.status === 200) {
            return ObjectAssign({}, state, {
                first_name : action.response.data.first_name,
                last_name : action.response.data.last_name,
                mobile_number : action.response.data.mobile_number,
                email: action.response.data.email,
                profile_image_path : action.response.data.profile_image_path
            });
        }
    }

    return state;
};


module.exports = Redux.createStore(reducer, initialState);
