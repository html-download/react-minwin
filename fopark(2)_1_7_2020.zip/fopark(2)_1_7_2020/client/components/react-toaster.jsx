const React = require('react');
import { toast } from 'react-toastify';

//reference url : https://fkhadra.github.io/react-toastify/

const propTypes = {
  position: "top-right",
  autoClose: 5000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true
};


class Toaster extends React.Component {
    constructor(props) {
        super(props);

        this.success = this.success.bind(this);
        this.warning = this.warning.bind(this);
        this.info = this.info.bind(this);
        this.error = this.error.bind(this);

    }
    componentDidMount(){
        //console.log('test')
    }
    success(msg) {
        toast.success(msg, propTypes);
    }
    warning(msg) {
        toast.warning(msg, propTypes);
    }
    info(msg) {
        toast.info(msg, propTypes);
    }
    error(msg) {
        toast.error(msg, propTypes);
    }
        
}

module.exports = Toaster;
