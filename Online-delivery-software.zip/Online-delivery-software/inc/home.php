<?php
/**
 * Updates Module custom post type
 */
add_action('init', 'home_post_type_register');
function home_post_type_register() {
	register_post_type( 'home' ,
						array(
							'label' => 'Page Settings',
							'singular_label' => 'home',
							'public' => true,
							'show_ui' => true,
							//'menu_icon' => get_stylesheet_directory_uri() . '/images/testimonials-icon.png', 
							'capability_type' => 'post',
							'hierarchical' => false,
							'rewrite' => true,
							'show_in_nav_menus' => true,
							'supports' => array('title','thumbnail','editor')
						)
					);

	add_filter('manage_edit-home_columns', 'home_edit_columns');

	function home_edit_columns($columns){
		$columns = array(
			'cb' 	=> '<input type="checkbox" />',
			'title' => 'home page',
			'author'=> 'Author',
			'date'	=>'Date'
		);

		return $columns;
	}
}

/* Set up the taxonomies. */ 
add_action( 'init', 'home_taxonomies', 0);
/* Registers taxonomies. */
function home_taxonomies() { 
	/* Set up the artist taxonomy arguments. */ 
	$category_args = array( 
	'hierarchical' => true,
	'query_var' => true,
	'show_ui' => true,
	'show_in_nav_menus' => false,
	'rewrite' => array(
	'slug' => 'home'),
	'labels' => array(
	'name' => 'home Category',
	'singular_name' => 'home Category',
	'edit_item' => 'Edit Category',
					'update_item' => 'Update Category',
					'add_new_item' => 'Add New Category',
					'new_item_name' => 'New Category',
					'all_items' => 'All Categories',
					'search_items' => 'Search Category',
					'parent_item' => 'Parent Category',
					'parent_item_colon' => 'Parent Category:',
					),
	);
	/* Register the technology taxonomy. */
	register_taxonomy( 'home_category', array('home'), $category_args );
}


?>