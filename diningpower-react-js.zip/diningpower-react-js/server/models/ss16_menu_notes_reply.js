/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16MenuNotesReply', {
    menuNotesReplyId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'menu_notes_reply_id'
    },
    menuNotesId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'menu_notes_id'
    },
    title: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'title'
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'message'
    },
    menuNotesReplyStatus: {
      type: DataTypes.ENUM('Active','Inactive','Delete'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'menu_notes_reply_status'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    }
  }, {
    tableName: 'ss16_menu_notes_reply'
  });
};
