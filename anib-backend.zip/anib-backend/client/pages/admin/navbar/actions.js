'use strict';
const ApiActions = require('../../../actions/api');
const Constants = require('./constants');
const Store = require('./store');


class Actions {
    
    static navToggle(value) {

        Store.dispatch({
            type: Constants.TOGGLE_NAVBAR,
            value: value
        });
    }

    static toggleOpen(value) {

        Store.dispatch({
            type: Constants.TOGGLE_OPEN,
            value: value
        });
    }

    static getUser(data) {
        
        ApiActions.get(
            '/user/profile',
             undefined,
             Store,
             Constants.GET_USER_ADMIN,
             Constants.GET_USER_ADMIN_RESPONSE,
            
        );
    }

}


module.exports = Actions;
