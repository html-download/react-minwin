'use strict'
import { createStore } from 'redux';
import Constants from './constants.jsx';
const initialState ={
 first_name: "foodi",
 last_name: "reactapp",
 email_id: "foodi@gmail.com",
 phone_number:	"9784648464",
 showPassword: false,
 startDate: new Date(),
 selectedOption: null,
 
}

const reducer = function(state = initialState, action){
  
	if(action.type === Constants.GET_PROFILE_RESPONSE) {

		return Object.assign(state, {first_name: action.value});
	}

  return state;
 }

const store = createStore(reducer, initialState);

export default store;