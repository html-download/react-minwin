'use strict';
const Actions = require('./actions');
const Alert = require('../../../../components/alert.jsx');
const CommonStore = require('../../common-store/store');
const PropTypes = require('prop-types');
const React = require('react');
const SelectControl = require('../../../../components/form/select-control.jsx');

const propTypes = {
    id: PropTypes.string,
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    loading: PropTypes.bool
};


class AssignDetailsForm extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};

        this.state = {
            id: props.id,
            user_id: props.user_id,
            user_name: props.user_name,
            editable_field: props.editable_field
        };

        this.getUpdateButton = this.getUpdateButton.bind(this);
        this.getLabelContent = this.getLabelContent.bind(this);
        this.addEditable = this.addEditable.bind(this);
        this.submitCustomer = this.submitCustomer.bind(this);
        this.getUserOptions = this.getUserOptions.bind(this);
    }

    componentWillReceiveProps(nextProps) {

        this.setState({
            id: nextProps.id,
            user_id: nextProps.user_id,
            user_name: nextProps.user_name,
            editable_field: nextProps.editable_field
        });

        //(this.input[nextProps.editable_field]) ? this.input[nextProps.editable_field].focus() : null;
    }

    submitCustomer(event, field_name) {
        

        event.preventDefault();
        event.stopPropagation();

        let value = (this.input[field_name]) ? this.input[field_name].value() : undefined;

        const id = this.props.deal_id;
        const data = {
            'attribute_key': field_name,
            'attribute_value': value
        };


        value ? Actions.saveDealDetails(id, data) : null;
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

    }

    addEditable(field) {
        Actions.addEditable(field)
    }

    getUpdateButton(field){
        return (
            <div className="editable-buttons">
                <button type="submit" onClick={ (e) => { this.submitCustomer(e, field) }} className="btn btn-primary btn-sm editable-submit"><i className="glyphicon glyphicon-ok"></i></button>
                <button type="button" onClick={ (e) => { Actions.removeEditable(field) }} className="btn btn-default btn-sm editable-cancel"><i className="glyphicon glyphicon-remove"></i></button>
            </div>
        )
    }

    getLabelContent(name, field, value, type) {
        return (
            <div className="form-gp">
                <label className="side">{name}</label>
                <div className="side-input">
                    { 
                        (value && value !== '') ? (
                            <a data-name={value} className="add-forms" data-type={type} onClick={ (e) => { this.addEditable(field) }} >{value}</a>
                        ) : (
                            <a className="add-forms editable editable-click editable-empty" onClick={ (e) => { this.addEditable(field) }} >+Add</a>
                        )
                    }
                </div>
            </div>
        )
    }

    getUserOptions() {

        const user_datas = CommonStore.getState().user_data ? CommonStore.getState().user_data : [];
        
        if (user_datas.length === 0) { 
            return null;
        }
        const data = user_datas.map((user_data, index) => {

            return <option
                    key={`user_data-option-${index}`} 
                    value={user_data.user_key}
                    data-tokens={`${user_data.first_name}`}>
                    {`${user_data.first_name}`}
                </option>;
        });
        return data;
    }

    render() {

        const alerts = [];

        if (this.props.error) {
            alerts.push(<Alert
                key="danger"
                type="danger"
                message={this.props.error}
            />);
        }

        const formElements = <fieldset>
            {
                this.props.editable_field === 'user_id' ? (
                    <SelectControl
                        ref={(c) => (this.input.user_id = c)}
                        name="user_id"
                        label="Assigned to"
                        defaultValue={this.props.user_id}
                        onChange={() => {}}
                        hasError={this.props.hasError.user_id}
                        help={this.props.help.user_id}
                        disabled={this.props.loading}
                        groupClasses={{'form-group': true, 'form-gp': true}}
                        labelClasses={{'control-label': false, 'side': true}}
                        inputClasses={{'form-control': true, 'add-forms': true, 'select-modal': true}}
                        appendElement={this.getUpdateButton('user_id')}
                        appendElementNotString={true}
                    >   
                        <option value="">Select Option</option>
                        { this.getUserOptions() }
                    </SelectControl>
                ) : this.getLabelContent('Assigned to:', 'user_id', this.props.user_name, 'select')
            }
            
        </fieldset>;

        let state = this.state;
        return (
            
            <div className={ `top-head-deal ${!this.props.hydrated ? 'loader-tab-content' : ''}` }>
                <div className="row">
                    <div className="col-md-6">

                        <form onSubmit={this.handleSubmit.bind(this)}>
                            {alerts}
                            {formElements}
                        </form>
                    </div>
                    <div className="col-md-6 text-right">
                        <button className="btns outline-danger" style={{'display': 'none'}}>Mark as Lost</button>
                    </div>
                </div>
            </div>
        );
    }
}

AssignDetailsForm.propTypes = propTypes;


module.exports = AssignDetailsForm;
