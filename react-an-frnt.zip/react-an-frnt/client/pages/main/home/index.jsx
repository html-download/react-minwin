"use strict";
const Actions = require("./actions");
const Config = require("../../../../config");
const QuoteModalForm = require("./quote-modal-form");
const React = require("react");
const ReactHelmet = require("react-helmet");
const ReactRouter = require("react-router-dom");
const Store = require("./store");

import Slider from "react-slick";
import ScrollAnimation from 'react-animate-on-scroll';

const Helmet = ReactHelmet.Helmet;
const Link = ReactRouter.Link;

class HomePage extends React.Component {
  constructor(props) {
    super(props);

    this.state = Store.getState();
  }

  componentDidMount() {
    this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    window.scrollTo(0, 0);
  }

  componentWillUnmount() {
    this.unsubscribeStore();
  }

  onStoreChange() {
    this.setState(Store.getState());
  }

  render() {
    function SampleNextArrow(props) {
      const { className, style, onClick } = props;
      return (
        <div className={className} onClick={onClick}>
          <i className="fa fa-angle-right" />
        </div>
      );
    }

    function SamplePrevArrow(props) {
      const { className, style, onClick } = props;
      return (
        <div className={className} onClick={onClick}>
          <i className="fa fa-angle-left" />
        </div>
      );
    }

    const settings = {
      dots: false,
      infinite: true,
      slidesToShow: 5,
      autoplay: true,
      speed: 500,
      autoplaySpeed: 1500,
      slidesToScroll: 1,
      nextArrow: <SampleNextArrow />,
      prevArrow: <SamplePrevArrow />,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 4
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            initialSlide: 3
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2
          }
        }
      ]
    };

    const TestimonialSettings = {
      dots: true,
      infinite: true,
      slidesToShow: 1,
      autoplay: false,
      speed: 500,
      autoplaySpeed: 500,
      slidesToScroll: 1,
      nextArrow: <SampleNextArrow />,
      prevArrow: <SamplePrevArrow />
    };

    return (
      <div>
        <Helmet>
          <title>{Config.get("/projectName")} - Home</title>
        </Helmet>
        <section className="banner text-center">
          <div className="container">
            <div className="d-table">
              <div className="d-table-cell">
              <ScrollAnimation animateIn="fadeInDown">
                <h1 className="text-white">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.{" "}
                </h1>
                </ScrollAnimation>
                <button
                  style={{ display: "none" }}
                  onClick={e => {
                    Actions.openQuoteModal();
                  }}
                  className="btn btn-primary fadeInUp wow lg"
                >
                  Get Quotes
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="brand text-center">
          <div className="container">
            <div className="box">
              <h2 className="hm_heading">
                Choose from the best insurers in the UAE{" "}
              </h2>
              <Slider {...settings} className="client-slide">
                <div className="item">
                  <img
                    src="/public/media/images/cl1.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl2.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl3.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl4.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl5.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl2.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl3.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl4.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
                <div className="item">
                  <img
                    src="/public/media/images/cl5.png"
                    alt="client"
                    className="zoomIn wow"
                  />
                </div>
              </Slider>
            </div>
          </div>
        </section>
        <section className="brokers-today text-center res-broker">
          <div className="container">
          <ScrollAnimation animateIn="fadeInUp">
            <h2 className="hm_heading">
              Consult with our car & motor insurance brokers today{" "}
            </h2>
            </ScrollAnimation>
            <div className="row">
              <div className="col-sm-4">
              <ScrollAnimation animateIn="zoomIn">
                <div className="box">
                  <div className="icon">
                    <img src="/public/media/images/ic1.png" />
                  </div>
                  <h3>Choose Car Insurance</h3>
                  <p>
                    Lorem ipsum dolor sit amet, adipiscing elit. Aenean commodo
                    ligula eget dolor.
                  </p>
                </div>
                </ScrollAnimation>
              </div>

              <div className="col-sm-4">
              <ScrollAnimation animateIn="zoomIn">
                <div className="box">
                  <div className="icon">
                    <img src="/public/media/images/ic2.png" />
                  </div>
                  <h3>Decide the Payment Method</h3>
                  <p>
                    Lorem ipsum dolor sit amet, adipiscing elit. Aenean commodo
                    ligula eget dolor.
                  </p>
                </div>
                </ScrollAnimation>
              </div>

              <div className="col-sm-4">
              <ScrollAnimation animateIn="zoomIn">
                <div className="box">
                  <div className="icon">
                    <img src="/public/media/images/ic3.png" />
                  </div>
                  <h3>Policy at your door step</h3>
                  <p>
                    Lorem ipsum dolor sit amet, adipiscing elit. Aenean commodo
                    ligula eget dolor.
                  </p>
                </div>
                </ScrollAnimation>
              </div>
            </div>
          </div>
        </section>

        <section className="best-car-needs">
        
          <div className="img">
          <ScrollAnimation animateIn="zoomIn">
            <img src="/public/media/images/car-needs.png" />
            </ScrollAnimation>
          </div>
          
          <div className="container-fluid">
            <div className="row">
              <div className="col-md-6" />
              <div className="col-md-6 padd-adjust">
              <ScrollAnimation animateIn="fadeInUp">
                <h2>
                  Find the best car & motor insurance in Dubai for your unique
                  needs
                </h2>
                </ScrollAnimation>
                <ScrollAnimation animateIn="fadeInUp">
                <ul className="ul_style">
                  <li>
                    With a large number of recognized car and motor insurance
                    companies in Dubai, sorting out various policies to find the
                    most suitable one can be quite a challenge and a daunting
                    task.
                  </li>
                  <li>
                    That is why at {Config.get("/projectName")}, we lend our
                    expertise to clients and advise them on which insurance
                    provider and policy can best meet their needs and
                    expectations.
                  </li>
                  <li>
                    Our team will help you identify and acquire a policy that
                    perfectly fits your requirements and your profile – age,
                    car, budget, driving record – so you have peace of mind
                    whenever you sit behind the wheel.
                  </li>
                  <li>
                    Based on this information, we will help you select and
                    compare policies to find the one that best suits your
                    specific needs and budget.
                  </li>
                </ul>
                </ScrollAnimation>
              </div>
            </div>
          </div>
        </section>

        <section className="profile-content">
          <div className="container">
          <ScrollAnimation animateIn="fadeInUp">
            <h2 className="text-center">
              {Config.get("/projectName")}
            </h2>
            </ScrollAnimation>
            <div className="row">
              <div className="col-md-4">
              <ScrollAnimation animateIn="zoomIn">
                <div className="box">
                  <div className="icon">
                    <i className="fa fa-user-circle" aria-hidden="true" />
                  </div>
                  <h4>{Config.get("/projectName")} Profile</h4>
                  <p>
                    Pellentesque volutpat gravida varius. Pellentesque posuere
                    rhoncus porta. Pellentesque nec maximus mauris. Vestibulum
                    pretium mattis diam vel aliquam. Maecenas vel elit rhoncus,
                    lobortis nulla quis, maximus tellus.
                  </p>
                </div>
                </ScrollAnimation>
              </div>
              <div className="col-md-4">
              <ScrollAnimation animateIn="zoomIn">
                <div className="box">
                  <div className="icon">
                    <i className="fa fa-pencil-square-o" aria-hidden="true" />
                  </div>
                  <h4>A Success Story</h4>
                  <p>
                    Pellentesque volutpat gravida varius. Pellentesque posuere
                    rhoncus porta. Pellentesque nec maximus mauris. Vestibulum
                    pretium mattis diam vel aliquam. Maecenas vel elit rhoncus,
                    lobortis nulla quis, maximus tellus.
                  </p>
                </div>
                </ScrollAnimation>
              </div>
              <div className="col-md-4">
              <ScrollAnimation animateIn="zoomIn">
                <div className="box">
                  <div className="icon">
                    <i className="fa fa-lightbulb-o" aria-hidden="true" />
                  </div>
                  <h4>What we do?</h4>
                  <p>
                    Pellentesque volutpat gravida varius. Pellentesque posuere
                    rhoncus porta. Pellentesque nec maximus mauris. Vestibulum
                    pretium mattis diam vel aliquam. Maecenas vel elit rhoncus,
                    lobortis nulla quis, maximus tellus.
                  </p>
                </div>
                </ScrollAnimation>
              </div>
            </div>
          </div>
        </section>

        <section className="clients-say">
          <div className="container relative">
          <ScrollAnimation animateIn="fadeInRight">
            <h2>
              <span>Some Of Inspiration</span> What Our Client Say
            </h2>
            </ScrollAnimation>
            <Slider {...TestimonialSettings} className="client-owlcarosel">
              <div className="item-box full_row">
                <div className="user-information">
                  <div className="white-box">
                  <ScrollAnimation animateIn="zoomIn">
                    <img
                      src="/public/media/images/user-image.jpg"
                    />
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="fadeInUp">
                    <h4>Mohammed Tawfiq</h4>
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="fadeInUp">
                    <p>Finance Manager</p>
                    </ScrollAnimation>
                  </div>
                </div>
                <div className="user-content">
                <ScrollAnimation animateIn="fadeInUp">
                  <p>
                    <i className="fa fa-quote-left" aria-hidden="true" />
                    Pellentesque volutpat gravida varius. Pellentesque posuere
                    rhoncus porta. Pellentesque nec maximus mauris. Vestibulum
                    pretium mattis diam vel aliquam. Maecenas vel elit rhoncus,
                    lobortis nulla quis, maximus tellus.
                    <i className="fa fa-quote-right" aria-hidden="true" />
                  </p>
                  </ScrollAnimation>
                </div>
              </div>

  <div className="item-box full_row">
                <div className="user-information">
                  <div className="white-box">
                  <ScrollAnimation animateIn="zoomIn">
                    <img
                      src="/public/media/images/user-image.jpg"
                    />
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="fadeInUp">
                    <h4>Mohammed Tawfiq</h4>
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="fadeInUp">
                    <p>Finance Manager</p>
                    </ScrollAnimation>
                  </div>
                </div>
                <div className="user-content">
                <ScrollAnimation animateIn="fadeInUp">
                  <p>
                    <i className="fa fa-quote-left" aria-hidden="true" />
                    Pellentesque volutpat gravida varius. Pellentesque posuere
                    rhoncus porta. Pellentesque nec maximus mauris. Vestibulum
                    pretium mattis diam vel aliquam. Maecenas vel elit rhoncus,
                    lobortis nulla quis, maximus tellus.
                    <i className="fa fa-quote-right" aria-hidden="true" />
                  </p>
                  </ScrollAnimation>
                </div>
              </div>


  <div className="item-box full_row">
                <div className="user-information">
                  <div className="white-box">
                  <ScrollAnimation animateIn="zoomIn">
                    <img
                      src="/public/media/images/user-image.jpg"
                    />
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="fadeInUp">
                    <h4>Mohammed Tawfiq</h4>
                    </ScrollAnimation>
                    <ScrollAnimation animateIn="fadeInUp">
                    <p>Finance Manager</p>
                    </ScrollAnimation>
                  </div>
                </div>
                <div className="user-content">
                <ScrollAnimation animateIn="fadeInUp">
                  <p>
                    <i className="fa fa-quote-left" aria-hidden="true" />
                    Pellentesque volutpat gravida varius. Pellentesque posuere
                    rhoncus porta. Pellentesque nec maximus mauris. Vestibulum
                    pretium mattis diam vel aliquam. Maecenas vel elit rhoncus,
                    lobortis nulla quis, maximus tellus.
                    <i className="fa fa-quote-right" aria-hidden="true" />
                  </p>
                  </ScrollAnimation>
                </div>
              </div>

              
            </Slider>
          </div>
        </section>
        <QuoteModalForm {...this.state} />
      </div>
    );
  }
}

module.exports = HomePage;
