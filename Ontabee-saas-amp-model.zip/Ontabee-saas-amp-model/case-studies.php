<?php include ('inc/header.php'); ?>

<div class="page_banner style2 bg1">
	<div class="container">
		<h1 class="head wow fadeInDown">Case Studies</h1>
		<h2 class="head small wow fadeInUp">Perfect Place to Launch Your Online Food Ordering Software</h2>
	</div> <!--container-->
</div> <!--page_banner-->	
	
<section class="grey">
	<div class="container">
		<ul class="case-study">
			<li>
				<div class="content">
					<p class="img"><img src="images/case-study/shuneezfsc.jpg" alt="Shuneezfsc"></p>
					<div>
						<h3>Shuneezfsc</h3>
						<p class="tag">
							<span class="web">Web Development</span>
							<span class="android">Android</span>
							<span class="ios">iOS</span>
						</p>
						<p>Shuneezfsc is a fast food restaurant company which is privately held in Saudi Arabia. From the date of originated, Shuneezfc has achieved best compliments for satisfying the customer of many with...</p>
						<a href="case-study/shuneezfsc" class="btn grey">Read More</a>
					</div>
				</div>
			</li>
			<li>
				<div class="content">
					<p class="img"><img src="images/case-study/hungrybunny.jpg" alt="Hungry Bunny"></p>
					<div>
						<h3>Hungry Bunny</h3>
						<p class="tag">
							<span class="web">Web Development</span>
							<span class="android">Android</span>
							<span class="ios">iOS</span>
						</p>
						<p>Hungry Bunny had come to the restaurant business with the vision to serve best quality food with delicious taste. Hungry Bunny, a Saudi specialty restaurant, has served delicious dishes to their customer...</p>
						<a href="case-study/hungrybunny" class="btn grey">Read More</a>
					</div>
				</div>
			</li>
		</ul>
	</div>
</section>

<?php include('inc/footer.php');?>