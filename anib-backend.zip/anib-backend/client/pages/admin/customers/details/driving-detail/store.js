'use strict';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');
const Redux = require('redux');


const initialState = {

    /** Loaders and Toast messages */
    hydrating: true,
    loading: false,

    error: undefined,    /** Error text */
    hasError: {}, /** Has error for field */
    help: {},
    
    customer_driving_profile_key: undefined, /** Customer Driving ID */

    editable_field: undefined, /** editable field */


    /** Form Data */
    first_license_country_id: undefined,
    first_license_country_name: undefined,
    first_license_age: undefined,
    first_license_age_text: undefined,
    uae_license_age: undefined,
    first_license_issue_date: undefined,
    uae_license_issue_date: undefined,
    driver_dob: undefined,

    /** Dropdown Data */
    country_data:[],
    first_licence_age_data: []
};
const reducer = function (state = initialState, action) {

    switch (action.type) {
        case Constants.DRIVING_DETAILS:
            return ObjectAssign({}, state, {
                hydrating: true,
                loading: true
            });
            break;
        case Constants.DRIVING_DETAILS_RESPONSE:

            const validation = ParseValidation(action.response);
            const data = (action.response && action.response.data) ? action.response.data : {};
            const stateUpdates = {
                loading: false,
                hydrating: false,
                error: validation.error,
                hasError: validation.hasError,
                help: validation.help
            };
            if (action.response && action.response.status === 200) {
                stateUpdates.customer_driving_profile_key = data.customer_driving_profile_key ? data.customer_driving_profile_key : undefined;
                stateUpdates.first_license_country_id = data.first_license_country_id ? data.first_license_country_id : undefined;
                stateUpdates.first_license_country_name = data.country_name ? data.country_name : undefined;
                stateUpdates.first_license_age = data.first_license_age ? data.first_license_age : undefined;
                stateUpdates.first_license_age_text = data.first_license_age_text ? data.first_license_age_text : undefined;
                stateUpdates.first_license_issue_date = data.first_license_issue_date ? data.first_license_issue_date : undefined;
                stateUpdates.uae_license_age = data.uae_license_age ? data.uae_license_age : undefined;
                stateUpdates.uae_license_issue_date = data.uae_license_issue_date ? data.uae_license_issue_date : undefined;
                stateUpdates.driver_dob = data.driver_dob ? data.driver_dob : undefined;
                stateUpdates.driver_name = data.driver_name ? data.driver_name : undefined;
                stateUpdates.license_number = data.license_number ? data.license_number : undefined;
            }
            return ObjectAssign({}, state, stateUpdates);
            break;
        case Constants.DISABLE_LOADER:
            return ObjectAssign({}, state, {
                hydrating: false
            });
            break;
        case Constants.EDITABLE_SHOW:
            return ObjectAssign({}, state, {
                editable_field: action.field
            });
            break;
        case Constants.EDITABLE_HIDE:
            return ObjectAssign({}, state, {
                editable_field: undefined
            });
            break;
        case Constants.GET_COUNTRY_RESULTS:

            return ObjectAssign({}, state, {
                country_data: []
            });
            break;
        case Constants.GET_COUNTRY_RESULTS_RESPONSE:
            return ObjectAssign({}, state, {
                country_data: action.response.data
            });
            break;
        case Constants.GET_DRIVING_EXPERIENCE_RESULTS:
            return ObjectAssign({}, state, {
                first_licence_age_data: []
            });
            break;
        case Constants.GET_DRIVING_EXPERIENCE_RESULTS_RESPONSE:
            const experiencedata = (action.response && action.response.data) ? action.response.data : [];
            return ObjectAssign({}, state, {
                first_licence_age_data: experiencedata ? experiencedata : []
            });
            break;
        case Constants.UPDATE_DATE_FIELD:

            switch (action.field) {
                case 'uae_license_issue_date':
                    return ObjectAssign({}, state, {
                        uae_license_issue_date : action.date
                    });
                    break; 
                case 'first_license_issue_date':
                    return ObjectAssign({}, state, {
                        first_license_issue_date : action.date
                    });
                    break;
                case 'driver_dob':
                    return ObjectAssign({}, state, {
                        driver_dob : action.date
                    });
                    break;
                default:
                    break;
            }
            break;
        default:
            return state;
            break;
    }
};


module.exports = Redux.createStore(reducer);
