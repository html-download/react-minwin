/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16AuthAssignment', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'id'
    },
    itemName: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'item_name'
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'user_id'
    },
    controllerId: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'controller_id'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    createdAt: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_at'
    },
    updatedAt: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'updated_at'
    }
  }, {
    tableName: 'ss16_auth_assignment'
  });
};
