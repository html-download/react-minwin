/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16VendorCriteriaPrice', {
    criteriaId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'criteria_id'
    },
    menuId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'menu_id'
    },
    criteriaPercentage: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'criteria_percentage'
    },
    criteriaValue: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'criteria_value'
    },
    startPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'start_price'
    },
    endPrice: {
      type: DataTypes.DECIMAL,
      allowNull: true,
      field: 'end_price'
    },
    status: {
      type: DataTypes.ENUM('Active','Deactive'),
      allowNull: false,
      field: 'status'
    },
    scenario: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'scenario'
    }
  }, {
    tableName: 'ss16_vendor_criteria_price'
  });
};
