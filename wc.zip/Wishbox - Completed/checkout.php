<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <section class="checkout-notification">
    <div class="container">
      <ul class="reset">
        <li class="focus"><span><i>1</i> Account Info</span></li>
        <li><span><i>2</i> Delivery Type</span></li>
        <li><span><i>3</i> Payment Method</span></li>
        <li><span><i>4</i> Order Confirmation</span></li>
      </ul>
      <!-- ul end -->
    </div>
    <!-- container -->
  </section>
  <!-- checkout notification -->
  <section class="checkout-page-content">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">
          <!-- full-row -->
          <div class="full_row">
            <!-- checkout box -->
            <div class="checkout-box">
              <i class="fi user1 icon-side"></i>
              <!-- boxed -->
              <div class="boxed">
                <!-- c title -->
                <div class="c-title">
                  <h3>Account Info</h3>
                  <p>To place your order now, log in to your existing account or sign up.</p>
                </div>
                <!-- c title -->
                <!-- before login -->
                <div class="before-login">
                  <button class="btn btn-outline-primary" onclick="location.href='/checkout-login';">
                  Have an account?<span class="full">LOG IN</span>
                  </button>
                  <button class="btn btn-primary" onclick="location.href='/checkout-login';">
                  New to Wishbox?<span class="full">SIGN UP</span>
                  </button>
                </div>
                <!-- before login -->
                <!-- guets login -->
                <div class="guest-login">
                  <!-- or -->
                  <div class="or-full"><span>OR</span></div>
                  <!-- or -->
                  <div class="c-title mb25">
                    <h3>Guest Login</h3>
                    <p>To place your order now, log in to your existing account or sign up.</p>
                  </div>
                  <!-- form box -->
                  <div class="form-box">
                    <!-- row -->
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group icon">
                          <label for="lename"><i class="fi user1"></i><span>Name</span></label>
                          <input id="lename" type="text" class="form-control">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group icon">
                          <label for="leemail"><i class="fi mail"></i><span>Email Id</span></label>
                          <input id="leemail" type="email" class="form-control">
                        </div>
                      </div>
                    </div>
                    <!-- row -->
                    <!-- row -->
                    <div class="row">
                      
                      <div class="col-sm-6">
                        <div class="form-group icon">
                          <label for="letell"><i class="lni-mobile"></i><span>Mobile Number</span></label>
                          <input id="letell" type="text" class="form-control">
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="btn-center">
                      <button class="btn grey w-100">Guest Login</button>
                    </div>
                        </div>
                    </div>
                    <!-- row -->
                    <!-- btn -->
                    
                  </div>
                  <!-- form box -->
                </div>
                <!-- guets login -->
              </div>
              <!-- boxed -->
            </div>
            <!-- checkout box -->
            <!-- checkout box -->
            <div class="checkout-box deactive">
              <i class="fi pin3 icon-side"></i>
              <!-- boxed -->
              <div class="boxed">
                <!-- c title -->
                <div class="c-title">
                  <h3>Delivery Type</h3>
                  <p>You can choose your delivery type here.</p>
                </div>
                <!-- c title -->
              </div>
              <!-- boxed -->
            </div>
            <!-- checkout box -->
            <!-- checkout box -->
            <div class="checkout-box deactive">
              <i class="fi wallet2 icon-side"></i>
              <!-- boxed -->
              <div class="boxed">
                <!-- c title -->
                <div class="c-title">
                  <h3>Payment Option</h3>
                  <p>You can choose your payment method to place order.</p>
                </div>
                <!-- c title -->
              </div>
              <!-- boxed -->
            </div>
            <!-- checkout box -->
          </div>
          <!-- full-row -->
        </div>
        <!-- col-sm-8 -->
        <div class="col-sm-4">
          <div class="side_bar_cart">
            <ul class="mini_cart">
              <li class="vendor">
                <h5>Ananas Restaurant & Cafeteria</h5>
                <span>Abu Hamour</span>
              </li>
              <li class="item">                
                <p><img src="assets/img/non-veg.svg">Super Spicy Sandwich</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>    
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->      
                <a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
                <span class="price">QR 20</span>
              </li>
              <li class="item">                
                <p><img src="assets/img/veg.svg">Chicken Biryani + Fried Leg + Pepsi</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>    
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->
                <span class="price">QR 20</span>
              </li>
              <li class="item">
                <p><img src="assets/img/non-veg.svg">Ghee Rice + Pepper Chicken</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>    
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->      
                <a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
                <span class="price">QR 20</span>
              </li>
              <li class="item">                
                <p><img src="assets/img/non-veg.svg">Mutton Biryani + Fried Leg + Pepsi 1/2</p>
                <div class="qty_box small float-left">
                  <span><i class="la la-minus"></i></span>    
                  <input type="text" class="form-control" value="2" readonly="">
                  <span><i class="la la-plus"></i></span>
                </div>
                <!--qty_box-->      
                <a class="customize" data-toggle="modal" data-target="#modal_choice">Edit<i class="la la-angle-down"></i></a>
                <span class="price">QR 20</span>
              </li>
            </ul>
            <!-- bill details -->
            <div class="bill-details">
              <div class="any-comments">
                <!-- any comments -->
                <div class="form-group">
                  <!-- formgroup -->
                  <textarea class="form-control" placeholder="Any comments? We will pass it to restaurant..."></textarea>
                </div>
              </div>
              <!-- any comments -->
              <!-- smile points -->
              <div class="smile-points">
                <p class="b">Smile Points</p>
                <span>Available Points - 150 <i class="info3 fi"></i> </span>
                <button class="redeem">REDEEM</button>
              </div>
              <!-- smile points -->
              <!-- Promocode -->
              <div class="promocode">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="PROMO CODE">
                  <div class="input-group-append">
                    <button class="btn btn-grey" type="button">APPLY</button>
                  </div>
                </div>
                <!-- Promocode -->
                <!-- text right -->
                <div class="text-right">
                  <a href="#apply-coupon" data-toggle="modal" data-target="#apply-coupon" class="primary-underline">Available Offers</a>
                </div>
                <!-- text right -->
              </div>
              <!-- Promocode -->
              <div class="bill-content">
                <p class="text-black">Bill Details</p>
                <p>Sub Total <span>QR 80</span></p>
                <p>Delivery Charge <span>QR 15</span></p>
                <p>Packaging Charge <span>QR 15</span></p>
                <p class="pink">Discount Value <span>- QR 10</span></p>
                <p class="pink">Smile Points <span>- QR 15</span></p>
                <p class="total">Total Amount <span>- QR 15</span></p>
              </div>
            </div>
            <!-- bill details -->
          </div>
          <!-- sidebar cart -->
        </div>
        <!-- col-sm-4 -->
      </div>
      <!-- row -->
    </div>
  </section>
</div>
<!--site_page-->
<!-- apply coupon -->
<div id="apply-coupon" class="modal available-Offers-modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <a class="close-modal" data-dismiss="modal"><i class="fi close"></i></a>
      <div class="modal-body">
        <h2>Available Offers</h2>
        <ul class="offers-ul">
          <li>
            <div class="offer-box">
              <h3>Get 20% discount using YES Bank Cards</h3>
              <p>Use code YESBANK20 and get 20% discount up to Rs.75 on orders above Rs.300. Valid only on Wednesday & Thursday</p>
              <div class="flex">
                <div class="ticket">YESBANK20</div>
                <button class="btn line">APPLY COUPON</button>
              </div>
            </div>
          </li>
          <li>
            <div class="offer-box">
              <h3>Get 30% discount using Mastercard</h3>
              <p>Use code MASTERCARD100 & get 30% discount up to Rs.100 on your 2 orders above Rs.99</p>
              <div class="flex">
                <div class="ticket">MASTERCARD100</div>
                <button class="btn line">APPLY COUPON</button>
              </div>
            </div>
          </li>
          <li>
            <div class="offer-box">
              <h3>Get 20% discount using Lakshmi Vilas Bank Cards</h3>
              <p>Use code LVB20 & get 20% discount up to Rs.50 on your orders above Rs.200</p>
              <div class="flex">
                <div class="ticket">LVB20</div>
                <button class="btn line">APPLY COUPON</button>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <!--modal-body-->
    </div>
    <!--modal-content-->
  </div>
  <!--modal-dialog-->
</div>
<!-- apply coupon -->
<?php include ('inc/footer.php'); ?>
