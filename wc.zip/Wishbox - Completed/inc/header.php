<!DOCTYPE HTML>
<html lang="en"> 
<head>
	<meta charset="UTF-8"/>
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>	
	<title>WishBox</title>
	<link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon" />
	<link href="https://fonts.googleapis.com/css?family=Ubuntu:300,400,500,700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="/assets/css/datepicker.min.css" type="text/css">
	<link rel="stylesheet" href="/assets/css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="/assets/css/style.css" type="text/css">	
	<link rel="stylesheet" href="/assets/css/bootstrap-select.min.css" type="text/css">
	<link rel="stylesheet" href="/assets/css/owl.carousel.min.css" type="text/css">
	<link rel="stylesheet" href="/assets/css/popup.css" type="text/css">	
	<link rel="stylesheet" href="/assets/css/line-awesome.css" type="text/css">
	<link rel="stylesheet" href="/assets/css/LineIcons.css" type="text/css">
	<link rel="stylesheet" href="/assets/css/flaticon.css" type="text/css">		
	<script src="../assets/js/jquery.min.js"></script>
</head>

<?php $page = explode('/', $_SERVER['REQUEST_URI'])[1];?>

<body class="<?php if($page == 'index' || $page == '') {echo 'home';} if($page == 'restaurant' || $page == 'restaurant?' || $page == 'restaurant-detail' || $page == 'grocery' || $page == 'grocery-detail' ||$page == 'laundry' ||$page == 'laundry-detail' ||$page == 'services'||$page == 'services-detail') {echo 'listing';} if($page == 'restaurant-detail'|| $page == 'grocery-detail' ||$page == 'laundry-detail' ||$page == 'services-detail') {echo ' detail_page';}?>">

<header class="site_header">
	<div class="container">
		<div class="site_logo float-left">
			<a href="/index"><img src="/assets/img/logo.png" alt="Logo"></a>			
		</div> <!--site_logo-->

		<div class="location form-group icon">
			<label for="search_location"><i class="fi pin3"></i></label>
            <input type="text" id="search_location" class="form-control" value="Abu Hamour">
		</div> <!--location-->

		<div class="header_right float-right">
			<ul class="top_menu float-left">
				<li class="dropdown how_works"><a data-toggle="dropdown"><i class="la la-question-circle"></i>How it Works</a>
					<div class="dropdown-menu">
						<div class="tab-content full_row">
							<div id="how_it_works" class="tabs show full_row">
								<ul>
									<li>
										<i class="fi shopping-bag"></i>
										<h5 class="mb5">Place your order</h5>
										<p class="mb0 grey">Enter your address, find what you're looking for, and easily order from the best restaurants in the neighborhood.</p>
									</li>
									<li>
									<i class="fi shop"></i>
										<h5 class="mb5">We handle the rest</h5>
										<p class="mb0 grey">We work with the merchant to make sure everything is ready for delivery or pickup, Then we'll send you a confirmation.</p>
									</li>
									<li>
										<i class="fi delivery-box"></i>
										<h5 class="mb5">The merchant arrives...</h5>
										<p class="mb0 grey">...or you pick it up. Either way, you'll get 20 Delivery Points for every $1 spent, which you can cash in for awesome rewards.</p>
									</li>
									<li><a class="laundry_works">How laundry works <i class="la la-arrow-right"></i></a></li>
								</ul>
							</div> <!--how_works-->

							<div id="laundry_works" class="tabs full_row">
								<ul>
									<li>
										<i class="fi shop"></i>
										<h5 class="mb5">Pick a cleaner</h5>
										<p class="mb0 grey">Customize your service with wash & fold, dry cleaning, and tailoring options, and pick the best cleaner in your area based on convenience, reviews, and ratings.</p>
									</li>
									<li>
										<i class="fi clock2"></i>
										<h5 class="mb5">Schedule pickup and delivery</h5>
										<p class="mb0 grey">Easily arrange pickup and delivery times around your schedule, so that you can focus on the fun stuff and leave the laundry to the pros.</p>
									</li>
									<li>
										<i class="fi credit-card1"></i>
										<h5 class="mb5">Know what you're paying for</h5>
										<p class="mb0 grey">No need to count socks. Just send us your clothes and we'll update your bill based on what we receive.</p>
									</li>
									<li><a class="how_it_works">How food and groceries work <i class="la la-arrow-right"></i></a></li>
								</ul>
							</div> <!--laundry_works-->
						</div> <!--tab-content-->
					</div> <!--dropdown-menu-->
				</li>
				<li><a href="tel:+"><i class="fi call"></i><span>Toll Free</span> - 800 6242</a></li>
				<li class="login"><a data-toggle="modal" data-target="#modal_login"><i class="fi login1"></i>Log in / sign up</a></li>
			</ul>

			<div class="acc_menu float-left">
				<div class="dropdown">
					<a class="toggle" data-toggle="dropdown">Hi, Tamilvanan <i class="fi user1"></i></a>
					<ul class="dropdown-menu">
						<li><a href="my-account"><i class="la la-user"></i>My Account</a></li>
						<li><a href="orders-history"><i class="la la-clock-o"></i>Orders History</a></li>
						<li><a href="address-book"><i class="lni-map-marker"></i>Address Book</a></li>
						<li><a href="favorites"><i class="la la-heart-o"></i>Favorites</a></li>
						<li><a href="wallet"><i class="lni-wallet"></i>Wallet</a></li>
						<li><a href="smile-points"><i class="lni-emoji-smile"></i>Smile Points  (Bal. 50 Points)</a></li>
						<li><a href="ratings"><i class="lni-star"></i>Ratings & Reviews</a></li>
						<li><a href="saved-cards"><i class="la la-credit-card"></i>Saved Cards</a></li>
						<li><a href="notifications"><i class="la la-bell"></i>Notifications</a></li>
						<li><a href="/"><i class="la la-sign-out"></i>Sign Out</a></li>						
					</ul>
				</div> <!--dropdown-->

				<select class="selectpicker hide">
					<option data-icon="en">English</option>
					<option data-icon="ar">Arabic</option>
				</select>
			</div> <!--acc_menu-->
			
			<a class="hide" data-toggle="modal" data-target="#modal_login"><i class="fi user1"></i></a>
			<a class="top_cart float-left"><i class="fi shopping-bag"></i> <span>2</span></a>
		</div> <!--header_right-->
	</div> <!--container-->
</header> <!--site_header-->