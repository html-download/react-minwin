/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16PowerRewards', {
    rewardId: {
      type: DataTypes.INTEGER(10).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'reward_id'
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'customer_key'
    },
    rewardsScenario: {
      type: DataTypes.ENUM('Account Created'),
      allowNull: false,
      field: 'rewards_scenario'
    },
    rewardDesc: {
      type: DataTypes.STRING(500),
      allowNull: false,
      field: 'reward_desc'
    },
    rewardPts: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'reward_pts'
    },
    status: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'status'
    },
    createdUserId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_user_id'
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_at'
    },
    updatedUserId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'updated_user_id'
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'updated_at'
    }
  }, {
    tableName: 'ss16_power_rewards'
  });
};
