

<?php include ('inc/header.php'); ?>

<?php
$email = "";
$name = "";
if(isset($_POST['banner_email']))
	$email = $_POST["banner_email"];
if(isset($_POST['try_email'])) 
	$email = $_POST["try_email"];
if(isset($_POST['try_name']))
	$name = $_POST["try_name"];	
?>
	
<section class="signup">	
	<div class="container floating_label">		
			<a href="<?php echo $baseurl;?>" class="logo"><img itemprop="image" src="/images/logo.png" alt="Ontabee"></a>
			<form id="signup" method="post" name="signup" onsubmit="return false;" id="signup">				
				<h1 class="head small">Try <span>Ontabee</span></h1>
				<p>No credit card required. All features included. Immediate access</p>

				<?php /*
				<p class="tell_us">Tell us about few things to be needed<br>
					<img src="/images/rajesh.png" alt="Rajesh Prabhu" data-toggle="tooltip" title="Rajesh Prabhu">
					
				</p>
				*/ ?>
				
				<label for="fa_name" class="icon">Your name <span class="pull-right text-danger error fa_name"></span>
					<input type="text" name="fa_name" id="fa_name" class="form-control" required="required" value="<?php echo $name;?>">
					<i class="fa fa-user-o"></i>
				</label>
				<!-- <p class="input-text">Encourage you to enter your real name</p> -->
				
				<label for="fa_email" class="icon">Email Id<span class="pull-right text-danger error fa_email"></span>
					<input type="email" name="fa_email" id="fa_email" class="form-control" value="<?php echo $email;?>" required="required">
					<i class="fa fa-envelope-o"></i>
				</label>
				<!-- <p class="input-text">We won't spam you at all</p> -->
				
				<label for="fa_tel">Phone Number<span class="pull-right text-danger error fa_tel"></span>
					<input type="tel" name="fa_tel" id="fa_tel" class="form-control" required="required"> 
				</label>
				<!-- <p class="input-text">We can have detail discussion if you need</p> -->
				
				<label for="fa_category" class="icon">Who are you?<span class="pull-right text-danger error fa_category"></span>
						
                        <select class="form-control" id="fa_category" name="fa_category" required="required">
                            <option disabled="disabled" selected value="">Please Select Category</option>
                            <option value="Restaurant owner">Restaurant owner</option>
                            <option value="Partnership">Reseller</option>
                            <option value="Developers/Designers">Developers/Designers</option>
                            <option value="Student">Student</option>
                            <option value="Others">Others</option>
                        </select>
                       <i class="fa fa-user-o"></i>
                                       
				</label>
				
				<input type="hidden" name="fa_country" id="fa_country" value="">
				<input type="hidden" name="fa_dial" id="fa_dial" value="">
				<input type="hidden" name="fa_url" id="fa_url" value="">
				<input type="hidden" name="for_name" id="for_name" value="Signup">
				<label class="domain" for="fa_rn">Restaurant Name <span class="pull-right text-danger error fa_rn"></span>
					<span class="http">https://</span>
					<input type="text" name="fa_rn" id="fa_rn" class="form-control" required="required">
					<span class="domain">.ontabee.com</span>
				</label>
				<p class="input-text">Example (https://sample.ontabee.com)</p>
				<input type="submit" name="signupbutton" id="signupbutton" class="btn full mt20"  value="Create Now">
				
			</form>
			
			<div class="content">
				<h2 class="head">Why choose us?</h2>
				<ul class="reset list">
					<li>Experience( 4 Years in the market)</li>
					<li>Best in the industry</li>
					<li>Complete solution for your business (Customer app, Delivery app, Vendor app)</li>
					<li>Low cost</li>
					<li>Unique features</li>
					<li>Guaranteed support team </li>
					<li>No hidden cost</li>
					<li>Using Modern technology</li>
					<li>Software performance and reliability</li>
				</ul>
			</div> <!--content-->
	</div> <!--container-->
</section> <!--section-->

<script>
	$(document).ready(function() {

  }  



<?php include('inc/footer.php');?>