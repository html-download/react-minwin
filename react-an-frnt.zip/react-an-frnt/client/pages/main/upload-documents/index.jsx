"use strict";
const React = require("react");
const ReactHelmet = require("react-helmet");
const ReactRouter = require("react-router-dom");

const Link = ReactRouter.Link;
const Helmet = ReactHelmet.Helmet;

import { Button, Modal, ModalBody, ModalFooter } from "reactstrap";

class UploadDocumentsPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false
    };
    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  }

  componentDidMount() {    
    window.scrollTo(0, 0);
  }

  render() {
    return (
      <section>
        <Helmet>
          <title>Upload Documents</title>
        </Helmet>
        <section className="empty-banner" />
        <section className="light_bg upload_details">
          <div className="container">
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item">
                  <Link to="/choose-policy">Choose Policy</Link>
                </li>
                <li className="breadcrumb-item" aria-current="page">
                  <Link to="/order-summary">Order summary</Link>
                </li>
                <li className="breadcrumb-item active" aria-current="page">
                  Upload Documents
                </li>
              </ol>
            </nav>

            <h2 className="blue-heading text-center">Upload Documents</h2>
            <div className="white-box-shadow text-center">
              <h5 className="borderded">Upload the following documents</h5>
              <div className="box-container">
                <div className="row">
                  <div className="col-md-6">
                    <div className="uploads">
                      <ul>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico1.png" />
                            </div>
                            <p>
                              Emirates ID (front)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label className="uploaded">
                                <i
                                  className="fa fa-check "
                                  aria-hidden="true"
                                />
                              </label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                            <div className="tag">
                              <button
                                className="tags wow zoomIn"
                                style={{
                                  visibility: "visible",
                                  animationName: "zoomIn"
                                }}
                              >
                                file.doc<span>×</span>{" "}
                              </button>
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico2.png" />
                            </div>
                            <p>
                              UAE Driving License (front)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico3.png" />
                            </div>
                            <p>
                              Vehicle Registration Card (front)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico4.png" />
                            </div>
                            <p>Home Country Driving License (Optional)</p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico5.png" />
                            </div>
                            <p>No Claims Certificate (if applicable)</p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="uploads">
                      <ul>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico1.png" />
                            </div>
                            <p>
                              Emirates ID (front)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico2.png" />
                            </div>
                            <p>
                              UAE Driving License (back)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico3.png" />
                            </div>
                            <p>
                              Vehicle Registration Card (back)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                        <li>
                          <div className="upload-desc">
                            <div className="icons">
                              <img src="/public/media/images/ico4.png" />
                            </div>
                            <p>
                              VCC Paper (for brand new vehicles)
                              <span className="highlight">*</span>
                            </p>
                            <div className="uplds">
                              <label htmlFor="file_upload">Upload</label>
                              <input
                                type="file"
                                className="form-control upld hidden"
                                id="file_upload"
                              />
                            </div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="compare-btn text-center">
              <button className="btn btn-primary" onClick={this.toggle}>
                Submit Documents
              </button>
            </div>
          </div>
        </section>

        <Modal
          isOpen={this.state.modal}
          toggle={this.toggle}
          modalClassName="uploads_modal"
        >
          <ModalBody>
            <div className="modal-body">
              <img src="/public/media/images/smile.png" />
              <h5>Thank you for your order</h5>
              <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500s, when an unknown printer took a galley{" "}
              </p>
              <button
                type="button"
                className="btn btn-primary"
                onClick={this.toggle}
              >
                OK
              </button>
            </div>
          </ModalBody>
        </Modal>
      </section>
    );
  }
}

module.exports = UploadDocumentsPage;
