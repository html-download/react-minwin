//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});

/*//Date picker
$('.datepicker').datetimepicker({
  format: 'DD/MM/YYYY'
});
$('.timepicker').datetimepicker({
  format: 'LT'
});*/

//Current Page
$(document).ready(function() {
  $("[href]").each(function() {
  if (this.href == window.location.href) {
      $(this).addClass("active");
      }
  });
});

//Full Height
/*$(function(){
  resize_pane();
  $(window).resize(resize_pane);
});*/
/*function resize_pane() {
  var offset = $('.layout_height').offset(),
  remaining_height = parseInt($(window).height() - offset.top - 0);
  $('.layout_height').height(remaining_height);
}*/

//slimScroll
$(".scrollbar").slimScroll({  
  alwaysVisible: true,
  railVisible: true,
  railColor: '#0D515C',
  railOpacity: 0.2,
  color: '#0D515C',
  size: '5px'
});

$('.heading .nav a').click(function(){
  $('.col-xs-6.layout_height .scrollbar').slimScroll({ scrollTo: '0px', alwaysVisible: true});
});