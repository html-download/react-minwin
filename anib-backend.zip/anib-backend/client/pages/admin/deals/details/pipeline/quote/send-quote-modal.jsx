'use strict';
const Actions = require('./actions');
const Button = require('../../../../../../components/form/button.jsx');
const ControlGroup = require('../../../../../../components/form/control-group.jsx');
const Modal = require('../../../../../../components/modal.jsx');
const PropTypes = require('prop-types');
const React = require('react');
const Spinner = require('../../../../../../components/form/spinner');
import { Form, FormGroup, Label, Input, FormText } from 'reactstrap';


const propTypes = {
    toggleModal: PropTypes.bool    
};

let styleModal =  { display : 'none', opacity : '0' };

class QuoteModal extends React.Component {   

    constructor(props) {

        super(props);        
        
    }    

    componentWillReceiveProps() {
        
        if (this.props.toggleModal) {
            styleModal = { display : 'block', opacity : '5' };
        }
    }

    sendQuoteMail(e) {

        e.preventDefault();        
        this.props.info_data.submit_quote();
        Actions.sendQuoteMail({
            deal_quote_id: this.props.info_data.deal_quote_key,
            deal_id: this.props.id,
            to: this.to.value,
            cc: this.cc.value,
            bcc: this.bcc.value,
            subject: this.subject.value,
            message: this.message.value,
        },this.props.toggle);
    }

    render() {        

        return (
            <div>                
                <Modal
                header="Send Quote Email"
                show={this.props.info_data.is_quote_modal_open}
                onClose={Actions.hideQuoteModal}
                groupClasses={{'model_design1': true}}
                modalDialogClasses={{'modal-dialog-centered': true}}>
                    <form>
                        <div className="form-box-horizandal">
                            <div className="form-group rq">
                                <label className="left-side">To</label>
                                <div className="right-side">                                
                                    <input type="text" ref={el => this.to = el} className="form-control"/>
                                    <span className="notes">Sperate Multiple email addresses with a comma(.)</span>
                                </div>
                            </div>
                            <div className="form-group rq">
                                <label className="left-side">CC</label>
                                <div className="right-side">
                                    <input type="text" ref={el => this.cc = el} className="form-control"/>
                                    <span className="notes">Sperate Multiple email addresses with a comma(.)</span>
                                </div>
                            </div>
                            <div className="form-group rq">
                                <label className="left-side">BCC</label>
                                <div className="right-side">
                                    <input type="text" ref={el => this.bcc = el} className="form-control"/>
                                    <span className="notes">Sperate Multiple email addresses with a comma(.)</span>
                                </div>
                            </div>
                            <div className="form-group rq">
                                <label className="left-side">From</label>
                                <div className="right-side">
                                    <p><b>ANIB</b> (motorinsurence@gmail.com)</p>
                                </div>
                            </div>
                            <div className="form-group rq">
                                <label className="left-side">Reply To</label>
                                <div className="right-side">
                                    <p><b>ANIB</b> (motorinsurence@gmail.com)</p>
                                </div>
                            </div>
                            <div className="form-group rq">
                                <label className="left-side">Subject</label>
                                <div className="right-side">
                                    <input type="text" ref={el => this.subject = el} className="form-control"/>
                                </div>
                            </div>
                            <div className="form-group rq">
                                <label className="left-side">Message</label>
                                <div className="right-side">
                                    <textarea type="text" ref={el => this.message = el} className="form-control height-5"></textarea>
                                </div>
                            </div>
                        </div>       
                        <div className="form-box-horizandal">                
                            <ControlGroup hideLabel={true} hideHelp={true} groupClasses={{'actions': true}}>
                                <Button
                                    type="button"
                                    inputClasses={{ 'btn': true, 'btn-white': true }}
                                    disabled={this.props.loading}
                                    onClick={(e) => {Actions.hideQuoteModal()}}
                                    >
                                    Close
                                </Button>
                                <Button
                                    type="submit"
                                    inputClasses={{ 'btn': true, 'btn-primary': true }}
                                    disabled={this.props.loading}
                                    onClick={(e) => this.sendQuoteMail(e)}
                                    >
                                    <Spinner space="right" show={this.props.loading} />
                                    Create
                                </Button>
                            </ControlGroup>
                        </div>                 
                    </form>
                </Modal>
            </div>
        );
    }
}
module.exports = QuoteModal;
