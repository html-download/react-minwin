"use strict";
const PropTypes = require("prop-types");
const React = require("react");
const ReactRouter = require("react-router-dom");

const Link = ReactRouter.Link;
const propTypes = {
  data: PropTypes.array
};

class Results extends React.Component {

    getTableData(id, value) {

        return (
            <td onClick={e => { this.props.history.push(`/admin/users/${id}`); }} >
                {value}
            </td>
        );
    }

    render() {

        const rows =
        this.props.data && this.props.data.length > 0 ? (
                this.props.data.map(record => {
                return (
                    <tr className="c-pointer" key={record.user_key}>
                    {this.getTableData(
                        record.user_key,
                        `${record.first_name == null ? " " : record.first_name} ${
                        record.last_name == null ? " " : record.last_name
                        }`
                    )}
                    {this.getTableData(record.user_key, record.email)}
                    {this.getTableData(record.user_key, record.mobile_number)}
                    { /* this.getTableData(record.user_key, record.user_type_label) */ }
                    {this.getTableData(record.user_key, record.role_name) }
                    </tr>
                );
                })
            ) : (
                <tr key="0">
                <td colSpan={5} className="text-center">
                    No record(s) found!
                </td>
                </tr>
            );

        return (

            <div className="table-responsive">
                <table className="table table-hover white_table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        {/* <th>User Type</th> */}
                        <th>Role</th>
                    </tr>
                </thead>
                {
                    this.props.list_loading ? (
                        <tbody>
                            <tr key='0'>
                                <td colSpan={5} className="text-center loader-tab-content">
                                    loading...
                                </td>
                            </tr>
                            <tr key='1'>
                                <td colSpan={5} className="text-center loader-tab-content">
                                    loading...
                                </td>
                            </tr>
                        </tbody>
                    ) : (
                        <tbody>
                            {rows}
                        </tbody>
                    )
                }
                </table>
            </div>
        );
    }
}

Results.propTypes = propTypes;

module.exports = Results;
