import {fitBounds} from 'google-map-react/utils';
const Constants = require('./constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../helpers/parse-validation');
const Redux = require('redux');
const UserIdentity = require('../../../helpers/user-identity');
const DateTimeHelper = require('../../../helpers/date-time');
const moment = require('moment');


const initialState = {
    loading: false,
    success: false,
    error: undefined,
    hasError: {},
    help: {},
    'showSideNav': false,
    'apiKey': {'key': UserIdentity.googleApiKey},
    'center': {
        'lat': 32.593357,
        'lng': -85.495163
    },
    'zoom': 17,
    'mapHeight': 0,
    'mapWidth': 0,
    'markers': [],
    'isOpen' : false,
    isLoaded: false,
    lot: {},
    available: 0,
    occupied: 0,
    noData: 0,
    reserved: 0,
    hybrid_flag : 1,
    lot_name : '',
    client_name : '',
    unavailable : 1,
    bbhubs : [],
    bus_hub_available : 0,
    bike_hub_available : 0,
    bus_lat_lng : '',
    bike_lat_lng : '',
    bus_timing : [],
    bus_timing_index : null,
    bus_timing_api : null,
    remaining_bus_seconds : 0,
    remaining_bus_minutes : 0,
    bike_timing_api : null,
    bike_timing_api_auth : null,
    bike_count : 0,
    lot_messages : [],
    lot_id : 0,
    overlay_url : "/public/media/images/lots/au-mcwhorter.png",
    overlay_coords_ne : "",
    overlay_coords_sw : "",
    isOverlayLoaded: false,
    isShowToast : false
};
const reducer = function (state, action) {

    if (action.type === Constants.GET_SUMMARY_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        const markers = [];
        let bus_hub_available = 0;
        let bike_hub_available = 0;
        let bus_lat_lng = '';
        let bike_lat_lng = '';
        let bus_timing_api = null;
        let bike_timing_api = null;
        let bike_timing_api_auth = null;

        let icon;
        let lot_name = result.lot_name;
        let hybrid_flag = result.occupancies.hybrid_flag;
        let client_name = result.occupancies.client_name;
        let status = result.occupancies.status;
        let lot_id = result.occupancies.id;

        result.occupancies.landmarks.forEach((landmark) => {
            const [lat, lng] = landmark.coords.split(',');
            if (landmark.name === 'bus_stop') {
                bus_lat_lng = landmark.coords;
                bus_hub_available += 1;
                icon = 'bus_marker.png';
                bus_timing_api = landmark.url;
            } else {
                bike_lat_lng = landmark.coords;
                bike_hub_available += 1;
                icon = 'bike_marker.png';
                bike_timing_api = landmark.url;
                bike_timing_api_auth = landmark.auth;
            }

            markers.push({
                stallNumber: landmark.api_id,
                lat: parseFloat(lat),
                lng: parseFloat(lng),
                reserved: null,
                status: 1,
                icon: icon,
                isOpen: false,
                lot_name : landmark.lot,
                zone: 0,
                reserve_flag: null,
                live_flag: 0,
                'is_user': 3
            });
        });
        
        const [neLat, neLng] = result.occupancies.overlay_coords_ne.split(',');
        const [swLat, swLng] = result.occupancies.overlay_coords_sw.split(',');
        const bound = {
            'ne': {
                'lat': neLat,
                'lng': neLng
            },
            'sw': {
                'lat': swLat,
                'lng': swLng
            }
        };

        const size = {'width': window.innerWidth, 'height': window.innerHeight};
        const {center, zoom} = fitBounds(bound, size);

        return ObjectAssign({}, state, {
            loading: false,
            isLoaded: true,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            mapHeight : window.innerHeight, 
            mapWidth: window.innerWidth,
            hybrid_flag : hybrid_flag,
            lot_name: lot_name,
            client_name: client_name,
            unavailable: status,
            lot: result.occupancies,
            center: center, 
            zoom: zoom,
            bbhubs: markers,
            bike_hub_available : bike_hub_available,
            bus_hub_available : bus_hub_available,
            bus_lat_lng : bus_lat_lng, 
            bike_lat_lng : bike_lat_lng,
            bus_timing_api : bus_timing_api,
            bike_timing_api: bike_timing_api,
            bike_timing_api_auth:  bike_timing_api_auth,
            lot_id : lot_id,
            overlay_coords_ne : result.occupancies.overlay_coords_ne,
            overlay_coords_sw : result.occupancies.overlay_coords_sw,
            overlay_url : result.occupancies.overlay_url
        });
    }

    if (action.type === Constants.UPDATE_OCCUPANCY) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.UPDATE_OCCUPANCY_RESPONSE) {
        const validation = ParseValidation(action.response);
        let result = action.response;

        let lot_name = result.lot_name;
                    
        const markers = [];
        const disabledZones = [];
        
        var available_state = 0, occupied_state = 0, noData_state = 0, reserved_state = 0;
        for(let zone in localStorage){
            if(localStorage.hasOwnProperty(zone)){
                const zoneValue = localStorage.getItem(zone);
                if(zoneValue === 'false'){
                    disabledZones.push(zone);
                }
            }
        }

        result.lot_status.forEach((stall) => {
            const [lat, lng] = stall.coords.split(',');
            const reserved = stall.reserve_flag;
            let icon;
            icon = 'green.png';

            if (state.unavailable === 1) {
                /*if(stall.zone === 'ada'){
                    icon = 'green-blue.png';
                }*/
                /*switch(stall.status){
                    case 0:
                        icon = 'green.png';
                        break;
                    case 1:
                        icon = 'red.png';
                        break;
                    default:
                        icon = 'orange.png';
                        break;
                }
                if (stall.status === 0 && stall.zone === 'ada'){
                    icon = 'green-blue.png';
                }
                
                if (stall.maintenance_flag === 1){
                    icon = 'red.png';
                }
                if(stall.live_flag === 1 && reserved){
                    icon = 'purple.png';
                }
                if(stall.display_only === 1 && stall.live_flag !== 1){
                    icon = 'orange.png';
                }
                if(reserved){
                    icon = 'purple.png';
                }*/
                if (reserved){
                    icon = 'purple.png';
                } else if(stall.status === 0 && stall.zone === 'ada'){
                    icon = 'green-blue.png';
                } else if(stall.status === 1 && stall.zone === 'ada'){
                     icon = 'red-blue.png';
                } else if(stall.status === 2 && stall.zone === 'ada'){
                     icon = 'orange-blue.png';
                } else if (stall.status === 1){
                    icon = 'red.png';
                } else if (stall.status === 2){
                    icon = 'orange.png';
                } else if (reserved){
                    icon = 'purple.png';
                } else if(stall.status === 0 && !reserved){
                    icon = 'green.png';
                }
                
            } else {
                icon = 'orange.png';
            }
            
            if(!disabledZones.includes(`${stall.zone}_selected`)){
                markers.push({
                    stallNumber: stall.stall_num,
                    lat: parseFloat(lat),
                    lng: parseFloat(lng),
                    reserved: reserved,
                    status: stall.status,
                    icon: icon,
                    isOpen: false,
                    lot_name : lot_name,
                    zone: stall.zone,
                    reserve_flag: stall.reserve_flag,
                    live_flag: stall.live_flag,
                });
                if (reserved){
                    reserved_state += 1;
                } else if(stall.status === 0 && !reserved){
                    available_state += 1;
                } else if (stall.status === 1){
                    occupied_state += 1;
                } else if (stall.status === 2){
                    noData_state += 1;
                } /*else if (reserved){
                    reserved_state += 1;
                }*/
            }
        });
        state.bbhubs.forEach((bbhub) => {
            markers.push(bbhub);
        });

        if (UserIdentity._checkCurrentAddress() !== null) {
            markers.push({
                stallNumber: 100001,
                'lat': parseFloat(UserIdentity._checkCurrentAddress().lat),
                'lng': parseFloat(UserIdentity._checkCurrentAddress().lng),
                reserved: 0,
                icon: 'marker_customer.png',
                isOpen: false,
                'is_user': 2,
                lot_name : 'search',
                zone: 0,
                reserve_flag: 0
            });
        }
        if (UserIdentity._checkUserAddress() !== null) {
            markers.push({
                stallNumber: 100002,
                'lat': parseFloat(UserIdentity._checkUserAddress().lat),
                'lng': parseFloat(UserIdentity._checkUserAddress().lng),
                reserved: 0,
                icon: 'marker_customer_des.png',
                isOpen: false,
                'is_user': 2,
                lot_name : 'search',
                zone: 0,
                reserve_flag: 0
            });
        }

        return ObjectAssign({}, state, {
            loading: false,
            isLoaded: true,
            success: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help,
            markers : markers,
            available: available_state,
            occupied: occupied_state,
            noData: noData_state,
            reserved: reserved_state,
            isShowToast: true
        });
    }

    if (action.type === Constants.UPDATE_MAP_CENTER) {
        return ObjectAssign({}, state, {
            center: action.latLng,
            zoom : action.zoom
        });
    }

    if (action.type === Constants.GET_BUS_TIMING) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.GET_BUS_TIMING_RESPONSE) {
        let results = (action.response.arrivals !== undefined) ? action.response.arrivals : [];

        let bus_timing = [];
        let bus_timing_index = null;
        let minutes = null;

        if (results.length > 0) {
            results.forEach((result, index) => {
                minutes = null;
                let arrived = UserIdentity._getTimeFromDate(result.timestamp);
                let difference = DateTimeHelper._getTimeInterval(moment().format("HH:mm"), arrived, 0);

                let arrived_c = moment(arrived, "HH:mm").format("h:mm A")
                if (index === 0) {
                    bus_timing_index = difference;
                }

                var hms = `${difference}:00`;   // your input string
                var a = hms.split(':'); // split it at the colons

                minutes = (+a[0]) * 60 + (+a[1]);

                bus_timing.push({
                    distance: result.distance,
                    route_id: result.route_id,
                    stop_id: result.stop_id,
                    vehicle_id: result.vehicle_id,
                    type: result.type,
                    timestamp: result.timestamp,
                    arrived: arrived_c,
                    difference: difference,
                    diff_minutes : minutes
                });
            });

            bus_timing.sort(function(a, b) {
                var avalue = a.diff_minutes,
                    bvalue = b.diff_minutes;
                if (avalue < bvalue) {
                    return -1;
                }
                if (avalue > bvalue) {
                    return 1;
                }
                return 0;
            });

            bus_timing.forEach((result, index) => {
                if (index === 0) {
                    bus_timing_index = result.difference;
                    minutes = result.diff_minutes;
                }
            });
            
        }

        
        var hms = `${bus_timing_index}:00`;   // your input string
        var a = hms.split(':'); // split it at the colons

        // minutes are worth 60 seconds. Hours are worth 60 minutes.
        var seconds = (+a[0]) * 60 * 60 + (+a[1]) * 60 + (+a[2]);
        
        return ObjectAssign({}, state, {
            bus_timing: bus_timing,
            bus_timing_index: bus_timing_index,
            remaining_bus_seconds : seconds,
            remaining_bus_minutes : minutes

        });
    }

    if (action.type === Constants.GET_BIKE_TIMING) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.GET_BIKE_TIMING_RESPONSE) {
        let results = action.response;

        let bike_count = 0;
        if (results.available_bikes) {
            bike_count = results.available_bikes
        }

        
        return ObjectAssign({}, state, {
            bike_count: bike_count
        });
    }

    if (action.type === Constants.SHOW_BUS_TIMING) {
        return ObjectAssign({}, state, {
            show: true
        });
    }

    if (action.type === Constants.HIDE_BUS_TIMING) {
        return ObjectAssign({}, state, {
            show: false
        });
    }

    if (action.type === Constants.GET_LOT_MESSAGE) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.GET_LOT_MESSAGE_RESPONSE) {
        let results = action.response;

        let lot_messages = results.lot_messages ? results.lot_messages : [];
                
        return ObjectAssign({}, state, {
            lot_messages: lot_messages
        });
    }

    if (action.type === Constants.GET_OVERLAY_IMAGE) {
        return ObjectAssign({}, state, {
            loading: false
        });
    }

    if (action.type === Constants.GET_OVERLAY_IMAGE_RESPONSE) {
        //const validation = ParseValidation(action.response);
        let result = action.response;

        return ObjectAssign({}, state, {
            loading: false,
            overlay_url: result.overlay_url ? result.overlay_url : null,
            isOverlayLoaded : true
        });
    }

    if (action.type === Constants.UPDATE_OVERLAY_LOAD) {
        return ObjectAssign({}, state, {
            isOverlayLoaded : false
        });
    }

    return state;
};


module.exports = Redux.createStore(reducer, initialState);
