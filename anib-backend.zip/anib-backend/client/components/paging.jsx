"use strict";
const PropTypes = require("prop-types");
const React = require("react");
import Pagination from "react-js-pagination";

const propTypes = {
  onChange: PropTypes.func,
  pages: PropTypes.object
};

class Paging extends React.Component {
  constructor(props) {

      super(props);

      this.els = {};

      this.state = {
        activePage: 1
      };

      this.handlePageChange = this.handlePageChange.bind(this);
  }

  componentDidUpdate(prevProps, prevState){

        if (prevProps.pages.current_page !== this.props.pages.current_page) {
            this.setState({
                activePage: this.props.pages.current_page ? parseInt(this.props.pages.current_page) : 1
            });
        }
        
  }

  onPrevPage() {

      this.props.onChange(this.props.pages.prev);
  }

  onNextPage() {

      this.props.onChange(this.props.pages.next);
  }

  handlePageChange(pageNumber) {
      
      this.props.onChange ? this.props.onChange(pageNumber) : null

  }

  render() {

    return (
      <div className="pagination-custom">
        <div className="row">
          <div className="col-sm-12 col-md-5">
            <div className="">
              Showing {this.props.pages.begin} to {this.props.pages.total < this.props.pages.end ? this.props.pages.total : this.props.pages.end} of {" "}
              {this.props.pages.total} entries
            </div>
          </div>
          <div className="col-sm-12 col-md-7">
            <Pagination
                prevPageText='Prev'
                nextPageText='Next'
                firstPageText='First'
                lastPageText='Last'
                activePage={this.state.activePage}
                itemsCountPerPage={this.props.pages.limit}
                totalItemsCount={this.props.pages.total}
                pageRangeDisplayed={5}
                onChange={this.handlePageChange}
              />
          </div>
        </div>

      </div>
    );
  }
}

Paging.propTypes = propTypes;

module.exports = Paging;
