'use strict';
const Actions = require('./actions');
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');

const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array,
    param: PropTypes.string
};


class Results extends React.Component {
    onDelete(event) {

        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        //console.log("1", 1);
        //Actions.changeSearchQuery(this.els.filters.state, this.props.history);
    }
    onStatusUpdate(id, client, status) {
        let msg = status ? `${id} has been activated successfully` : `${id} has been deactivated successfully`;
        Actions.statusUpdate({
            name : id,
            client_name : client,
            status : status ? 1 : 0
        }, msg);
    }
    render() {
        const rows = this.props.data === undefined ? (
                <tr>
                    <td colSpan={5} style={{'textAlign' : 'center'}}>
                        Something wrong with input!
                    </td>
                </tr>
            ) : (this.props.data.length === 0) ? (
                <tr>
                    <td colSpan={5} style={{'textAlign' : 'center'}}>
                        No record(s) found!. please select client to get details 
                    </td>
                </tr>
            ) : this.props.data.map((record, index) => {
                index++;
            return (
                <tr key={record.id}>
                    <td>
                        {index}
                    </td>
                    <td>
                        <Link
                            to={`/lots/${record.lot_name}`}
                            title="View"
                            title="Edit">
                            {record.lot_name}
                        </Link>
                    </td>
                    <td>{record.client_name}</td>
                    <td className="status">
                        <label className="switch" htmlFor={`id_${record.lot_name}`}>
                            <input type="checkbox" name={`id_${record.lot_name}`} id={`id_${record.lot_name}`} defaultChecked={record.status}  onChange={(event)=> { this.onStatusUpdate(record.lot_name, record.client_name, event.target.checked)}} />
                            <span className="slider"></span>
                        </label>
                    </td>
                    <td className="action">
                        {/*<Link
                            to={`/main/lots/view/${record.id}`}
                            title="View"
                            title="Edit">
                            <i className="fa fa-eye"></i>
                        </Link>*/}
                        <Link
                            to={`/lots-details/${record.client_name}/${record.lot_name}`}>
                            <i className="fa fa-pencil"></i>
                        </Link>
                        <a role="button" data-id={record.id} onClick={this.onDelete.bind(this)} className="trash" title="Delete"><i className="fa fa-trash"></i></a>
                        {/*<Link
                            className="trash"
                            to={`/main/lots/delete/${record.id}`}
                            title="Delete">
                            <i className="fa fa-trash"></i>
                        </Link>*/}
                    </td>
                </tr>
            );
        });

        return (
            <div className="table-responsive">
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th width="20">#</th>
                            <th className="stretch">Name</th>
                            <th className="stretch">Client Name</th>
                            <th className="status">Status</th>
                            <th className="action">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rows}
                    </tbody>
                </table>
            </div>
        );
    }
}

Results.propTypes = propTypes;


module.exports = Results;
