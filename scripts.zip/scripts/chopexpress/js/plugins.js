document.write('<scr'+'ipt type="text/javascript" src="js/popper.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.smoothState.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/wow.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/iziToast.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/datetimepicker.js" ></scr'+'ipt>');
