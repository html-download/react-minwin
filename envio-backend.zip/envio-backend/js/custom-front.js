//Fixed Header
$(window).on('load scroll resize orientationchange', function () {
    var scroll = $(window).scrollTop();
    if (scroll >= 50) {
        $(".site_header").addClass("fixed");
    } else {
        $(".site_header").removeClass("fixed");
    }		
});

//Custom scrollbar
jQuery(document).ready(function(){
	jQuery('.scrollbar-inner').scrollbar();
});

//Animation
new WOW().init();

//floating_label
$(document).on('focus active', '.form-group',function(){
	$(this).addClass('focus');

});
$(document).on('blur', '.form-group',function(){
	//$('label[for='+$(this).attr('id')+']').removeClass('focus');
    $(this).removeClass('focus');
});

//Tooltip
$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	$('[rel="tooltip"]').tooltip();
});

// Date Time Picker
$(".datepicker").datetimepicker({		
	minView: 2,
	format: "dd/mm/yyyy",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

$(".timepicker").datetimepicker({		
    format: 'HH:ii P',
    autoclose: true,
    showMeridian: true,
    startView: 1
});

$(".datetime").datetimepicker({		
	format: "dd/mm/yyyy - HH:ii P",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});

//Modal
$(".modal_change").click(function(){
	$("body").addClass("modal_open");
});
$(".modal .close").click(function(){
	$("body").removeClass("modal_open");
});

//Auto tab
$(".otp input").keyup(function () {
    if (this.value.length == this.maxLength) {
      $(this).parent('span').next('span').find('input').focus();
    }
});

//Current Page
$(document).ready(function() {
    $("[href]").each(function() {
    if (this.href == window.location.href) {
        $(this).addClass("active");
        }
    });
});

//Vehicle Active
$('.vehicle label').click(function(e) {
    e.preventDefault();
    $('label').removeClass('active');
    $(this).addClass('active');
});

//New Booking
$(".book_action").click(function(){  
    $(".booking").toggleClass("closed");
});

//Rating
jQuery(function() {
    jQuery('.starbox').each(function() {
      var starbox = jQuery(this);
      starbox.starbox({
        average: starbox.attr('data-start-value'),
        changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
        ghosting: starbox.hasClass('ghosting'),
        autoUpdateAverage: starbox.hasClass('autoupdate'),
        buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
        stars: starbox.attr('data-star-count') || 5
      }).bind('starbox-value-changed', function(event, value) {
        if(starbox.hasClass('random')) {
          var val = Math.random();
          starbox.next().text('Random: '+val);
          return val;
        } else {
          $('input[name="rating"]').val(value);
        }
      }).bind('starbox-value-moved', function(event, value) {
        $('input[name="rating"]').val(value);
      });
    });
});

//Tabs active from outside
$('a.next[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    var target = this.href.split('#');
    $('.nav a').filter('[href="#'+target[1]+'"]').tab('show').parent('li').addClass('active');
});

$('a.next[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $('.nav li').prev('li').addClass('active');
});

$('a.prev[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    var target = this.href.split('#');
    $('.nav a').filter('[href="#'+target[1]+'"]').tab('show').parent('li').next('li').removeClass('active');
});

/*equal height*/
(function( $, window, document, undefined ){
	'use strict';
	var $list   = $( '.equal' ),
    $items		= $list.find( '.height' ),
    setHeights	= function()
    {
        $items.css( 'height', 'auto' );
        var perRow = Math.floor( $list.width() / $items.width() );
        if( perRow == null || perRow < 2 ) return true;
        for( var i = 0, j = $items.length; i < j; i += perRow )
        {
            var maxHeight	= 0,
                $row		= $items.slice( i, i + perRow );

            $row.each( function()
            {
                var itemHeight = parseInt( $( this ).outerHeight() );
                if ( itemHeight > maxHeight ) maxHeight = itemHeight;
            });
            $(window).on('load', $row.css( 'height', maxHeight ));
        }
    };	
	setHeights();
	$(window).on('resize', setHeights);
})( jQuery, window, document );

//accordion
$('#accordion').on('shown.bs.collapse', function () {
    var panel = $(this).find('.in');
    $('html, body').animate({
        scrollTop: panel.offset().top-200
    }, 500);
});  

//Mobile Menu
$("#mobile_nav").on('click', function() {
    $(".site_menu").fadeToggle();
    $(".site_menu").toggleClass("open");
    $(this).toggleClass("open");
 });
 $(".site_menu a, .site_menu").on('click', function() {
    $(".site_menu").fadeOut();
    $(".site_menu").removeClass("open");
    $("#mobile_nav").removeClass("open");
 });

 //step_form
$('.action a.btn').on('click', function () {
    var href = $(this).attr('href');
    $('html, body').animate({
        scrollTop: $(href).offset().top
    }, 400);
});

//Booking Tabs
$('.nav_tabs a').click(function () {
    $('.target').hide();
    $('#div' + $(this).attr('target')).show();
    $('.nav_tabs a').removeClass("active");
    $(this).addClass("active");

    $('body,html').animate({
        scrollTop: 0
    }, 400);
    return false;
});