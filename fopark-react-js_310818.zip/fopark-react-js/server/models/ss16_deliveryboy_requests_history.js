/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16DeliveryboyRequestsHistory', {
    historyId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'history_id'
    },
    orderKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'order_key'
    },
    deliveryboyKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'deliveryboy_key'
    },
    requestedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'requested_datetime'
    },
    acceptedDeliveryboyKey: {
      type: DataTypes.STRING(16),
      allowNull: true,
      field: 'accepted_deliveryboy_key'
    },
    acceptedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'accepted_datetime'
    },
    rejectedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'rejected_datetime'
    },
    cancelReason: {
      type: DataTypes.STRING(155),
      allowNull: false,
      field: 'cancel_reason'
    },
    completedDatetime: {
      type: DataTypes.DATE,
      allowNull: true,
      field: 'completed_datetime'
    }
  }, {
    tableName: 'ss16_deliveryboy_requests_history'
  });
};
