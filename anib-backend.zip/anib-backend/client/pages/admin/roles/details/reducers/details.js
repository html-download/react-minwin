'use strict';
const Constants = require('../constants');
const ObjectAssign = require('object-assign');
const ParseValidation = require('../../../../../helpers/parse-validation');


const initialState = {
    hydrated: false,
    loading: false,
    error: undefined,
    hasError: {},
    help: {},
    _id: undefined,    
    role_key: undefined,
    role_name: undefined,
    role_status: undefined,
    role_type: undefined,
    permission: {}
};
const reducer = function (state = initialState, action) {

    if (action.type === Constants.GET_DETAILS) {
        return ObjectAssign({}, initialState, {
            hydrated: false,
            loading: true
        });
    }

    if (action.type === Constants.GET_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);
        
        return ObjectAssign({}, state, {
            hydrated: true,
            loading: false,
            role_name: action.response.data.role_name,
            role_key: action.response.data.role_key,
            role_status: action.response.data.role_status,
            role_type: action.response.data.role_type,
            permission: JSON.parse(action.response.data.role_json)
        });
    }

    if (action.type === Constants.SAVE_DETAILS) {
        return ObjectAssign({}, state, {
            loading: true,
            isActive: action.request.data.isActive,
            username: action.request.data.username,
            email: action.request.data.email
        });
    }

    if (action.type === Constants.SAVE_DETAILS_RESPONSE) {
        const validation = ParseValidation(action.response);
        const stateUpdates = {
            loading: false,
            showSaveSuccess: !action.err,
            error: validation.error,
            hasError: validation.hasError,
            help: validation.help
        };

        if (action.response.hasOwnProperty('username')) {
            stateUpdates.isActive = action.response.isActive;
            stateUpdates.username = action.response.username;
            stateUpdates.email = action.response.email;
        }

        return ObjectAssign({}, state, stateUpdates);
    }

    if (action.type === Constants.HIDE_DETAILS_SAVE_SUCCESS) {
        return ObjectAssign({}, state, {
            showSaveSuccess: false
        });
    }

    return state;
};


module.exports = reducer;
