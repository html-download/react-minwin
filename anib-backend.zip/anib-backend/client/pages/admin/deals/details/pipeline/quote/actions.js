'use strict';
const Store = require('./store');
const Constant =  require('./constants');
const ApiActions = require('../../../../../../actions/api');
const CommonHelper = require('../../../../../../helpers/common-functions');

class Actions {
    
    static toggleQuote() {
            
        Store.dispatch({
            type : Constant.TOGGLE_QUOTE
        });
    }

    static getDealQuote(data) {
        
        ApiActions.get(
            '/deal-quote',
            data,
            Store,
            Constant.GET_DEAL_QUOTE_DETAILS,
            Constant.GET_DEAL_QUOTE_DETAILS_RESPONSE
        );
    }

    static getMortgage() {
        
        ApiActions.get(
            '/mortgage',
            undefined,
            Store,
            Constant.GET_MORTGAGE_DETAILS,
            Constant.GET_MORTGAGE_DETAILS_RESPONSE
        );
    }

    static getProduct() {

        ApiActions.get(
            '/underwriter',
            undefined,
            Store,
            Constant.GET_PRODUCT_DETAILS,
            Constant.GET_PRODUCT_DETAILS_RESPONSE
        );
    }

    static saveQuoteDetails(data) {
        
        ApiActions.post(
            '/deal-quote',
            data,
            Store,
            Constant.SAVE_QUOTE_DETAILS,
            Constant.SAVE_QUOTE_DETAILS_RESPONSE
        );
    }

    static updateQuoteDetails(id, data, toggle) {

        ApiActions.put(
            `/deal-quote/${id}`,
            data,
            Store,
            Constant.UPDATE_QUOTE_DETAILS,
            Constant.UPDATE_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(3 , response.data.url, id);
                        CommonHelper.windowScroll();
                    }
                }
            }
        );
    }

    static sendQuoteMail(data, toggle) {

        ApiActions.post(
            '/deal-quote/send',
            data,
            Store,
            Constant.SAVE_DEAL_QUOTE_DETAILS,
            Constant.SAVE_DEAL_QUOTE_DETAILS_RESPONSE,
            (err, response) => {

                if (!err) {
                    if (response.status === 200) {
                        toggle(3 , false, data.deal_quote_id);
                        CommonHelper.windowScroll();
                    }
                }
            }
        );
    }

    static updateDate(date, field) {
            
        Store.dispatch({
            type : Constant.UPDATE_DATE,
            date: date,
            field: field,
        });
    }

    static openQuoteModal(deal_quote_key,handleSubmit) {
        
        Store.dispatch({
            type : Constant.OPEN_QUOTE_MODAL,
            deal_quote_key: deal_quote_key,
            submit_quote:handleSubmit
        });
    }

    static hideQuoteModal() {

        Store.dispatch({
            type : Constant.HIDE_QUOTE_MODAL
        });
    }
}

module.exports = Actions;