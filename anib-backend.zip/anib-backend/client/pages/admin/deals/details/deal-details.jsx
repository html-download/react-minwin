const Actions = require('./actions');
const Closed = require('./closed/index');
const Modal = require('../../../../components/modal.jsx');
const NewDeal = require('./new-deal/index.jsx');
const Order = require('./order/index');
const PropTypes = require('prop-types');
const Quote = require('./quote/index');
const HouseKeeping = require('./house-keeping/index');
const React = require('react');

import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';


const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool,
};


class DealPage extends React.Component {
    constructor(props) {

        super(props);

        this.toggle = this.toggle.bind(this);
        
        this.state = {
          activeTab: 1
        };
    }

    toggle(tab) {
        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }

    render() {
        return (
          <div className={classnames({  })}>
            <Nav tabs className={classnames({ 'reset': true, 'wizard-links': true })}>
              <NavItem className={classnames({ active: this.state.activeTab === 1, green: this.state.activeTab > 1  })}>
                <NavLink
                  onClick={() => { this.toggle(1); }}
                >
                  New Deal
                </NavLink>
              </NavItem>
              <NavItem className={classnames({ active: this.state.activeTab === 2, green: this.state.activeTab > 2  })}>
                <NavLink
                  onClick={() => { this.toggle(2); }}
                >
                  Quote
                </NavLink>
              </NavItem>
              <NavItem className={classnames({ active: this.state.activeTab === 3, green: this.state.activeTab > 3  })}>
                <NavLink
                  onClick={() => { this.toggle(3); }}
                >
                  Order
                </NavLink>
              </NavItem>
              <NavItem className={classnames({ active: this.state.activeTab === 4, green: this.state.activeTab > 4  })}>
                <NavLink
                  onClick={() => { this.toggle(4); }}
                >
                  House Keeping
                </NavLink>
              </NavItem>
              <NavItem className={classnames({ active: this.state.activeTab === 5, green: this.state.activeTab > 5  })}>
                <NavLink
                  onClick={() => { this.toggle(5); }}
                >
                  Closed
                </NavLink>
              </NavItem>
            </Nav>
            <TabContent activeTab={this.state.activeTab} className={classnames({ 'tab-content': true })}>
                <TabPane tabId={1}>
                    <NewDeal/>                    
                </TabPane>
                <TabPane tabId={2}>
                    <Quote/>                     
                </TabPane>
                <TabPane tabId={3}>
                    <Order/>
                </TabPane>
                <TabPane tabId={4}>
                   <HouseKeeping/>
                </TabPane>
                <TabPane tabId={5}>
                    <Closed/>
                </TabPane>
            </TabContent>
          </div>
        );
      }
}

DealPage.propTypes = propTypes;


module.exports = DealPage;
