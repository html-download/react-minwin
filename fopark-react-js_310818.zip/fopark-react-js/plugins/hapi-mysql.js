'use strict'

const register = (server, options, next) => {
    server.register([{
        register: require('hapi-plugin-mysql'),
        options: {
            host: "192.168.1.179",
            user: "svnuser",
            password: "pXc9nbmrnC"
        }
    }])
    next();
}

register.attributes = {
    name: 'React View'
}

module.exports = register