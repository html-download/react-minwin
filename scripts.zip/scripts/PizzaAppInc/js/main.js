function checkWidth(init)
{
    /*If browser resized, check width again */
   
    if ($(window).width() > 960) 
    {
       
      $(function() {
          
		var stickyHeaderTop = $('#stickyheader').offset().top;
		$(window).scroll(function() {
			if ($(window).scrollTop() > stickyHeaderTop) {
				$('#stickyheader').css({position: 'fixed'}).addClass('goToTop');
				//$('#stickyalias').css('display', 'block');
			} else {
				$('#stickyheader').css({position: "static"}).removeClass('goToTop');
				//$('#stickyalias').css('display', 'none');
			}
		});
	});
    }
    else{
    $(function() {
          
		var stickyHeaderTop = $('#stickyheader').offset().top;
		$(window).scroll(function() { 
			if ($(window).scrollTop() > stickyHeaderTop) {
				$('#stickyheader').css({position: 'fixed'}).removeClass('goToTop');
				//$('#stickyalias').css('display', 'block');
			} else {
				$('#stickyheader').css({position: "static"}).removeClass('goToTop');
				//('#stickyalias').css('display', 'none');
			}
		});
	});
    }

}
$(document).ready(function() {
    checkWidth(true);

    $(window).resize(function() {
        checkWidth(false);
     
                  var a=$('#stickyheader').hasClass('goToTop');
                
    });
});