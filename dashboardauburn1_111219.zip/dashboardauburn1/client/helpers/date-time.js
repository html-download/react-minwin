'use strict';
const moment = require('moment-timezone');
const Config = require('../../config.js');

module.exports = {
    _emailDateTemplate : function () {
        try {
            var day = moment().tz(Config.get('/timeZone')).format("MMM DD, YYYY h:mmA");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _historicalDateFormat : function (date) {
        try {
            var day = moment(date).format("DD-MM-YYYY");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getTimeStringFromDateString : function (dateString) {
        try {
            var day = moment(dateString).tz(Config.get('/timeZone')).format("h:mm a");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getLotMessageDate : function (dateString) {
        try {
            var day = moment(dateString).format("MM/DD/YYYY");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    },
    _getLotMessageTime : function (dateString) {
        try {
            var day = moment(dateString).format("h:mm A");
            return day;
        } catch (e) {
            console.log(e.message);
            return null;
        }
    }

};
