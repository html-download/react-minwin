/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Subscribe', {
    subscribeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'subscribe_id'
    },
    subscriberKey: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'subscriber_key'
    },
    subscriberName: {
      type: DataTypes.STRING(230),
      allowNull: false,
      field: 'subscriber_name'
    },
    subscriberEmail: {
      type: DataTypes.STRING(230),
      allowNull: false,
      field: 'subscriber_email'
    },
    city: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'city'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    }
  }, {
    tableName: 'ss16_subscribe'
  });
};
