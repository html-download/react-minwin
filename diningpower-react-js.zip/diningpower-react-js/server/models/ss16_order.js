/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16Order', {
    orderId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'order_id'
    },
    orderKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'order_key'
    },
    outletKey: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'outlet_key'
    },
    orderDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: sequelize.literal('CURRENT_TIMESTAMP'),
      field: 'order_datetime'
    },
    currencyCode: {
      type: DataTypes.STRING(3),
      allowNull: false,
      field: 'currency_code'
    },
    customerKey: {
      type: DataTypes.STRING(16),
      allowNull: true,
      field: 'customer_key'
    },
    firstName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'first_name'
    },
    lastName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'last_name'
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'email'
    },
    mobileNumber: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'mobile_number'
    },
    shopKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'shop_key'
    },
    shopLogo: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'shop_logo'
    },
    shopName: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'shop_name'
    },
    orderTotal: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'order_total'
    },
    subTotal: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'sub_total'
    },
    serviceTaxPercentage: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'service_tax_percentage'
    },
    serviceTax: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'service_tax'
    },
    vatPercentage: {
      type: DataTypes.INTEGER(3),
      allowNull: false,
      field: 'vat_percentage'
    },
    vat: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'vat'
    },
    promocodeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'promocode_id'
    },
    promocode: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'promocode'
    },
    promocodeAmount: {
      type: "DOUBLE",
      allowNull: false,
      field: 'promocode_amount'
    },
    deliveryType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'delivery_type'
    },
    deliveryFee: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'delivery_fee'
    },
    deliveryCity: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'delivery_city'
    },
    deliveryArea: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'delivery_area'
    },
    address: {
      type: DataTypes.STRING(250),
      allowNull: false,
      field: 'address'
    },
    comments: {
      type: DataTypes.STRING(200),
      allowNull: false,
      field: 'comments'
    },
    flatNo: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'flat_no'
    },
    apartment: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'apartment'
    },
    deliveryInstruction: {
      type: DataTypes.STRING(125),
      allowNull: false,
      field: 'delivery_instruction'
    },
    companyName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'company_name'
    },
    alternateContact: {
      type: DataTypes.STRING(12),
      allowNull: false,
      field: 'alternate_contact'
    },
    landmark: {
      type: DataTypes.STRING(75),
      allowNull: false,
      field: 'landmark'
    },
    message: {
      type: DataTypes.STRING(125),
      allowNull: false,
      field: 'message'
    },
    paymentStatus: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'payment_status'
    },
    paymentType: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'payment_type'
    },
    deliveryStatus: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'delivery_status'
    },
    postalCode: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'postal_code'
    },
    deliveryTiming: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'delivery_timing'
    },
    deliveryMinutes: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'delivery_minutes'
    },
    pickupDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      field: 'pickup_date'
    },
    pickupTime: {
      type: DataTypes.TIME,
      allowNull: false,
      field: 'pickup_time'
    },
    otp: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'otp'
    },
    otpValidity: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'otp_validity'
    },
    ccavenueTrackingId: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'ccavenue_tracking_id'
    },
    ccavenueBankRefNo: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'ccavenue_bank_ref_no'
    },
    ccavenueMessage: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'ccavenue_message'
    },
    ccavenuePaymentMode: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'ccavenue_payment_mode'
    },
    ccavenueCardName: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'ccavenue_card_name'
    },
    ccavenueEncResp: {
      type: DataTypes.TEXT,
      allowNull: false,
      field: 'ccavenue_encResp'
    },
    isCommission: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'is_commission'
    },
    commissionPercentage: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'commission_percentage'
    },
    commissionAmount: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'commission_amount'
    },
    adminProfit: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'admin_profit'
    },
    vendorProfit: {
      type: DataTypes.DECIMAL,
      allowNull: false,
      field: 'vendor_profit'
    },
    deviceId: {
      type: DataTypes.STRING(255),
      allowNull: false,
      field: 'device_id'
    },
    deviceType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'device_type'
    },
    packagePrice: {
      type: "DOUBLE",
      allowNull: false,
      field: 'package_price'
    },
    deliveryboyKey: {
      type: DataTypes.STRING(16),
      allowNull: true,
      field: 'deliveryboy_key'
    },
    assignedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'assigned_datetime'
    },
    isPaymentOndelivery: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      defaultValue: '0',
      field: 'is_payment_ondelivery'
    },
    signature: {
      type: DataTypes.STRING(150),
      allowNull: false,
      field: 'signature'
    },
    commentsOndelivery: {
      type: DataTypes.TEXT,
      allowNull: true,
      field: 'comments_ondelivery'
    },
    deliveryboyPayStatus: {
      type: DataTypes.INTEGER(4),
      allowNull: false,
      defaultValue: '0',
      field: 'deliveryboy_pay_status'
    },
    customerLatitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'customer_latitude'
    },
    customerLongitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'customer_longitude'
    }
  }, {
    tableName: 'ss16_order'
  });
};
