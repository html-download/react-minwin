// password
$('.password-dropper').on('click', function() {
   $(this).toggleClass('password_text');
   let input = $($(this).prev());
   if (input.attr('type') == 'password') {
      input.attr('type', 'text');
   } else {
      input.attr('type', 'password');
   }
});

// loader
$('.loader').on('click', function() {
   var $this = $(this);
   var loadingText = '<i class="las la-circle-notch la-spin"></i> loading...';
   if ($(this).html() !== loadingText) {
      $this.data('original-text', $(this).html());
      $this.html(loadingText);
   }
   setTimeout(function() {
      $this.html($this.data('original-text'));
   }, 9000);
});


// js select2
$(document).ready(function() {
   //  $('#intro-modal').modal('show');
   $('[data-toggle="tooltip"]').tooltip();


});

// click to slide
$('body').on('click', '.toggle-menu', function() {
   var toggleId = $(this).data('id');
   $('#' + toggleId).toggleClass('open');
   $('.overlay-menu').toggleClass('open');
   $('body').toggleClass('overflow-stop');
   $(this).toggleClass('open');
});

// mouseup
$(document).mouseup(function(e) {
   var container = $(".sidebar_slide, .toggle-menu");
   if (!container.is(e.target) && container.has(e.target).length === 0) {
      container.removeClass("open");
      $('.overlay-menu').removeClass('open');
      $('body').removeClass('overflow-stop');
   }
});


//Modal
$('.modal').on('hidden.bs.modal', function() {
   if ($('.modal').hasClass('show')) {
      $('body').addClass('modal-open');
   }
});

// preloader function
function preloader_onchange() {
   $('.page_preloader').addClass('loader');
   setTimeout(function() {
      $('.page_preloader').removeClass("loader")
   }, 500);

}


// change event radio
$('.radio-buttons input.radio').change(function() {
   if (this.value == 'food') {
      // preloader on change
      preloader_onchange();
      $('body').removeClass('shopping_active');

   } else if (this.value == 'shop') {
      preloader_onchange();
      $('body').addClass('shopping_active');
   }
});


// stop propogation
// search and filter
$('.search-and-filter .dropdown-menu').click(function(e) {
   e.stopPropagation();
});

$('.search-and-filter .dropdown').on('shown.bs.dropdown', function() {
   $('.filter_overlay').addClass('opens');
   $('body').addClass('overflow-menu-stop');
})
$('.search-and-filter .dropdown').on('hidden.bs.dropdown', function() {
   $('.filter_overlay').removeClass('opens');
   $('body').removeClass('overflow-menu-stop');
});

// sticky side

$('[data-sticky-slide]').stickySidebar({
   topSpacing: 10,
   bottomSpacing: 10,
   minWidth: 993,
   innerWrapperSelector: '[data-sticky-inner]',
});

$('[data-cart-slide]').stickySidebar({
   topSpacing: 10,
   bottomSpacing: 10,
   minWidth: 767,
   innerWrapperSelector: '[data-cart-inner]',
});

// click to scroll
$('.sidebar-stick ul').onePageNav({
   currentClass: 'current',
   changeHash: false,
   scrollSpeed: 500
});

// gallery 
$('.menu_box').magnificPopup({
   delegate: 'a.img',
   type: 'image',
   closeOnContentClick: false,
   closeBtnInside: false,
   mainClass: 'mfp-with-zoom mfp-img-mobile',
   image: {
      verticalFit: true
   },
   gallery: {
      enabled: false
   },
   zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
         return element.find('img');
      }
   }
});

// btn added
$('.btn-add-loaded').on('click', function() {
   $(this).addClass('loaded');
   const buttons = $(this);
   setTimeout(function() {
      buttons.removeClass("loaded");
      buttons.addClass("loadeds");
      buttons.parent().addClass("item-added");
      iziToast.success({
         title: 'Food',
         position: 'bottomLeft',
         message: 'Vegetable Frankie Added Sucessfully!',
      });
   }, 500);
});

// change password


$("#changepassword").change(function() {
   if ($(this).prop('checked')) {
      $(".show-hide").addClass("open");
   } else {
      $(".show-hide").removeClass("open");
   }
});


// range slider

$(".price_range").ionRangeSlider({
   type: "double",
   grid: true,
   skin: "round",
   min: 0,
   max: 1000,
   from: 250,
   to: 600,
   prefix: "R"
});

// owl carosel


// categories slide
$('.subbanner-slide').owlCarousel({
   center: false,
   nav: false,
   dots: true,
   items: 1,
   autoplay: true,
   loop: true,
   autoplay: true,
   margin: 0
});

// footrer show hide


// footer closepanel

$(".site_footer .col-md-3 h3").click(function() {
   $(this).parent().toggleClass('open');
});


//Current Page
$(document).ready(function() {
   $("[href]").each(function() {
      if (this.href == window.location.href) {
         $(this).addClass("current_page");
      }
   });
});

// click to top
$(".click-top").on("click", function(e) {
   $("html, body").animate({
      scrollTop: 0
   }, 1000);
});

$(".usermenu-switch, .navigation, .navigation ul.reset li a").on("click", function(e) {
   $(".navigation").toggleClass('open');
   $("body").toggleClass('overflow-menu-stop');
});


// sidebar menu
$(".bars-toggle, .sidebar-stick li a, .sidebar-stick").on("click", function(e) {
   $("body").toggleClass('sidebar_menu_detail_toggle');
});

$(".sidebar-stick .box-boxed").on("click", function(event) {
   event.stopPropagation();
});
