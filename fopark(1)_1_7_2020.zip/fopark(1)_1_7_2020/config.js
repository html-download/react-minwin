'use strict';
const Confidence = require('confidence');
/*const Dotenv = require('dotenv');

Dotenv.config({ silent: true });*/

const criteria = {
    env: process.env.NODE_ENV
};

const config = {
    $meta: 'This file configures the plot device.',
    projectName: 'AU Parking',
    port: {
        web: {
            $filter: 'env',
            test: 8023,
            production: process.env.PORT,
            $default: 8023
        }
    },
    baseUrl: {
        $filter: 'env',
        $meta: 'values should not end in "/"',
        production: 'http://app.au-parking.com',
        $default: 'http://192.168.1.103:8023'
    },
    apiUrl: {
        $filter: 'env',
        production: 'https://api6.fopark-api.com',
        $default: 'https://api6.fopark-api.com'
    },
    apiToken: {
        $filter: 'env',
        production: '85be2342d3d0008fc76a448cee6febbd641d83053069c0a3',
        $default: '85be2342d3d0008fc76a448cee6febbd641d83053069c0a3'
    },
    client: {
        $filter: 'env',
        production: 'auburn',
        $default: 'auburn'
    },
    defaultZones: {
        $filter: 'env',
        production: [
            'a', 
            'b', 
            'c', 
            'pc-1', 
            'pc-2', 
            'pc-3', 
            'pc-4', 
            'ada', 
            //'temp'
        ],
        $default: [
            'a', 
            'b', 
            'c', 
            'pc-1', 
            'pc-2', 
            'pc-3', 
            'pc-4', 
            'ada', 
            //'temp'
        ],
    },
    googleApiKey: {
        $filter: 'env',
        production: 'AIzaSyDNlIS2XVNFDl-FS3HfSaEWAIzm4-t66Lw',
        $default: 'AIzaSyDNlIS2XVNFDl-FS3HfSaEWAIzm4-t66Lw'
        //$default: 'AIzaSyA6SE4CuWBxuaRMh-02bIX-6sEWMGaIO00'//old key
    },
    authAttempts: {
        forIp: 50,
        forIpAndUser: 7
    },
    cookieSecret: {
        $filter: 'env',
        //production: process.env.COOKIE_SECRET,
        production: '!k3yb04rdK4tz~4qu4~k3yb04rdd0ss!',
        $default: '!k3yb04rdK4tz~4qu4~k3yb04rdd0gz!'
    },
    mysqlEnvironment: {
        $filter: 'env',
        production: {
            "username": "xxxxx",
            "password": "xxxxx",
            "database": "xxxxx",
            "host": "xxxxx",
            "dialect": "mysql"
        },
        $default: {
            "username": "xxxxx",
            "password": "xxxxx",
            "database": "xxxxx",
            "host": "xxxxx",
            "dialect": "mysql"
        },
        test: {
            "username": "xxxxx",
            "password": "xxxxx",
            "database": "xxxxx",
            "host": "xxxxx",
            "dialect": "mysql"
        }
    },
    nodemailer: {
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        auth: {
            user: 'technoducedevelopers@gmail.com',
            pass: process.env.SMTP_PASSWORD
        }
    },
    system: {
        fromAddress: {
            name: 'AU Parking',
            address: 'technoducedevelopers@gmail.com'
        },
        toAddress: {
            name: 'AU Parking',
            address: 'technoducedevelopers@gmail.com'
        }
    },

};


const store = new Confidence.Store(config);


exports.get = function (key) {

    return store.get(key, criteria);
};


exports.meta = function (key) {

    return store.meta(key, criteria);
};
