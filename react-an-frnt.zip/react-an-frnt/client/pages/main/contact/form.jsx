'use strict';
const Actions = require('./actions');
const Alert = require('../../../components/alert.jsx');
const Button = require('../../../components/form/button.jsx');
const ControlGroup = require('../../../components/form/control-group.jsx');
const React = require('react');
const Spinner = require('../../../components/form/spinner.jsx');
const Store = require('./store');
const TextControl = require('../../../components/form/text-control.jsx');
const TextareaControl = require('../../../components/form/textarea-control.jsx');
const Toaster = require('../../../helpers/toaster.js');

class Form extends React.Component {
    constructor(props) {

        super(props);

        this.input = {};
        this.state = Store.getState();
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));

        if (this.input.name) {
            this.input.name.focus();
        }
    }

    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {

        this.setState(Store.getState());
    }

    handleSubmit(event) {

        event.preventDefault();
        event.stopPropagation();

        Toaster.error('Page is under construction!')

      {/* Actions.sendMessage({
            name: this.input.name.value(),
            lastname: this.input.lastname.value(),
            email: this.input.email.value(),
            phonenumber: this.input.phonenumber.value(),
            message: this.input.message.value()
        });   */}

    }

    render() {

        let alert = [];

        if (this.state.success) {
            alert = <Alert
                type="success"
                message="Success. We have received your message."
            />;
        }
        else if (this.state.error) {
            alert = <Alert
                type="danger"
                message={this.state.error}
            />;
        }

        let formElements;

        if (!this.state.success) {
            formElements = <fieldset>
         <div className="row">
               <div className="col-md-6">
                <TextControl
                    ref={(c) => (this.input.name = c)}
                    name="name"
                    label="Enter Your First name"
                    hasError={this.state.hasError.name}
                    help={this.state.help.name}
                    disabled={this.state.loading}
                />
                </div>
                  <div className="col-md-6">
                <TextControl
                    ref={(c) => (this.input.lastname = c)}
                    name="lastname"
                    label="Enter Your Last Name"
                    hasError={this.state.hasError.lastname}
                    help={this.state.help.lastname}
                    disabled={this.state.loading}
                />
                </div>
                 <div className="col-md-6">
                <TextControl
                    ref={(c) => (this.input.email = c)}
                    name="email"
                    label="Enter your Email Id"
                    hasError={this.state.hasError.email}
                    help={this.state.help.email}
                    disabled={this.state.loading}
                />
                </div>
                  <div className="col-md-6">
                <TextControl
                    ref={(c) => (this.input.phonenumber = c)}
                    name="phonenumber"
                    label="Enter Your Phone Number"
                    hasError={this.state.hasError.phonenumber}
                    help={this.state.help.phonenumber}
                    disabled={this.state.loading}
                />
                </div>
                  <div className="col-md-12">
                <TextareaControl
                    ref={(c) => (this.input.message = c)}
                    name="message"
                    label="Message"
                    rows="5"
                    hasError={this.state.hasError.message}
                    help={this.state.help.message}
                    disabled={this.state.loading}
                />

                <ControlGroup hideLabel={true} hideHelp={true}>
                    <Button
                        type="submit"
                        inputClasses={{ 'btn-primary': true }}
                        disabled={this.state.loading}>

                        Submit
                        <Spinner space="left" show={this.state.loading} />
                    </Button>
                </ControlGroup>
                 </div>
                </div>
            </fieldset>;
        }

        return (
            <div className="col-md-8 contact_form">
                <h5>Get in Touch</h5>
                <form onSubmit={this.handleSubmit.bind(this)}>
                    {alert}
                   
                    {formElements}
                                
                </form>
            </div>
        );
    }
}


module.exports = Form;
