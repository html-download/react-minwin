/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16DeliveryBoy', {
    deliveryBoyId: {
      type: DataTypes.INTEGER(11).UNSIGNED,
      allowNull: false,
      primaryKey: true,
      field: 'delivery_boy_id'
    },
    deliveryBoyKey: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'delivery_boy_key'
    },
    deliveryBoyName: {
      type: DataTypes.STRING(50),
      allowNull: false,
      field: 'delivery_boy_name'
    },
    deliveryBoyUsername: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'delivery_boy_username'
    },
    deliveryBoyEmail: {
      type: DataTypes.STRING(128),
      allowNull: false,
      field: 'delivery_boy_email'
    },
    deliveryBoyPassword: {
      type: DataTypes.STRING(70),
      allowNull: false,
      field: 'delivery_boy_password'
    },
    commision: {
      type: DataTypes.FLOAT,
      allowNull: false,
      field: 'commision'
    },
    status: {
      type: DataTypes.ENUM('Active','Onjob','Off','Deactive'),
      allowNull: false,
      defaultValue: 'Active',
      field: 'status'
    },
    deviceToken: {
      type: DataTypes.STRING(130),
      allowNull: false,
      field: 'device_token'
    },
    deviceType: {
      type: DataTypes.INTEGER(1),
      allowNull: false,
      field: 'device_type'
    },
    createdBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'created_by'
    },
    modifiedBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'modified_by'
    },
    createdDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'created_datetime'
    },
    modifiedDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'modified_datetime'
    },
    latitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'latitude'
    },
    longitude: {
      type: DataTypes.STRING(24),
      allowNull: false,
      field: 'longitude'
    },
    profileImage: {
      type: DataTypes.STRING(250),
      allowNull: true,
      field: 'profile_image'
    },
    mobileNumber: {
      type: DataTypes.BIGINT,
      allowNull: false,
      field: 'mobile_number'
    }
  }, {
    tableName: 'ss16_delivery_boy'
  });
};
