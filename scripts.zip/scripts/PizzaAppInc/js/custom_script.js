
new WOW().init();

//Select
$( document ).ready(function() {
$('#selectbox-city-list2, #cityloadingvalues').selectpicker();
}); 
//select end



 signUpWithFacebook = function() {
        FB.login(function(response){
            if (response.authResponse) 
                window.location.href = base_url+"/users/fb_signup.html?referalcode="+$('#referal_code_friend').val();
        },{scope: 'public_profile,email'});
        return false;
    };

    loginWithFacebook = function() {
        FB.login(function(response){
            if (response.authResponse) 
                window.location.href = base_url+"/users/fb_login.html?referalcode="+$('#referal_code_friend').val();
        },{scope: 'public_profile,email'});
        return false;
    };

    logoutWithFacebook = function() {
        //alert("hai");
        /*FB.logout(function(response){
            alert("hai");
        });*/
    };

    window.fbAsyncInit = function() {
        FB.init({
            appId:  app_id,
            cookie: true, // This is important, it's not enabled by default
            version: 'v2.5'
        });
    };
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {
        return;
    }
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

function validateEmail(email) {
    var emailReg = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    var valid = emailReg.test(email);
    if (!valid) return false;
    else
        return true;
}

function setupLabel() {
    if ($('.label_check input').length) {
        $('.label_check').each(function() {
            $(this).removeClass('c_on');
        });
        $('.label_check input:checked').each(function() {
            $(this).parent('label').addClass('c_on');
        });
    };
    if ($('.label_radio input').length) {
        $('.label_radio').each(function() {
            $(this).removeClass('r_on');
        });
        $('.label_radio input:checked').each(function() {
            $(this).parent('label').addClass('r_on');
        });
    };
};

function validation($element) {
    $error = 0;
    postal_code_expr = /^[0-9]{4,6}$/;
    var re = /^\w+$/;/*numbers and alphabets*/
    $($element).each(function() {
        
        if ($(this).is("input, select")) {
            if ($(this).hasClass("required") && ($(this).val() == "")) {
                $(this).siblings(".errors").text($(this).attr("name") + ' ' + cannot_be_empty);
                $error = 1;
            } else if ($(this).hasClass("password_repeat") && ($(this).val() != "")) {
                if ($("#signup_form .password").val() != $(this).val()) {
                    $(this).siblings(".errors").text($(this).attr("name") + ' ' + "doesn't match");
                    $error = 1;
                }
            } else if ($(this).hasClass("password") && ($(this).val() != "")) {
                
                if($('#signup_form #signup_password').val() != '' && !(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])\S{8,12}$/).test($('#signup_password').val())) {
                    $(this).siblings(".errors").text($(this).attr("name") + ' ' + "accept minmum length of 8 and contaning at least 1 Upper, Lower and numeric character (a-z,A-Z,0-9,!@#$%^&*)");
                    $error = 1;
                }
            
            } else if ($(this).hasClass("minimum") && ($(this).val() != "") && ($(this).val().length < parseInt($(this).attr("min")))) {
                $(this).siblings(".errors").text($(this).attr("name") + " have minimum " + $(this).attr("min") + " characters.");
                $error = 1;
            } else if ($(this).hasClass("maximum") && ($(this).val() != "") && ($(this).val().length > parseInt($(this).attr("min")))) {
                $(this).siblings(".errors").text($(this).attr("name") + " have maximum " + $(this).attr("max") + " characters.");
                $error = 1;
            } else if ($(this).hasClass("email") && ($(this).val() != "") && (!validateEmail($(this).val()))) {
                $(this).siblings(".errors").text(invalid_email);
                $error = 1;
            } 
          /*  else if ($(this).hasClass("password") != $(this).hasClass("minimum")) {
                $(this).siblings(".errors1").text("Password does not match");
                $error = 1;
            }*/
            else if ($(this).hasClass("numbersOnly") && ($(this).val() != "") && (!$.isNumeric($(this).val()))) {
                $(this).siblings(".errors").text($(this).attr("name") + ' '+ accept_numbers);
                $error = 1;
            } else if ($(this).hasClass("anOnly") && ($(this).val() != "") && (!(re).test($(this).val()))) {
                $(this).siblings(".errors").text($(this).attr("name") + ' ' + accept_numbers_alphabets);
                $error = 1;
            } else if ($(this).hasClass("phone")) {
                if (!$.isNumeric($(this).val())) {
                    $(this).siblings(".errors").text($(this).attr("name") +  ' ' + accept_numbers);
                    $error = 1;
                } else if ($(this).val().length > 7 || $(this).val().length < 16) {
                    $(this).siblings(".errors").text($(this).attr("name") + " accept length between 7 to 16");
                    $error = 1;
                }
                else
                {
                    $error = 0;
                }
            } else if ($(this).hasClass("custom_phone") && ($(this).val() != "") && (!(/^[0-9]{7,16}$/).test($(this).val()))) {
                $(this).siblings(".errors").text($(this).attr("name") + mob_error);
                $error = 1;
            } else if ($(this).hasClass("postal_code") && ($(this).val() != '') && (!(postal_code_expr).test($(this).val()))) {
                $(this).siblings(".errors").text(postal_error);
                $error = 1; 
            } else if ($(this).hasClass("must_check") && (!$(this).is(":checked"))) {
                $(this).siblings(".errors").text(please_accept +' '+ $(this).attr("name"));
                $error = 1;
            } 
            else
                $(this).siblings(".errors").text("");
        }

    });
    return $error;
}

function showAutoComplete() {
    return true;
    $.ajax({
        url: base_url + "/area.html",
        type: "get",
        data: {
            city_key: $("#selectbox-city-list2").val()
        },
        dataType: "json",
        beforeSend: function() {
            $("#inputArea").parent().prepend("<div class='header_loading'><img src='" + theme_path + "loader.gif'/></div>");
        },
        complete: function() {
            $(".header_loading").remove();
        },
        success: function(data) {
            $options = [];
            $.each(data, function(i, field) {
                $option = {
                    "label": field.location,
                    "value": field.area_key
                };
                $options.push($option);
            });
            $("#inputArea").autocomplete({
                source: $options,
                focus: function(event, ui) {
                    $("#inputArea").val(ui.item.label);
                    $("#inputAreaCtrl").val(ui.item.value);
                    return false;
                },
                select: function(event, ui) {
                    $("#inputArea").val(ui.item.label);
                    $("#inputAreaCtrl").val(ui.item.value);
                    return false;
                },
                minLength: 1,
            });
        },
    });
}
$(document).ready(function() {

    
    if ($(".select_loader").length) $(".select_loader").remove();
    $('.label_check, .label_radio').click(function() {
        setupLabel();
    });
    setupLabel();
    $(".alert-success,.alert-danger").delay(5000).fadeOut('slow', function() {
        $(this).remove();
    });
   
    $(document).on("click", ".actionButtons", function() {
        $(".action_modal").find(".errors").html("");
        $(".action_modal").find("input,textarea").val("");
        $("#login_form").find("#email_id").val(customer_email);
        if (customer_email) $("#login_form").find("#checkbox-1-1").attr("checked", true);
    });
   
    $(document).on("submit", "#find_shop_form", function() { 
        $errors = 0;
        if ($(this).hasClass(".find_rest")) $("#typeRestaurant").val(1);
        if ($(this).hasClass(".find_all_shop")) $("#typeRestaurant").val(0);
        if($("#cityloadingvalues").val()=='')
        {
            $(".sub_error").html(Area_cannot_be_empty);
            $("#cityloadingvalues").siblings(".errors").html(Area_cannot_be_empty);
            $errors = 1;
        }
        if ($("#selectbox-city-list2").val() == "") {
            $("#selectbox-city-list2").siblings(".errors").html(Please_select_the_city);
            $errors = 1;
        } else
            $("#selectbox-city-list2").siblings(".errors").html("");
        if ($("#selectbox-category-list").val() == "") {
            $("#selectbox-category-list").siblings(".errors").html(Please_select_category);
            $errors = 1;
        } else
            $("#selectbox-category-list").siblings(".errors").html("");
        if ($("#cityloadingvalues").val() == "") {
            $(".sub_error").html(Area_cannot_be_empty);
            $("#cityloadingvalues").siblings(".errors").html(Area_cannot_be_empty);
            $errors = 1;
        } 
        else
            $("#cityloadingvalues").siblings(".errors").html("");
        if ($errors) return false;
    });
    $(document).on("click", "#login_button", function() {
        var url = window.location.href;
        if (!validation($("#login_form").find(".validation"))) {
            if ($("#checkbox-1-1").prop("checked")) $param = {
                customer_email: $("#email_id").val(),
                customer_password: $("#password").val(),
                rememeber_me: 1
            };
            else
                $param = {
                    customer_email: $("#email_id").val(),
                    customer_password: $("#password").val()
                };
            $.ajax({
                url: base_url + "/users/login.html",
                type: "post",
                data: $param,
                beforeSend: function() {
                    $("#login_button").parent().prepend("<div class='spinner'>  <div class='rect1'></div>  <div class='rect2'></div>  <div class='rect3'></div>  <div class='rect4'></div>  <div class='rect5'></div></div>");
                },
                complete: function() {
                    $(".spinner").remove();
                },
                dataType: "json",
                success: function(data) {
                    $("#login_form").find(".errors").html("");
                    if (parseInt(data['httpcode']) != 200) {
                        $.each(data['error'], function(key, value) {
                            $("#login_form").find("." + key).html(value[0]);
                        });
                    } else{
                        //window.location.href = url;
                        window.location.reload(true);
                    }
                }
            });
        }
        return false;
    });
    $(document).on("click", "#signup_button", function() {
        var url = window.location.href;
        if (!validation($("#signup_form").find(".validation"))) {
//alert("T");
            $.ajax({
                url: base_url + "/users/signup.html",
                type: "POST",
                data: {
                    customer_name: $("#signup_name").val(),
                    customer_last_name: $("#signup_last_name").val(),
                    password: $("#signup_password").val(),
                    repeat_password: $("#signup_repeat_password").val(),
                    customer_email: $("#signup_email").val(),
                    customer_mobile: $("#signup_phone").val(),
                    referal_code_friend: $("#referal_code_friend").val(),
                    // nit_number: $("#signup_nit_number").val(),
                },
                beforeSend: function() {
                    $("#signup_button").parent().prepend("<div class='spinner'>  <div class='rect1'></div>  <div class='rect2'></div>  <div class='rect3'></div>  <div class='rect4'></div>  <div class='rect5'></div></div>");
                },
                complete: function() {
                    $(".spinner").remove();
                },
                dataType: "json",
                success: function(data) {					
                    if (parseInt(data['httpcode']) != 200) {
                        $.each(data['error'], function(key, value) {
                            $("#signup_form").find("." + key).html(value);
                        });
                    } else{
                        //window.location.href = url;
                        window.history.pushState("", "", "/");
                        window.location.reload(true);
                    }
                }
                
            });
        }
        return false;
    });
    $(document).on("click", "#forgot_pwd_button", function() {
        if (!validation($("#forgot_pwd_form").find(".validation"))) {
            $.ajax({
                url: base_url + "/users/forgot_password.html",
                type: "POST",
                data: {
                    customer_email: $("#forgot_pwd_email").val()
                },
                dataType: "json",
                beforeSend: function() {
                    $("#forgot_pwd_button").parent().prepend("<div class='spinner'>  <div class='rect1'></div>  <div class='rect2'></div>  <div class='rect3'></div>  <div class='rect4'></div>  <div class='rect5'></div></div>");
                },
                complete: function() {
                    $(".spinner").remove();
                },
                success: function(data) {
                    if (parseInt(data['httpcode']) != 200) {
                        $.each(data['error'], function(key, value) {
                            $("#forgot_pwd_form").find("." + key).html(value);
                        });
                    } else
                        window.location.href = base_url;
                }
            });
        }
        return false;
    });
    $(document).on("click", ".sign_up", function() {
       
        //var subcityerr = $('#subscityerr').val();
        var emailsubserr = $('#emailsubserr').val();
        var invalidemailerr = $('#invalidemailerr').val();
        var termscond = $('#termscond').val();
        $error = 0;
        // if ($("#selectbox-city-list1").val() == "") {
        //     $("#city_list_errors").html(subcityerr);
        //     $error = 1;
        // } else
        //     $("#city_list_errors").html("");
        if ($("#inputEmail").val() == "") {
            $("#inputEmail").siblings(".errors").html(emailsubserr);
            $error = 1;
        } else if (!validateEmail($("#inputEmail").val())) {
            $("#inputEmail").siblings(".errors").html(invalidemailerr);
            $error = 1;
        } else
            $("#inputEmail").siblings(".errors").html("");
        if ($("#checkbox-3-3:checked").length == 0) {
            $("#checkbox_3_3_errors").html(termscond);
            $error = 1;
        } else
            $("#checkbox_3_3_errors").html("");
        if (!$error) {
            $loader = theme_path;
            $params = {
               // "city": $("#selectbox-city-list1").val(),
                "email": $("#inputEmail").val()
            }
            $.ajax({
                url: base_url + "/subscribe.html",
                type: "post",
                data: $params,
                dataType: "json",
                beforeSend: function() {
                    $("#subscribe").addClass("subscribe_loading");
                    $("#subscribe").append('<div class="subscribe_loader"><img src=' + $loader + 'loader.gif></div>');
                },
                complete: function() {
                    $("#subscribe").removeClass("subscribe_loading");
                    $(".subscribe_loader").remove();
                },
                success: function(data) {
                   
                    if (data.error) {
                        if (data.error.email) $("#inputEmail").siblings(".errors").html(data.error.email);
                        else
                            $("#checkbox_3_3_errors").html("Please try again later");
                    } else
                        $(".subscription").html("<p class='after-signup'>"+data.success+"</p>");
                    },
            });
        }
        return false;
    })

    $(document).on("click", "#joinus_button", function() {
        var url = window.location.href;       
        if (!validation($("#join_form").find(".validation"))) {
            $.ajax({
                url: base_url + "/users/joinus.html",
                type: "POST",
                data: {
                    restaurant_name: $("#rest_name").val(),
                    restaurant_city: $("#rest_city").val(),
                    restaurant_area: $("#rest_area").val(),
                    vendor_name: $("#vendor_name").val(),
                    email: $("#vendor_email").val(),
                    phone: $("#contact_number").val()
                },
                beforeSend: function() {
                    $("#joinus_button").parent().prepend("<div class='login_loading'><img src='" + theme_path + "loader.gif'/></div>");
                },
                complete: function() {
                    $(".login_loading").remove();
                },
                dataType: "json",
                success: function(data) {
                    if (parseInt(data['httpcode']) != 200) {
                        $.each(data['error'], function(key, value) {
                            $("#join_form").find("." + key).html(value);
                        });
                    } else
                        window.location.href = url;
                }
            });
        }
        return false;
    });
});


// pace loader

/*! pace 1.0.0 */
(function(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X=[].slice,Y={}.hasOwnProperty,Z=function(a,b){function c(){this.constructor=a}for(var d in b)Y.call(b,d)&&(a[d]=b[d]);return c.prototype=b.prototype,a.prototype=new c,a.__super__=b.prototype,a},$=[].indexOf||function(a){for(var b=0,c=this.length;c>b;b++)if(b in this&&this[b]===a)return b;return-1};for(u={catchupTime:100,initialRate:.03,minTime:250,ghostTime:100,maxProgressPerFrame:20,easeFactor:1.25,startOnPageLoad:!0,restartOnPushState:!0,restartOnRequestAfter:500,target:"body",elements:{checkInterval:100,selectors:["body"]},eventLag:{minSamples:10,sampleCount:3,lagThreshold:3},ajax:{trackMethods:["GET"],trackWebSockets:!0,ignoreURLs:[]}},C=function(){var a;return null!=(a="undefined"!=typeof performance&&null!==performance&&"function"==typeof performance.now?performance.now():void 0)?a:+new Date},E=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||window.msRequestAnimationFrame,t=window.cancelAnimationFrame||window.mozCancelAnimationFrame,null==E&&(E=function(a){return setTimeout(a,50)},t=function(a){return clearTimeout(a)}),G=function(a){var b,c;return b=C(),(c=function(){var d;return d=C()-b,d>=33?(b=C(),a(d,function(){return E(c)})):setTimeout(c,33-d)})()},F=function(){var a,b,c;return c=arguments[0],b=arguments[1],a=3<=arguments.length?X.call(arguments,2):[],"function"==typeof c[b]?c[b].apply(c,a):c[b]},v=function(){var a,b,c,d,e,f,g;for(b=arguments[0],d=2<=arguments.length?X.call(arguments,1):[],f=0,g=d.length;g>f;f++)if(c=d[f])for(a in c)Y.call(c,a)&&(e=c[a],null!=b[a]&&"object"==typeof b[a]&&null!=e&&"object"==typeof e?v(b[a],e):b[a]=e);return b},q=function(a){var b,c,d,e,f;for(c=b=0,e=0,f=a.length;f>e;e++)d=a[e],c+=Math.abs(d),b++;return c/b},x=function(a,b){var c,d,e;if(null==a&&(a="options"),null==b&&(b=!0),e=document.querySelector("[data-pace-"+a+"]")){if(c=e.getAttribute("data-pace-"+a),!b)return c;try{return JSON.parse(c)}catch(f){return d=f,"undefined"!=typeof console&&null!==console?console.error("Error parsing inline pace options",d):void 0}}},g=function(){function a(){}return a.prototype.on=function(a,b,c,d){var e;return null==d&&(d=!1),null==this.bindings&&(this.bindings={}),null==(e=this.bindings)[a]&&(e[a]=[]),this.bindings[a].push({handler:b,ctx:c,once:d})},a.prototype.once=function(a,b,c){return this.on(a,b,c,!0)},a.prototype.off=function(a,b){var c,d,e;if(null!=(null!=(d=this.bindings)?d[a]:void 0)){if(null==b)return delete this.bindings[a];for(c=0,e=[];c<this.bindings[a].length;)e.push(this.bindings[a][c].handler===b?this.bindings[a].splice(c,1):c++);return e}},a.prototype.trigger=function(){var a,b,c,d,e,f,g,h,i;if(c=arguments[0],a=2<=arguments.length?X.call(arguments,1):[],null!=(g=this.bindings)?g[c]:void 0){for(e=0,i=[];e<this.bindings[c].length;)h=this.bindings[c][e],d=h.handler,b=h.ctx,f=h.once,d.apply(null!=b?b:this,a),i.push(f?this.bindings[c].splice(e,1):e++);return i}},a}(),j=window.Pace||{},window.Pace=j,v(j,g.prototype),D=j.options=v({},u,window.paceOptions,x()),U=["ajax","document","eventLag","elements"],Q=0,S=U.length;S>Q;Q++)K=U[Q],D[K]===!0&&(D[K]=u[K]);i=function(a){function b(){return V=b.__super__.constructor.apply(this,arguments)}return Z(b,a),b}(Error),b=function(){function a(){this.progress=0}return a.prototype.getElement=function(){var a;if(null==this.el){if(a=document.querySelector(D.target),!a)throw new i;this.el=document.createElement("div"),this.el.className="pace pace-active",document.body.className=document.body.className.replace(/pace-done/g,""),document.body.className+=" pace-running",this.el.innerHTML='<div class="pace-progress">\n  <div class="pace-progress-inner"></div>\n</div>\n<div class="pace-activity"></div>',null!=a.firstChild?a.insertBefore(this.el,a.firstChild):a.appendChild(this.el)}return this.el},a.prototype.finish=function(){var a;return a=this.getElement(),a.className=a.className.replace("pace-active",""),a.className+=" pace-inactive",document.body.className=document.body.className.replace("pace-running",""),document.body.className+=" pace-done"},a.prototype.update=function(a){return this.progress=a,this.render()},a.prototype.destroy=function(){try{this.getElement().parentNode.removeChild(this.getElement())}catch(a){i=a}return this.el=void 0},a.prototype.render=function(){var a,b,c,d,e,f,g;if(null==document.querySelector(D.target))return!1;for(a=this.getElement(),d="translate3d("+this.progress+"%, 0, 0)",g=["webkitTransform","msTransform","transform"],e=0,f=g.length;f>e;e++)b=g[e],a.children[0].style[b]=d;return(!this.lastRenderedProgress||this.lastRenderedProgress|0!==this.progress|0)&&(a.children[0].setAttribute("data-progress-text",""+(0|this.progress)+"%"),this.progress>=100?c="99":(c=this.progress<10?"0":"",c+=0|this.progress),a.children[0].setAttribute("data-progress",""+c)),this.lastRenderedProgress=this.progress},a.prototype.done=function(){return this.progress>=100},a}(),h=function(){function a(){this.bindings={}}return a.prototype.trigger=function(a,b){var c,d,e,f,g;if(null!=this.bindings[a]){for(f=this.bindings[a],g=[],d=0,e=f.length;e>d;d++)c=f[d],g.push(c.call(this,b));return g}},a.prototype.on=function(a,b){var c;return null==(c=this.bindings)[a]&&(c[a]=[]),this.bindings[a].push(b)},a}(),P=window.XMLHttpRequest,O=window.XDomainRequest,N=window.WebSocket,w=function(a,b){var c,d,e,f;f=[];for(d in b.prototype)try{e=b.prototype[d],f.push(null==a[d]&&"function"!=typeof e?a[d]=e:void 0)}catch(g){c=g}return f},A=[],j.ignore=function(){var a,b,c;return b=arguments[0],a=2<=arguments.length?X.call(arguments,1):[],A.unshift("ignore"),c=b.apply(null,a),A.shift(),c},j.track=function(){var a,b,c;return b=arguments[0],a=2<=arguments.length?X.call(arguments,1):[],A.unshift("track"),c=b.apply(null,a),A.shift(),c},J=function(a){var b;if(null==a&&(a="GET"),"track"===A[0])return"force";if(!A.length&&D.ajax){if("socket"===a&&D.ajax.trackWebSockets)return!0;if(b=a.toUpperCase(),$.call(D.ajax.trackMethods,b)>=0)return!0}return!1},k=function(a){function b(){var a,c=this;b.__super__.constructor.apply(this,arguments),a=function(a){var b;return b=a.open,a.open=function(d,e){return J(d)&&c.trigger("request",{type:d,url:e,request:a}),b.apply(a,arguments)}},window.XMLHttpRequest=function(b){var c;return c=new P(b),a(c),c};try{w(window.XMLHttpRequest,P)}catch(d){}if(null!=O){window.XDomainRequest=function(){var b;return b=new O,a(b),b};try{w(window.XDomainRequest,O)}catch(d){}}if(null!=N&&D.ajax.trackWebSockets){window.WebSocket=function(a,b){var d;return d=null!=b?new N(a,b):new N(a),J("socket")&&c.trigger("request",{type:"socket",url:a,protocols:b,request:d}),d};try{w(window.WebSocket,N)}catch(d){}}}return Z(b,a),b}(h),R=null,y=function(){return null==R&&(R=new k),R},I=function(a){var b,c,d,e;for(e=D.ajax.ignoreURLs,c=0,d=e.length;d>c;c++)if(b=e[c],"string"==typeof b){if(-1!==a.indexOf(b))return!0}else if(b.test(a))return!0;return!1},y().on("request",function(b){var c,d,e,f,g;return f=b.type,e=b.request,g=b.url,I(g)?void 0:j.running||D.restartOnRequestAfter===!1&&"force"!==J(f)?void 0:(d=arguments,c=D.restartOnRequestAfter||0,"boolean"==typeof c&&(c=0),setTimeout(function(){var b,c,g,h,i,k;if(b="socket"===f?e.readyState<2:0<(h=e.readyState)&&4>h){for(j.restart(),i=j.sources,k=[],c=0,g=i.length;g>c;c++){if(K=i[c],K instanceof a){K.watch.apply(K,d);break}k.push(void 0)}return k}},c))}),a=function(){function a(){var a=this;this.elements=[],y().on("request",function(){return a.watch.apply(a,arguments)})}return a.prototype.watch=function(a){var b,c,d,e;return d=a.type,b=a.request,e=a.url,I(e)?void 0:(c="socket"===d?new n(b):new o(b),this.elements.push(c))},a}(),o=function(){function a(a){var b,c,d,e,f,g,h=this;if(this.progress=0,null!=window.ProgressEvent)for(c=null,a.addEventListener("progress",function(a){return h.progress=a.lengthComputable?100*a.loaded/a.total:h.progress+(100-h.progress)/2},!1),g=["load","abort","timeout","error"],d=0,e=g.length;e>d;d++)b=g[d],a.addEventListener(b,function(){return h.progress=100},!1);else f=a.onreadystatechange,a.onreadystatechange=function(){var b;return 0===(b=a.readyState)||4===b?h.progress=100:3===a.readyState&&(h.progress=50),"function"==typeof f?f.apply(null,arguments):void 0}}return a}(),n=function(){function a(a){var b,c,d,e,f=this;for(this.progress=0,e=["error","open"],c=0,d=e.length;d>c;c++)b=e[c],a.addEventListener(b,function(){return f.progress=100},!1)}return a}(),d=function(){function a(a){var b,c,d,f;for(null==a&&(a={}),this.elements=[],null==a.selectors&&(a.selectors=[]),f=a.selectors,c=0,d=f.length;d>c;c++)b=f[c],this.elements.push(new e(b))}return a}(),e=function(){function a(a){this.selector=a,this.progress=0,this.check()}return a.prototype.check=function(){var a=this;return document.querySelector(this.selector)?this.done():setTimeout(function(){return a.check()},D.elements.checkInterval)},a.prototype.done=function(){return this.progress=100},a}(),c=function(){function a(){var a,b,c=this;this.progress=null!=(b=this.states[document.readyState])?b:100,a=document.onreadystatechange,document.onreadystatechange=function(){return null!=c.states[document.readyState]&&(c.progress=c.states[document.readyState]),"function"==typeof a?a.apply(null,arguments):void 0}}return a.prototype.states={loading:0,interactive:50,complete:100},a}(),f=function(){function a(){var a,b,c,d,e,f=this;this.progress=0,a=0,e=[],d=0,c=C(),b=setInterval(function(){var g;return g=C()-c-50,c=C(),e.push(g),e.length>D.eventLag.sampleCount&&e.shift(),a=q(e),++d>=D.eventLag.minSamples&&a<D.eventLag.lagThreshold?(f.progress=100,clearInterval(b)):f.progress=100*(3/(a+3))},50)}return a}(),m=function(){function a(a){this.source=a,this.last=this.sinceLastUpdate=0,this.rate=D.initialRate,this.catchup=0,this.progress=this.lastProgress=0,null!=this.source&&(this.progress=F(this.source,"progress"))}return a.prototype.tick=function(a,b){var c;return null==b&&(b=F(this.source,"progress")),b>=100&&(this.done=!0),b===this.last?this.sinceLastUpdate+=a:(this.sinceLastUpdate&&(this.rate=(b-this.last)/this.sinceLastUpdate),this.catchup=(b-this.progress)/D.catchupTime,this.sinceLastUpdate=0,this.last=b),b>this.progress&&(this.progress+=this.catchup*a),c=1-Math.pow(this.progress/100,D.easeFactor),this.progress+=c*this.rate*a,this.progress=Math.min(this.lastProgress+D.maxProgressPerFrame,this.progress),this.progress=Math.max(0,this.progress),this.progress=Math.min(100,this.progress),this.lastProgress=this.progress,this.progress},a}(),L=null,H=null,r=null,M=null,p=null,s=null,j.running=!1,z=function(){return D.restartOnPushState?j.restart():void 0},null!=window.history.pushState&&(T=window.history.pushState,window.history.pushState=function(){return z(),T.apply(window.history,arguments)}),null!=window.history.replaceState&&(W=window.history.replaceState,window.history.replaceState=function(){return z(),W.apply(window.history,arguments)}),l={ajax:a,elements:d,document:c,eventLag:f},(B=function(){var a,c,d,e,f,g,h,i;for(j.sources=L=[],g=["ajax","elements","document","eventLag"],c=0,e=g.length;e>c;c++)a=g[c],D[a]!==!1&&L.push(new l[a](D[a]));for(i=null!=(h=D.extraSources)?h:[],d=0,f=i.length;f>d;d++)K=i[d],L.push(new K(D));return j.bar=r=new b,H=[],M=new m})(),j.stop=function(){return j.trigger("stop"),j.running=!1,r.destroy(),s=!0,null!=p&&("function"==typeof t&&t(p),p=null),B()},j.restart=function(){return j.trigger("restart"),j.stop(),j.start()},j.go=function(){var a;return j.running=!0,r.render(),a=C(),s=!1,p=G(function(b,c){var d,e,f,g,h,i,k,l,n,o,p,q,t,u,v,w;for(l=100-r.progress,e=p=0,f=!0,i=q=0,u=L.length;u>q;i=++q)for(K=L[i],o=null!=H[i]?H[i]:H[i]=[],h=null!=(w=K.elements)?w:[K],k=t=0,v=h.length;v>t;k=++t)g=h[k],n=null!=o[k]?o[k]:o[k]=new m(g),f&=n.done,n.done||(e++,p+=n.tick(b));return d=p/e,r.update(M.tick(b,d)),r.done()||f||s?(r.update(100),j.trigger("done"),setTimeout(function(){return r.finish(),j.running=!1,j.trigger("hide")},Math.max(D.ghostTime,Math.max(D.minTime-(C()-a),0)))):c()})},j.start=function(a){v(D,a),j.running=!0;try{r.render()}catch(b){i=b}return document.querySelector(".pace")?(j.trigger("start"),j.go()):setTimeout(j.start,50)},"function"==typeof define&&define.amd?define(function(){return j}):"object"==typeof exports?module.exports=j:D.startOnPageLoad&&j.start()}).call(this);



// scrolltop

var scrolltotop={setting:{startline:100,scrollto:0,scrollduration:1e3,fadeduration:[500,100]},controlHTML:'<div class="scrollTop fa fa-angle-up"></div>',controlattrs:{offsetx:30,offsety:50},anchorkeyword:"#top",state:{isvisible:!1,shouldvisible:!1},scrollup:function(){this.cssfixedsupport||this.$control.css({opacity:0});var t=isNaN(this.setting.scrollto)?this.setting.scrollto:parseInt(this.setting.scrollto);t="string"==typeof t&&1==jQuery("#"+t).length?jQuery("#"+t).offset().top:0,this.$body.animate({scrollTop:t},this.setting.scrollduration)},keepfixed:function(){var t=jQuery(window),o=t.scrollLeft()+t.width()-this.$control.width()-this.controlattrs.offsetx,s=t.scrollTop()+t.height()-this.$control.height()-this.controlattrs.offsety;this.$control.css({left:o+"px",top:s+"px"})},togglecontrol:function(){var t=jQuery(window).scrollTop();this.cssfixedsupport||this.keepfixed(),this.state.shouldvisible=t>=this.setting.startline?!0:!1,this.state.shouldvisible&&!this.state.isvisible?(this.$control.stop().animate({opacity:1},this.setting.fadeduration[0]),this.state.isvisible=!0):0==this.state.shouldvisible&&this.state.isvisible&&(this.$control.stop().animate({opacity:0},this.setting.fadeduration[1]),this.state.isvisible=!1)},init:function(){jQuery(document).ready(function(t){var o=scrolltotop,s=document.all;o.cssfixedsupport=!s||s&&"CSS1Compat"==document.compatMode&&window.XMLHttpRequest,o.$body=t(window.opera?"CSS1Compat"==document.compatMode?"html":"body":"html,body"),o.$control=t('<div id="topcontrol">'+o.controlHTML+"</div>").css({position:o.cssfixedsupport?"fixed":"absolute",bottom:o.controlattrs.offsety,right:o.controlattrs.offsetx,opacity:0,cursor:"pointer"}).attr({title:"Back to Top"}).click(function(){return o.scrollup(),!1}).appendTo("body"),document.all&&!window.XMLHttpRequest&&""!=o.$control.text()&&o.$control.css({width:o.$control.width()}),o.togglecontrol(),t('a[href="'+o.anchorkeyword+'"]').click(function(){return o.scrollup(),!1}),t(window).bind("scroll resize",function(){o.togglecontrol()})})}};scrolltotop.init();


// Date Time Picker

$(".datetime").datetimepicker({		
	format: "dd-M-yyyy - HH:ii P",
	autoclose: true,
	showMeridian: true,
	todayBtn: false
});