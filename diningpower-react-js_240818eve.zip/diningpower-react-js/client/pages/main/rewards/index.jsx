const React = require('react');
const ReactHelmet = require('react-helmet');

const Helmet = ReactHelmet.Helmet;

class RewardsPage extends React.Component {
    componentDidMount() {
        window.scrollTo(0, 0);
    }
    render() {

        return (
            <div>
                <Helmet>
                    <title>Rewards</title>
                </Helmet>
                <section className="reward">
                    <div className="container">
                        <div className="full_row text-center custom">
                            <div className="width-600">
                                <h2>Power Rewards</h2>
                                <p className="first">Earn points with every order - points never expire!</p>
                                <img src="/public/media/images/reward.png" alt="Power Rewards" className="mb20"/>
                                <ul className="reset">
                                    <li className="orange">
                                        <div className="price">
                                            <img src="/public/media/images/power_bucks.png" alt="Power Bucks" />
                                        </div>
                                        <h5>PowerBucks work just like cash. Power up with every bite!</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>$10</td>
                                                    <td>4,500 pts</td>
                                                    <td>4,250 pts</td>
                                                    <td>4,000 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$20</td>
                                                    <td>7,500 pts</td>
                                                    <td>7,200 pts</td>
                                                    <td>6,750 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$50</td>
                                                    <td>15,000 pts</td>
                                                    <td>14,250 pts</td>
                                                    <td>12,750 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$100</td>
                                                    <td>27,500 pts</td>
                                                    <td>26,000 pts</td>
                                                    <td>23,500 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>

                                    <li>
                                        <div className="price">
                                            <img src="/public/media/images/starbucks.png" alt="Star Bucks" />
                                        </div>
                                        <h5>Starbucks gift card. Get some joe yo.</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>$50</td>
                                                    <td>18,750 pts</td>
                                                    <td>17,500 pts</td>
                                                    <td>16,250 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$100</td>
                                                    <td>35,750 pts</td>
                                                    <td>32,500 pts</td>
                                                    <td>30,000 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>

                                    <li>
                                        <div className="price">
                                            <img src="/public/media/images/apple.png" alt="Apple" />
                                        </div>
                                        <h5>Apple gift card. Mac, iPhone fans, this one’s for you.</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>$10</td>
                                                    <td>18,750 pts</td>
                                                    <td>17,500 pts</td>
                                                    <td>16,250 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$100</td>
                                                    <td>35,000 pts</td>
                                                    <td>32,500 pts</td>
                                                    <td>30,000 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>

                                    <li>
                                        <div className="price">
                                            <img src="/public/media/images/amazon.png" alt="Power Bucks" />
                                        </div>
                                        <h5>Amazon gift card. Options galore, indulge yourself.</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>$50</td>
                                                    <td>18,750 pts</td>
                                                    <td>17,500 pts</td>
                                                    <td>16,250 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$100</td>
                                                    <td>35,000 pts</td>
                                                    <td>32,500 pts</td>
                                                    <td>30,000 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>

                                    <li className="orange">
                                        <div className="price">
                                            <img src="/public/media/images/t-shirt1.png" alt="Dining Power T-Shirt" />
                                        </div>
                                        <h5>Dining Power T-Shirt. Dining Power logo.</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Sizes (S, M, L, XL, XXL)</td>
                                                    <td>500 pts</td>
                                                    <td>475 pts</td>
                                                    <td>450 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>

                                    <li className="orange">
                                        <div className="price">
                                            <img src="/public/media/images/t-shirt2.png" alt="Dining Power T-Shirt" />
                                        </div>
                                        <h5>Dining Power T-Shirt. “I run on coffee and tacos.”</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Sizes (S, M, L, XL, XXL)</td>
                                                    <td>500 pts</td>
                                                    <td>475 pts</td>
                                                    <td>450 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>

                                    <li>
                                        <div className="price">
                                            <img src="/public/media/images/cash.png" alt="Cash" />
                                        </div>
                                        <h5>Points can also be redeemed for cash.</h5>
                                        <table className="table">
                                            <thead>
                                                <tr>
                                                    <th>&nbsp&nbsp</th>
                                                    <th>Classic</th>
                                                    <th>Power Plus (?)</th>
                                                    <th>Power Plus Elite (?)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>$100</td>
                                                    <td>37,500 pts</td>
                                                    <td>35,500 pts</td>
                                                    <td>32,500 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$250</td>
                                                    <td>87,500 pts</td>
                                                    <td>81,250 pts</td>
                                                    <td>76,250 pts</td>
                                                </tr>
                                                <tr>
                                                    <td>$500</td>
                                                    <td>172,500 pts</td>
                                                    <td>157,500 pts</td>
                                                    <td>147,500 pts</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>
                                    
                                </ul>
                                <p className="pts"><a role="button">Sign in </a> to view your Power Rewards.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            
        );
    }
}


module.exports = RewardsPage;
