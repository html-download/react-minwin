document.write('<scr'+'ipt type="text/javascript" src="js/bootstrap.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/jquery.sticky-kit.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/chosen.jquery.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/ResizeSensor.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/product_gallery.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/datepicker.min.js" ></scr'+'ipt>');
document.write('<scr'+'ipt type="text/javascript" src="js/i18n/datepicker.en.js" ></scr'+'ipt>');






