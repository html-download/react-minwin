<?php include ('inc/header.php'); ?>
<div class="site_page full_row">
  <!-- myaccount -->
  <section class="myaccount-page">
    <!-- container -->
    <div class="container mx-1150">
      <div class="full_row">
        <!-- fullrow -->
        <div class="side-bar-acc">
          <!-- header -->
          <div class="side-bar-header">
            <div class="round">KR</div>
            <h4>Khuzaimah Raghid</h4>
            <p>khuzaimahraghid@gmail.com</p>
            <p class="mb-0">+98765432101</p>
          </div>
          <!-- header -->
          <ul class="reset nav-side">
            <li><a href="/my-account"><i class="fi user"></i> My Account</a></li>
            <li><a href="/orders-history"><i class="fi clock2"></i> Orders History </a></li>
            <li><a href="/address-book"><i class="fi pin3"></i> Address Book </a></li>
            <li><a href="/favorites"><i class="fi heart"></i> Favorites </a></li>
            <li><a href="/wallet"><i class="fi wallet2"></i> Wallet </a></li>
            <li><a href="/smile-points"><i class="fi smile"></i> Smile Points  <span>(Bal. 50 Points)</span> </a></li>
            <li><a href="/ratings"><i class="fi star2"></i> Ratings & Reviews </a></li>
            <li><a href="/saved-cards"><i class="fi credit-card1"></i> Saved Cards </a></li>
            <li><a href="/notifications"><i class="fi notification"></i> Notifications </a></li>
            <li><a href="/"><i class="fi login2"></i> Sign Out </a></li>
          </ul>
        </div>
        <!-- sidebar -->
        <!-- rating page content -->
        <div class="acc_page_content">
          <div class="acc_title">
            <i class="fi star2"></i>
            <h2>Ratings & Reviews</h2>
            <p>Restaurant’s ratings and reviews</p>
          </div>
          <div class="white-30 ratings">


                <ul class="reviews full_row">
   
                        <li>
                            <div class="user_info">
                                <span class="img">KR<img src="assets/img/logo/1.jpg"></span>
                                <span class="name">Eat More</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                        <li>
                            <div class="user_info">
                                <span class="img">TK<img src="assets/img/logo/2.jpg"></span>
                                <span class="name">Pastamasta Taste food</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                        <li>
                            <div class="user_info">
                                <span class="img">JA<img src="assets/img/logo/3.jpg"></span>
                                <span class="name">Hot Pot Restaurants</span>
                                <span class="overall_star small star_4"></span>
                                <span class="date">Tue, 20 Mar 2019</span>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eget massa augue. Vivamus a posuere nibh, et congue dolor etiam quam leo, euismod quis nisi non, vulputate posuere lacus erat dui, tristique posuere nisi sit amet.</p>
                            <p class="images gallery">
                                <a href="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                    <span style="background-image:url(assets/img/items/Boneless-Ginger-Chicken.jpg)"></span>
                                    <img src="assets/img/items/Boneless-Ginger-Chicken.jpg">
                                </a>
                                <a href="assets/img/items/Executive-Chicken-Biryani.jpg">
                                    <span style="background-image:url(assets/img/items/Executive-Chicken-Biryani.jpg)"></span>
                                    <img src="assets/img/items/Executive-Chicken-Biryani.jpg">
                                </a>
                                <a href="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                    <span style="background-image:url(assets/img/items/Masala-Chicken-Tikka-Wrap.jpg)"></span>
                                    <img src="assets/img/items/Masala-Chicken-Tikka-Wrap.jpg">
                                </a>
                            </p>
                        </li>
                    </ul>



           
           </div>
        <!-- rating page content -->
      </div>
      <!-- fullrow -->
    </div>
    <!-- container -->
  </section>
  <!-- myaccount -->
</div>
<!--site_page-->
<?php include ('inc/footer.php'); ?>

<script type="text/javascript">
        //Image Popup
    $('.images.gallery').each(function() {
        $(this).magnificPopup({
            delegate: 'a',
            type: 'image',
            closeOnContentClick: false,
            closeBtnInside: false,
            mainClass: 'mfp-with-zoom mfp-img-mobile',
            image: {
                verticalFit: true
            },
            gallery: {
                enabled: true
            },
            zoom: {
                enabled: true,
                duration: 300,
                opener: function(element) {
                    return element.find('img');
                }
            }       
        });
    });
</script>