/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16RecipeType', {
    recipeTypeId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      field: 'recipe_type_id'
    },
    recipeName: {
      type: DataTypes.STRING(100),
      allowNull: false,
      field: 'recipe_name'
    }
  }, {
    tableName: 'ss16_recipe_type'
  });
};
