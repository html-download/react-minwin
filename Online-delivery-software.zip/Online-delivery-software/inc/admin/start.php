<?php
/**
 * Adds the custom admin panel to the admin area
 */

function designpixi_admin() {  
	include( DesignPixi_ADMIN . '/panel.php');  
}  

function DesignPixi_admin_init() {
	wp_enqueue_style( "admin_css", DesignPixi_ADMIN_CSS . "/admin.css", false, "1.0", "all"); // CSS
	wp_enqueue_script( array("jquery", "jquery-ui-core", "interface", "jquery-ui-sortable", "wp-lists", "jquery-ui-sortable") ); // jQuery UI Sortable
	
    /* Register our script. This is loaded only in the Theme admin panel */
 wp_register_script('admins_js', DesignPixi_ADMIN_JS . '/jquery.min.js', false, "11.0");
	wp_register_script('admin_js', DesignPixi_ADMIN_JS . '/admin.js', false, "1.0");
	
}

// Adds the designpixi Menu to the Wordpress admin area
function designpixi_admin_menu() {  
    $page = add_menu_page(DesignPixi_THEMENAME, 'Theme Options', 'administrator', DesignPixi_THEMESHORTNAME, "designpixi_admin");    
    add_action('admin_print_scripts-' . $page, 'designpixi_admin_scripts');
}  

function designpixi_admin_scripts() {
    wp_enqueue_script('admins_js');
    wp_enqueue_script('admin_js');
	 
}

add_action('admin_init', 'designpixi_admin_init');
add_action('admin_menu', 'designpixi_admin_menu');
?>