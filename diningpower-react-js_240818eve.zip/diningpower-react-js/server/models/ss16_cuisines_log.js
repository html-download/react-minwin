/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('ss16CuisinesLog', {
    logId: {
      type: DataTypes.BIGINT,
      allowNull: false,
      primaryKey: true,
      field: 'log_id'
    },
    cuisineId: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'cuisine_id'
    },
    cuisineName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'cuisine_name'
    },
    vendorId: {
      type: DataTypes.STRING(16),
      allowNull: false,
      field: 'vendor_id'
    },
    vendorName: {
      type: DataTypes.STRING(64),
      allowNull: false,
      field: 'vendor_name'
    },
    cuisineScenario: {
      type: DataTypes.ENUM('Created','Edited','Attached','Approved','Restored','Deleted'),
      allowNull: false,
      field: 'cuisine_scenario'
    },
    proposedStatus: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: '1',
      field: 'proposed_status'
    },
    scenarioDatetime: {
      type: DataTypes.DATE,
      allowNull: false,
      field: 'scenario_datetime'
    },
    doneBy: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      field: 'done_by'
    }
  }, {
    tableName: 'ss16_cuisines_log'
  });
};
