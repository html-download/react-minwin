'use strict';
const Actions = require('./actions');
const Constants = require('./constants');
const CreateTaskForm = require('../../tasks/search/create-new/index');
const CreateNoteForm = require('./notes/create-note-form.jsx');
const Modal = require('../../../../components/modal.jsx');
const Notes = require('./notes/index');
const PropTypes = require('prop-types');
const UploadFile = require('../../../../helpers/aixos-ajax');
const React = require('react');
const Store = require('./store');
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';


const propTypes = {
    error: PropTypes.string,
    hasError: PropTypes.object,
    help: PropTypes.object,
    history: PropTypes.object,
    loading: PropTypes.bool
};


class TaskForm extends React.Component {

    constructor(props) {

        super(props);
        this.toggle = this.toggle.bind(this);
        this.state = {
            activeTab: '1'
        };
        this.taskCallBack = this.taskCallBack.bind(this);
        this.taskOnCloseCallBack = this.taskOnCloseCallBack.bind(this);
        this.removeNote = this.removeNote.bind(this);
        this.removeDocu = this.removeDocu.bind(this);
    }

    toggle(tab) {

        if (this.state.activeTab !== tab) {
            this.setState({
                activeTab: tab
            });
        }
    }

    taskCallBack(event) {

        event.preventDefault();
        event.stopPropagation();
        Actions.getDealTask(this.props.deal_id);
    }

    taskOnCloseCallBack(event) {

        event.preventDefault();
        event.stopPropagation();
        Actions.hideTaskModal();
    }

    renderNotes() {
        
        return (this.props.notes && this.props.notes.length > 0) ? this.props.notes.map((record) => {
            return (<Notes key={record.deal_note_key} deleteFun={ this.removeNote } {...record}></Notes>);
        }) : [];
    }

    uploadDocument(refName) {

        if (this[refName] && this[refName].files[0]) {
            var formData = new FormData();
            formData.append("file", this[refName].files[0]);
            formData.append("deal_id", this.props.deal_id);
            UploadFile.upload('/deal-document', formData, Store, Constants.GET_DEAL_DOCU_DETAILS, Constants.GET_DEAL_DOCU_DETAILS_RESPONSE);
        }
    }

    renderDealDocuments() {

        return this.props.deal_docu.length > 0 ? this.props.deal_docu.map((value, index) => {
            return (
                <div className="col-sm-12">
                <div className="box">
                    <div className="icon"><i className="fa fa-file-pdf-o"></i></div>
                    <a href={value.deal_document_path} target="_blank" className="add-forms editable editable-click">{ value.deal_document_name }</a>
                    <p className="date">{value.created_at}</p>
                    <a href="javascript:" onClick={ (e) => this.removeDocu(value.deal_document_key) } className="remove"><i className="fa fa-trash"></i> Remove</a>
                </div>
              </div>
            );
        }) : null
    }

    removeNote(note_key) {        

        Actions.deleteNote(note_key,this.props.deal_id);
    }

    removeDocu(docu_key) {

        Actions.deleteDocu(docu_key,this.props.deal_id);
    }

    removeTask(task_key) {

        Actions.deleteTask(task_key,this.props.deal_id);
    }


    render() {        

        return (
            <div className={classnames({ 'cs-tab': true })}>
            <Nav tabs >
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '1' })}
                  onClick={() => { this.toggle('1'); }}
                >
                  All
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '2' })}
                  onClick={() => { this.toggle('2'); }}
                >
                  Notes
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '3' })}
                  onClick={() => { this.toggle('3'); }}
                >
                  Tasks
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  className={classnames({ active: this.state.activeTab === '4' })}
                  onClick={() => { this.toggle('4'); }}
                >
                  Documents
                </NavLink>
              </NavItem>
            </Nav>
            <TabContent activeTab={this.state.activeTab} className={classnames({ 'tab-content': true})}>
                <TabPane tabId="1">
                    <div className="btn-group-2">
                        <button className="btn btn-secondary" onClick={ (e) => { Actions.addNoteModal() } }>Add Note</button>
                        <button className="btn btn-secondary" onClick={ (e) => { Actions.addTaskModal() } }>Add Task</button>
                        <button className="btn btn-secondary" onClick={() => { this.toggle('4'); }}>Add Documents</button>
                    </div>

                    <div className="row">
                    <div className="col-sm-6 notelist">
                        <div className="upload-listing mx400 mt-30 cus doc">
                            { (this.props.notes.length > 0) ? <h2>Note List</h2> : <p className="empty">Notes are empty...</p> }
                            { this.renderNotes() }
                            </div>
                     </div>

                        <div className="col-sm-6 notelist">
                             <div className="upload-listing mx400 mt-30 cus doc">   
                                { (this.props.deal_docu.length > 0) ? <h2>Document List</h2> : <p className="empty">No documents found for this deal....</p> }
                               <div className="row">{ this.renderDealDocuments()}</div>
                            </div>
                       </div>
                   </div>


                    <div className="table-responsive mt-10">
                        { 
                            (this.props.deal_task.length > 0) ?                            
                                <h2>Tasks list</h2>
                            : ''
                        }
                        <table className="table white_table">
                            <thead>
                                <tr>
                                    <th>Task Title</th>
                                    <th>Insurence Value</th>
                                    <th>Assigned Username</th>
                                    <th>Task date</th>
                                    <th>Task time</th>
                                    <th>Duration</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>                                
                                {
                                    this.props.deal_task.map((record) => {                                                      
                                        return (
                                            <tr key={record.task_key}>
                                                <td>{record.task_title}</td>
                                                <td>{record.vehicle_insured_value}</td>
                                                <td>{record.assigned_user_name}</td>
                                                <td> {record.task_date}</td>
                                                <td> {record.task_time}</td>
                                                <td> {record.duration}</td>
                                                <td><a href="javascript:" onClick={ (e) => this.removeTask(record.task_key) } className="remove"><i className="fa fa-trash"></i> Remove</a></td>
                                            </tr>
                                        );                                        
                                    })
                                }
                                
                                { 
                                    (this.props.deal_task.length === 0) ?                                     
                                    <tr>
                                        <td colSpan="7" style={ {textAlign:"center"} }>No tasks found for this deal...</td>
                                    </tr>                                    
                                    : ''
                                }
                                    
                            </tbody>
                        </table>
                    </div>
                </TabPane>
                <TabPane tabId="2">
                    <div className="btn-group-2">
                        <button className="btn btn-secondary" onClick={ (e) => { Actions.addNoteModal() } }>Add Note</button>
                    </div>
                    <div className="upload-listing mt-10 cus overflow-600">       
                        { (this.props.notes.length > 0) ? <h2>Note List</h2> : <p className="empty">Notes are empty...</p> }             
                        { this.renderNotes() }
                    </div>
                </TabPane>
                <TabPane tabId="3">
                    <div className="btn-group-2">
                        <button className="btn btn-secondary" onClick={ (e) => { Actions.addTaskModal() } }>Add Task</button>
                    </div>
                    <div className="table-responsive mt-10">
                        { 
                            (this.props.deal_task.length > 0) ?                            
                                <h2 className="heading-20">Tasks list</h2>
                            : ''
                        }
                        <table className="table white_table">
                            <thead>
                                <tr>
                                    <th>Task Title</th>
                                    <th>Insurence Value</th>
                                    <th>Assigned Username</th>
                                    <th>Task date</th>
                                    <th>Task time</th>
                                    <th>Duration</th>
                                </tr>
                            </thead>
                            <tbody>                                
                                {
                                    this.props.deal_task.map((record) => {                                                      
                                        return (
                                            <tr key={record.task_key}>
                                                <td>{record.task_title}</td>
                                                <td>{record.vehicle_insured_value}</td>
                                                <td>{record.assigned_user_name}</td>
                                                <td> {record.task_date}</td>
                                                <td> {record.task_time}</td>
                                                <td> {record.duration}</td>
                                            </tr>
                                        );                                        
                                    })
                                }
                                
                                { 
                                    (this.props.deal_task.length === 0) ?                                     
                                    <tr>
                                        <td colSpan="6">No tasks found for this deal.</td>
                                    </tr>                                    
                                    : ''
                                }
                                    
                            </tbody>
                        </table>
                    </div>
                </TabPane>
                <TabPane tabId="4">
                    <input className="hidden" type="file" ref={(c) => (this.deal_document = c)} onChange={ (e) => this.uploadDocument('deal_document') } id="file"/>
                    <label className="drag-files" htmlFor="file">
                        Drag Files here or click to upload
                    </label>
                    <div className="upload-listing mt-10 enq-doc cus overflow-600">                    
                        { (this.props.deal_docu.length > 0) ? <h2>Document List</h2> : <span className="empty">Documents are empty...</span> }
                      
                        <div className="row">
                        { this.renderDealDocuments()}
                        </div>
                      </div>
                   
                </TabPane>
            </TabContent>
            <CreateTaskForm
                history={this.props.history}
                id={this.props.id}
                hasError ={ false }
                help ={ false }
                deal_id ={ this.props.deal_id }
                show={ this.props.task_modal_show }
                onCreate={this.taskCallBack}
                onModelClose={this.taskOnCloseCallBack}
                {...this.props} />
            <CreateNoteForm
                history={this.props.history}
                deal_id={this.props.deal_id}
                {...this.props} />
          </div>
        );
    }
}

TaskForm.propTypes = propTypes;


module.exports = TaskForm;