'use strict';
const PropTypes = require('prop-types');
const React = require('react');
const ReactRouter = require('react-router-dom');
const Action = require('./actions');

const Link = ReactRouter.Link;
const propTypes = {
    data: PropTypes.array
};


class Results extends React.Component {
    

    constructor(props) {
        super(props);

        this.handleUpdateStatusEvent = this.handleUpdateStatusEvent.bind(this);
        this.handleEditTask = this.handleEditTask.bind(this);
    }

    handleEditTask(task) {
        
        Action.showCreateNew(task);
    }

    getTableData(id, value, task) {
        
        return (
            <td>{value}</td>
        );
    }
    
    

    getStatusData(id, label, status) {

        return (
            <td>
                { this.checkStatusType(label, status) }
            </td>
        );
    }

    getTaskView(id, value) {

        return (
            <td>
                <Link to={`/admin/deals/${id}`}>{value}</Link>
            </td>
        );
    }

    getCustomerView(id, value) {

        return (
            <td>
                <Link to={`/admin/customers/${id}`} >{value}</Link>
            </td>
        );
    }

    handleUpdateStatusEvent(task_key) {
        
        const data = {
            task_status: event.target.value,
            task_key: task_key
        };
        Action.updatedStatus(data, this.props.query);
    }


    taskStatusUpdate(id, label, status)
    {
        return (<td>
                <select name="taks_status" className="form-control" defaultValue={status} onChange={ (e) => this.handleUpdateStatusEvent(id) }>
                    <option value="1">Pending</option>
                    <option value="3">Started</option>
                    <option value="2">Completed</option>
                </select>
            </td>
        );
    }

    checkStatusType(label,status) {

        let statusLable = '';
        switch (status) {
            case 1:
                statusLable = <label className="status green">{label}</label>;
                break;
            case 2:
                statusLable = <label className="status pink">{label}</label>;
                break;
            case 3:
                statusLable = <label className="status yellow">{label}</label>;
                break;
            default:
                statusLable = '';
                break;
        }
        return statusLable;
    }

    render() {

        const rows = (this.props.data && this.props.data.length > 0) ? this.props.data.map((record) => {
            return (
                <tr className="c-pointer" key={record.task_key}>
                    { this.getStatusData(record.task_key, record.task_status_text,record.task_status) }
                    { this.getTableData(record.task_key, record.task_title, record) }
                    { this.getTaskView(record.task_type_id, record.deal) }
                    { this.getTableData(record.task_key, record.assigned_user_name, record) }
                    { /* this.getTableData(record.task_key, record.task_date_time, record) */ }
                    { this.getTableData(record.task_key, record.created_at, record) }
                    { this.getTableData(record.task_key, record.modified_at, record) }
                    { this.taskStatusUpdate(record.task_key, record.task_status_text,record.task_status) }
                </tr>
            );
        }) : (
            <tr key='0'>
                <td colSpan={10} className="text-center">
                    No record(s) found!
                </td>
            </tr>
        );

        return (
            <div className="table-responsive">
                <table className="table table-hover white_table">
                    <thead>
                        <tr>                            
                            <th>Status</th>
                            <th>Title</th>
                            <th>Enquiry</th>
                            <th>Assigned To</th>
                            {/* <th>Due In</th> */}
                            <th>Created ON</th>
                            <th>Updated ON</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    {
                        this.props.list_loading ? (
                            <tbody>
                                <tr key='0'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='1'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='2'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                                <tr key='3'>
                                    <td colSpan={10} className="text-center loader-tab-content">
                                        loading...
                                    </td>
                                </tr>
                            </tbody>
                        ) : (
                            <tbody>
                                {rows}
                            </tbody>
                        )
                    }
                </table>
            </div>
        );
    }
}

Results.propTypes = propTypes;


module.exports = Results;
