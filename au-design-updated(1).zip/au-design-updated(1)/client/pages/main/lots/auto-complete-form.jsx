import React from 'react';
import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng,
} from 'react-places-autocomplete';
const ObjectAssign = require('object-assign');
const UserIdentity = require('../../../helpers/user-identity');

class LocationSearchInput extends React.Component {
    constructor(props) {
        super(props);
        this.state = { address: '' };
        this.currentAddressGet = this.currentAddressGet.bind(this);
    }
    componentDidMount () {
        if (UserIdentity._checkUserAddress() !== null) {
            this.setState({ address : UserIdentity._checkUserAddress().address });
        }
        if (navigator.geolocation) {
          // Can use geolocation, proceed with getting the location
          navigator.geolocation.getCurrentPosition(this.savePosition, this.positionError);
        } else {
          // Can't use geolocation, we should tell the user
          $('div.main').prepend('<p class="error">Your browser doesn\'t support geolocation. Try upgrading to a newer browser like <a href="https://chrome.google.com/" target="_blank">Google Chrome</a></p>');
        }
        
    }
    componentWillReceiveProps(nextProps, nextState) {
        if (UserIdentity._checkUserAddress() !== null) {
            this.setState({ address : UserIdentity._checkUserAddress().address });
        } else {
            this.setState({ address : '' });
        }
    }
    currentAddressGet () {
        if (navigator.geolocation) {
          // Can use geolocation, proceed with getting the location
          navigator.geolocation.getCurrentPosition(this.savePosition, this.positionError);
          if (UserIdentity._checkIsLot() !== null) {
              $("#hybrid").click()
              $("#hybrid").click()
          }
        } else {
          // Can't use geolocation, we should tell the user
          $('div.main .err').html('<p class="error">Your browser doesn\'t support geolocation. Try upgrading to a newer browser like <a href="https://chrome.google.com/" target="_blank">Google Chrome</a></p>');
        }
    }
    handleChange (address) {

        this.setState({ address : address });
    }

    handleSelect (address) {
        this.setState({ address : address });
        geocodeByAddress(address)
          .then(results => getLatLng(results[0]))
          .then(latLng => this.saveAddress(ObjectAssign({}, latLng, this.state)))
          .catch(error => console.error('Error', error));
    }

    handleCurrentSelect (address) {
        this.setState({ address : address });
        geocodeByAddress(address)
          .then(results => getLatLng(results[0]))
          .then(latLng => this.saveAddress(ObjectAssign({}, latLng, this.state)))
          .catch(error => console.error('Error', error));
    }

    saveAddress (data) {
        localStorage.setItem(`address_${UserIdentity._checkUserToken()}`, JSON.stringify(data));
        if (UserIdentity._checkIsLot() !== null) {
            $("#hybrid").click()
            $("#hybrid").click()
        }
    }
    
    savePosition(position) {
      let latLng = {
          lat : position.coords.latitude,
          lng : position.coords.longitude
      };
      localStorage.setItem(`current_address_${UserIdentity._checkUserToken()}`, JSON.stringify(latLng));
    }
    positionError() {
      $('div.main .err').html('<p class="error"><strong>Sorry!</strong> There was an error getting your location.</p>');
    }
    render() {
        return (
            <div className="">
                  <PlacesAutocomplete
                    value={this.state.address}
                    onChange={this.handleChange.bind(this)}
                    onSelect={this.handleSelect.bind(this)}
                  >
                    {({ getInputProps, suggestions, getSuggestionItemProps, loading }) => (
                      <div>
                        <input
                          {...getInputProps({
                            placeholder: 'Enter your destination to find your closest lot..',
                            className: 'form-control',
                            role : "combobox",
                            'aria-autocomplete' : "list",
                            'aria-expanded' :"false" 
                          })}
                        />
                       
                        <div className="autocomplete-dropdown-container">
                          {loading && <div>Loading...</div>}
                          {suggestions.map(suggestion => {
                            const className = suggestion.active
                              ? 'suggestion-item--active'
                              : 'suggestion-item';
                            // inline style for demonstration purpose
                            const style = suggestion.active
                              ? { backgroundColor: '#d9540d', cursor: 'pointer' ,padding: '10px 6px', color: '#fff', borderBottom: '1px solid rgba(255, 255, 255, 0.1)'}
                              : { backgroundColor: '#003263', cursor: 'pointer',padding: '10px 6px', color: '#fff',  borderBottom: '1px solid rgba(255, 255, 255, 0.1)' };
                            return (
                              <div
                                {...getSuggestionItemProps(suggestion, {
                                  className,
                                  style,
                                })}
                              >
                                <span>{suggestion.description}</span>
                              </div>
                            );
                          })}
                        </div>
                         <a onClick={this.currentAddressGet} data-dismiss="modal" style={{ 'display' : 'none'}}> <img src={`/public/media/images/icons/current_loc.png`} alt="Current Location" /> <span>Get current location</span></a>
                         <div className="main">
                         </div>
                      </div>
                    )}
                  </PlacesAutocomplete>
            </div>
        );
    }
}

module.exports = LocationSearchInput;
