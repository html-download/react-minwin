'use strict';
const Actions = require('./actions');
const CommonHelper = require('../../../../../../helpers/common-functions');
const React = require('react');
const Store = require('./store');
const ViewPolicy = require('../../../../policies/search/view-form');


class HouseKeeping extends React.Component {   

    constructor(props) {

        super(props);
        this.state = Store.getState();

        this.handleSubmit=  this.handleSubmit.bind(this);
    }

    componentDidMount() {

        this.unsubscribeStore = Store.subscribe(this.onStoreChange.bind(this));
    }

    componentDidUpdate(prevProps, prevState) {

        if (prevProps.order_id !== this.props.order_id && this.props.order_id !== '') {
            Actions.getDealQuote(this.props.order_id);
        }
    }

    componentWillReceiveProps(nextProps) {     

        nextProps.deal_data.deal_quote_key ? Actions.getDealQuote(nextProps.deal_data.deal_quote_key) : undefined;
    }
    componentWillUnmount() {

        this.unsubscribeStore();
    }

    onStoreChange() {        

        this.setState(Store.getState());
    }
        
    toggleQuote() {
        
        Actions.toggleQuote();
    }

    handleSubmit(event) {

        let value = this.state.quote_data;
        const data = {
            deal_id: this.props.id,
            deal_quote_id: value.deal_quote_key,
            quote_verification:this.state.quote_verification
        };
        /* !CommonHelper.isEmpty(this.state.quote_data) ? Actions.updateQuoteDetails(value.deal_quote_key, data, this.props.toggle, this.props.updateOrderId) : null; */
        !CommonHelper.isEmpty(this.state.quote_data) ? Actions.completeDeal(data, this.props.toggle, this.props.updateOrderId) : null;
    }

    verfication(e, index , quote_verification_key){
        
        Actions.updateVerificationState(e.target.checked,index);
    }


    openPolicyModal() {

        Actions.openPolicyModal();
    }

    render() {

        const value = this.state.quote_data;

        return (
            <div>
                <div className="wi-content mt-30 full_row">
                    <div className="text-right mb-2"> <a className="link-text collapse-txt" data-toggle="collapse" href="#genrate"> Collapse </a> </div>
                    <div className="genrate-new-quote collapse show" id="genrate">
                        { CommonHelper.isEmpty(this.state.quote_data) ? (
                                <div className="under-construction">
                                    <h3>Sorry! Please select order for House Keeping</h3>
                                    <p>Thank you for your patience.</p>
                                </div>
                            ): (
                            <div className="first-box">
                                <h4 className="f20">Policy Summary {/* <a href="" className="f16">Edit Policy</a> */}</h4>
                                <p>Lt's Start by creating a new quote for the customer</p>

                                <div className="product-box">
                                    <ul className="product-listing reset">
                                        <li>
                                            <div className="box">
                                                <div className="img"><img src={value.insurence_product_image}/></div>
                                                <p>Policy Start Date: <b>{value['policy_start_date']}</b> </p>
                                                <p>Policy Expiry Date: <b>{value['policy_expire_date']}</b> </p>
                                                <p>Policy Number: <b>{value['policy_number']}</b> </p>
                                                <p>Quotation Number: {value['quotation_number']}</p>
                                                <div className="right-cd text-cenetr">
                                                    <button onClick={ (e) => this.openPolicyModal() } className="btn btn-outline-success no-shadow mt-3"> <i className="fa fa-external-link"></i> View Policy</button>
                                                </div>
                                            </div>
                                            <div className="box-fields">
                                                <h4 className="f20 mt-2 mb-4">Verification Tasks</h4>
                                                <ul className="ul_check reset">
                                                { 
                                                    (this.state.quote_verification.length > 0) ? this.state.quote_verification.map((item, index) => {
                                                        return(
                                                            <li>
                                                                <input type="checkbox" onChange={ (e) => this.verfication(e,index,item.quote_verification_key) } name={item.quote_verification_key} id={ `vlist${item.quote_verification_key}` } className="checkbox" defaultChecked={ (parseInt(item.is_verified) === 1) ? true : false }/>
                                                                <label className="checkbox" htmlFor={ `vlist${item.quote_verification_key}` }> { item.quote_verification_name } </label>
                                                            </li>
                                                        ) 
                                                    }) : ''
                                                }
                                                </ul>
                                                <div className="text-right mt-3 mb-3">
                                                    <button data-toggle="modal" data-target="#send-quote" disabled={ this.state.loading_mark_as_won ? 'disabled' : ''} className="btn btn-success ml-1 loader no-shadow" onClick={() => {this.handleSubmit()}}>Closed Success</button>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                <ViewPolicy                    
                    Actions = {Actions}
                    is_view_policy={this.state.is_view_policy}
                    {...this.state.policy_details}
                />
            </div>
        );
    }
}
module.exports = HouseKeeping;
