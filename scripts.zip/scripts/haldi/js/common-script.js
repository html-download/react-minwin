$(document).ready(function () {
    exeOnLoad.apply(arguments);

    // Newsletter
    $(".newsletter #submit").click(function () {
        $(".newsletter .error").show();
    });

    initScrollbar();

    jQuery(function() {
        jQuery('#starbox-quality-rating').each(function() {
            var starbox = jQuery(this);
            starbox.starbox({
                average: starbox.attr('data-start-value'),
                changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
                ghosting: starbox.hasClass('ghosting'),
                autoUpdateAverage: starbox.hasClass('autoupdate'),
                buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
                stars: starbox.attr('data-star-count') || 5
            }).bind('starbox-value-changed', function(event, value) {
                if(starbox.hasClass('random')) {
                    var val = Math.random();
                    starbox.next().text('Random: '+val);
                    return val;
                } else {
                    $('input[name="quality_rating"]').val(value);
                    
                }
            });
        });

    jQuery('#starbox-service-rating').each(function() {
            var starbox = jQuery(this);
            starbox.starbox({
                average: starbox.attr('data-start-value'),
                changeable: starbox.hasClass('unchangeable') ? false : starbox.hasClass('clickonce') ? 'once' : true,
                ghosting: starbox.hasClass('ghosting'),
                autoUpdateAverage: starbox.hasClass('autoupdate'),
                buttons: starbox.hasClass('smooth') ? false : starbox.attr('data-button-count') || 5,
                stars: starbox.attr('data-star-count') || 5
            }).bind('starbox-value-changed', function(event, value) {
                if(starbox.hasClass('random')) {
                    var val = Math.random();
                    starbox.next().text('Random: '+val);
                    return val;
                } else {
                    $('input[name="service_rating"]').val(value);
                    
                }
            });
        });
    });

});

/**
 *
 * @param count
 */
function updateCartCount(count) {
    var cartEle = $('.site_header a.cart');

    if (cartEle.find('span').get(0) === undefined) {
        cartEle.append('<span></span>');
    }

    if (parseInt(count) === 0) {
        cartEle.find('span').remove();
        return false;
    }
    cartEle.find('span').html(count);
}

/**
 *
 */
function initSpinner() {
    var spinnerEle, qtyInputEle, qty, isChanged;
    $('.qty-spinner .spinner-direction').unbind('click').click(function () {
        spinnerEle = $(this).closest('.qty-spinner');
        qtyInputEle = spinnerEle.find('[type="number"]');

        qty = parseInt(qtyInputEle.val());
        isChanged = false;

        if ($(this).attr('data-direction') === '+') {
            qty++;
            isChanged = true;
        } else {
            if (qty > 1) {
                qty--;
                isChanged = true;
            }
        }
        qtyInputEle.val(qty);

        if (isChanged) {
            spinnerEle
                .data('spinner', {value: qty})
                .trigger($.Event('spinner.change'));
        }
    });
}

/**
 *
 */
function initScrollbar() {
    $('.scrollbar-inner').scrollbar();
}